﻿[CmdletBinding()]
param(
    # The repository root. Defaults to the repository this tools folder was installed into.
    [string]$Repository,
    # Downloaded PBI package(s): a ZIP, a folder, or individual files (REFINED-PBI.md, attachments).
    # Remaining arguments are sources too, so several files can be dropped onto Add-PbiInput.cmd at once.
    [Parameter(Mandatory = $true, Position = 0, ValueFromRemainingArguments = $true)][string[]]$Source,
    # Optional when the refined PBI header or the file name carries the ID.
    [string]$PbiId,
    # Replace input files whose content changed (the previous version is kept under .previous/<timestamp>/).
    [switch]$UpdateChanged,
    [switch]$Json
)
# Akzo SDD Builder v2.5.2 - copies a downloaded PBI package into docs/sdd/pbi-input/<PBI-ID>/.
# - Creates the folder automatically; reads the sources only (the ZIP or folder is never changed).
# - Never overwrites an existing input file (unless -UpdateChanged); identical files are skipped.
# - Skips Markdown that declares another PBI (no cross-PBI contamination).
# - Keeps the folder out of Visual Studio / VS Code Git Changes through .git/info/exclude (local to this clone).
#   A folder the team already tracks in Git is never hidden.
# Exit codes: 0 imported or nothing new, 4 PBI ID required, 6 conflict or PBI mismatch.
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
if (-not $Repository) { $Repository = Split-Path -Parent $PSScriptRoot }
$repo = Resolve-SDDFullPath $Repository
if (-not (Test-Path -LiteralPath $repo -PathType Container)) { throw "Repository not found: $Repository" }

$r = Import-SDDPbiInput -Repository $repo -Source $Source -PbiId $PbiId -UpdateChanged:$UpdateChanged
$code = switch ($r.status) { 'PbiIdRequired' { 4 } 'PbiMismatch' { 6 } 'InputConflict' { 6 } default { 0 } }
if ($Json) { $r | ConvertTo-Json -Depth 6 | Write-Output; exit $code }

$color = if ($code -eq 0) { 'Green' } else { 'Red' }
Write-Host ("PBI input: {0}  (PBI {1})" -f $r.status, $r.pbiId) -ForegroundColor $color
if ($r.inputFolder) { Write-Host ("  folder    {0}" -f $r.inputFolder) }
foreach ($f in @($r.files)) {
    if (-not $f) { continue }
    $c = switch ($f.status) { 'Copied' { 'Green' } 'Updated' { 'Green' } 'Conflict' { 'Red' } 'SkippedOtherPbi' { 'Yellow' } default { 'DarkGray' } }
    Write-Host ("  {0,-16} {1}{2}" -f $f.status, $f.packagePath, $(if ($f.detail) { "  - $($f.detail)" } else { '' })) -ForegroundColor $c
}
foreach ($w in @($r.warnings)) { if ($w) { Write-Host "  WARNING  $w" -ForegroundColor Yellow } }
if ($r.git) {
    if (-not $r.git.gitAvailable) { Write-Host '  git       not a Git repository, or Git is not installed (nothing to hide)' -ForegroundColor DarkGray }
    elseif ($r.git.visibleInGitChanges -eq 0) { Write-Host ("  git       local-only ({0}); nothing appears in Git Changes" -f $r.git.exclusion) -ForegroundColor Cyan }
    else { Write-Host ("  git       {0} file(s) visible in Git Changes ({1})" -f $r.git.visibleInGitChanges, $r.git.exclusion) -ForegroundColor Yellow }
}
if ($r.message) { Write-Host "  $($r.message)" -ForegroundColor $(if ($code -eq 0) { 'Gray' } else { 'Yellow' }) }
if ($code -eq 0 -and $r.pbiId) { Write-Host ("NEXT: in Copilot Chat select 'Akzo SDD Developer' and say: Start Development {0} <Feature Name>" -f $r.pbiId) -ForegroundColor Cyan }
exit $code
