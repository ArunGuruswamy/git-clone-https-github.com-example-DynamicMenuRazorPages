﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Repository,
    [Parameter(Mandatory = $true)][string]$Feature,
    [string]$ChangeFolder,
    [switch]$Strict
)
# Akzo SDD Builder v2.5.2 - backward-compatible wrapper (v2.2-v2.3 command line).
# The rules live in Assert-SDDArtifacts.ps1 / SDD.Common.psm1 so the two tools can no longer diverge.
#   -Strict  -> AnalysisComplete gate, plus ImplementationApproved when an approval exists.
#   default  -> Initialized gate (files present, PBI ID declared).
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$repo = Resolve-SDDFullPath $Repository
$assert = Join-Path $PSScriptRoot 'Assert-SDDArtifacts.ps1'
$failed = $false

if ($ChangeFolder) {
    $cf = if ([IO.Path]::IsPathRooted($ChangeFolder)) { $ChangeFolder } else { Join-Path $repo $ChangeFolder }
    if (-not (Test-Path -LiteralPath $cf -PathType Container)) { Write-Host "FAIL: Working change folder missing: $ChangeFolder" -ForegroundColor Red; $failed = $true }
    else {
        foreach ($name in @('00-intake.md', '08-analysis.md', 'regression-impact.md', 'contract-matrix.md', 'token-usage.md', 'pr-review-audit.md')) {
            if (-not (Test-Path -LiteralPath (Join-Path $cf $name) -PathType Leaf)) { Write-Host "FAIL: Missing working artifact: $name" -ForegroundColor Red; $failed = $true }
        }
        if ($Strict) {
            foreach ($name in @('01-feature-inventory.md', '02-clarifications.md', '06-test-plan.md', '07-tasks.md', '08-analysis.md', 'regression-impact.md', 'contract-matrix.md')) {
                $p = Join-Path $cf $name
                if ((Test-Path -LiteralPath $p -PathType Leaf) -and ((Read-SDDText $p) -match '(?im)^\s*PENDING\b')) { Write-Host "FAIL: $name still contains PENDING" -ForegroundColor Red; $failed = $true }
            }
        }
    }
}
$stage = if ($Strict) { 'AnalysisComplete' } else { 'Initialized' }
& $assert -Repository $repo -Feature $Feature -Stage $stage -NoStateUpdate
if ($LASTEXITCODE -ne 0) { $failed = $true }
if ($Strict -and -not $failed) {
    $stateFile = @(Find-SDDStateFile -Repository $repo -Feature $Feature)
    if ($stateFile.Count -eq 1 -and (Test-Path -LiteralPath (Join-Path (Split-Path -Parent $stateFile[0]) 'approval.json'))) {
        & $assert -Repository $repo -Feature $Feature -Stage ImplementationApproved -NoStateUpdate
        if ($LASTEXITCODE -ne 0) { $failed = $true }
    }
}
if ($failed) { exit 1 }
Write-Host 'SDD validation passed. Build and test evidence is checked separately (Stage ImplementationVerified).' -ForegroundColor Green
exit 0
