﻿[CmdletBinding()]
param(
    [string]$Repository = (Get-Location).Path,
    [Parameter(Mandatory = $true)][string]$PbiId,
    # Write pbi-inventory.json/.md and extracted text into this folder (normally <work folder>/pbi-analysis).
    [string]$OutFolder,
    [switch]$Json
)
# Akzo SDD Builder v2.5.2 - read-only inventory of ONE PBI's input package (refined PBI + attachments).
# Start-SDD.ps1 runs this automatically; use it to re-check after adding an attachment.
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$repo = Resolve-SDDFullPath $Repository
$found = Find-SDDPbiSource -Repository $repo -PbiId $PbiId
if (-not $found.Selected) { Write-Host "PBI $PbiId : $($found.Status). $($found.Reason)" -ForegroundColor Red; exit 4 }
$params = @{ Repository = $repo; PbiId = $PbiId; Selected = $found.Selected }
if ($OutFolder) { $params['WorkFolder'] = (Resolve-SDDFullPath $OutFolder); $params['Write'] = $true }
$inv = New-SDDPbiInventory @params
if ($Json) { $inv | ConvertTo-Json -Depth 6 | Write-Output; exit 0 }
Write-Host (ConvertTo-SDDInventoryMarkdown $inv)
exit 0
