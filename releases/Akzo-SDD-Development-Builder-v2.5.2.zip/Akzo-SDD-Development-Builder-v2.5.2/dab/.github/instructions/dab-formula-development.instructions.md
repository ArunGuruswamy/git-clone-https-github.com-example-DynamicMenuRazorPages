---
applyTo: "**"
---

# DAB Formula Development Instructions

Caveman rules. Short. Obey.

Full detail lives in `docs/architecture/`. Read only what you need.

## Before coding

- Read `docs/architecture/ARCHITECTURE-SUMMARY.md`.
- Read `docs/architecture/PBI-DEVELOPMENT-PLAYBOOK.md`.
- Read `docs/architecture/ARCHITECTURE-DECISION-MAP.md`.
- Read the flow doc for the PBI domain.
- `git fetch origin`. Inspect latest `origin/develop`.
- Search existing implementation before creating new code.
- Old feature branches are not current behavior.

## PBI analysis

1. Extract requirements.
2. Separate: CONFIRMED / ASSUMPTION / OPEN QUESTION.
3. Find current implementation.
4. Trace end-to-end flow.
5. Identify shared code.
6. Identify regression risk.
7. Produce plan before coding.
8. Implement minimum change.
9. Test affected and neighboring flows.

## Architecture

Layering, actual:

```
Function (Azure Functions) -> Command/Query -> IDispatcher -> Handler
  -> Validator / Helper -> I*QueryService | I*CommandService -> GraphQL client
```

- Function -> Application -> Data -> Common. Never upward.
- Do not bypass a layer without existing precedent.
- No data access in Function classes.
- No GraphQL client calls in Application. Use the service interface.

## CQRS

- Commands change state. Queries read.
- `ICommand<T>` / `IQuery<T>` markers, `ICommandHandler<,>` / `IQueryHandler<,>`.
- `Dispatcher` resolves handlers by reflection. No MediatR. No pipeline.
- Validation runs **inside the handler**, not in a pipeline.
- Handlers and validators are auto-registered in `Program.cs` by assembly scan.
- New **data services** and **helper interfaces** must be registered manually in `Program.cs`.
- Keep functions thin. Throw `AppValidationException`; middleware maps it.
- Two validation styles exist (throw vs collect). Do not unify them.

## GraphQL

- Search existing `.graphql` operations first. 57 exist.
- Keep the domain prefix: `Formula_`, `MarketColor_`, `Product_`, `ComplexUpdate_`.
- Never invent schema fields. Check the `schema.graphql` snapshot.
- Generated `*GraphQL.Client.cs` is **committed**. Never hand-edit it.
- Changing a variable changes `ExecuteAsync` signatures. Fix production code **and** test mocks.
- Build after any GraphQL change. Review the generated diff.

## Product rules

Never assume selected `ProductId` == `PaintSystem.ProductId`.

Always inspect: `ProductId`, `ParentProductId`, `OriginalProductId`, `IsPrimaryDerivedProduct`, `ProductNr`.

- `IsPrimaryDerivedProduct` is nullable. `null` is its own case.
- IR validation substitutes the **parent** product when primary-derived.
- Versioning uses the **union** of product and parent.
- Create-side and update-side conversion rules differ. Do not merge them.
- Four different product rules exist. Do not extract a shared helper.

## Paint System existence

Before changing existence validation, inspect the actual `.graphql` filters:
`MarketColorInstanceId`, `ProductId`, `LocalGlobalId`, `RecordIsActive`, `RecordIsDeleted`,
`PaintSystemStatusId`, `GeoId`, `colorImitations.ColorId`.

- `LocalGlobalId` lives on ImitationRequest, not PaintSystem.
- `Formula_GetQualifyingImprovedFormulaPaintSystems` filters `RecordIsDeleted` only, not `RecordIsActive`.
- Local vs Global differ only by `GeoId.isNull`.
- Do not invent filters.

## Versioning

Never do version arithmetic in a handler.

Owners: `VersioningHelper`, `PaintSystemVersioningService`, `CreatePaintSystemVersionResolver`,
`CreatePaintSystemVersioningContextResolver`, `Versioning.DefaultVersion`.

- Rules are grouped per IR CDMS key: default `1.1` / minor+1 / major+1 / complaint `C`.
- Rules are NOT universal across request types.

## Status

Do not assume status ownership.

This service writes exactly two transitions:
- PaintSystem created -> `Incomplete`.
- PaintSystem created with an IR -> IR set to `InDevelopment`.

`Actual`, `Historic`, IR `Closed` are NOT implemented here. Do not duplicate external transitions.

## Imitation Requests

Creating an IR does NOT create a Paint System.

When changing shared validation, regression-check at minimum:
New Sample, Improved Formula, Technical, Adaption, Industrialization, Product Modification,
Master Candidate.

## Duplicate validation

Two distinct checks. Keep them distinct.

- Exact duplicate: `MarketColorInstanceId` + `ProductId` + `LocalGlobalId`.
- Cross-over: `ColorId` + `ProductId` + `LocalGlobalId` (different MCIs, same colour).

## Shared files — extra care

`ImitationRequestValidator.cs`, `CreateImitationRequestValidator.cs`, `CreatePaintSystemHandler.cs`,
`CreatePaintSystemVersionResolver.cs`, `VersioningHelper.cs`,
`ConversionEligibilityValidationHelper.cs`, `PaintSystemQueryService.cs`, `Program.cs`,
`Constants.cs`, `RoutingMiddleware.cs`, generated `*GraphQL.Client.cs`, `TestParams.cs`.

Check all callers and affected request types before changing them.

## CDMS routing

`RoutingMiddleware` can forward requests to the CDMS Function App when `FeatureFlags_Cdms` is on.
Your handler may be unreachable. Check the exclusion list.

## Branch safety

A PBI branch must not remove functionality present in develop.

Before PR:

```powershell
git diff origin/develop --stat
git diff origin/develop --diff-filter=D --name-only
```

Look for unexpected deletions, unrelated files, old code replacing newer code, generated client
churn, shared validation regressions.

## Testing

MSTest + NSubstitute. Mirror the production folder layout. Use `TestParams`.

For every change: happy path, negative validation, existing-behavior regression, derived product,
Local/Global, status, version, GraphQL errors — where relevant.

```powershell
dotnet build AN.ColorAppsAzure.BL.sln
dotnet test AN.ColorAppsAzure.BL.sln --settings coverlet.runsettings --collect:"XPlat Code Coverage"
```

All C# must pass SonarCloud. See `sonar-rules.instructions.md`.

## Never do this

- Do not guess schema fields, business rules, status transitions or version rules.
- Do not copy whole files from old branches.
- Do not replace newer develop files with old PBI files.
- Do not create duplicate helpers without searching first.
- Do not refactor unrelated code during a PBI.
- Do not silently change another request type.
- Do not implement before tracing the existing flow.
- Do not delete a failing test to go green.

## If uncertain

STOP. Report:

```
NOT CONFIRMED
Evidence found: ...
Missing: ...
Question: ...
```

## Architecture document index

`docs/architecture/`

| Document | Use when |
|---|---|
| `ARCHITECTURE-SUMMARY.md` | always first |
| `SYSTEM-ARCHITECTURE.md` | layers, DI, middleware, startup |
| `CQRS-FLOW.md` | new endpoint / command / query / handler |
| `IMITATION-REQUEST-FLOW.md` | IR rules and request types |
| `PAINT-SYSTEM-FLOW.md` | Paint System create / update / publish |
| `DATA-ACCESS-GRAPHQL.md` | GraphQL / DAB / CDMS / cache |
| `PRODUCT-DERIVATION-RULES.md` | product / parent / derived |
| `STATUS-AND-VERSIONING.md` | status or version rules |
| `TESTING-ARCHITECTURE.md` | tests |
| `ARCHITECTURE-DECISION-MAP.md` | "where does rule X live?" |
| `PBI-DEVELOPMENT-PLAYBOOK.md` | starting any PBI |
| `MERGE-SAFETY-CHECKLIST.md` | before PR / after rebase |
| `ANTI-HALLUCINATION-RULES.md` | always |
| `OPEN-QUESTIONS.md` | something is unprovable |

Open only what the PBI needs. Do not load every document.
