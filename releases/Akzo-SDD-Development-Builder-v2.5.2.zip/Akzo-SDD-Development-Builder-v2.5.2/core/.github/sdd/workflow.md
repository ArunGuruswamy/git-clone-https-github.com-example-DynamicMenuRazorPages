# Authoritative SDD workflow — v2.5.2

This is the sole phase, mode and execution authority for Full, Caveman Concise, reviewer handoffs, project skills and prompts. Technical skills supply domain guidance, never a competing lifecycle. Full and Concise differ only in response length; artifacts, business rules and quality gates are identical.

## Execution modes
FAST is the default after ImplementationApproved. Complete all approved tasks continuously with no per-file or per-task permission requests. Group related edits, run targeted checks at meaningful checkpoints, fix in-scope failures and continue automatically. Finish with consolidated regression.

STANDARD adds intermediate checks without additional approval requests. STEP performs one task and pauses only when explicitly requested by the developer. No agent, config or handoff may silently select STEP. Legacy STEP_MODE is ignored. An explicit session choice wins; retain it in progress.json. Mandatory pauses after approval: zero in FAST/STANDARD except an unresolved required business decision, material scope change, security permission or unrecoverable failure.

Never stage, commit, push, deploy, change branches or rewrite history automatically. Preserve unrelated user files and changes. Ordinary edits within approved scope are already authorized. Each cloud task is isolated; use the existing checkout and do not create a worktree unless explicitly requested.

## P0 — Capabilities, once per session or meaningful change
Probe authorized capabilities with a harmless workspace read, a temporary-file edit and a version command. Record **advertised, callable, authorized, executed, succeeded** separately. A tool name, printed command, project file or configured CI pipeline proves none of the later states. Reuse successful probes until the environment changes.

| Capability | Action / fallback |
|---|---|
| Workspace read/search | Search relevant paths first; if unavailable report the specific missing capability. |
| Workspace edit | Write artifacts directly and read them back. If unavailable continue analysis and report NEEDS EDIT TOOL; never claim a saved file. |
| Terminal | Execute authorized local commands. If unavailable continue read/edit work, and mark build/test/gates NOT EXECUTED with the reason. |
| Local build tools | Run `tools/Test-SDDCapabilities.ps1 -Repository . -Feature <Feature>`; inspect actual command success, SDK pins and project compatibility. |
| Test Explorer / diagnostics | Use callable IDE tools with project/test filters; preserve actual results and their provenance. Untested host integrations stay UNKNOWN. |
| CI / MCP | Check the specific authorized service only when needed; a pipeline file means configured, not executed. Never infer authentication or execution. |
| Images / PDF | Open with an available reader; otherwise report the attachment Unreadable with the reason. |

MCP access is not terminal access. Never request Azure MCP for a local .NET build. An Unrestricted tool profile only removes the agent's tool-name restriction; it grants no permission. Do not bypass execution policies or enterprise restrictions. Never ask the developer to run mkdir, save Markdown, copy chat text or execute ordinary commands when authorized tools can do it.

## P1 — Start, discover and pin
Accept `Start Development <PBI-ID> <Feature Name>`, for example `Start Development 305183 Complaint Imitation Request`. Run `tools/Start-SDD.ps1 -Repository . -Request "<verbatim command>" -Json` when a terminal exists.

Identity precedence: explicit command, feature branch, persisted active PBI. Conflicting sources return **PbiConflict**; ask the single precise identity question and preserve existing artifacts. After the user selects the ID, pass it explicitly with `-ConfirmPbiSelection`. The same resolution is retained for the same branch. Never silently switch PBI, inspect another PBI's package, or overwrite another PBI's approved specifications.

Primary input: `docs/sdd/pbi-input/<id>/REFINED-PBI.md`. Also discover original PBI Markdown, approved PBI Builder handoffs under `docs/sdd/pbi-sources/<id>-*/`, configured PBI_SOURCES and existing SDD artifacts. Folder/header identity must match before using or copying material; a body mention is not identity. An approved refined PBI is reused unchanged, never re-refined. Do not invent requirements.

Use `-Source <zip|folder|files>` or `tools/Add-SDDPbiInput.ps1` for supplied packages. Import keeps layout, protects existing files, and puts attachments in the PBI folder. Changed upstream input requires the user's confirmed re-export and `-UpdateChangedInput`; earlier versions remain under `.previous/`. A unique matching download may be imported after identity validation; multiple candidates require one selection question.

| Start result | Continue with |
|---|---|
| Initialized / Resumed | Current phase and remaining work; do not repeat unchanged completed analysis. |
| PbiNotFound / PbiAmbiguous | Report searched locations/candidates, ask only for the missing source/selection. |
| RoleAmbiguous | Inspect project files, then ask once if still ambiguous; retain the answer in settings.json. |
| InputConflict / PbiMismatch | Resolve upstream change/identity before importing. |
| InputEdited | Run Get-SDDStatus.ps1; use its supported recovery after inspecting the findings, preserving edited copies. |
| ReconcileExistingSpec | Check ownership, revision and approval state. Never overwrite; obtain the necessary scope decision. |
| RefinementRequired | Original input alone needs refinement and upstream business approval; analysis may proceed within known facts. |

Without a terminal, perform the same identity, discovery and persistence work through read/search/edit tools. Save state in `docs/sdd/changes/<id>-<Feature>/sdd-state.json` with pbiId, feature, title, role, skill, source, sourceKind, templateVersion and stage; gates remain NOT EXECUTED until actually run.

## P1a — Inputs and architecture
Inventory the selected PBI's attachments and companions (decision log, open questions, evidence, history). Read substantive inputs once; cached extracted text is reusable only when content hashes and extractor capability match. History is superseded; duplicate content is not reanalysed. Cite every file in spec.md with its contribution or Reviewed / Unreadable / Unsupported / Not relevant and a reason. Supporting files are evidence, never independent authorization or added scope.

Resolve every deterministic PX discrepancy and record semantic conflicts as SX-nn. Never silently reconcile business behavior, persisted values, messages, errors or expected tests. Ask the PO only when a missing decision blocks those facts. Inputs remain read-only; corrections belong in decisions or a new approved upstream export.

Select DAB, CDMS or Angular UI from actual project evidence and load its skill automatically. Inspect csproj, global.json, package.json, references, generated types, dispatcher, DI and route ownership. Never assume .NET version, MediatR, IDispatcher or a dependency structure; do not migrate .NET 8 to 10 or replace existing dispatch conventions. Mixed backends require real route/feature-flag and API-envelope evidence. Companion skills load only for affected components.

## P2 — Analysis and physical persistence
Preserve phases **0 Route, 1 Intake, 2 Inventory, 3 Clarify, 4 Specify, 5 Plan, 6 Tasks, 7 Analyze**. Use the current phase templates and `feature-inventory` guidance. Record current behavior with actual file/class/method evidence; classify AC coverage EXISTS / PARTIAL / MISSING / CONFLICT, identify reuse and implement only genuine approved gaps.

Write the only published spec and plan at `src/.github/specs/<ShortFeatureName>/spec.md` and `plan.md` (or `.github/specs/` when no src exists). Short PascalCase folder names contain no PBI number; both documents retain the PBI ID/title. For 305183 use `ComplaintImitationRequest`. Create directories automatically; preserve existing approved documents and check revision/approval before any update.

Use the full required sections from `.github/sdd/templates/spec.md` and `plan.md`: AC, business rules, existing/required behavior, validations, contracts, dependencies and scenarios; affected components, tasks, reuse, contract analysis, regression impact and verification strategy. Keep the upstream PBI verbatim inside its source markers and AC verbatim in the AC section. Do not invent implementation claims. Cite real repository evidence. `N/A - <reason>` is permitted; empty content, bare N/A, missing mandatory sections and unresolved placeholders are not complete analysis.

Read both files back from disk. Working notes live in `docs/sdd/changes/<id>-<Feature>/`: intake, inventory, clarifications, 06-test-plan.md, 07-tasks.md, 08-analysis.md, regression-impact.md, contract-matrix.md and pr-review-audit.md. Tasks may span coherent related files; each has AC/gap references and verification evidence. Tick working tasks, never approved plan.md.

Run `tools/Assert-SDDArtifacts.ps1 -Repository . -Feature <Feature> -Stage AnalysisComplete`. Fix in-scope failures; maximum three correction rounds. **Initialized** only means documents exist. **AnalysisComplete** requires substantive validated analysis and does not require implementation approval.

Present one approval summary: PBI/business approval, role, input/discrepancy handling, current flow, reuse, gaps, contracts, affected files, task groups, tests and blocking decisions. Stop for the user's implementation approval; no production edits beforehand.

## P3 — Record approval and continue
On an explicit user approval, run `tools/Approve-SDD.ps1 -Repository . -Feature <Feature> -Statement "<verbatim words>"`; the approver must be the person, never an agent. Require **ImplementationApproved** PASS. The record binds spec, plan and exact PBI inputs to that statement. Do not call this tool without the user's approval. If execution is unavailable, preserve the completed analysis and report the exact gate capability needed; the approval decision does not make an unexecuted gate pass.

If the refined PBI is not business-approved, show its status. `-AcknowledgeUnapprovedPbi` requires the user's explicit acknowledgment; otherwise wait for business approval. Any material spec/plan/input change requires renewed approval. Immediately continue approved implementation in the same agent workflow, FAST by default.

## P4 — Continuous implementation and verified resume
Phase **8 Implement**: inspect existing user changes and remaining approved tasks; read relevant files; make coherent related edits; inspect changed regions; verify the checkpoint; fix in-scope defects; update 07-tasks.md and use Update-SDDProgress.ps1 to record verified task IDs and evidence. Continue automatically. Get-SDDProgress.ps1 returns remaining tasks and detects stale checkpoints; preserve previous evidence for diagnosis. Do not reanalyse unchanged approved artifacts.

Classify failure as implementation defect, environment problem, terminal cancellation, test infrastructure failure or business-rule conflict. At most two build/test retries after a correction or diagnosed transient failure; never loop identical implementation failures. Continue independent work when one capability is blocked. Required permissions and decisions remain prerequisites.

Apply relevant verified domain rules: Paint System creation/update, Actual/Non-Actual transitions, IR Complaint/Technical/New Sample/Improved Formula, duplicate IR checks, Primary/Secondary Derived products and family association, version/alternative numbers, formula/measurement requirements and Local/Global. Preserve active/deleted filters, nullable contracts (including CS8625), response envelopes and Angular validation/error display. Inspect GraphQL selections and actual generated types before using fields. Never hand-edit generated StrawberryShake clients; regenerate through the repository workflow and inspect callers/mocks. Keep Sonar, regression, naming and architecture standards applicable to the approved change.

## P5 — Review, final verification and PR readiness
Phase **9 Independent Review**: use the Akzo SDD Reviewer/handoff with current scope and evidence. Load only applicable approved historical rules via Get-SDDApplicableRules.ps1; exported real comments require provenance and approval. Candidate engineering checks are labelled as candidates. Findings become scoped fix tasks; re-review changed dependencies, maximum three rounds. A model does not approve its own work. Unavailable independent review is reported, never fabricated.

Phase **10 Verify**: use Get-SDDVerificationPlan.ps1 to select actual projects and dependent tests. Invoke-SDDVerification.ps1 captures real stdout/stderr, logs, process exits, bounded timeouts/retries and source/configuration fingerprints. Scope Targeted is incremental; Scope Final must cover full regression. Reuse matching successful command/source/log evidence; do not build again merely to repeat a completed phase. Source, dependency, project or configuration edits invalidate prior results.

SDK-style .NET defaults collect current-run TRX and reject zero executed tests. Classic projects need confirmed MSBuild/VSTest commands; Angular uses repository noninteractive npm scripts. For custom commands inspect actual runner outcomes/counts; an exit-zero command that ran no tests does not demonstrate regression. Missing tools, cancelled/unfinished commands and unrun integrations are NOT EXECUTED, never PASS. CI files alone are not execution evidence.

Get-SDDStatus.ps1 and verification flag tracked `.sln`/`.slnx` changes absent from the approved plan's exact solution paths. Show the files and suggested restoration command for user review; never run git restore automatically. Intentional solution edits must be part of the hash-bound approved plan.

**ImplementationVerified** requires current successful build/test evidence. **PRReady** additionally requires Scope Final regression, all approved task checkpoints, no open independent review findings (explicit NIT waivers recorded), and completion.md with AC → file/class/method → executed test traceability. Include applicable coverage/Sonar/contract and merge-safety results. Never call the PBI complete when required checks are missing. No automatic stage, commit, push or deployment.

Phase **11 Archive** runs only after confirmed merge or explicit request. Update the living domain spec with approved deltas and cited decisions; archive the change folder without discarding evidence.

## Git hygiene and context budget
Published spec.md/plan.md, application source, tests and intentionally tracked standards stay visible in Git. Local tools, PBI inputs, extracted text, work notes and caches use `.git/info/exclude`; exclusions never hide tracked modifications. Never broadly ignore Markdown, .github or feature specs. Preserve team-owned files and report tracked/modified builder assets during upgrades.

Load this workflow/constitution once, the selected skill and phase-specific templates. Search relevant paths first; reuse project maps by content fingerprint. Bound full map rebuilding to changed project/configuration content; unchanged hashes do not justify rereading architecture. At most two identical failed calls without new evidence, two build/test retries after diagnosis and three analysis/review rounds. Keep compact progress updates. Track observed files read, repeated reads, tool calls, scans, build/test invocations, mandatory pauses and elapsed time. Actual provider token usage is UNKNOWN unless exposed; do not infer token or speed improvements from proxy counts.
