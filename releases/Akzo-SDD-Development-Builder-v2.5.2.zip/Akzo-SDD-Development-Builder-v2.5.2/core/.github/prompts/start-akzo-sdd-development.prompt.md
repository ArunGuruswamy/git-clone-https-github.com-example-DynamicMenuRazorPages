---
agent: Akzo SDD Developer
description: "Start Development <PBI-ID> <Feature Name> [(source: <PBI Builder ZIP or folder>)]: read the refined PBI and every attachment in docs/sdd/pbi-input/<PBI-ID>/, select DAB/CDMS/UI from repository evidence, write and verify spec.md + plan.md, stop for approval."
argument-hint: "<PBI-ID> <Feature Name>   e.g. 305183 Complaint Imitation Request (source: C:\\Users\\me\\Downloads\\305183.zip)"
---
Start Development ${input:request:<PBI-ID> <Feature Name>}

Follow `.github/sdd/workflow.md`, steps P-1 to P2, without asking for anything the repository already answers:
1. P0 capability preflight using authorized probes and their actual outcomes.
2. P-1/P1 import (when I give a `(source: ...)` path) and discovery (`tools/Start-SDD.ps1 -Request "<my words>" -Json` when you have a terminal; otherwise the same steps with search/read/edit).
3. P1a: read the inventory and every file in `docs/sdd/pbi-input/<PBI-ID>/` (attachments included); open images and PDFs with your own tools; cite every file and answer every discrepancy ID in spec.md.
4. Phases 0-7: inventory, clarify, then write the completed `src/.github/specs/<ShortFeatureName>/spec.md` and `plan.md` to disk, read them back, and run the `AnalysisComplete` gate until PASS (or report `NOT EXECUTED` when there is no terminal).
5. Show the Approval Summary (PBI approval status, inputs, discrepancies) and stop. No application source edits before my approval is recorded.
