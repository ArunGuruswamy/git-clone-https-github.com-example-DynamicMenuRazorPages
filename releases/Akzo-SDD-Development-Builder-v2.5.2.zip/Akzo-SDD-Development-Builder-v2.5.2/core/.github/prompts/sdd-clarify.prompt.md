---
agent: Akzo SDD Developer
description: "Classify PBI requirements as CONFIRMED / ASSUMPTION / OPEN QUESTION and list PBI-vs-code gaps."
---

Follow `.github/sdd/workflow.md`, the sole phase and execution-mode authority.


Run PHASE 3 (CLARIFY) for the current PBI. Check `docs/architecture/OPEN-QUESTIONS.md` first.
Ask at most 5 questions, each with options and a recommended answer. Use the NOT CONFIRMED format for blockers. Update `02-clarifications.md`.
