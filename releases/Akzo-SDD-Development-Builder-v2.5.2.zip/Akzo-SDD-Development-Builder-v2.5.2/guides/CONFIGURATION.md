# v2.5.2 configuration

`.github/sdd/workflow.md` defines all phases and modes. FAST is the default after approval; STANDARD adds checkpoints; STEP requires an explicit user choice. Legacy STEP_MODE does not override this workflow.

Optional local `.sdd-builder/settings.json`:
```json
{"role":"DAB","specRoot":"src/.github/specs","executionMode":"FAST","activePbi":"305183"}
```
Role overrides resolve ambiguous layouts only. Start-SDD considers explicit command, feature branch, then the persisted active PBI; disagreements return PbiConflict (exit 7) before reading another PBI. After the user answers, use the selected explicit ID with `-ConfirmPbiSelection`; the resolution is retained for that branch. The pin lives in `.sdd-builder/active-pbi.json`.

Optional `.sdd-builder/verification-config.json`:
```json
{"build":"dotnet build path/to/App.sln --nologo","test":"dotnet test path/to/App.sln --logger trx"}
```
Use actual repository commands and SDK pins. Classic CDMS projects require confirmed MSBuild/VSTest commands; no automatic framework or dispatcher migration occurs. Angular defaults use `npm run build` and noninteractive `npm run test:ci`; configure alternatives explicitly. No secrets belong in either file.

## Execution
```powershell
./tools/Get-SDDVerificationPlan.ps1 -Repository . -ChangedFiles src/App/Rule.cs -Scope Targeted
./tools/Invoke-SDDVerification.ps1 -Repository . -Feature ComplaintImitationRequest -Scope Targeted
./tools/Invoke-SDDVerification.ps1 -Repository . -Feature ComplaintImitationRequest -Scope Final
./tools/Update-SDDProgress.ps1 -Repository . -Feature ComplaintImitationRequest -Tasks T1,T2 -Evidence 'AC-1 and AC-2 tests passed'
./tools/Get-SDDProgress.ps1 -Repository . -Feature ComplaintImitationRequest
```
PowerShell arrays use commas; command-line callers can pass `-Tasks 'T1,T2'`. Completed task IDs must appear in the approved plan. A checkpoint requires current successful verification. Source or plan changes report stale checkpoints, preserving previous evidence for inspection. To select STEP explicitly, pass `-Mode STEP` when recording the checkpoint; tell the agent to use STEP for the current session.

`-Build` and `-Test` override defaults. `-TimeoutMinutes` defaults to 30; `-TimeoutSeconds` allows shorter bounds. `-MaxRetries` is 0 by default, maximum 2. Only configured transient exit codes (default 75) retry automatically; implementation errors and timeouts require diagnosis. `-Force` reruns matching checks. A successful unchanged command set and source/configuration fingerprint can be reused without another build.

Logs capture stdout, stderr, exit code, attempt count and elapsed seconds. Pending records persist before execution; killed sessions cannot imply PASS. Default SDK-style .NET tests collect unique-run TRX and reject zero executed tests. Custom build/test commands require reviewing their runner results; arbitrary successful commands do not establish functional correctness. Scope Final means the configured test command must cover full regression. Targeted evidence cannot pass PRReady.

## Cache and exclusions
Project maps are keyed by project/reference/configuration content. Unknown ownership, imports or dependency ambiguity conservatively selects all test projects. Extraction cache entries are keyed by input content, builder version and extractor capability; input hashes are always refreshed. Cache failure triggers re-extraction. Runtime state is local under `.sdd-builder/` and the PBI work folder. Source fingerprints include source/configuration and published specs, exclude build/dependency outputs and runtime notes, and fail on linked source paths that cannot be safely resolved. Custom scripts/configuration that affect verification should live in source-controlled paths, not output/cache directories.

## Solution protection
Only exact backtick `.sln` or `.slnx` paths in the plan's **Affected source files** section authorize solution modifications. Approval binds that section's hash. Status and verification report accidental changes with a restoration command for user review; they never execute it.
