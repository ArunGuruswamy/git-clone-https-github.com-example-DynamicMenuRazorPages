﻿<#
.SYNOPSIS
  Installs Akzo SDD Developer v2.5.2 into one repository (CDMS, DAB or UI).

.DESCRIPTION
  Copies the agents, prompts, skills, instructions, constitution, config and templates into <Destination>\.github.
  It also copies reference docs into <Destination>\docs.
  - Git-clean by default: existing files are not overwritten, preventing tracked-file changes.
  - Newly installed, untracked SDD files and installer backup files are added to the repository-local
    .git/info/exclude file, so they remain available locally but do not appear in Git changes.
  - No project Git history, index, commits or branches are changed.
  - Use -UpdateExisting only when you intentionally want to refresh files already in the repo.
  - Use -TrackInstalledFiles if you intend to commit installed SDD assets to the repository.

.EXAMPLE
  .\Install-DevelopmentBuilder.ps1 -Target DAB  -Destination C:\src\AN.ColorAppsAzure.BL
  .\Install-DevelopmentBuilder.ps1 -Target CDMS -Destination C:\src\AN.ColorAppsAzure.BL.ColorDMS
  .\Install-DevelopmentBuilder.ps1 -Target DAB -Destination C:\src\AN.ColorAppsAzure.BL -UpdateExisting
  .\Install-DevelopmentBuilder.ps1 -Target UI   -Destination C:\src\AN.ColorAppsAzure.UI `
      -CdmsRepo C:\src\AN.ColorAppsAzure.BL.ColorDMS -DabRepo C:\src\AN.ColorAppsAzure.BL -UiRepo C:\src\AN.ColorAppsAzure.UI
#>
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("CDMS", "DAB", "UI")]
    [string]$Target,

    [Parameter(Mandatory = $true)]
    [string]$Destination,

    [ValidateSet("Both", "Full", "Concise")]
    [string]$Mode = "Both",

    [string]$CdmsRepo,
    [string]$DabRepo,
    [string]$UiRepo,

    # Explicit opt-in: overwrite installed files that already exist (a backup is created first).
    [switch]$UpdateExisting,

    # Explicit opt-in: leave installed assets visible to Git so they can be committed.
    [switch]$TrackInstalledFiles,

    # Legacy option: force replacement of team-owned files; may produce Git changes.
    [switch]$Force,

    # Remove obsolete builder-managed launchers only. Backups are kept outside the repo.
    [switch]$PruneLegacy,

    # Default CMD behavior: keep builder tools local-only, without editing Git-tracked team files.
    [switch]$LocalOnlyMode,

    # Standard: agents declare their tool list. Unrestricted: the 'tools:' line is omitted so the IDE grants
    # every available tool (use when Visual Studio 2026 shows no edit/terminal tool for the agent).
    [ValidateSet("Standard", "Unrestricted")]
    [string]$ToolProfile = "Standard"
)

$ErrorActionPreference = "Stop"
$sourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$stamp = (Get-Date -Format "yyyyMMdd-HHmmss") + "-" + [guid]::NewGuid().ToString("N").Substring(0,8)
$script:installed = 0
$script:skipped = 0
$script:localExcludePatterns = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
$script:configExistedAtStart = $false
$script:builderVersion = "2.5.2"
$script:manifest = New-Object System.Collections.Generic.List[object]
$script:trackedSkipped = New-Object System.Collections.Generic.List[string]
$script:backupRoot = $null
$script:hookOwnership = $null

function Get-DestinationRelative([string]$path) {
    $full = [IO.Path]::GetFullPath($path)
    $base = $Destination.TrimEnd([char]92, [char]47)
    if ($full.Length -gt $base.Length) { return $full.Substring($base.Length).TrimStart([char]92, [char]47).Replace([char]92, [char]47) }
    return ''
}

function Add-ManifestEntry([string]$target, [string]$action, [string]$backup) {
    $hash = if (Test-Path -LiteralPath $target -PathType Leaf) { (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() } else { $null }
    $script:manifest.Add([pscustomobject][ordered]@{ path = (Get-DestinationRelative $target); action = $action; sha256 = $hash; backup = $backup; backupSha256 = $(if ($backup) { (Get-FileHash -LiteralPath (Join-Path $Destination $backup) -Algorithm SHA256).Hash.ToLowerInvariant() } else { $null }) })
}

function Backup-ExistingFile([string]$target) {
    # Backups live outside .github so Copilot never loads them; the folder is locally excluded from Git.
    if (-not $script:backupRoot) { $script:backupRoot = Join-Path $Destination ('.sdd-installer-backups/' + $stamp) }
    $rel = Get-DestinationRelative $target
    $backup = Join-Path $script:backupRoot $rel
    New-Item -ItemType Directory -Path (Split-Path -Parent $backup) -Force | Out-Null
    Copy-Item -LiteralPath $target -Destination $backup -Force
    Write-Host "  backup   $rel -> .sdd-installer-backups/$stamp/$rel" -ForegroundColor Yellow
    return ('.sdd-installer-backups/' + $stamp + '/' + $rel)
}

function Write-Step([string]$m) { Write-Host "`n==> $m" -ForegroundColor Cyan }

$script:gitTrackingLoaded = $false
$script:gitTrackingCommands = 0
$script:trackedFiles = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
function Test-GitTrackedPath([string]$path) {
    if (-not $script:gitTrackingLoaded) {
        $script:gitTrackingLoaded = $true
        $script:gitRoot = (& git -C $Destination rev-parse --show-toplevel 2>$null | Out-String).Trim()
        $script:gitTrackingCommands++
        if ($LASTEXITCODE -ne 0 -or -not $script:gitRoot) { $script:gitRoot = ''; return $false }
        $raw = (& git -C $script:gitRoot ls-files --cached -z 2>$null | Out-String).TrimEnd("`r","`n")
        $script:gitTrackingCommands++
        if ($LASTEXITCODE -ne 0) { throw 'Could not read Git tracking; installation stopped.' }
        foreach ($p in ($raw -split "`0")) { if ($p) { [void]$script:trackedFiles.Add($p) } }
    }
    if (-not $script:gitRoot) { return $false }
    $prefix = $script:gitRoot.TrimEnd([char]92,[char]47) + [IO.Path]::DirectorySeparatorChar
    $full = [IO.Path]::GetFullPath($path)
    if (-not $full.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) { return $false }
    return $script:trackedFiles.Contains($full.Substring($prefix.Length).Replace('\','/'))
}

function Register-LocalOnlyPath([string]$path) {
    if ($TrackInstalledFiles) { return }
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return }
    if (Test-GitTrackedPath $path) { return }
    $relative = $path.Substring($Destination.TrimEnd('\').Length).TrimStart('\', '/').Replace('\', '/')
    if ($relative) { [void]$script:localExcludePatterns.Add('/' + $relative) }
}

function Register-InstallerBackups([string]$target) {
    $dir = Split-Path -Parent $target
    $leaf = Split-Path -Leaf $target
    if (Test-Path -LiteralPath $dir -PathType Container) {
        Get-ChildItem -LiteralPath $dir -Filter ($leaf + '.backup-*') -File -ErrorAction SilentlyContinue | ForEach-Object {
            Register-LocalOnlyPath $_.FullName
        }
    }
}

function Copy-WithBackup([string]$source, [string]$target) {
    $prefix = $Destination.TrimEnd([char]92,[char]47) + [IO.Path]::DirectorySeparatorChar
    $full = [IO.Path]::GetFullPath($target)
    if (-not $full.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) { throw "Install path escapes destination: $target" }
    $cursor = $Destination
    foreach ($part in $full.Substring($prefix.Length).Split([IO.Path]::DirectorySeparatorChar)) {
        $cursor = Join-Path $cursor $part
        if ((Test-Path -LiteralPath $cursor) -and ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Linked install path is not writable by the installer: $cursor" }
    }
    # A tracked file cannot be hidden using .gitignore or .git/info/exclude.
    # In local-only mode NEVER edit it. Keep team-owned settings unchanged.
    if ($LocalOnlyMode -and (Test-GitTrackedPath $target)) {
        $same = (Test-Path -LiteralPath $target) -and ((Get-FileHash -LiteralPath $source).Hash -eq (Get-FileHash -LiteralPath $target).Hash)
        if (-not $same) {
            Write-Host "  tracked  NOT UPDATED (team-owned, Git-tracked): $target" -ForegroundColor DarkYellow
            $script:trackedSkipped.Add((Get-DestinationRelative $target))
        }
        Add-ManifestEntry $target $(if ($same) { 'tracked-current' } else { 'tracked-not-updated' }) $null
        $script:skipped++
        return
    }
    $dir = Split-Path -Parent $target
    if (-not (Test-Path -LiteralPath $target) -and (Test-GitTrackedPath $target) -and -not ($UpdateExisting -or $Force)) {
        Write-Host "  skip     $target (tracked path is missing from the worktree; preserving the deletion; use -UpdateExisting only if you intend to restore it)" -ForegroundColor Yellow
        $script:skipped++
        return
    }
    if (!(Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    if (Test-Path -LiteralPath $target) {
        $srcHash = (Get-FileHash -LiteralPath $source).Hash
        $dstHash = (Get-FileHash -LiteralPath $target).Hash
        if ($srcHash -eq $dstHash) {
            Register-LocalOnlyPath $target
            Register-InstallerBackups $target
            Add-ManifestEntry $target 'current' $null
            $script:skipped++
            return
        }
        if (-not ($UpdateExisting -or $Force)) {
            Write-Host "  keep     $target (exists; use -UpdateExisting to replace intentionally)" -ForegroundColor DarkGray
            Register-LocalOnlyPath $target
            Register-InstallerBackups $target
            Add-ManifestEntry $target 'kept' $null
            $script:skipped++
            return
        }
        $oldManifest = Join-Path $Destination '.sdd-builder/manifest.json'
        if ((Test-Path -LiteralPath $oldManifest) -and -not $Force) {
            $owned = @((Get-Content -LiteralPath $oldManifest -Raw | ConvertFrom-Json).installs | ForEach-Object { $_.files } | Where-Object { $_.path -eq (Get-DestinationRelative $target) -and $_.action -in @('installed','updated') }) | Select-Object -Last 1
            if ($owned -and $owned.sha256 -and $owned.sha256 -ne $dstHash.ToLowerInvariant()) {
                Write-Warning "Kept modified builder file: $(Get-DestinationRelative $target). Review before explicit -Force replacement."
                Add-ManifestEntry $target 'kept-modified' $null; $script:skipped++; return
            }
        }
        $backup = Backup-ExistingFile $target
        Copy-Item -LiteralPath $source -Destination $target -Force
        Register-LocalOnlyPath $target
        Add-ManifestEntry $target 'updated' $backup
        Write-Host "  update   $target" -ForegroundColor Green
        $script:installed++
        return
    }
    Copy-Item -LiteralPath $source -Destination $target -Force
    Register-LocalOnlyPath $target
    Register-InstallerBackups $target
    Add-ManifestEntry $target 'installed' $null
    Write-Host "  install  $target" -ForegroundColor Green
    $script:installed++
}

function Copy-IfAbsent([string]$source, [string]$target) {
    # Team- or developer-owned content (config.md, review learnings, architecture docs): seeded once,
    # never overwritten by -UpdateExisting. Only -Force replaces it (with a backup).
    if ((Test-Path -LiteralPath $target) -and -not $Force) {
        Write-Host "  keep     $target (team-owned; seeded only when absent)" -ForegroundColor DarkGray
        Register-LocalOnlyPath $target
        Register-InstallerBackups $target
        Add-ManifestEntry $target 'kept' $null
        $script:skipped++
        return
    }
    Copy-WithBackup $source $target
}

function Copy-IfMissing([string]$source, [string]$target) {
    if ((Test-Path -LiteralPath $target) -and -not ($Force -or $UpdateExisting)) {
        Write-Host "  keep     $target (already exists)" -ForegroundColor DarkGray
        Register-LocalOnlyPath $target
        Register-InstallerBackups $target
        Add-ManifestEntry $target 'kept' $null
        $script:skipped++
        return
    }
    Copy-WithBackup $source $target
}

function Write-GitLocalExcludes {
    if ($TrackInstalledFiles -or $script:localExcludePatterns.Count -eq 0) { return }
    $repoRootRaw = & git -C $Destination rev-parse --show-toplevel 2>$null
    if ($LASTEXITCODE -ne 0 -or -not $repoRootRaw) {
        Write-Warning "Destination is not a Git repository; local ignore rules were not written."
        return
    }
    $repoRoot = [IO.Path]::GetFullPath(([string]$repoRootRaw).Trim())
    # Prefer Git's absolute resolved path (handles linked worktrees); fall back for older Git versions.
    $excludePath = & git -C $repoRoot rev-parse --path-format=absolute --git-path info/exclude 2>$null
    if ($LASTEXITCODE -ne 0 -or -not $excludePath) {
        $excludePath = & git -C $repoRoot rev-parse --git-path info/exclude 2>$null
        if ($LASTEXITCODE -ne 0 -or -not $excludePath) {
            Write-Warning "Could not resolve repository-local info/exclude; installed assets may appear as untracked files."
            return
        }
        $excludePath = [string]$excludePath
        if (-not [IO.Path]::IsPathRooted($excludePath)) {
            $gitDir = & git -C $repoRoot rev-parse --absolute-git-dir 2>$null
            if ($LASTEXITCODE -ne 0 -or -not $gitDir) {
                Write-Warning "Could not resolve Git directory; local ignore rules were not written."
                return
            }
            $excludePath = Join-Path ([string]$gitDir).Trim() 'info/exclude'
        }
    }
    $excludePath = [IO.Path]::GetFullPath(([string]$excludePath).Trim())
    $excludeDir = Split-Path -Parent $excludePath
    if (-not (Test-Path -LiteralPath $excludeDir)) { New-Item -ItemType Directory -Path $excludeDir -Force | Out-Null }
    $existing = @()
    if (Test-Path -LiteralPath $excludePath) { $existing = @(Get-Content -LiteralPath $excludePath) }
    $existingSet = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($line in $existing) { [void]$existingSet.Add([string]$line) }
    $added = @($script:localExcludePatterns | Where-Object { -not $existingSet.Contains($_) } | Sort-Object)
    if ($added.Count -eq 0) { return }
    if (-not $existingSet.Contains('# Added by Akzo SDD Development Builder (local-only files)')) {
        Add-Content -LiteralPath $excludePath -Value '# Added by Akzo SDD Development Builder (local-only files)' -Encoding UTF8
    }
    Add-Content -LiteralPath $excludePath -Value $added -Encoding UTF8
    Write-Host ("  git      hid {0} local-only SDD file(s) from Git status via .git/info/exclude" -f $added.Count) -ForegroundColor Cyan
}

# Copies every file under <sourceRoot>\<bucket> into <Destination>, preserving relative paths.
function Install-Tree([string]$bucket, [scriptblock]$policy) {
    $root = Join-Path $sourceRoot $bucket
    if (!(Test-Path -LiteralPath $root)) { return }
    $root = (Resolve-Path -LiteralPath $root).Path
    Get-ChildItem -LiteralPath $root -Recurse -File -Force | ForEach-Object {
        $rel = $_.FullName.Substring($root.Length).TrimStart('\', '/')
        $dst = Join-Path $Destination $rel
        & $policy $_.FullName $dst $rel
    }
}

# ---------------------------------------------------------------- safe legacy cleanup
function Remove-ObsoleteBuilderFiles {
    if (-not $PruneLegacy) { return }
    # Strict allowlist: never delete .github/specs, docs/sdd/changes, PBI inputs,
    # custom agent files, project source, or arbitrary files in .github.
    $legacy = @(
        'Run-Akzo-SDD-DevelopmentBuilder.cmd',
        'Run-Akzo-SDD-DevelopmentBuilder.ps1',
        'tools/Run-Akzo-SDD-DevelopmentBuilder.ps1',
        'tools/Run-Akzo-SDD-DevelopmentBuilder.cmd'
    )
    $backupDir = Join-Path $Destination ('.sdd-installer-backups/' + $stamp)
    foreach ($relative in $legacy) {
        $candidate = Join-Path $Destination $relative
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
        # Do not move tracked files, which are team-owned.
        if (Test-GitTrackedPath $candidate) {
            Write-Warning "Obsolete tracked file retained for manual team review: $relative"
            continue
        }
        $ownershipFile = Join-Path $Destination '.sdd-builder/manifest.json'
        $owned = if (Test-Path -LiteralPath $ownershipFile) { @((Get-Content -LiteralPath $ownershipFile -Raw | ConvertFrom-Json).installs | ForEach-Object { $_.files } | Where-Object { $_.path -eq $relative -and $_.sha256 -eq (Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash.ToLowerInvariant() }) } else { @() }
        if (-not $owned.Count) { Write-Warning "Legacy launcher retained: ownership not established for $relative"; continue }
        $target = Join-Path $backupDir $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
        Move-Item -LiteralPath $candidate -Destination $target -Force
        Write-Host "  legacy   backed up obsolete launcher: $relative" -ForegroundColor Yellow
    }
}

function Remove-BuilderLocalExclusions {
    # Previous releases concealed builder files in .git/info/exclude.
    # Only remove exact file exclusions for paths deployed by this package,
    # not user-authored ignore rules or exclusions of unrelated assets.
    if (-not $TrackInstalledFiles) { return }
    $gitDirRaw = & git -C $Destination rev-parse --absolute-git-dir 2>$null
    if ($LASTEXITCODE -ne 0 -or -not $gitDirRaw) { return }
    $excludePath = Join-Path ([string]$gitDirRaw).Trim() 'info/exclude'
    if (-not (Test-Path -LiteralPath $excludePath -PathType Leaf)) { return }
    $contents = @(Get-Content -LiteralPath $excludePath)
    $known = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($bucket in @('core','tooling','shared','cdms','dab','ui','backend')) {
        $root = Join-Path $sourceRoot $bucket
        if (-not (Test-Path -LiteralPath $root)) { continue }
        $root = (Resolve-Path -LiteralPath $root).Path
        Get-ChildItem -LiteralPath $root -Recurse -File -Force | ForEach-Object {
            $rel = $_.FullName.Substring($root.Length).TrimStart('\','/').Replace('\','/')
            [void]$known.Add('/' + $rel)
        }
    }
    $filtered = @($contents | Where-Object {
        $line = $_.Trim()
        -not $known.Contains($line)
    })
    if ($filtered.Count -ne $contents.Count) {
        Copy-Item -LiteralPath $excludePath -Destination ($excludePath + '.sdd-backup-' + $stamp) -Force
        Set-Content -LiteralPath $excludePath -Value $filtered -Encoding UTF8
        Write-Host "  git      removed $($contents.Count - $filtered.Count) old builder exclusions; restored Git visibility" -ForegroundColor Green
    }
}

# ---------------------------------------------------------------- validate
$Destination = [IO.Path]::GetFullPath($Destination)
if (!(Test-Path -LiteralPath $Destination)) { throw "Repository folder not found: $Destination" }

Write-Step "Validating repository ($Target)"
if (!(Test-Path -LiteralPath (Join-Path $Destination ".git"))) {
    Write-Warning "No .git folder at $Destination. Confirm this is the repository root."
}
$signatureOk = switch ($Target) {
    "DAB"  { [bool](Get-ChildItem -LiteralPath $Destination -Filter "*.sln" -File | Where-Object { $_.Name -notmatch "ColorDMS" }) -and (Test-Path (Join-Path $Destination "src")) }
    "CDMS" { [bool](Get-ChildItem -LiteralPath $Destination -Filter "*.sln" -File -Recurse -Depth 2 | Where-Object { $_.Name -match "ColorDMS|CDMS" }) }
    "UI"   { Test-Path -LiteralPath (Join-Path $Destination "angular.json") }
}
if (-not $signatureOk) {
    if (-not $Force) { throw "Repository does not look like $Target ($Destination). Nothing was changed. Re-run with -Force only if you are sure." }
    Write-Warning "Repository does not look like $Target; continuing because -Force was given."
}
$script:configExistedAtStart = Test-Path -LiteralPath (Join-Path $Destination ".github/sdd/config.md")

Remove-ObsoleteBuilderFiles

# ---------------------------------------------------------------- core
Write-Step "Core: agents, prompts, skills, constitution, templates"
Install-Tree "core" {
    param($src, $dst, $rel)
    $name = Split-Path -Leaf $rel
    if ($name -eq "akzo-sdd-developer.agent.md" -and $Mode -eq "Concise") { Register-LocalOnlyPath $dst; return }
    if ($name -eq "akzo-sdd-developer-concise.agent.md" -and $Mode -eq "Full") { Register-LocalOnlyPath $dst; return }
    if ($name -eq "config.md" -or $name -eq "review-learnings.md") { Copy-IfAbsent $src $dst; return }
    if ($name -eq "sonar-rules.instructions.md") {
        if ($Target -eq "UI") { return }
        Copy-IfAbsent $src $dst; return
    }
    if ($name -like "*.agent.md" -and $ToolProfile -eq "Unrestricted") {
        $tmp = Join-Path ([IO.Path]::GetTempPath()) ("sdd-" + $name)
        $text = Get-Content -LiteralPath $src -Raw
        $text = $text -replace "(?m)^tools:.*\r?\n", ""
        if ($Mode -eq "Concise") { $text = $text -replace "(?m)^(\s*)agent: Akzo SDD Developer(\r?)$", '$1agent: Akzo SDD Developer - Caveman Concise$2' }
        Set-Content -LiteralPath $tmp -Value $text -Encoding UTF8 -NoNewline
        Copy-WithBackup $tmp $dst
        Remove-Item -LiteralPath $tmp -Force
        return
    }
    if (($name -like "*.prompt.md" -or $name -eq "akzo-sdd-reviewer.agent.md") -and $Mode -eq "Concise") {
        # Point prompt files and reviewer handoffs at the only installed developer agent.
        $tmp = Join-Path ([IO.Path]::GetTempPath()) $name
        $text = (Get-Content -LiteralPath $src -Raw) -replace "(?m)^(\s*)agent: Akzo SDD Developer(\r?)$", '$1agent: Akzo SDD Developer - Caveman Concise$2'
        Set-Content -LiteralPath $tmp -Value $text -Encoding UTF8 -NoNewline
        Copy-WithBackup $tmp $dst
        Remove-Item -LiteralPath $tmp -Force
        return
    }
    Copy-WithBackup $src $dst
}

Write-Step "SDD validator tools"
Install-Tree "tooling" { param($src, $dst, $rel) Copy-WithBackup $src $dst }

Write-Step "Shared UI reference (docs/sdd/ui)"
Install-Tree "shared" { param($src, $dst, $rel) Copy-WithBackup $src $dst }

switch ($Target) {
    "CDMS" {
        Write-Step "CDMS: instructions + quality reference"
        Install-Tree "cdms"    { param($src, $dst, $rel) Copy-WithBackup $src $dst }
        Install-Tree "backend" { param($src, $dst, $rel) Copy-WithBackup $src $dst }
        if (!(Test-Path -LiteralPath (Join-Path $Destination "docs/architecture/ARCHITECTURE-SUMMARY.md"))) {
            Write-Host "  note     docs/architecture missing. Run /sdd-bootstrap-architecture in Copilot Chat." -ForegroundColor Yellow
        }
    }
    "DAB" {
        Write-Step "DAB: instructions + architecture docs (only if missing) + quality reference"
        Install-Tree "dab"     { param($src, $dst, $rel) Copy-IfAbsent $src $dst }
        Install-Tree "backend" { param($src, $dst, $rel) Copy-WithBackup $src $dst }
    }
    "UI" {
        Write-Step "UI: SDD instructions"
        Install-Tree "ui" { param($src, $dst, $rel) Copy-WithBackup $src $dst }
    }
}

# ---------------------------------------------------------------- check-in spec root
# Create directory only; do not put a .gitkeep here or locally ignore source specs.
$featureSpecParent = if (Test-Path -LiteralPath (Join-Path $Destination "src")) { "src/.github/specs" } else { ".github/specs" }
$featureSpecPath = Join-Path $Destination $featureSpecParent
if (!(Test-Path -LiteralPath $featureSpecPath)) { New-Item -ItemType Directory -Path $featureSpecPath -Force | Out-Null }
Write-Host "  spec     $featureSpecPath (check-in-ready feature specs; no PBI numbers in folder names)" -ForegroundColor Cyan

# ---------------------------------------------------------------- PBI input folder
$pbiInput = Join-Path $Destination 'docs/sdd/pbi-input'
if (-not (Test-Path -LiteralPath $pbiInput)) { New-Item -ItemType Directory -Path $pbiInput -Force | Out-Null }
Write-Host "  PBI      Drag the PBI Builder ZIP onto tools\Add-PbiInput.cmd (creates docs/sdd/pbi-input/<PBI-ID>/, local-only)" -ForegroundColor Cyan

# ---------------------------------------------------------------- local commit gate (pre-commit hook)
# Blocks committing application source while a PBI is in progress and not verified. Only installed when the
# repository has no pre-commit hook of its own and no core.hooksPath (shared hook managers are never touched).
$hookMarker = '# Akzo SDD Development Builder commit gate'
try {
    $hooksPathCfg = (& git -C $Destination config --get core.hooksPath 2>$null | Out-String).Trim()
    $hookDir = (& git -C $Destination rev-parse --path-format=absolute --git-path hooks 2>$null | Out-String).Trim()
    if ($hooksPathCfg) { Write-Host "  hook     skipped (core.hooksPath is set; run tools/Assert-SDDCommit.ps1 from your own hook if wanted)" -ForegroundColor Yellow }
    elseif ($hookDir) {
        $hookFile = Join-Path $hookDir 'pre-commit'
        if (Test-Path -LiteralPath $hookFile) {
            if ((Get-Content -LiteralPath $hookFile -Raw) -like "*$hookMarker*") { Write-Host "  hook     commit gate already installed" -ForegroundColor Green }
            else { Write-Host "  hook     skipped (the repository already has a pre-commit hook)" -ForegroundColor Yellow }
        } else {
            if (-not (Test-Path -LiteralPath $hookDir)) { New-Item -ItemType Directory -Path $hookDir -Force | Out-Null }
            $lines = @(
                '#!/bin/sh',
                $hookMarker,
                '# Blocks committing application source while a PBI in progress is not verified.',
                '# Respects the effective corporate PowerShell execution policy.',
                'root=$(git rev-parse --show-toplevel 2>/dev/null) || exit 0',
                '[ -f "$root/tools/Assert-SDDCommit.ps1" ] || exit 0',
                'if command -v pwsh >/dev/null 2>&1; then ps=pwsh; elif command -v powershell.exe >/dev/null 2>&1; then ps=powershell.exe; elif command -v powershell >/dev/null 2>&1; then ps=powershell; else exit 0; fi',
                '"$ps" -NoLogo -NoProfile -File "$root/tools/Assert-SDDCommit.ps1" -Repository "$root" || exit 1',
                'exit 0'
            )
            [IO.File]::WriteAllText($hookFile, (($lines -join "`n") + "`n"), (New-Object System.Text.UTF8Encoding($false)))
            if (-not $IsWindows -and $PSVersionTable.PSEdition -eq 'Core') { & chmod +x $hookFile 2>$null }
            $script:hookOwnership = [ordered]@{ sha256 = (Get-FileHash -LiteralPath $hookFile -Algorithm SHA256).Hash.ToLowerInvariant(); created = $true }
            Write-Host '  hook     pre-commit commit gate installed' -ForegroundColor Cyan
        }
    }
} catch { Write-Host "  hook     not installed: $($_.Exception.Message)" -ForegroundColor Yellow }

# ---------------------------------------------------------------- folders
foreach ($d in @("docs/sdd/specs", "docs/sdd/changes", "docs/sdd/changes/archive")) {
    $p = Join-Path $Destination $d
    if (!(Test-Path -LiteralPath $p)) { New-Item -ItemType Directory -Path $p -Force | Out-Null }
    if ($LocalOnlyMode) { continue }
    $keep = Join-Path $p ".gitkeep"
    if (!(Test-Path -LiteralPath $keep)) {
        if ((Test-GitTrackedPath $keep) -and -not ($UpdateExisting -or $Force)) {
            Write-Host "  skip     $keep (tracked file is missing; preserving the deletion)" -ForegroundColor Yellow
            continue
        }
        New-Item -ItemType File -Path $keep | Out-Null
    }
    Register-LocalOnlyPath $keep
}

# ---------------------------------------------------------------- config paths
$configPath = Join-Path $Destination ".github/sdd/config.md"
$repoMap = @{
    "C:\src\AN.ColorAppsAzure.BL.ColorDMS" = $CdmsRepo
    "C:\src\AN.ColorAppsAzure.BL"          = $DabRepo
    "C:\src\AN.ColorAppsAzure.UI"          = $UiRepo
}
switch ($Target) {
    "CDMS" { if (-not $CdmsRepo) { $repoMap["C:\src\AN.ColorAppsAzure.BL.ColorDMS"] = $Destination } }
    "DAB"  { if (-not $DabRepo)  { $repoMap["C:\src\AN.ColorAppsAzure.BL"] = $Destination } }
    "UI"   { if (-not $UiRepo)   { $repoMap["C:\src\AN.ColorAppsAzure.UI"] = $Destination } }
}
if (-not (Test-Path -LiteralPath $configPath) -and (Test-GitTrackedPath $configPath) -and -not ($UpdateExisting -or $Force)) {
    Write-Warning "The tracked SDD config is missing from the worktree; preserving the deletion. Use -UpdateExisting only if you intend to restore it."
} elseif ($script:configExistedAtStart -and -not $Force) {
    Write-Host "  keep     $configPath (existing config not modified by default)" -ForegroundColor DarkGray
    Register-LocalOnlyPath $configPath
} elseif ($LocalOnlyMode -and (Test-GitTrackedPath $configPath)) {
    Write-Host "  tracked  preserved team-owned config: $configPath" -ForegroundColor DarkYellow
} else {
    $config = Get-Content -LiteralPath $configPath -Raw
    # Longest default first so "...BL" does not clobber "...BL.ColorDMS".
    foreach ($key in ($repoMap.Keys | Sort-Object Length -Descending)) {
        $value = $repoMap[$key]
        if ($value) { $config = $config.Replace("``$key``", "``$([IO.Path]::GetFullPath($value))``") }
    }
    Set-Content -LiteralPath $configPath -Value $config -Encoding UTF8
    Register-LocalOnlyPath $configPath
}

# ---------------------------------------------------------------- multi-root workspace
if ($CdmsRepo -and $DabRepo -and $UiRepo) {
    Write-Step "Multi-root workspace"
    $ws = [ordered]@{
        folders  = @(
            [ordered]@{ name = "CDMS"; path = [IO.Path]::GetFullPath($CdmsRepo) },
            [ordered]@{ name = "DAB";  path = [IO.Path]::GetFullPath($DabRepo) },
            [ordered]@{ name = "UI";   path = [IO.Path]::GetFullPath($UiRepo) }
        )
        settings = [ordered]@{
            "chat.promptFiles" = $true
            "github.copilot.chat.codeGeneration.useInstructionFiles" = $true
        }
    }
    $wsPath = Join-Path $Destination ".github/sdd/AkzoColorApps.code-workspace"
    if ((Test-Path -LiteralPath $wsPath) -and -not ($UpdateExisting -or $Force)) {
        Write-Host "  keep     $wsPath (existing workspace not modified by default)" -ForegroundColor DarkGray
        Register-LocalOnlyPath $wsPath
    } else {
        if (Test-Path -LiteralPath $wsPath) {
            Copy-Item -LiteralPath $wsPath -Destination "$wsPath.backup-$stamp" -Force
            Register-LocalOnlyPath "$wsPath.backup-$stamp"
        }
        $ws | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $wsPath -Encoding UTF8
        Register-LocalOnlyPath $wsPath
        Write-Host "  install  $wsPath  (File > Open Workspace from File...)" -ForegroundColor Green
    }
}

Remove-BuilderLocalExclusions

# ---------------------------------------------------------------- local Git hygiene
Write-Step "Local-only Git hygiene"
if ($TrackInstalledFiles) {
    Write-Host "  Git tracking explicitly enabled; installed assets may appear in Git status." -ForegroundColor Yellow
} else {
    if ($LocalOnlyMode) {
        foreach ($rel in @('docs/sdd/changes/', 'docs/sdd/pbi-input/')) {
            [void]$script:localExcludePatterns.Add('/' + $rel)
        }
    }
    # Installer bookkeeping is always local-only, whatever the mode.
    foreach ($rel in @('.sdd-installer-backups/', '.sdd-builder/')) { [void]$script:localExcludePatterns.Add('/' + $rel) }
    # PBI inputs (refined PBI, attachments) are local-only unless the team already tracks that folder.
    $trackedInputs = @(& git -C $Destination ls-files -- 'docs/sdd/pbi-input' 2>$null)
    if ($LASTEXITCODE -eq 0 -and $trackedInputs.Count -eq 0) { [void]$script:localExcludePatterns.Add('/docs/sdd/pbi-input/') }
    Write-GitLocalExcludes
    Write-Host "  New local-only builder assets and temporary SDD work are excluded via .git/info/exclude; existing tracked files remain visible and unchanged in local-only mode." -ForegroundColor Cyan
    Write-Host "  This does not hide or revert tracked files already modified by a previous installation." -ForegroundColor Yellow
}

# ---------------------------------------------------------------- manifest (enables uninstall / rollback)
$manifestDir = Join-Path $Destination '.sdd-builder'
if (!(Test-Path -LiteralPath $manifestDir)) { New-Item -ItemType Directory -Path $manifestDir -Force | Out-Null }
$manifestPath = Join-Path $manifestDir 'manifest.json'
$previous = @()
if (Test-Path -LiteralPath $manifestPath) {
    try { $previous = @((Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json).installs) } catch { $previous = @() }
}
foreach ($entry in $script:manifest) {
    if ($entry.action -in @('installed','updated') -and (Test-Path -LiteralPath (Join-Path $Destination $entry.path))) { $entry.sha256 = (Get-FileHash -LiteralPath (Join-Path $Destination $entry.path) -Algorithm SHA256).Hash.ToLowerInvariant() }
}
$install = [ordered]@{
    version = $script:builderVersion; installedAtUtc = [DateTime]::UtcNow.ToString('o'); target = $Target; mode = $Mode
    toolProfile = $ToolProfile; localOnly = [bool]$LocalOnlyMode; updateExisting = [bool]$UpdateExisting
    backupFolder = $(if ($script:backupRoot) { '.sdd-installer-backups/' + $stamp } else { $null })
    excludeBlock = '# Added by Akzo SDD Development Builder (local-only files)'
    hook = $script:hookOwnership; gitTrackingCommands = $script:gitTrackingCommands
    trackedNotUpdated = $script:trackedSkipped.ToArray(); files = $script:manifest.ToArray()
}
$allInstalls = New-Object System.Collections.Generic.List[object]
foreach ($p in $previous) { $allInstalls.Add($p) }
$allInstalls.Add([pscustomobject]$install)
$doc = [ordered]@{ builder = 'Akzo SDD Development Builder'; currentVersion = $script:builderVersion; installs = $allInstalls.ToArray() }
$doc | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $manifestPath -Encoding UTF8

# ---------------------------------------------------------------- verify
Write-Step "Verification"
foreach ($agent in @(Get-ChildItem -LiteralPath (Join-Path $Destination ".github/agents") -File -Filter "akzo-sdd-*.agent.md" -ErrorAction SilentlyContinue)) {
    $marker = [regex]::Match((Get-Content -LiteralPath $agent.FullName -Raw), 'sdd-builder-version:\s*([0-9.]+)')
    $v = if ($marker.Success) { $marker.Groups[1].Value } else { 'pre-2.4 (no version marker)' }
    $color = if ($v -eq $script:builderVersion) { 'Green' } else { 'Red' }
    Write-Host ("  agent    {0}: version {1}" -f $agent.Name, $v) -ForegroundColor $color
}
if ($script:trackedSkipped.Count -gt 0) {
    Write-Host ""
    Write-Host ("WARNING: {0} Git-tracked builder file(s) were NOT updated (local-only mode never edits team-owned files):" -f $script:trackedSkipped.Count) -ForegroundColor Red
    $script:trackedSkipped | ForEach-Object { Write-Host "  - $_" -ForegroundColor Red }
    Write-Host "  The agent you run may still be the OLD version. Upgrade them through a reviewed PR:" -ForegroundColor Yellow
    Write-Host "  .\Install-DevelopmentBuilder.ps1 -Target $Target -Destination <repo> -UpdateExisting -TrackInstalledFiles   (on a branch, then review git diff)" -ForegroundColor Yellow
}
Get-ChildItem -LiteralPath (Join-Path $Destination ".github/agents") -File | Where-Object Name -Like "*sdd-developer*" | Select-Object Name
Get-ChildItem -LiteralPath (Join-Path $Destination ".github/skills") -Directory | Select-Object Name
Write-Host ("Installed/updated: {0}   Unchanged/kept: {1}" -f $script:installed, $script:skipped)

Write-Step "Git status (read-only)"
git -C $Destination status --short --branch

Write-Host "`nDone. Reopen Copilot Chat, select 'Akzo SDD Developer' (or '- Caveman Concise'), then type: Start Development" -ForegroundColor Green
Write-Host "Important: `"spec.md`" and `"plan.md`" under src/.github/specs/<ShortFeatureName> must be visible to Git for check-in." -ForegroundColor Yellow
Write-Host "Version-managed upgrade complete. Review Git changes before committing; existing PBI artifacts were preserved." -ForegroundColor DarkGray
