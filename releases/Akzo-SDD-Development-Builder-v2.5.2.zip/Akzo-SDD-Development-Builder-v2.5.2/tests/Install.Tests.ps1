﻿# Installation, upgrade, rollback and Git hygiene (Phase J). The .cmd launcher itself needs cmd.exe and
# Windows execution policy, so it is covered by static tests here and by the Windows checklist in the release notes.

$script:Installer = Join-Path $script:PackageRoot 'Install-DevelopmentBuilder.ps1'
$script:Uninstaller = Join-Path $script:PackageRoot 'Uninstall-DevelopmentBuilder.ps1'

function Invoke-Installer([string]$Repo, [string[]]$Extra = @()) {
    # Same parameters the .cmd launcher passes.
    $args2 = @('-Target', 'DAB', '-Destination', $Repo, '-Mode', 'Both', '-UpdateExisting', '-PruneLegacy', '-LocalOnlyMode') + $Extra
    $out = & $script:Pwsh -NoLogo -NoProfile -File $script:Installer @args2 2>&1 | Out-String
    return [pscustomobject]@{ ExitCode = $LASTEXITCODE; Output = ($out -replace "\x1b\[[0-9;]*m", '') }
}
function Get-GitStatus([string]$Repo) { return ((& git -C $Repo status --porcelain --untracked-files=all) | Out-String).Trim() }

Test 'Install.CleanInstallLeavesCleanGitStatus' {
    $r = New-FixtureRepo DAB
    $i = Invoke-Installer $r
    Assert-Equal 0 $i.ExitCode "installer exit: $($i.Output)"
    foreach ($p in @('.github/agents/akzo-sdd-developer.agent.md', '.github/agents/akzo-sdd-developer-concise.agent.md', 'tools/Start-SDD.ps1', 'tools/SDD.Common.psm1', 'tools/Assert-SDDArtifacts.ps1', 'tools/Approve-SDD.ps1', '.sdd-builder/manifest.json')) {
        Assert-True (Test-Path "$r/$p") "$p installed"
    }
    Assert-Equal '' (Get-GitStatus $r) 'local-only install shows no Git changes'
    Assert-Match $i.Output 'akzo-sdd-developer.agent.md: version 2.5.2' 'version verified'
} 'RequiresGit'

Test 'Install.RepeatedInstallIsIdempotent' {
    $r = New-FixtureRepo DAB
    $null = Invoke-Installer $r
    $i = Invoke-Installer $r
    Assert-Equal 0 $i.ExitCode 'second run succeeds'
    Assert-NotMatch $i.Output '(?m)^\s+(install|update|backup)\s' 'nothing copied or backed up again'
    Assert-True (-not (Test-Path "$r/.sdd-installer-backups")) 'no backups created'
    Assert-Equal '' (Get-GitStatus $r) 'still clean'
} 'RequiresGit'

Test 'Install.UpgradeReplacesUntrackedOldFilesWithBackup' {
    $r = New-FixtureRepo DAB
    Write-File "$r/tools/Start-SDD.ps1" "# v2.3.4 Start-SDD (old)`n"
    $i = Invoke-Installer $r
    Assert-Equal 0 $i.ExitCode 'upgrade succeeds'
    Assert-Match ([IO.File]::ReadAllText("$r/tools/Start-SDD.ps1")) 'Akzo SDD Builder v2.5.2' 'tool upgraded'
    $bak = @(Get-ChildItem "$r/.sdd-installer-backups" -Recurse -File -Force -Filter 'Start-SDD.ps1')
    Assert-Equal 1 $bak.Count 'old version backed up outside tools/'
    Assert-True (@(Get-ChildItem "$r/tools", "$r/.github" -Recurse -File -Force | Where-Object Name -match '\.backup-').Count -eq 0) 'no backup files next to agents/tools (RC-16)'
    Assert-Equal '' (Get-GitStatus $r) 'clean'
} 'RequiresGit'

Test 'Install.UpgradeFromV212TrackedAgentsIsReportedNotModified' {
    # Teams that committed v2.1.x agents: local-only mode must not edit them, and must SAY so (RC-15).
    $r = New-FixtureRepo DAB
    Write-File "$r/.github/agents/akzo-sdd-developer.agent.md" "---`nname: Akzo SDD Developer`n---`n# v2.1.2 agent`n"
    Invoke-Git $r @('add', '-A') | Out-Null; Invoke-Git $r @('commit', '-qm', 'team committed v2.1.2 agent') | Out-Null
    $i = Invoke-Installer $r
    Assert-Equal 0 $i.ExitCode 'installer completes'
    Assert-Match ([IO.File]::ReadAllText("$r/.github/agents/akzo-sdd-developer.agent.md")) 'v2.1.2 agent' 'tracked file untouched'
    Assert-Match $i.Output 'Git-tracked builder file\(s\) were NOT updated' 'warning printed'
    Assert-Match $i.Output 'akzo-sdd-developer.agent.md: version pre-2.4' 'old version detected'
    $m = Get-Content "$r/.sdd-builder/manifest.json" -Raw | ConvertFrom-Json
    Assert-True (@($m.installs[-1].trackedNotUpdated) -contains '.github/agents/akzo-sdd-developer.agent.md') 'recorded in manifest'
    Assert-Equal '' (Get-GitStatus $r) 'no tracked modification'
} 'RequiresGit'

Test 'Install.TrackedUpgradeThroughReviewedPr' {
    $r = New-FixtureRepo DAB
    Write-File "$r/.github/agents/akzo-sdd-developer.agent.md" "# v2.1.2 agent`n"
    Invoke-Git $r @('add', '-A') | Out-Null; Invoke-Git $r @('commit', '-qm', 'v2.1.2') | Out-Null
    $out = & $script:Pwsh -NoLogo -NoProfile -File $script:Installer -Target DAB -Destination $r -Mode Both -UpdateExisting -TrackInstalledFiles 2>&1 | Out-String
    Assert-Equal 0 $LASTEXITCODE "tracked upgrade: $out"
    Assert-Match (Get-GitStatus $r) 'M \.github/agents/akzo-sdd-developer\.agent\.md' 'change visible for the PR'
    $bak = @(Get-ChildItem "$r/.sdd-installer-backups" -Recurse -File -Force -Filter 'akzo-sdd-developer.agent.md')
    Assert-Equal 1 $bak.Count 'previous agent backed up'
} 'RequiresGit'

Test 'Install.SpecsAndAppCodeNeverHidden' {
    $r = New-FixtureRepo DAB
    $null = Invoke-Installer $r
    Write-File "$r/src/.github/specs/ComplaintImitationRequest/spec.md" "# s`n- PBI ID: 305183`n"
    Write-File "$r/src/AN.ColorAppsAzure.Formula/New.cs" "class N {}`n"
    $status = Get-GitStatus $r
    Assert-Match $status 'src/\.github/specs/ComplaintImitationRequest/spec\.md' 'spec visible to Git'
    Assert-Match $status 'src/AN\.ColorAppsAzure\.Formula/New\.cs' 'code visible to Git'
    $exclude = [IO.File]::ReadAllText("$r/.git/info/exclude")
    Assert-NotMatch $exclude '(?m)^\*\.md$|(?m)^/?src/\.github' 'no broad .md or specs exclusion'
    Write-File "$r/docs/sdd/pbi-input/305183/REFINED-PBI.md" "x"
    Assert-NotMatch (Get-GitStatus $r) 'pbi-input' 'local PBI input stays local'
} 'RequiresGit'

Test 'Install.WrongRepositoryStopsWithoutChanges' {
    $r = New-FixtureRepo Unknown
    $i = Invoke-Installer $r
    Assert-True ($i.ExitCode -ne 0) 'refuses'
    Assert-Match $i.Output 'does not look like DAB' 'clear reason'
    Assert-True (-not (Test-Path "$r/.github")) 'nothing written'
} 'RequiresGit'

Test 'Install.UnrestrictedToolProfileOmitsToolsLine' {
    $r = New-FixtureRepo DAB
    $i = Invoke-Installer $r @('-ToolProfile', 'Unrestricted')
    Assert-Equal 0 $i.ExitCode 'installs'
    Assert-NotMatch ([IO.File]::ReadAllText("$r/.github/agents/akzo-sdd-developer.agent.md")) '(?m)^tools:' 'tools line removed'
    Assert-Match ([IO.File]::ReadAllText("$r/.github/agents/akzo-sdd-developer.agent.md")) 'sdd-builder-version: 2.5.2' 'still versioned'
} 'RequiresGit'

Test 'Install.ConciseModeRetargetsPrompts' {
    $r = New-FixtureRepo DAB
    $out = & $script:Pwsh -NoLogo -NoProfile -File $script:Installer -Target DAB -Destination $r -Mode Concise -LocalOnlyMode 2>&1 | Out-String
    Assert-Equal 0 $LASTEXITCODE "concise install: $out"
    Assert-True (-not (Test-Path "$r/.github/agents/akzo-sdd-developer.agent.md")) 'full agent not installed'
    Assert-Match ([IO.File]::ReadAllText("$r/.github/prompts/start-akzo-sdd-development.prompt.md")) 'agent: Akzo SDD Developer - Caveman Concise' 'prompt points at concise agent'
} 'RequiresGit'

Test 'Install.UninstallRemovesOnlyBuilderFiles' {
    $r = New-FixtureRepo DAB
    $null = Invoke-Installer $r
    Write-File "$r/src/.github/specs/ComplaintImitationRequest/spec.md" "# s`n- PBI ID: 305183`n"
    Write-File "$r/docs/sdd/pbi-input/305183/REFINED-PBI.md" "keep me"
    Add-Content "$r/.github/sdd/constitution.md" "`nTeam edit after install.`n"
    $out = & $script:Pwsh -NoLogo -NoProfile -File $script:Uninstaller -Destination $r 2>&1 | Out-String
    Assert-Equal 0 $LASTEXITCODE "uninstall: $out"
    Assert-True (-not (Test-Path "$r/.github/agents/akzo-sdd-developer.agent.md")) 'agent removed'
    Assert-True (-not (Test-Path "$r/tools/Start-SDD.ps1")) 'tool removed'
    Assert-True (Test-Path "$r/.github/sdd/constitution.md") 'edited file kept'
    Assert-True (Test-Path "$r/src/.github/specs/ComplaintImitationRequest/spec.md") 'spec kept'
    Assert-True (Test-Path "$r/src/.github/specs/TechnicalRemarks/spec.md") 'existing spec kept'
    Assert-True (Test-Path "$r/docs/sdd/pbi-input/305183/REFINED-PBI.md") 'PBI input kept'
    Assert-True (Test-Path "$r/src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Common/Constants.cs") 'code kept'
    $ex = [IO.File]::ReadAllText("$r/.git/info/exclude")
    Assert-NotMatch $ex '(?m)^/tools/' 'builder file exclusions removed'
    Assert-Match $ex '(?m)^/docs/sdd/pbi-input/$' 'PBI inputs stay local-only after uninstall'
    Assert-NotMatch ((& git -C $r status --porcelain --untracked-files=all) -join "`n") 'pbi-input' 'PBI input still not in Git Changes'
} 'RequiresGit'

Test 'Install.RollbackLastUpgradeRestoresPreviousFiles' {
    $r = New-FixtureRepo DAB
    Write-File "$r/tools/Start-SDD.ps1" "# previous Start-SDD`n"
    $null = Invoke-Installer $r
    $out = & $script:Pwsh -NoLogo -NoProfile -File $script:Uninstaller -Destination $r -RollbackLastUpgrade 2>&1 | Out-String
    Assert-Equal 0 $LASTEXITCODE "rollback: $out"
    Assert-Equal "# previous Start-SDD`n" ([IO.File]::ReadAllText("$r/tools/Start-SDD.ps1")) 'previous version restored'
    Assert-True (-not (Test-Path "$r/tools/Approve-SDD.ps1")) 'files added by that upgrade removed'
} 'RequiresGit'

Test 'Install.CmdLauncherRespectsExecutionPolicy' {
    $cmd = [IO.File]::ReadAllText((Join-Path $script:PackageRoot 'Install-DevelopmentBuilder.cmd'))
    Assert-Match $cmd "\`$effective -in @\('AllSigned','Restricted'\)\) \{ throw" 'AllSigned/Restricted refused'
    Assert-Match $cmd "if \(\`$effective -eq 'RemoteSigned'\)" 'unblocking only under RemoteSigned'
    Assert-NotMatch $cmd '(?i)Set-ExecutionPolicy|-ExecutionPolicy\s+Bypass|Unrestricted''' 'never changes or bypasses policy'
    Assert-Match $cmd 'Install-DevelopmentBuilder\.ps1' 'launches the bundled installer'
    Assert-Match $cmd '(?m)^:usage' 'usage label present'
} 'Static'

Test 'Install.PackageFilesUseWindowsSafeEncoding' {
    foreach ($f in (Get-ChildItem $script:PackageRoot -Recurse -File -Include '*.ps1', '*.psm1', '*.cmd' | Where-Object { $_.FullName -notmatch '[\\/]tests[\\/]results' })) {
        $bytes = [IO.File]::ReadAllBytes($f.FullName)
        $nonAscii = @($bytes | Where-Object { $_ -gt 127 }).Count
        $bom = $bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF
        if ($f.Extension -eq '.cmd') { Assert-Equal 0 $nonAscii "$($f.Name) must be ASCII" }
        elseif ($nonAscii -gt ($(if ($bom) { 3 } else { 0 }))) { Assert-True $bom "$($f.Name) contains non-ASCII text and needs a UTF-8 BOM for Windows PowerShell 5.1" }
    }
} 'Static'

Test 'Install.UpgradeKeepsTeamOwnedConfigAndDocs' {
    # v2.3.4 regression: the .cmd always passes -UpdateExisting, which replaced config.md, sonar rules and
    # docs/architecture on every run (with a backup) and dropped the developer's confirmed build commands.
    $r = New-FixtureRepo DAB
    $null = Invoke-Installer $r
    Add-Content "$r/.github/sdd/config.md" "`n| CONFIRMED_BUILD | msbuild custom.sln |`n"
    Add-Content "$r/docs/architecture/STATUS-AND-VERSIONING.md" "`nTeam note: complaint suffix confirmed.`n"
    $i = Invoke-Installer $r
    Assert-Equal 0 $i.ExitCode 'upgrade runs'
    Assert-Match ([IO.File]::ReadAllText("$r/.github/sdd/config.md")) 'CONFIRMED_BUILD' 'config edits kept'
    Assert-Match ([IO.File]::ReadAllText("$r/docs/architecture/STATUS-AND-VERSIONING.md")) 'Team note' 'architecture doc edits kept'
} 'RequiresGit'
