﻿# v2.5.2 regression tests. IDE behavior is a simulated contract, never a live VS claim.
function Import-ExecutionModule { Import-Module (Join-Path $script:Tools 'SDD.Common.psm1') -Force -Global }
function Invoke-FixtureVerification([string]$Repo,[string]$Build='git --version',[string]$Test='git status --short',[string[]]$Extra=@()) {
    Invoke-Tool 'Invoke-SDDVerification.ps1' (@('-Repository',$Repo,'-Feature','ComplaintImitationRequest','-Build',$Build,'-Test',$Test) + $Extra)
}
function New-RunnerCommand([string]$Repo,[string]$Name,[string]$Body) {
    $path = "$Repo/.sdd-builder/test-runner/$Name.ps1"
    Write-File $path $Body
    return '"' + $script:Pwsh + '" -NoLogo -NoProfile -File "' + $path + '"'
}

Test 'V252.WorkflowAuthorityAndPauseBudget' {
    $workflow = [IO.File]::ReadAllText("$script:PackageRoot/core/.github/sdd/workflow.md")
    Assert-Match $workflow 'FAST is the default' 'FAST default'
    Assert-Match $workflow 'STEP performs one task and pauses only when explicitly requested' 'STEP explicit'
    Assert-Match $workflow 'Mandatory pauses after approval: zero' 'pause budget'
    $agents = @(Get-ChildItem "$script:PackageRoot/core/.github/agents" -Filter '*developer*.md')
    foreach ($a in $agents) {
        $s = [IO.File]::ReadAllText($a.FullName)
        Assert-Match $s '\.github/sdd/workflow.md' 'authority referenced'
        Assert-True ($s.Length -lt 3500) 'always-loaded agent size budget'
    }
    foreach ($f in Get-ChildItem "$script:PackageRoot/core/.github" -Recurse -File -Filter '*.md') {
        Assert-NotMatch ([IO.File]::ReadAllText($f.FullName)) '(?i)step mode \(default ON\)|in step mode|one file, one change, one build|STEP_MODE`\s*\|\s*`on' "No competing step defaults in $($f.Name)"
    }
} 'Static'

Test 'V252.PbiBranchAndPersistedSelection' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    Invoke-Git $r @('checkout','-qb','feature/305183-complaint') | Out-Null
    $a = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',$r,'-Title','Complaint Imitation Request')
    Assert-Equal '305183' $a.Data.pbiId 'branch identity'
    Assert-Equal 'FAST' $a.Data.executionMode 'default mode'
    Invoke-Git $r @('checkout','-qb','feature/no-id') | Out-Null
    $b = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',$r)
    Assert-Equal '305183' $b.Data.pbiId 'persisted identity'
    Assert-Equal 'Resumed' $b.Data.status 'resume same feature'
} 'RequiresGit'

Test 'V252.PbiConflictCannotSilentlySwitch' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    Invoke-Git $r @('checkout','-qb','feature/305184-other') | Out-Null
    $a = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',$r,'-Request','Start Development 305183 Complaint Imitation Request')
    Assert-Equal 7 $a.ExitCode 'conflict rejected'
    Assert-Equal 'PbiConflict' $a.Data.status 'one precise conflict'
    Assert-True (-not (Test-Path "$r/.sdd-builder/active-pbi.json")) 'no pin before resolution'
    $b = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',$r,'-Request','Start Development 305183 Complaint Imitation Request','-ConfirmPbiSelection')
    Assert-Equal 0 $b.ExitCode 'explicit confirmed resolution'
} 'RequiresGit'

Test 'V252.PersistedConflictAndArgumentConflict' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    Write-File "$r/.sdd-builder/settings.json" '{"activePbi":"305184"}'
    $a = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',$r,'-PbiId','305183','-Title','Complaint Imitation Request')
    Assert-Equal 7 $a.ExitCode 'persisted conflict'
    $b = Invoke-Tool 'Start-SDD.ps1' @('-Repository',$r,'-PbiId','305184','-Request','Start Development 305183 Complaint Imitation Request')
    Assert-True ($b.ExitCode -ne 0) 'two explicit identities rejected'
}

Test 'V252.SourceAndConfigurationInvalidateEvidence' {
    $r = New-ApprovedFixture
    Assert-Equal 0 (Invoke-FixtureVerification $r).ExitCode 'initial execution'
    $v = Invoke-FixtureVerification $r
    Assert-Match $v.Output 'REUSED' 'unchanged successful commands reused'
    Add-Content "$r/src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Common/Constants.cs" '// source changed'
    $a = Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-Stage','ImplementationVerified')
    Assert-Equal 1 $a.ExitCode 'stale source rejected'
    Assert-Match $a.Output 'fingerprint' 'source diagnosis'
    Assert-Equal 0 (Invoke-FixtureVerification $r).ExitCode 'fresh source reverified'
    Write-File "$r/global.json" '{"sdk":{"version":"8.0.100"}}'
    Assert-Equal 1 (Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-Stage','ImplementationVerified')).ExitCode 'SDK configuration invalidates'
}

Test 'V252.RunnerTimeoutAndRealLogs' {
    $r = New-ApprovedFixture
    $slow = New-RunnerCommand $r 'slow' 'Start-Sleep -Seconds 20'
    $v = Invoke-FixtureVerification $r $slow 'git --version' @('-TimeoutSeconds','1')
    Assert-Equal 1 $v.ExitCode 'timeout fails'
    $j = Get-Content "$r/$script:Work/verification.json" -Raw | ConvertFrom-Json
    Assert-Equal -1 $j.checks[0].exitCode 'timeout code'
    Assert-Match $j.checks[0].reason 'Timed out' 'timeout reason'
    Assert-True (-not $j.checks[1].executed) 'test invalidated after failed build'
    Assert-True (Test-Path "$r/$($j.checks[0].logFile)") 'log saved'
}

Test 'V252.RunnerBoundedTransientRetries' {
    $r = New-ApprovedFixture
    $body = '$p=Join-Path $PSScriptRoot "attempt.txt"; $n=0; if(Test-Path $p){$n=[int](Get-Content $p)}; $n++; Set-Content $p $n; if($n -lt 2){[Console]::Error.WriteLine("transient fixture failure");exit 75}; Write-Output "recovered"'
    $cmd = New-RunnerCommand $r 'transient' $body
    $v = Invoke-FixtureVerification $r $cmd 'git --version' @('-MaxRetries','1')
    Assert-Equal 0 $v.ExitCode "transient recovers: $($v.Output)"
    $j = Get-Content "$r/$script:Work/verification.json" -Raw | ConvertFrom-Json
    Assert-Equal 2 @($j.checks[0].attempts).Count 'bounded retry count'
    Assert-Equal 75 $j.checks[0].attempts[0].exitCode 'original exit preserved'
    Assert-Match ([IO.File]::ReadAllText("$r/$($j.checks[0].attempts[0].logFile)")) 'transient fixture failure' 'stderr captured'
    $bad = New-RunnerCommand $r 'bad' 'exit 7'
    $b = Invoke-FixtureVerification $r $bad 'git --version' @('-MaxRetries','2')
    $j = Get-Content "$r/$script:Work/verification.json" -Raw | ConvertFrom-Json
    Assert-Equal 1 @($j.checks[0].attempts).Count 'implementation error not blindly retried'
    Assert-Equal 7 $j.checks[0].exitCode 'real failure exit'
}

Test 'V252.InterruptedCheckpointNeverPasses' {
    $r = New-ApprovedFixture
    $null = Invoke-FixtureVerification $r
    $file = "$r/$script:Work/verification.json"
    $doc = Get-Content $file -Raw | ConvertFrom-Json
    $doc.checks[0].executed=$false; $doc.checks[0].exitCode=$null; $doc.checks[0].reason='INTERRUPTED'
    Write-File $file ($doc | ConvertTo-Json -Depth 10)
    Assert-Equal 1 (Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-Stage','ImplementationVerified')).ExitCode 'incomplete checkpoint rejected'
    $v=Invoke-FixtureVerification $r
    Assert-Equal 0 $v.ExitCode 'interruption recovered'
    Assert-NotMatch $v.Output 'REUSED' 'incomplete run never reused'
}

Test 'V252.ProjectDependencySelectionAndMapCache' {
    Import-ExecutionModule
    $r=New-FixtureRepo DAB
    Write-File "$r/src/Common/Common.csproj" '<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFramework>net8.0</TargetFramework></PropertyGroup></Project>'
    Write-File "$r/src/App/App.csproj" '<Project Sdk="Microsoft.NET.Sdk"><ItemGroup><ProjectReference Include="../Common/Common.csproj" /></ItemGroup></Project>'
    Write-File "$r/tests/App.Tests/App.Tests.csproj" '<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><IsTestProject>true</IsTestProject></PropertyGroup><ItemGroup><ProjectReference Include="../../src/App/App.csproj" /></ItemGroup></Project>'
    Write-File "$r/tests/Other.Tests/Other.Tests.csproj" '<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><IsTestProject>true</IsTestProject></PropertyGroup></Project>'
    $p=Get-SDDVerificationPlan $r @('src/Common/Rule.cs') Targeted
    Assert-Equal 1 @($p.testTargets).Count 'transitive dependent selected'
    Assert-Equal 'tests/App.Tests/App.Tests.csproj' $p.testTargets[0] 'correct dependent'
    Assert-True (-not $p.map.cacheHit) 'first map built'
    $p=Get-SDDVerificationPlan $r @('src/Common/Rule.cs') Targeted
    Assert-True $p.map.cacheHit 'unchanged project map reused'
    Write-File "$r/Directory.Build.props" '<Project />'
    $p=Get-SDDVerificationPlan $r @('src/Common/Rule.cs') Targeted
    Assert-True (-not $p.map.cacheHit) 'config invalidates map'
    Assert-Equal 2 @($p.testTargets).Count 'imports trigger conservative full test selection'
    Assert-Equal 2 @((Get-SDDVerificationPlan $r @('src/Common/Rule.cs') Final).testTargets).Count 'final regression all tests'
}

Test 'V252.SolutionGuardReportsWithoutRestoring' {
    $r=New-ApprovedFixture
    Add-Content "$r/AN.ColorAppsAzure.BL.sln" '# accidental VS edit'
    $v=Invoke-FixtureVerification $r
    Assert-True ($v.ExitCode -ne 0) 'unplanned solution blocked'
    Assert-Match $v.Output 'AN.ColorAppsAzure.BL.sln' 'exact path'
    Assert-Match $v.Output 'git restore' 'reviewable restoration recommendation'
    Assert-Match ([IO.File]::ReadAllText("$r/AN.ColorAppsAzure.BL.sln")) 'accidental VS edit' 'never restored'
    $status=Invoke-ToolJson 'Get-SDDStatus.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-PbiId','305183')
    Assert-True (@($status.Data.checks | Where-Object { $_.area -eq 'Solution' -and $_.status -eq 'FAIL' }).Count -eq 1) 'status guard'
}

Test 'V252.IntentionalSolutionEditRequiresApprovedPlan' {
    $r=New-ApprovedFixture
    $plan="$r/src/.github/specs/ComplaintImitationRequest/plan.md"
    $s=[IO.File]::ReadAllText($plan).Replace('## Affected source files and components',"## Affected source files and components`n`n- Modify ``AN.ColorAppsAzure.BL.sln`` for the approved project addition.")
    Write-File $plan $s
    Assert-Equal 0 (Invoke-Tool 'Approve-SDD.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-Statement','Approved solution addition')).ExitCode 'reapproved plan'
    Add-Content "$r/AN.ColorAppsAzure.BL.sln" '# intended edit'
    Assert-Equal 0 (Invoke-FixtureVerification $r).ExitCode 'approved solution modification allowed'
}

Test 'V252.ResumeVerifiedProgressAndStaleDetection' {
    $r=New-ApprovedFixture
    $null=Invoke-FixtureVerification $r
    $a=Invoke-Tool 'Update-SDDProgress.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-Tasks','T1,T2','-Evidence','Fixture checkpoint validated')
    Assert-Equal 0 $a.ExitCode "checkpoint saved: $($a.Output)"
    $g=Invoke-ToolJson 'Get-SDDProgress.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest')
    Assert-Equal 'FAST' $g.Data.mode 'FAST persisted'
    Assert-Equal 2 @($g.Data.remaining).Count 'only remaining tasks'
    Assert-Equal 'UNKNOWN' $g.Data.previous.metrics.actualTokens 'no invented tokens'
    Add-Content "$r/src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Common/Constants.cs" '// changed'
    $g=Invoke-ToolJson 'Get-SDDProgress.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest')
    Assert-Match $g.Data.status 'STALE' 'changed checkpoint invalidated'
    Assert-Equal 0 @($g.Data.completed).Count 'no stale completion claim'
}

Test 'V252.ExtractionCacheContentInvalidation' {
    $r=New-FixtureRepo DAB; Add-RefinedPbi $r
    $null=Invoke-Tool 'Start-SDD.ps1' @('-Repository',$r,'-PbiId','305183','-Title','Complaint Imitation Request')
    $cache=@(Get-ChildItem "$r/.sdd-builder/cache/extraction" -File)
    Assert-True ($cache.Count -gt 0) 'extraction cached'
    $before=@($cache | ForEach-Object { (Get-FileHash $_.FullName).Hash }) -join ','
    $null=Invoke-Tool 'Start-SDD.ps1' @('-Repository',$r,'-PbiId','305183','-Title','Complaint Imitation Request')
    Assert-Equal $before (@(Get-ChildItem "$r/.sdd-builder/cache/extraction" -File | ForEach-Object { (Get-FileHash $_.FullName).Hash }) -join ',') 'unchanged extraction cache not rewritten'
    Write-File "$r/docs/sdd/pbi-input/305183/attachments/new.txt" 'New supporting evidence'
    $null=Invoke-Tool 'Start-SDD.ps1' @('-Repository',$r,'-PbiId','305183','-Title','Complaint Imitation Request')
    Assert-True (@(Get-ChildItem "$r/.sdd-builder/cache/extraction" -File).Count -gt $cache.Count) 'new content gets new cache entry'
}

Test 'V252.RollbackPreservesModifiedHookAndSettings' {
    $r=New-FixtureRepo DAB; $null=Invoke-Installer $r
    Add-Content "$r/.git/hooks/pre-commit" '# team edit'
    Write-File "$r/.sdd-builder/settings.json" '{"role":"DAB"}'
    $out=& $script:Pwsh -NoLogo -NoProfile -File $script:Uninstaller -Destination $r 2>&1 | Out-String
    Assert-Equal 0 $LASTEXITCODE "uninstall: $out"
    Assert-True (Test-Path "$r/.git/hooks/pre-commit") 'modified hook kept'
    Assert-True (Test-Path "$r/.sdd-builder/settings.json") 'user settings kept'
    Assert-True (Test-Path "$r/.sdd-builder/manifest.json") 'unresolved ownership retained'
} 'RequiresGit'

Test 'V252.RollbackRejectsTamperedBackupAndTraversal' {
    $r=New-FixtureRepo DAB; Write-File "$r/tools/Start-SDD.ps1" '# previous'
    $null=Invoke-Installer $r
    $mp="$r/.sdd-builder/manifest.json"; $m=Get-Content $mp -Raw | ConvertFrom-Json
    $entry=@($m.installs[-1].files | Where-Object path -eq 'tools/Start-SDD.ps1')[0]
    Write-File "$r/$($entry.backup)" '# corrupt backup'
    $before=(Get-FileHash "$r/tools/Start-SDD.ps1").Hash
    $out=& $script:Pwsh -NoLogo -NoProfile -File $script:Uninstaller -Destination $r -RollbackLastUpgrade 2>&1 | Out-String
    Assert-Equal $before (Get-FileHash "$r/tools/Start-SDD.ps1").Hash 'corrupt backup never restored'
    $m.installs[-1].files[0].path='../outside.txt'; Write-File $mp ($m | ConvertTo-Json -Depth 10)
    $out=& $script:Pwsh -NoLogo -NoProfile -File $script:Uninstaller -Destination $r 2>&1 | Out-String
    Assert-True ($LASTEXITCODE -ne 0) 'path traversal refused before mutations'
} 'RequiresGit'

Test 'V252.NoOpUpgradeRollbackKeepsEarlierHook' {
    $r=New-FixtureRepo DAB; $null=Invoke-Installer $r; $null=Invoke-Installer $r
    $out=& $script:Pwsh -NoLogo -NoProfile -File $script:Uninstaller -Destination $r -RollbackLastUpgrade 2>&1 | Out-String
    Assert-Equal 0 $LASTEXITCODE 'rollback no-op install'
    Assert-True (Test-Path "$r/.git/hooks/pre-commit") 'earlier hook retained'
    $m=Get-Content "$r/.sdd-builder/manifest.json" -Raw | ConvertFrom-Json
    Assert-Equal 1 @($m.installs).Count 'one record remains'
    Assert-True ($m.installs[0].gitTrackingCommands -le 2) 'Git tracking snapshot budget'
    Assert-NotMatch ([IO.File]::ReadAllText("$r/.git/hooks/pre-commit")) 'ExecutionPolicy Bypass|--no-verify' 'policy respected'
} 'RequiresGit'

Test 'V252.UpgradePreservesUserModifiedOwnedFile' {
    $r=New-FixtureRepo DAB; $null=Invoke-Installer $r
    Add-Content "$r/tools/Start-SDD.ps1" '# my customization'
    $a=Invoke-Installer $r
    Assert-Equal 0 $a.ExitCode 'upgrade succeeds'
    Assert-Match ([IO.File]::ReadAllText("$r/tools/Start-SDD.ps1")) 'my customization' 'user edits retained'
} 'RequiresGit'

Test 'V252.ReproducibleReleaseAndManifestIntegrity' {
    $out=New-TestRoot
    $builder=Join-Path $script:PackageRoot 'release/Build-Release.ps1'
    $null=& $script:Pwsh -NoLogo -NoProfile -File $builder -PackageRoot $script:PackageRoot -OutputDirectory $out -SkipTests 2>&1
    Assert-Equal 0 $LASTEXITCODE 'first packaging'
    $zip="$out/Akzo-SDD-Development-Builder-v2.5.2.zip"; $h=(Get-FileHash $zip).Hash
    $null=& $script:Pwsh -NoLogo -NoProfile -File $builder -PackageRoot $script:PackageRoot -OutputDirectory $out -SkipTests 2>&1
    Assert-Equal 0 $LASTEXITCODE 'second packaging'
    Assert-Equal $h (Get-FileHash $zip).Hash 'repeat-build ZIP hashes identical'
    $dest=Join-Path $out 'extracted'; Expand-Archive -LiteralPath $zip -DestinationPath $dest
    $pkg=Join-Path $dest 'Akzo-SDD-Development-Builder-v2.5.2'
    $manifest=Get-Content "$pkg/release/RELEASE-MANIFEST.json" -Raw | ConvertFrom-Json
    foreach ($f in $manifest.files) { Assert-Equal $f.sha256 (Get-FileHash "$pkg/$($f.path)" -Algorithm SHA256).Hash.ToLowerInvariant() "manifest $($f.path)" }
    Assert-True (-not (Test-Path "$pkg/release/TEST-REPORT.json")) 'no run-specific reports in package'
    Assert-Equal ($manifest.fileCount+1) @(Get-ChildItem $pkg -Recurse -Force -File).Count 'manifest covers every payload file'
}

Test 'V252.ApprovedStandaloneHandoffDiscovery' {
    $r=New-FixtureRepo DAB
    $source=[IO.File]::ReadAllText((Join-Path $script:FixtureData '305183/REFINED-PBI.md'))
    Write-File "$r/docs/sdd/pbi-sources/305183-ComplaintImitationRequest/HANDOFF.md" $source
    $s=Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',$r,'-Request','Start Development 305183 Complaint Imitation Request')
    Assert-Equal 0 $s.ExitCode "approved handoff: $($s.Output)"
    Assert-Equal 'ApprovedHandoff' $s.Data.sourceKind 'approved identity-checked handoff accepted'
}

Test 'V252.ConflictResolutionDoesNotAskAgainForSameBranch' {
    $r=New-FixtureRepo DAB; Add-RefinedPbi $r
    Invoke-Git $r @('checkout','-qb','feature/305184-other') | Out-Null
    Write-File "$r/.sdd-builder/settings.json" '{"activePbi":"305184","role":"DAB"}'
    $s=Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',$r,'-Request','Start Development 305183 Complaint Imitation Request','-ConfirmPbiSelection')
    Assert-Equal 0 $s.ExitCode 'explicit resolution'
    $s=Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',$r)
    Assert-Equal 0 $s.ExitCode 'same conflict answer reused'
    Assert-Equal '305183' $s.Data.pbiId 'confirmed ID kept'
    Invoke-Git $r @('checkout','-qb','feature/305185-third') | Out-Null
    $s=Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',$r)
    Assert-Equal 7 $s.ExitCode 'new branch conflict asks again'
} 'RequiresGit'

Test 'V252.FinalRegressionAndNullExitRequired' {
    $r=New-ApprovedFixture
    $null=Invoke-FixtureVerification $r 'git --version' 'git status --short' @('-Scope','Targeted')
    Write-File "$r/$script:Work/review.md" "# Review`nOpen findings: 0`n"
    Write-File "$r/$script:Work/completion.md" 'AC traceability documented'
    $a=Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-Stage','PRReady')
    Assert-Equal 1 $a.ExitCode 'targeted is insufficient for PR'
    Assert-Match $a.Output 'Final regression' 'specific diagnosis'
    $null=Invoke-FixtureVerification $r
    $file="$r/$script:Work/verification.json"; $j=Get-Content $file -Raw | ConvertFrom-Json
    $j.checks[0].exitCode=$null; Write-File $file ($j | ConvertTo-Json -Depth 10)
    $a=Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-Stage','ImplementationVerified')
    Assert-Equal 1 $a.ExitCode 'null exit never coerced to success'
}

Test 'V252.CapabilityAdvertisedExecutableCanFail' {
    # Put a callable failing dotnet stub first on PATH. Host IDE APIs stay UNKNOWN.
    $r=New-FixtureRepo DAB; $bin=Join-Path (New-TestRoot) 'bin'; [void][IO.Directory]::CreateDirectory($bin)
    if ($env:OS -eq 'Windows_NT') { Write-File "$bin/dotnet.cmd" "@echo off`r`nexit /b 23`r`n" }
    else { Write-File "$bin/dotnet" "#!/bin/sh`nexit 23`n"; & chmod +x "$bin/dotnet" }
    $priorPath=$env:PATH
    try {
        $env:PATH=$bin+[IO.Path]::PathSeparator+$priorPath
        $a=Invoke-ToolJson 'Test-SDDCapabilities.ps1' @('-Repository',$r)
        Assert-True $a.Data.tools.dotnet.advertised 'executable discovered'
        Assert-True $a.Data.tools.dotnet.executed 'probe actually executed'
        Assert-True (-not $a.Data.tools.dotnet.succeeded) 'failed probe not success'
        Assert-True (-not $a.Data.tools.dotnet.available) 'failed probe not build capability'
        Assert-Equal 23 $a.Data.tools.dotnet.exitCode 'exit code retained'
        Assert-Equal 'UNKNOWN' $a.Data.agent.testExplorer 'IDE not inferred'
    } finally { $env:PATH=$priorPath }
}

Test 'V252.ProcessCancellationLeavesIncompleteEvidence' {
    $r=New-ApprovedFixture
    $slow=New-RunnerCommand $r 'cancel' 'Start-Sleep -Seconds 30'
    $psi=New-Object Diagnostics.ProcessStartInfo
    $psi.FileName=$script:Pwsh; $psi.UseShellExecute=$false
    $psi.RedirectStandardOutput=$true; $psi.RedirectStandardError=$true
    $argsList=@('-NoLogo','-NoProfile','-File',(Join-Path $script:Tools 'Invoke-SDDVerification.ps1'),'-Repository',$r,'-Feature','ComplaintImitationRequest','-Build',$slow,'-Test','git --version')
    if ($PSVersionTable.PSVersion.Major -ge 7) { foreach($arg in $argsList){$psi.ArgumentList.Add($arg)} }
    else { $psi.Arguments=(@($argsList | ForEach-Object { '"'+$_.Replace('"','\"')+'"' })) -join ' ' }
    $proc=[Diagnostics.Process]::Start($psi)
    $outTask=$proc.StandardOutput.ReadToEndAsync(); $errTask=$proc.StandardError.ReadToEndAsync()
    try {
        $file="$r/$script:Work/verification.json"; $limit=[DateTime]::UtcNow.AddSeconds(15)
        while(-not (Test-Path $file) -and [DateTime]::UtcNow -lt $limit -and -not $proc.HasExited){Start-Sleep -Milliseconds 100}
        Assert-True (Test-Path $file) 'pending checkpoint persisted before execution'
        if(-not $proc.HasExited){if($PSVersionTable.PSVersion.Major -ge 7){$proc.Kill($true)}else{& taskkill.exe /PID $proc.Id /T /F | Out-Null}}
        [void]$proc.WaitForExit(5000)
        $j=Get-Content $file -Raw | ConvertFrom-Json
        Assert-True (-not $j.checks[0].executed -or $null -eq $j.checks[0].exitCode -or $j.checks[0].exitCode -ne 0) 'cancelled process never passed'
        $gate=Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-Stage','ImplementationVerified')
        Assert-Equal 1 $gate.ExitCode 'cancelled evidence blocks readiness'
    } finally {
        if(-not $proc.HasExited){if($PSVersionTable.PSVersion.Major -ge 7){$proc.Kill($true)}else{$proc.Kill()}}
        $proc.Dispose()
    }
}

Test 'V252.NoBlockingQuestionsDoesNotMeanBusinessApproval' {
    Import-ExecutionModule
    Assert-True (-not (Get-SDDPbiApprovalState "Blocking questions: None`nTechnical feasibility review: Approved").Approved) 'no invented business approval'
    Assert-True (-not (Get-SDDPbiApprovalState "Status: Ready`nBusiness approval: Not approved").Approved) 'explicit rejection wins'
    Assert-True (Get-SDDPbiApprovalState "Status: Approved`nBlocking questions: None").Approved 'actual approval accepted'
    $r=New-ApprovedFixture
    $a=Invoke-Tool 'Approve-SDD.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-Statement','Not approved')
    Assert-True ($a.ExitCode -ne 0) 'negative approval rejected'
}

Test 'V252.EmptyTestSelectionDoesNotPass' {
    $out=New-TestRoot
    $log=& $script:Pwsh -NoLogo -NoProfile -File (Join-Path $script:PackageRoot 'tests/Run-Tests.ps1') -Filter 'DefinitelyNoMatchingTest.*' -ReportDirectory $out 2>&1 | Out-String
    Assert-True ($LASTEXITCODE -ne 0) 'zero tests fail runner'
    Assert-Match $log 'No tests matched' 'specific diagnosis'
}
