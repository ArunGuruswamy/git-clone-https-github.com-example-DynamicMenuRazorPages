﻿# v2.5 - single PBI input folder docs/sdd/pbi-input/<PBI-ID>/ with refined PBI, PBI Builder companion files
# and Azure DevOps attachments. Covers the acceptance tests of the "Single PBI Input Folder" brief, section 8.

function Start-Pkg([string]$Repo, [string[]]$Extra = @()) {
    return (Invoke-ToolJson 'Start-SDD.ps1' (@('-Repository', $Repo, '-Request', 'Start Development 305183 Complaint Imitation Request') + $Extra))
}
function Gate([string]$Repo, [string]$Stage = 'AnalysisComplete') {
    return (Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $Repo, '-Feature', 'ComplaintImitationRequest', '-Stage', $Stage))
}
function Add-Package([string]$Repo) {
    $pkg = Copy-PackageFixture (Join-Path $Repo 'docs/sdd/pbi-input/305183')
    return $pkg
}

Test 'Inputs.RefinedPbiDiscoveredFromNumberedFolder' {
    $r = New-FixtureRepo DAB; $null = Add-Package $r
    # A companion document that claims 'Status: Approved' must not replace REFINED-PBI.md as the primary source.
    Write-File "$r/docs/sdd/pbi-input/305183/Approved technical remarks.md" "# Technical remarks`n`nStatus: Approved`n`n- Reuse the existing endpoint.`n"
    $x = Start-Pkg $r
    Assert-Equal 0 $x.ExitCode "start: $($x.Output)"
    Assert-Equal 'docs/sdd/pbi-input/305183/REFINED-PBI.md' $x.Data.source 'REFINED-PBI.md in the numbered folder is the primary source'
    Assert-Equal '[CAA][DAB API] Complaint Imitation Request' $x.Data.pbiTitle 'full PBI title taken from the H1 without the ID'
    $inv = Get-Inventory $r
    $roles = @{}; foreach ($i in $inv.items) { $roles[$i.packagePath] = $i.role }
    Assert-Equal 'Primary' $roles['REFINED-PBI.md'] 'primary role'
    Assert-Equal 'Original' $roles['REQUEST.md'] 'original request role'
    Assert-Equal 'Supporting' $roles['Approved technical remarks.md'] 'extra Markdown is supporting evidence'
    Assert-Equal 'History' $roles['history/2026-10-07-q01-new-sample-status/REFINED-PBI-SNAPSHOT.md'] 'history snapshot not a requirement source'
}

Test 'Inputs.AttachmentsDiscoveredRecursively' {
    $r = New-FixtureRepo DAB; $null = Add-Package $r
    $a = "$r/docs/sdd/pbi-input/305183/attachments"
    Write-File "$a/rules.txt" "Rule list for AC-1.`n"
    Write-File "$a/screens/ir/create/notes.md" "# Screen notes`n`nThe create screen shows the complaint version.`n"
    New-PngFile "$a/screens/ir/create/complaint-create.png" 1280 720
    New-JpegFile "$a/screens/photo.jpg" 800 600
    $x = Start-Pkg $r
    Assert-Equal 0 $x.ExitCode 'start'
    $paths = @((Get-Inventory $r).items | ForEach-Object { $_.packagePath })
    foreach ($p in @('attachments/rules.txt', 'attachments/screens/ir/create/notes.md', 'attachments/screens/ir/create/complaint-create.png', 'attachments/screens/photo.jpg')) {
        Assert-True ($paths -contains $p) "attachment found recursively: $p"
    }
    $spec = [IO.File]::ReadAllText("$r/src/.github/specs/ComplaintImitationRequest/spec.md")
    Assert-Match $spec '\| `attachments/screens/ir/create/complaint-create\.png` \| png \| Attachment \| RequiresAgentReview: PNG image 1280x720' 'spec sources table pre-filled with every attachment'
}

Test 'Inputs.PbiIdValidated' {
    $r = New-FixtureRepo DAB
    # 1. A package whose refined PBI declares another ID is refused on import; nothing is copied.
    $pkg = Copy-PackageFixture (Join-Path (New-TestRoot) 'download')
    $t = [IO.File]::ReadAllText("$pkg/REFINED-PBI.md").Replace('# 305183 -', '# 305184 -')
    Write-File "$pkg/REFINED-PBI.md" $t
    $x = Invoke-ToolJson 'Add-SDDPbiInput.ps1' @('-Repository', $r, '-PbiId', '305183', $pkg)
    Assert-Equal 6 $x.ExitCode 'mismatch exit code'
    Assert-Equal 'PbiMismatch' $x.Data.status 'mismatch status'
    Assert-True (-not (Test-Path "$r/docs/sdd/pbi-input/305183")) 'nothing imported on mismatch'
    # 2. A document of another PBI inside this PBI's folder is excluded and reported.
    $null = Add-Package $r
    Write-File "$r/docs/sdd/pbi-input/305183/attachments/other.md" "# Other`n`n- PBI ID: 305999`n`nUnrelated requirement: AC-1 must send an email.`n"
    $s = Start-Pkg $r
    Assert-Equal 0 $s.ExitCode 'start'
    $other = @((Get-Inventory $r).items | Where-Object { $_.packagePath -eq 'attachments/other.md' })[0]
    Assert-Equal 'ForeignPbi' $other.status 'foreign document excluded'
    Assert-Match ($s.Data.discrepancies -join "`n") 'PX-FOREIGN-[0-9A-F]{4} OtherPbiDocument' 'foreign document reported as discrepancy'
}

Test 'Inputs.SupportedFormatsParsed' {
    $r = New-FixtureRepo DAB; $null = Add-Package $r
    $a = "$r/docs/sdd/pbi-input/305183/attachments"
    Write-File "$a/notes.txt" "TXT-MARKER plain text`n"
    Write-File "$a/matrix.csv" "Rule,Value`nCSV-MARKER,1`n"
    Write-File "$a/payload.json" "{ ""marker"": ""JSON-MARKER"" }`n"
    New-DocxFile "$a/Business rules.docx" @('DOCX-MARKER business rule one', 'Second paragraph')
    New-XlsxFile "$a/validation.xlsx" 'Rules' @(, @('XLSX-MARKER', 'Due date', '42'))
    New-PngFile "$a/screen.png" 320 200
    New-JpegFile "$a/photo.jpeg" 1024 768
    New-PdfFile "$a/design.pdf" 'PDF-MARKER design note'
    $old = $env:SDD_DISABLE_EXTERNAL_EXTRACTORS
    try {
        $env:SDD_DISABLE_EXTERNAL_EXTRACTORS = '1'
        $x = Start-Pkg $r
        Assert-Equal 0 $x.ExitCode 'start'
        $items = @{}; foreach ($i in (Get-Inventory $r).items) { $items[$i.packagePath] = $i }
        Assert-Equal 'Read' $items['attachments/notes.txt'].status 'txt read'
        Assert-Equal 'Read' $items['attachments/matrix.csv'].status 'csv read'
        Assert-Equal 'Read' $items['attachments/payload.json'].status 'json read'
        Assert-Equal 'Extracted' $items['attachments/Business rules.docx'].status 'docx extracted'
        Assert-Equal 'Extracted' $items['attachments/validation.xlsx'].status 'xlsx extracted'
        Assert-Match ([IO.File]::ReadAllText((Join-Path $r $items['attachments/Business rules.docx'].textPath))) 'DOCX-MARKER business rule one' 'docx text written to pbi-extracted'
        Assert-Match ([IO.File]::ReadAllText((Join-Path $r $items['attachments/validation.xlsx'].textPath))) 'XLSX-MARKER \| Due date \| 42' 'xlsx cells extracted'
        Assert-Equal 'RequiresAgentReview' $items['attachments/screen.png'].status 'png needs visual review'
        Assert-Match $items['attachments/photo.jpeg'].reason 'JPEG image 1024x768' 'jpeg dimensions read'
        Assert-Equal 'RequiresAgentReview' $items['attachments/design.pdf'].status 'pdf without extractor needs agent review'
    } finally { $env:SDD_DISABLE_EXTERNAL_EXTRACTORS = $old }
    if (Get-Command pdftotext -ErrorAction SilentlyContinue) {
        $y = Start-Pkg $r
        $pdf = @((Get-Inventory $r).items | Where-Object { $_.packagePath -eq 'attachments/design.pdf' })[0]
        Assert-Equal 'Extracted' $pdf.status 'pdf extracted with pdftotext'
        Assert-Match ([IO.File]::ReadAllText((Join-Path $r $pdf.textPath))) 'PDF-MARKER' 'pdf text extracted'
    }
    # Nothing was written into the input folder.
    $inputFiles = @(Get-ChildItem "$r/docs/sdd/pbi-input/305183" -Recurse -File | Where-Object { $_.Name -match 'inventory|\.txt\.txt|extracted' })
    Assert-Equal 0 $inputFiles.Count 'inventory and extracted text are kept out of the input folder'
}

Test 'Inputs.MissingAndUnsupportedReportedByName' {
    $r = New-FixtureRepo DAB; $null = Add-Package $r
    $a = "$r/docs/sdd/pbi-input/305183/attachments"
    Write-File "$a/empty.txt" ''
    Write-File "$a/broken.docx" 'this is not a zip'
    Write-File "$a/Outlook mail.msg" 'binary-ish'
    New-ZipWithEntries "$a/nested.zip" ([ordered]@{ 'x.md' = '# x' })
    # A file the refined PBI refers to but nobody attached is reported, never assumed.
    $pbiFile = "$r/docs/sdd/pbi-input/305183/REFINED-PBI.md"
    Write-File $pbiFile (([IO.File]::ReadAllText($pbiFile)) + "`n## Attachments`n- Screen flow: see ``complaint-flow.png`` and REQUEST.md.`n")
    $x = Start-Pkg $r
    $miss = @((Get-Inventory $r).discrepancies | Where-Object { $_.type -eq 'ReferencedFileMissing' })
    Assert-Equal 1 $miss.Count 'one missing referenced file (REQUEST.md exists)'
    Assert-Match $miss[0].detail "'complaint-flow\.png', which is not in the PBI input folder" 'missing attachment named'
    $items = @{}; foreach ($i in (Get-Inventory $r).items) { $items[$i.packagePath] = $i }
    Assert-Equal 'Unreadable' $items['attachments/empty.txt'].status 'empty file'
    Assert-Match $items['attachments/empty.txt'].reason 'empty' 'reason given'
    Assert-Equal 'Unreadable' $items['attachments/broken.docx'].status 'corrupt docx'
    Assert-Equal 'Unsupported' $items['attachments/Outlook mail.msg'].status 'msg unsupported'
    Assert-Equal 'Unsupported' $items['attachments/nested.zip'].status 'nested archive unsupported'
    Assert-Match ($x.Data.unreadable -join "`n") 'attachments/broken\.docx: Unreadable' 'exact filename reported by Start Development'
    # The gate fails until the spec cites each of them with its result; then passes.
    Complete-PackageAnalysis $r -SkipFiles @('attachments/broken.docx')
    $g = Gate $r
    Assert-Equal 1 $g.ExitCode 'uncited unreadable file blocks AnalysisComplete'
    Assert-Match $g.Output "does not cite PBI input file 'attachments/broken\.docx'" 'names the file'
    Complete-PackageAnalysis $r
    $g = Gate $r
    Assert-Equal 0 $g.ExitCode "all inputs cited: $($g.Output)"
}

Test 'Inputs.ConflictingRequirementsDetected' {
    $r = New-FixtureRepo DAB; $null = Add-Package $r
    $x = Start-Pkg $r
    $ids = @((Get-Inventory $r).discrepancies | ForEach-Object { $_.id })
    foreach ($id in @('PX-APPROVAL', 'PX-Q01', 'PX-D01', 'PX-AC07')) { Assert-True ($ids -contains $id) "discrepancy $id detected (got $($ids -join ', '))" }
    Assert-True (@($ids | Where-Object { $_ -like 'PX-TEXT-*' }).Count -eq 1) 'past-date message only in REQUEST.md detected'
    Assert-True ($ids -notcontains 'PX-D02') 'approved decision is not a discrepancy'
    $spec = [IO.File]::ReadAllText("$r/src/.github/specs/ComplaintImitationRequest/spec.md")
    Assert-Match $spec '\| PX-Q01 \| QuestionStatusConflict \|.*\| PENDING \|' 'discrepancy pre-filled for resolution'
    # Not resolved silently: an unaddressed discrepancy fails the gate.
    Complete-PackageAnalysis $r -SkipDiscrepancies @('PX-D01')
    $g = Gate $r
    Assert-Equal 1 $g.ExitCode 'unaddressed discrepancy blocks the gate'
    Assert-Match $g.Output 'does not address discrepancy PX-D01 \(DecisionNotApproved\)' 'gate names the discrepancy'
}

Test 'Inputs.SourceTraceabilityEnforced' {
    $r = New-FixtureRepo DAB; $null = Add-Package $r
    New-PngFile "$r/docs/sdd/pbi-input/305183/attachments/screen.png"
    $null = Start-Pkg $r
    Complete-PackageAnalysis $r -SkipFiles @('EVIDENCE.md')
    $g = Gate $r
    Assert-Match $g.Output "does not cite PBI input file 'EVIDENCE\.md'" 'uncited supporting document reported'
    # A RequiresAgentReview file cited without a review result is not enough.
    Complete-PackageAnalysis $r
    $spec = "$r/src/.github/specs/ComplaintImitationRequest/spec.md"
    Write-File $spec ([IO.File]::ReadAllText($spec).Replace('Reviewed with the image/PDF tool: shows the Complaint IR screen; supports AC-1.', 'Screenshot of the create screen.'))
    $g = Gate $r
    Assert-Match $g.Output "cites 'attachments/screen\.png' \(RequiresAgentReview\) without its review result" 'review result required'
    Complete-PackageAnalysis $r
    $g = Gate $r
    Assert-Equal 0 $g.ExitCode "fully traced: $($g.Output)"
}

Test 'Inputs.SpecAndPlanSavedAutomatically' {
    $r = New-FixtureRepo DAB; $null = Add-Package $r
    $x = Start-Pkg $r
    foreach ($f in @('spec.md', 'plan.md')) { Assert-True (Test-Path "$r/src/.github/specs/ComplaintImitationRequest/$f") "$f saved on disk" }
    $spec = [IO.File]::ReadAllText("$r/src/.github/specs/ComplaintImitationRequest/spec.md")
    $plan = [IO.File]::ReadAllText("$r/src/.github/specs/ComplaintImitationRequest/plan.md")
    foreach ($h in @('## PBI sources and attachments', '## Discrepancies and source conflicts', '## Status and versioning rules', '## Open questions, assumptions, decisions and dependencies')) { Assert-Match $spec ([regex]::Escape($h)) "spec section $h" }
    foreach ($h in @('## Implementation impact matrix', '## CQRS handlers, validators and GraphQL contracts', '## Derived products and Paint System relationships', '## Applicable PR-review lessons', '## Unit and regression tests')) { Assert-Match $plan ([regex]::Escape($h)) "plan section $h" }
    Assert-Match $spec '- PBI title: \[CAA\]\[DAB API\] Complaint Imitation Request' 'PBI ID and title in the header'
    Assert-Match $spec 'Refined PBI approval: NOT business-approved \(Status: Blocked' 'approval status in the header'
    $g = Gate $r
    Assert-Equal 1 $g.ExitCode 'template is not a completed analysis'
    Assert-Match $g.Output 'PENDING table cell' 'pre-filled PENDING cells must be completed'
    Complete-PackageAnalysis $r
    $g = Gate $r
    Assert-Equal 0 $g.ExitCode "completed analysis passes: $($g.Output)"
}

Test 'Inputs.NoCrossPbiContamination' {
    $r = New-FixtureRepo DAB; $null = Add-Package $r
    Write-File "$r/docs/sdd/pbi-input/305184/REFINED-PBI.md" "# 305184 - Other feature`n`nStatus: Approved`n`n## Acceptance criteria`n- AC-1 Given x When y Then z happens for the other feature.`n"
    Write-File "$r/docs/sdd/pbi-input/305184/attachments/other-rules.txt" "OTHER-PBI-MARKER`n"
    $x = Start-Pkg $r
    $inv = Get-Inventory $r
    Assert-True (@($inv.items | Where-Object { $_.path -notlike 'docs/sdd/pbi-input/305183/*' }).Count -eq 0) 'only files of PBI 305183 inventoried'
    $all = (Get-ChildItem "$r/docs/sdd/changes/305183-ComplaintImitationRequest" -Recurse -File | ForEach-Object { [IO.File]::ReadAllText($_.FullName) }) -join "`n"
    $all += [IO.File]::ReadAllText("$r/src/.github/specs/ComplaintImitationRequest/spec.md")
    Assert-NotMatch $all 'OTHER-PBI-MARKER|other-rules\.txt|305184' 'nothing of PBI 305184 in the 305183 artifacts'
}

Test 'Inputs.OriginalAttachmentsPreserved' {
    $r = New-FixtureRepo DAB
    $dl = Copy-PackageFixture (Join-Path (New-TestRoot) '2026-10-07-305183-complaint-imitation-request')
    New-PdfFile "$dl/attachments/design.pdf" 'design'
    $zip = Join-Path (New-TestRoot) '2026-10-07-305183-complaint-imitation-request.zip'
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::CreateFromDirectory($dl, $zip, [IO.Compression.CompressionLevel]::Optimal, $true)
    $zipHash = (Get-FileHash $zip -Algorithm SHA256).Hash
    $i = Invoke-ToolJson 'Add-SDDPbiInput.ps1' @('-Repository', $r, $zip)
    Assert-Equal 0 $i.ExitCode "import: $($i.Output)"
    $inputRoot = "$r/docs/sdd/pbi-input/305183"
    $before = Get-TreeHashes $inputRoot
    $null = Start-Pkg $r
    Complete-PackageAnalysis $r
    $null = Gate $r
    $null = Start-Pkg $r
    $after = Get-TreeHashes $inputRoot
    Assert-Equal (($before.Keys | ForEach-Object { "$_=$($before[$_])" }) -join ';') (($after.Keys | ForEach-Object { "$_=$($after[$_])" }) -join ';') 'input files unchanged, nothing added to the input folder'
    Assert-Equal $zipHash (Get-FileHash $zip -Algorithm SHA256).Hash 'downloaded ZIP unchanged'
    # A changed download never silently overwrites an existing input file.
    Write-File "$dl/OPEN-QUESTIONS.md" "# Open questions`n`nChanged later.`n"
    $c = Invoke-ToolJson 'Add-SDDPbiInput.ps1' @('-Repository', $r, '-PbiId', '305183', $dl)
    Assert-Equal 6 $c.ExitCode 'conflict exit code'
    Assert-Equal 'InputConflict' $c.Data.status 'conflict reported'
    Assert-Equal $before['/OPEN-QUESTIONS.md'] (Get-FileHash "$inputRoot/OPEN-QUESTIONS.md" -Algorithm SHA256).Hash 'existing file not overwritten'
    $u = Invoke-ToolJson 'Add-SDDPbiInput.ps1' @('-Repository', $r, '-PbiId', '305183', '-UpdateChanged', $dl)
    Assert-Equal 0 $u.ExitCode 'explicit update'
    $prev = @(Get-ChildItem "$inputRoot/.previous" -Recurse -File -Filter 'OPEN-QUESTIONS.md')
    Assert-Equal 1 $prev.Count 'previous version kept'
    Assert-Equal $before['/OPEN-QUESTIONS.md'] (Get-FileHash $prev[0].FullName -Algorithm SHA256).Hash 'previous version byte-identical, original name'
}

Test 'Inputs.ImportFromZipCreatesFolderAndInfersId' {
    $r = New-FixtureRepo DAB
    $root = New-TestRoot
    $pkg = Copy-PackageFixture (Join-Path $root '2026-10-07-305183-complaint-imitation-request')
    New-DocxFile "$pkg/attachments/rules.docx" @('rule')
    Write-File "$pkg/__MACOSX/._REFINED-PBI.md" 'junk'
    Write-File "$pkg/Thumbs.db" 'junk'
    $zip = Join-Path $root 'download.zip'
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::CreateFromDirectory($pkg, $zip, [IO.Compression.CompressionLevel]::Optimal, $true)
    $i = Invoke-ToolJson 'Add-SDDPbiInput.ps1' @('-Repository', $r, $zip)
    Assert-Equal 0 $i.ExitCode "import: $($i.Output)"
    Assert-Equal '305183' $i.Data.pbiId 'PBI ID read from the refined PBI header'
    foreach ($f in @('REFINED-PBI.md', 'REQUEST.md', 'DECISION-LOG.md', 'OPEN-QUESTIONS.md', 'EVIDENCE.md', 'attachments/rules.docx', 'history/2026-10-07-q01-new-sample-status/REFINED-PBI-SNAPSHOT.md')) {
        Assert-True (Test-Path "$r/docs/sdd/pbi-input/305183/$f") "wrapper folder unwrapped, layout kept: $f"
    }
    Assert-True (-not (Test-Path "$r/docs/sdd/pbi-input/305183/__MACOSX")) 'macOS junk skipped'
    Assert-True (-not (Test-Path "$r/docs/sdd/pbi-input/305183/Thumbs.db")) 'Windows junk skipped'
    # Single attachments dropped later go to attachments/, and the ID comes from -PbiId.
    $shot = Join-Path $root 'Screenshot 2026-10-08.png'; New-PngFile $shot
    $j = Invoke-ToolJson 'Add-SDDPbiInput.ps1' @('-Repository', $r, '-PbiId', '305183', $shot)
    Assert-Equal 0 $j.ExitCode 'single attachment import'
    Assert-True (Test-Path "$r/docs/sdd/pbi-input/305183/attachments/Screenshot 2026-10-08.png") 'original file name preserved under attachments/'
    # Unsafe archives are rejected before anything is written.
    $bad = Join-Path $root 'evil-305183.zip'
    New-ZipWithEntries $bad ([ordered]@{ 'REFINED-PBI.md' = "# 305183 - x`n"; '../../escape.md' = 'x' })
    $k = Invoke-Tool 'Add-SDDPbiInput.ps1' @('-Repository', $r, '-PbiId', '305183', $bad)
    Assert-True ($k.ExitCode -ne 0) 'unsafe ZIP rejected'
    Assert-Match $k.Output 'Unsafe path in ZIP' 'reason reported'
    Assert-True (-not (Test-Path (Join-Path (Split-Path -Parent $r) 'escape.md'))) 'nothing written outside'
    # Without a determinable ID the import asks for it instead of guessing.
    $loose = Join-Path $root 'notes.txt'; Write-File $loose 'x'
    $q = Invoke-ToolJson 'Add-SDDPbiInput.ps1' @('-Repository', $r, $loose)
    Assert-Equal 4 $q.ExitCode 'PBI ID required'
}

Test 'Inputs.DuplicatesDetected' {
    $r = New-FixtureRepo DAB; $null = Add-Package $r
    New-PdfFile "$r/docs/sdd/pbi-input/305183/attachments/spec v1.pdf" 'same'
    Copy-Item "$r/docs/sdd/pbi-input/305183/attachments/spec v1.pdf" "$r/docs/sdd/pbi-input/305183/attachments/copy/spec v1 (1).pdf" -Force -ErrorAction SilentlyContinue
    if (-not (Test-Path "$r/docs/sdd/pbi-input/305183/attachments/copy")) { [void](New-Item -ItemType Directory "$r/docs/sdd/pbi-input/305183/attachments/copy"); Copy-Item "$r/docs/sdd/pbi-input/305183/attachments/spec v1.pdf" "$r/docs/sdd/pbi-input/305183/attachments/copy/spec v1 (1).pdf" }
    $null = Start-Pkg $r
    $dups = @((Get-Inventory $r).items | Where-Object { $_.status -eq 'Duplicate' })
    Assert-Equal 1 $dups.Count 'one duplicate'
    Assert-Equal 'attachments/spec v1.pdf' $dups[0].duplicateOf 'duplicate points at the first copy'
    # Importing the same content under another name is skipped.
    $other = Join-Path (New-TestRoot) 'renamed.pdf'
    Copy-Item "$r/docs/sdd/pbi-input/305183/attachments/spec v1.pdf" $other
    $i = Invoke-ToolJson 'Add-SDDPbiInput.ps1' @('-Repository', $r, '-PbiId', '305183', $other)
    Assert-Equal 'DuplicateSkipped' $i.Data.files[0].status 'same content not copied twice'
}

Test 'Inputs.GitChangesStayClean' {
    $r = New-FixtureRepo DAB
    $gitignoreBefore = Test-Path "$r/.gitignore"
    $dl = Copy-PackageFixture (Join-Path (New-TestRoot) 'download-305183')
    New-PngFile "$dl/attachments/screen.png"
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-Request', "Start Development 305183 Complaint Imitation Request (source: $dl)")
    Assert-Equal 0 $x.ExitCode "start with source: $($x.Output)"
    Assert-Equal 'Imported' $x.Data.import.status 'imported from the prompt hint'
    Assert-Equal 0 ([int]$x.Data.import.git.visibleInGitChanges) 'importer reports nothing visible in Git Changes'
    $inputs = @(& git -C $r status --porcelain --untracked-files=all -- docs/sdd/pbi-input)
    Assert-Equal 0 $inputs.Count "PBI inputs not in Git Changes: $($inputs -join ', ')"
    $analysis = @(& git -C $r status --porcelain --untracked-files=all -- docs/sdd/changes/305183-ComplaintImitationRequest/pbi-analysis)
    Assert-Equal 0 $analysis.Count 'extracted text and inventory not in Git Changes'
    $visible = (& git -C $r status --porcelain --untracked-files=all) -join "`n"
    Assert-Match $visible 'src/\.github/specs/ComplaintImitationRequest/spec\.md' 'spec.md stays visible for check-in'
    Assert-Match $visible 'src/\.github/specs/ComplaintImitationRequest/plan\.md' 'plan.md stays visible for check-in'
    Assert-Equal $gitignoreBefore (Test-Path "$r/.gitignore") 'no .gitignore created'
    $ex = [IO.File]::ReadAllText("$r/.git/info/exclude")
    Assert-Match $ex '(?m)^/docs/sdd/pbi-input/305183/$' 'input folder excluded locally'
    Assert-NotMatch $ex 'src/\.github' 'specs never excluded'
    # Re-running adds no duplicate lines.
    $null = Start-Pkg $r
    Assert-Equal 1 ([regex]::Matches([IO.File]::ReadAllText("$r/.git/info/exclude"), '(?m)^/docs/sdd/pbi-input/305183/$').Count) 'exclusion written once'
} 'RequiresGit'

Test 'Inputs.TrackedInputsNeverHidden' {
    $r = New-FixtureRepo DAB; $null = Add-Package $r
    Invoke-Git $r @('add', 'docs/sdd/pbi-input/305183/REFINED-PBI.md') | Out-Null
    Invoke-Git $r @('commit', '-q', '-m', 'team tracks refined PBIs') | Out-Null
    $exBefore = [IO.File]::ReadAllText("$r/.git/info/exclude")
    $x = Start-Pkg $r
    Assert-Equal 0 $x.ExitCode 'start'
    Assert-Equal 'TrackedByTeam' $x.Data.localOnly.'docs/sdd/pbi-input/305183' 'tracked folder recognised'
    Assert-NotMatch ([IO.File]::ReadAllText("$r/.git/info/exclude")) 'pbi-input/305183' 'no exclusion for a team-tracked folder'
    (Get-Item -LiteralPath "$r/docs/sdd/pbi-input/305183/REFINED-PBI.md").IsReadOnly = $false # simulate deliberate tampering
    Write-File "$r/docs/sdd/pbi-input/305183/REFINED-PBI.md" (([IO.File]::ReadAllText("$r/docs/sdd/pbi-input/305183/REFINED-PBI.md")) + "`nEdited.`n")
    Assert-Match ((& git -C $r status --porcelain) -join "`n") 'M docs/sdd/pbi-input/305183/REFINED-PBI\.md' 'edits to tracked inputs stay visible'
    Assert-True ($exBefore.Length -le ([IO.File]::ReadAllText("$r/.git/info/exclude")).Length) 'exclude file only appended'
} 'RequiresGit'

Test 'Inputs.UnapprovedPbiNeedsExplicitAcknowledgement' {
    $r = New-FixtureRepo DAB; $null = Add-Package $r
    $null = Start-Pkg $r
    Complete-PackageAnalysis $r
    $g = Gate $r
    Assert-Equal 0 $g.ExitCode 'analysis may complete on a blocked PBI'
    Assert-Match $g.Output 'not business-approved' 'warning shown'
    $a = Invoke-Tool 'Approve-SDD.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Statement', 'Approved, implement T1-T4', '-ApprovedBy', 'Asha Developer')
    Assert-True ($a.ExitCode -ne 0) 'approval refused without acknowledgement'
    Assert-Match $a.Output 'not business-approved' 'reason'
    Assert-True (-not (Test-Path "$r/docs/sdd/changes/305183-ComplaintImitationRequest/approval.json")) 'nothing recorded'
    $b = Invoke-Tool 'Approve-SDD.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Statement', 'Approved despite PBI status Blocked, implement T1-T4', '-ApprovedBy', 'Asha Developer', '-AcknowledgeUnapprovedPbi')
    Assert-Equal 0 $b.ExitCode "acknowledged approval: $($b.Output)"
    $ap = [IO.File]::ReadAllText("$r/docs/sdd/changes/305183-ComplaintImitationRequest/approval.json") | ConvertFrom-Json
    Assert-True ($ap.pbiApprovalAcknowledged) 'acknowledgement recorded'
    Assert-Match $ap.inputFingerprint '^[0-9a-f]{64}$' 'input package fingerprint recorded'
}

Test 'Inputs.AttachmentChangeAfterApprovalRequiresReapproval' {
    $r = New-FixtureRepo DAB
    Add-RefinedPbi $r   # approved fixture
    Write-File "$r/docs/sdd/pbi-input/305183/attachments/rules.txt" "Rule: complaint suffix c.`n"
    $null = Start-Pkg $r
    Complete-PackageAnalysis $r
    $a = Invoke-Tool 'Approve-SDD.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Statement', 'Approved, implement T1-T4', '-ApprovedBy', 'Asha Developer')
    Assert-Equal 0 $a.ExitCode "approved: $($a.Output)"
    (Get-Item -LiteralPath "$r/docs/sdd/pbi-input/305183/attachments/rules.txt").IsReadOnly = $false # simulate deliberate tampering
    Write-File "$r/docs/sdd/pbi-input/305183/attachments/rules.txt" "Rule: complaint suffix C (changed by PO).`n"
    $g = Gate $r 'ImplementationApproved'
    Assert-Equal 1 $g.ExitCode 'changed attachment invalidates approval'
    Assert-Match $g.Output 'input package \(refined PBI or attachments\) changed after approval' 'reason'
}

Test 'Inputs.FeaturesStartedBeforeV25KeepTheirRules' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Start-Pkg $r
    # Simulate a feature initialised by v2.4: v2.4 documents, no templateVersion in the state.
    $state = "$r/docs/sdd/changes/305183-ComplaintImitationRequest/sdd-state.json"
    $s = [IO.File]::ReadAllText($state) | ConvertFrom-Json
    $s.PSObject.Properties.Remove('templateVersion')
    Write-File $state ($s | ConvertTo-Json -Depth 8)
    $pbi = [IO.File]::ReadAllText("$r/docs/sdd/pbi-input/305183/REFINED-PBI.md")
    Write-File "$r/src/.github/specs/ComplaintImitationRequest/spec.md" ([IO.File]::ReadAllText("$script:FixtureData/305183/spec.completed.v24.md").Replace('{{PBI_SOURCE}}', $pbi.TrimEnd()))
    Write-File "$r/src/.github/specs/ComplaintImitationRequest/plan.md" ([IO.File]::ReadAllText("$script:FixtureData/305183/plan.completed.v24.md"))
    Write-File "$r/docs/sdd/changes/305183-ComplaintImitationRequest/pr-review-audit.md" "# PR review rule audit`n`nApplicable rules: NONE - none registered.`nEvidence: validator inspected.`nStatus: PASS`n"
    Write-File "$r/docs/sdd/pbi-input/305183/attachments/late.txt" "Added after the v2.4 analysis.`n"
    $g = Gate $r
    Assert-Equal 0 $g.ExitCode "v2.4 analysis still passes after the upgrade: $($g.Output)"
    Assert-Match $g.Output "not enforced for documents created before v2.5" 'new traceability reported as warning'
}

Test 'Inputs.DownloadedPackageSuggestedWhenFolderMissing' {
    $r = New-FixtureRepo DAB
    $dl = New-TestRoot
    $old = $env:SDD_DOWNLOADS_DIR
    try {
        $env:SDD_DOWNLOADS_DIR = $dl
        $pkg = Copy-PackageFixture (Join-Path $dl 'tmp-pkg')
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [IO.Compression.ZipFile]::CreateFromDirectory($pkg, (Join-Path $dl '2026-10-07-305183-complaint-imitation-request.zip'))
        Remove-Item $pkg -Recurse -Force
        Write-File (Join-Path $dl 'unrelated-3051830.zip') 'x'
        $x = Start-Pkg $r
        Assert-Equal 4 $x.ExitCode 'not found yet'
        Assert-Equal 1 @($x.Data.downloadCandidates).Count 'exactly the matching download listed (no partial ID match)'
        Assert-Match $x.Data.next "-Source '.*2026-10-07-305183-complaint-imitation-request\.zip'" 'next step imports it'
        Assert-True (-not (Test-Path "$r/docs/sdd/pbi-input")) 'nothing imported without being asked'
    } finally { $env:SDD_DOWNLOADS_DIR = $old }
}

Test 'Inputs.DragAndDropLauncherShipped' {
    $cmd = Join-Path $script:Tools 'Add-PbiInput.cmd'
    Assert-True (Test-Path $cmd) 'Add-PbiInput.cmd shipped in tools'
    $t = [IO.File]::ReadAllText($cmd)
    Assert-Match $t 'Add-SDDPbiInput\.ps1' 'calls the importer'
    Assert-NotMatch $t '(?i)ExecutionPolicy\s+Bypass|Set-ExecutionPolicy' 'never bypasses the execution policy'
} 'Static'
