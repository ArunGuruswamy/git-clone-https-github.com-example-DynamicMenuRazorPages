﻿# PR-review learning, agent parity (Full vs Caveman Concise), contract checks (Phase I, Phase K)

Test 'Review.ImportNormalisesAndDeduplicatesRealExport' {
    $r = New-FixtureRepo DAB
    Write-File "$r/docs/sdd/review-lessons/inbox/pr-comments.csv" (@'
PullRequestId,FilePath,Line,Author,Comment,Status
4711,src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestValidator.cs,42,Reviewer A,"Move this magic string to Constants.",Fixed
4720,src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Application/PaintSystem/Shared/VersioningHelper.cs,10,Reviewer B,"Move this magic string to constants!",Fixed
4721,projects/formulas/src/app/app.component.ts,5,Reviewer A,"Snackbar shows blank message when errors array is empty.",Active
'@)
    $x = Invoke-Tool 'Import-SDDReviewComments.ps1' @('-Repository', $r)
    Assert-Equal 0 $x.ExitCode "import: $($x.Output)"
    $rows = @(Import-Csv "$r/docs/sdd/review-lessons/register.csv")
    Assert-Equal 2 $rows.Count 'duplicate concern merged'
    $magic = $rows | Where-Object { $_.ReviewerConcern -match 'magic string' }
    Assert-Match $magic.PullRequests 'PR 4711.*PR 4720' 'both PR references kept'
    Assert-Equal 'Candidate' $magic.ApprovalStatus 'never auto-approved'
    Assert-Equal 'UI' ($rows | Where-Object { $_.ReviewerConcern -match 'Snackbar' }).Applicability 'UI applicability'
}

Test 'Review.MarkdownExportSupported' {
    $r = New-FixtureRepo DAB
    Write-File "$r/docs/sdd/review-lessons/inbox/export.md" "## PR 5001 - src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Common/Constants.cs:12`nUse static readonly instead of const here.`n`n## PR 5002 - src/X.cs:3`nAdd a negative test for the validator.`n"
    $x = Invoke-Tool 'Import-SDDReviewComments.ps1' @('-Repository', $r)
    Assert-Equal 0 $x.ExitCode "import: $($x.Output)"
    Assert-Equal 2 @(Import-Csv "$r/docs/sdd/review-lessons/register.csv").Count 'two rules'
}

Test 'Review.NoExportMeansNoRules' {
    $r = New-FixtureRepo DAB
    $x = Invoke-Tool 'Import-SDDReviewComments.ps1' @('-Repository', $r)
    Assert-True ($x.ExitCode -ne 0) 'refuses without data'
    Assert-Match $x.Output 'export script alone is not the data' 'explains'
    Assert-True (-not (Test-Path "$r/docs/sdd/review-lessons/register.csv")) 'nothing invented'
}

Test 'Review.OnlyApprovedApplicableRulesLoaded' {
    $r = New-FixtureRepo DAB
    Write-File "$r/docs/sdd/review-lessons/inbox/pr.csv" "PR,File,Line,Comment`n1,src/a.cs,1,Backend rule one`n2,projects/x.ts,1,UI rule two`n3,src/b.cs,1,Backend rule three`n"
    $null = Invoke-Tool 'Import-SDDReviewComments.ps1' @('-Repository', $r)
    $rows = @(Import-Csv "$r/docs/sdd/review-lessons/register.csv")
    foreach ($row in $rows) { if ($row.ReviewerConcern -match 'one|two') { $row.ApprovalStatus = 'Approved' } }
    $rows | Export-Csv "$r/docs/sdd/review-lessons/register.csv" -NoTypeInformation
    $x = Invoke-ToolJson 'Get-SDDApplicableRules.ps1' @('-Repository', $r, '-Paths', 'src/AN.ColorAppsAzure.Formula/X.cs')
    $names = @($x.Data.rules | ForEach-Object { $_.ReviewerConcern })
    Assert-True ($names -contains 'Backend rule one') 'approved backend rule'
    Assert-True ($names -notcontains 'Backend rule three') 'candidate excluded'
    Assert-True ($names -notcontains 'UI rule two') 'UI rule not loaded for a backend-only change'
}

Test 'Agents.FullAndConciseShareIdenticalProtocol' {
    $get = { param($f) $t = [IO.File]::ReadAllText((Join-Path $script:PackageRoot "core/.github/agents/$f")); $m = [regex]::Match($t, '(?s)<!-- sdd-protocol:begin.*?<!-- sdd-protocol:end -->'); if (-not $m.Success) { throw "$f has no protocol block" }; $m.Value }
    Assert-Equal (& $get 'akzo-sdd-developer.agent.md') (& $get 'akzo-sdd-developer-concise.agent.md') 'same gates and workflow'
} 'Static'

Test 'Agents.ConciseShortensChatOnly' {
    $t = [IO.File]::ReadAllText((Join-Path $script:PackageRoot 'core/.github/agents/akzo-sdd-developer-concise.agent.md'))
    Assert-Match $t 'Artifacts written normal and full: spec.md, plan.md, test evidence' 'artifacts not shortened'
} 'Static'

Test 'Agents.NoStaleArtifactNamesOrChatApproval' {
    foreach ($f in (Get-ChildItem (Join-Path $script:PackageRoot 'core/.github') -Recurse -File -Include '*.agent.md', '*.prompt.md', 'SKILL.md')) {
        $t = [IO.File]::ReadAllText($f.FullName)
        Assert-NotMatch $t '(?<![\w-])`analysis\.md`(?!\s*→)' "$($f.Name) uses analysis.md (RC-12)"
        Assert-NotMatch $t 'approval is recorded in `analysis.md` or in this chat' "$($f.Name) accepts chat-only approval (RC-09)"
        Assert-NotMatch $t 'Mandatory first tool action' "$($f.Name) still forces terminal-first start (RC-02)"
    }
} 'Static'

Test 'Agents.VersionMarkersPresent' {
    foreach ($f in @('akzo-sdd-developer.agent.md', 'akzo-sdd-developer-concise.agent.md', 'akzo-sdd-reviewer.agent.md')) {
        Assert-Match ([IO.File]::ReadAllText((Join-Path $script:PackageRoot "core/.github/agents/$f"))) 'sdd-builder-version: 2\.5\.2' "$f versioned"
    }
} 'Static'

Test 'Contracts.SpecMustCoverGraphqlAndValidation' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Invoke-Tool 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Complete-FixtureAnalysis $r
    $p = "$r/src/.github/specs/ComplaintImitationRequest/spec.md"
    $t = [IO.File]::ReadAllText($p)
    $t = [regex]::Replace($t, '(?s)## API and GraphQL contracts.*?(?=## Validation)', '')
    Write-File $p $t
    $a = Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'AnalysisComplete')
    Assert-Equal 1 $a.ExitCode 'contract section required'
    Assert-Match $a.Output 'API and GraphQL contracts' 'names the missing section'
}

Test 'Regression.PlanMustStateRegressionImpact' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Invoke-Tool 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Complete-FixtureAnalysis $r
    $p = "$r/src/.github/specs/ComplaintImitationRequest/plan.md"
    Write-File $p ([regex]::Replace([IO.File]::ReadAllText($p), '(?s)(## Regression impact and test strategy\s*\n).*?(?=## Dependency)', "`$1`nN/A`n`n"))
    $a = Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'AnalysisComplete')
    Assert-Equal 1 $a.ExitCode 'bare N/A regression section rejected'
}
