---
applyTo: "**/*.cs"
---

# CDMS (ColorDMS) development rules

Short rules. Detail: `.github/skills/cdms-development/SKILL.md` and `docs/sdd/quality-reference/`.

- Layers: Function → Application → Data (XRM) → Common. Never upward. No `IOrganizationService` outside Data.
- `net48`: `ConfigureAwait(false)` on every await. No `.Result` / `.Wait()`. Check `LangVersion` before C# 8+ syntax.
- CRM access through the existing `TryGetService(out _, out var error)` pattern. A failed connection returns a failure response. It does not throw.
- Attribute logical names and option-set values come from early-bound classes or metadata. Never invent them.
- Option-set and lookup cache misses are null-safe. Lookup-by-name returns `null`, never `""`.
- Every `EntityReference` hop is null-checked.
- External HTTP: static `HttpClient` + `protected virtual` seam. `using` on content and response.
- Broad catch only with the fatal-exception filter. Messages come from `Constants.ErrorMessages`.
- Duplicate detection via `IsErrorMessage(..., "Duplicate Record Found")` → `IsDuplicate`.
- Keep the route, verb and JSON shape compatible with the UI (the UI reaches CDMS through DAB `RoutingMiddleware`).
- Porting a legacy plugin rule: cite the plugin and keep its behaviour unless the PBI says otherwise.
- Tests: MSTest + NSubstitute, mirror folders, `Test<Class>` subclasses for seams, cover every branch.
- Unsure? Output `NOT CONFIRMED` (evidence / missing / question) and stop.
