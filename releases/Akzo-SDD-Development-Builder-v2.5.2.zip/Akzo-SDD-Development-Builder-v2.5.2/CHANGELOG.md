# Changelog

## v2.5.2 — continuous execution and current-source verification
- Unified FAST workflow, explicit STEP, PBI identity pinning, cached context and verified resume.
- Deterministic build/test runner, source fingerprints, solution guard and final regression gate.
- Safe installer ownership/rollback and reproducible packaging. See `release/RELEASE-NOTES-v2.5.2.md`.

## v2.5.1 — protected inputs, automatic file placement, commit gate
See `release/RELEASE-NOTES-v2.5.1.md`.

## v2.5.0 - single PBI input folder and Azure DevOps attachments
See `release/RELEASE-NOTES-v2.5.0.md`.

## v2.4.0 - stabilisation
See `release/RELEASE-NOTES-v2.4.0.md` and `release/ROOT-CAUSE-MATRIX.md`.


## v2.1.2 — Git-clean and install-safety hardening
- Improved Git root and local exclude resolution for normal repositories and Git worktrees.
- Installer defaults preserve missing tracked files instead of recreating them unless `-UpdateExisting` or `-Force` is explicitly selected.
- Existing SDD assets that are skipped by the selected agent mode are still registered for local-only Git exclusion when appropriate.
- Setup wizard command preview now recommends the `.cmd` launcher, avoiding direct execution of a downloaded unsigned `.ps1` under `RemoteSigned`.
- Installer does not change execution policy, reset Git state, commit, or push. It stops when PowerShell policy requires signing.

# Changelog

## v2.1.1 — Git-clean installer

- Installation is local-only by default: files that already exist are not overwritten.
- Newly copied untracked SDD assets and installer-created backup files are excluded through the repository-local `.git/info/exclude` file.
- Existing `.github/sdd/config.md` and multi-root workspace files are not rewritten on a normal install.
- `-UpdateExisting` explicitly refreshes existing assets after making a backup.
- `-TrackInstalledFiles` leaves new assets visible to Git for teams that intentionally want to commit the SDD builder content.
- No branch, index, commit or Git history operations are performed.
- The installer cannot automatically revert tracked modifications left by an older installation; those changes must be reviewed separately.


## v2.2.0 (controlled pilot)
Added automatic project-role selection guidance, short-feature check-in spec/plan, approval and regression/contract/token templates, validation utilities, and phase-reference corrections. Maintains v2.1.2 flow.
