# Akzo SDD Development Builder v2.5.3 - start here

## 1. Install or upgrade (one command)

In PowerShell, from **any folder** (the full path to the extracted package makes it work from the repository folder too):

```powershell
& "C:\Users\<you>\Downloads\Akzo-SDD-Development-Builder-v2.5.3\Install-DevelopmentBuilder.cmd" DAB "C:\Users\<you>\source\repos\AN.ColorAppsAzure.BL" Both
```

If the shell says `.\Install-DevelopmentBuilder.cmd is not recognized`, you are not inside the package folder: use the full-path form above.

| Repository | Command |
|---|---|
| DAB | `.\Install-DevelopmentBuilder.cmd DAB "<path to AN.ColorAppsAzure.BL>" Both` |
| CDMS | `.\Install-DevelopmentBuilder.cmd CDMS "<path to AN.ColorAppsAzure.BL.ColorDMS>" Both` |
| UI | `.\Install-DevelopmentBuilder.cmd UI "<path to UI>" Both "<CDMS path>" "<DAB path>" "<UI path>"` |

What it does:
- Runs only under the machine's existing PowerShell policy. Under `RemoteSigned` it unblocks the package scripts it is about to run. Under `AllSigned` or `Restricted` it stops and tells you to request an IT-signed package. It never changes or bypasses policy and never asks for administrator rights.
- Copies agents, prompts, skills, templates and `tools/` into the repository. Replaced files are backed up to `.sdd-installer-backups/<timestamp>/`.
- Keeps builder files local-only through `.git/info/exclude`, so **Source Control shows only your feature changes**. `src/.github/specs/` and application code are never hidden.
- Never edits Git-tracked team files. If your team committed an older agent, the installer prints `NOT UPDATED` with the list, so you know you are still running the old agent (see section 5).
- Never overwrites `.github/sdd/config.md`, `sonar-rules.instructions.md`, review learnings or `docs/architecture/*` once they exist.
- Running it again is safe: unchanged files are skipped.

If Visual Studio 2026 shows the agent without edit or terminal tools, try the host-default tool profile and recheck actual capabilities:

```cmd
set SDD_TOOL_PROFILE=Unrestricted
Install-DevelopmentBuilder.cmd DAB "<path>" Both
```

## 2. Add the PBI Builder files (once per PBI)

Download the PBI Builder package (ZIP) and the PBI's Azure DevOps attachments. Do not unzip or rename them. Then either:

- **drag** the ZIP (or a folder, or single files) onto `tools\Add-PbiInput.cmd` in the repository, or run
  `"<repo>\tools\Add-PbiInput.cmd" "C:\Users\<you>\Downloads\2026-10-07-305183-complaint-imitation-request.zip"`, or
- add the path to the Start Development prompt: `Start Development 305183 Complaint Imitation Request (source: C:\Users\<you>\Downloads\2026-10-07-305183-complaint-imitation-request.zip)`.

Result, created for you:

```
docs/sdd/pbi-input/305183/
  REFINED-PBI.md        primary requirements (the only required file)
  REQUEST.md or PBI.md  original request (optional)
  DECISION-LOG.md  OPEN-QUESTIONS.md  EVIDENCE.md  history/   (PBI Builder companions)
  attachments/          Azure DevOps attachments, any depth: PDF, DOCX, XLSX, CSV, PNG, JPG, JSON, TXT, MD
```

- The PBI ID is read from the refined PBI header (`# 305183 - ...` or `PBI ID: 305183`), else from the file name; a package whose refined PBI declares another ID is refused.
- The package layout and file names are kept; a single wrapper folder is unwrapped; loose files go to `attachments/`.
- Existing files are never overwritten (identical files are skipped). If the PBI was re-refined, re-import with `-UpdateChanged`; the old version is kept under `.previous/`.
- The folder is added to `.git/info/exclude`, so **nothing appears in Visual Studio or VS Code Git Changes**. A folder your team already commits is never hidden.
- Copying files into the folder by hand also works; Start Development then hides them the same way.
- If you forget this step, Start Development finds a ZIP named after the PBI in your Downloads folder and the agent imports it.

## 3. Start development

Open the repository in VS Code or Visual Studio 2026, choose **Akzo SDD Developer** (or **Akzo SDD Developer - Caveman Concise**), and type:

```
Start Development 305183 Complaint Imitation Request
```

To use a different spec folder name than the one derived from the title (for example to extend an existing folder), add it at the end: `Start Development 305183 Complaint Imitation Request (spec folder: ComplaintIR)`. `Akzo-SDD-Development-Builder.html` in this package builds the prompt and every command for you.

The agent then, without further prompts:
1. checks which tools it has (search, edit, terminal, test runner);
2. finds the refined PBI by its ID, selects DAB/CDMS/UI from repository evidence and loads the matching skill;
3. inventories every file of `docs/sdd/pbi-input/305183/` (Word, Excel and PDF text extracted; images and scanned PDFs opened by the agent), lists each file in the spec with what it contributes, and reports conflicts between them instead of resolving them silently;
4. analyses the existing code and writes **completed** `src/.github/specs/ComplaintImitationRequest/spec.md` and `plan.md`, reads them back, and runs the `AnalysisComplete` gate;
5. shows the approval summary and stops.

You approve in chat (for example `Approved, implement T1-T4`). The agent records it with `tools/Approve-SDD.ps1` and continues in **FAST** mode through all approved task groups, targeted checkpoints, independent review and final regression. STANDARD adds checks; STEP pauses per task only when you explicitly request it. Full and Caveman Concise use the same `.github/sdd/workflow.md`. Any later change to spec.md, plan.md, the refined PBI or an attachment needs a new approval. If the refined PBI is not approved yet (for example `Status: Blocked`), the agent tells you, and your approval must say so explicitly (`Approved despite PBI status Blocked, implement T1-T4`).

## 4. Gates you can run yourself

```powershell
.\tools\Assert-SDDArtifacts.ps1 -Repository . -Feature ComplaintImitationRequest -Stage AnalysisComplete
.\tools\Assert-SDDArtifacts.ps1 -Repository . -Feature ComplaintImitationRequest -Stage ImplementationApproved
.\tools\Invoke-SDDVerification.ps1 -Repository . -Feature ComplaintImitationRequest
.\tools\Assert-SDDArtifacts.ps1 -Repository . -Feature ComplaintImitationRequest -Stage ImplementationVerified
.\tools\Assert-SDDArtifacts.ps1 -Repository . -Feature ComplaintImitationRequest -Stage PRReady
```

Stages: `Initialized` -> `AnalysisComplete` -> `ImplementationApproved` -> `ImplementationVerified` -> `PRReady`. The current stage and its history are in `docs/sdd/changes/<PBI-ID>-<Feature>/sdd-state.json`.

## 5. Teams that committed an older builder to Git

Local-only mode never edits those files. Upgrade them once, on a branch, through a reviewed PR:

```powershell
.\Install-DevelopmentBuilder.ps1 -Target DAB -Destination "<path>" -Mode Both -UpdateExisting -TrackInstalledFiles
git diff --stat
```

## More
- `guides/QUICK-START.md` - one page for developers
- `guides/VS2026-COMPATIBILITY.md` - Visual Studio 2026 and VS Code differences, tool fallback
- `guides/ROLLBACK.md` - uninstall and rollback
- `guides/KNOWN-LIMITATIONS.md` - what is and is not verified
- `release/` - root-cause matrix, release notes, manifest with hashes. Run-specific reports and benchmarks are external delivery evidence


## Something looks wrong? (v2.5.3)

```powershell
cd "C:\Users\<you>\source\repos\AN.ColorAppsAzure.BL"
.\tools\Get-SDDStatus.ps1 -Repository .          # shows what is wrong and the next step
.\tools\Get-SDDStatus.ps1 -Repository . -Fix     # puts files where they belong
```

`-Fix` restores edited PBI inputs, merges and hides stray copies of the package, collects misplaced spec/plan files (also from the Desktop or Documents) in `docs/sdd/changes/<id>-<Feature>/agent-draft/`, and makes the inputs read-only. It never deletes a file, never touches application source and never runs a Git write command.

The installer adds a local pre-commit gate only when the repository has no existing hook or hook manager. It respects the effective PowerShell policy and checks current verification evidence.

## New execution controls
See `guides/CONFIGURATION.md` for target selection, command overrides, transient retry budgets, source fingerprints and verified progress. PBI conflicts require one explicit choice; ordinary approved tasks do not. Exact solution paths must be in the approved plan before `.sln` changes can pass verification.

## v2.5.3: the reported Complaint PaintSystem session

For `Start Development 306400 Creation of Complaint PaintSystem`, the required files are:

```text
C:\Users\RGA\source\repos\AN.ColorAppsAzure.BL\src\.github\specs\ComplaintPaintSystem\spec.md
C:\Users\RGA\source\repos\AN.ColorAppsAzure.BL\src\.github\specs\ComplaintPaintSystem\plan.md
```

The agent creates them during analysis, reads them back, then verifies the same files again when you approve implementation. It prints both paths; a chat plan is insufficient. The tool resolves from the repository root even if Visual Studio starts the terminal in src/ or a project folder. Analysis placeholders are completed by the agent before approval, not by asking you to create files.

If code was already edited, preserve those edits and tell the new agent to recover this PBI's analysis/spec/plan from the approved inputs and current diff, then continue the approved scope. Do not infer that past code edits imply approval. For ordinary schema/history inspection, it runs available tools itself. A genuine unresolved business choice remains a focused question.

A successful upgrade says READY. INSTALLATION INCOMPLETE (exit 3) lists preserved old or edited runtime files; it does not mean the new agent is active. For unchanged tracked builder assets, use the reviewed team update in section 5. For user-modified owned assets, merge the listed differences; do not use Force indiscriminately. Reopen Copilot Chat and select the updated agent after a successful installation.

For the reported existing DAB installation, this single policy-preserving command explicitly refreshes tracked builder assets (their changes remain visible for review):

```powershell
.\Upgrade-DevelopmentBuilder.cmd DAB "C:\Users\RGA\source\repos\AN.ColorAppsAzure.BL" Both
```

It does not stage, commit or push. Modified owned files remain protected and are listed if a merge is required. After READY, reopen Copilot Chat, choose the updated agent and resume `Start Development 306400 Creation of Complaint PaintSystem` with the original approved source.
