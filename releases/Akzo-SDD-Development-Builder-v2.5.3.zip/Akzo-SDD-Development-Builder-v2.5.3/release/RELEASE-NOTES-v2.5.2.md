# Akzo SDD Development Builder v2.5.2

One shared workflow replaces competing agent lifecycles. FAST completes approved work continuously; STANDARD adds checks; STEP is explicit. Full and Caveman Concise reference the same behavior and differ only in response style.

## Changes
- Explicit/branch/persisted PBI resolution, conflict reporting and a retained active-PBI pin; approved standalone handoffs remain discoverable.
- Existing specification persistence and hash-bound approval retained. Analysis remains independent of implementation approval; source and PBI protection stay enforced.
- Deterministic target selection, dependency-aware .NET test projects, conservative fallbacks, command configuration, bounded processes/retries and complete logs.
- Verification tied to current source/configuration. Final regression required for PR readiness; current identical results can be reused. Verified task checkpoints support resume.
- Content-keyed extraction and project-map caches; phase-specific context and compact agents; provider tokens UNKNOWN unless reported.
- Exact solution-path guard in status and verification. No automatic restore.
- One installer Git tracking snapshot, unique backups, preservation of user-edited owned assets, hash-verified backups/hooks and safe rollback. Generated hook respects effective PowerShell execution policy.
- Release manifest and ZIP exclude dynamic test reports, sample output and timestamps. Fixed entry metadata and ordered payloads support repeat builds; compare hashes for the same inputs/runtime.

## Install / rollback
From the extracted package on Windows:
```powershell
.\Install-DevelopmentBuilder.cmd DAB "C:\src\AN.ColorAppsAzure.BL" Both
.\Uninstall-DevelopmentBuilder.ps1 -Destination "C:\src\AN.ColorAppsAzure.BL" -RollbackLastUpgrade
```
Replace DAB with CDMS or UI and use the appropriate path. RemoteSigned/enterprise policy is respected; no administrator elevation or policy bypass is requested. Use -WhatIf on the uninstaller to preview.

## Validation
Run `tests/Run-Tests.ps1`; build with `release/Build-Release.ps1 -OutputDirectory <outside-source>`. Test reports are external to package content. Tests include the Start Development 305183 simulation, actual subprocess exit/log/timeout/retry evidence, state protection, installer/rollback, and repeated ZIP/hash comparison. See the delivered test report for exact current results. Linux fixture results do not establish Windows or IDE integration; details are in `guides/KNOWN-LIMITATIONS.md`.
