# Release notes - v2.5.1

v2.5.1 comes from a real run of v2.5.0 on PBI 305183. The agent skipped the workflow: spec and plan went to the Desktop, the refined PBI was edited, a copy of the package was extracted into `tools/`, five unreviewed source files were staged, and completion was claimed without a build. Everything that needed a manual fix is now done by a tool, and the gates and agents refuse the shortcuts.

## What changed
| Problem seen | v2.5.1 behaviour |
|---|---|
| Refined PBI edited ("Developer-approved", "In Development") | Every input file's SHA-256 is recorded when it enters `docs/sdd/pbi-input/<id>/` and the file is made read-only. An edit is reported as `PX-EDITED-*`, `Start-SDD` returns `InputEdited`, `Assert-SDDArtifacts` fails, `Approve-SDD` refuses. |
| ZIP extracted into `tools/` (shows in Git Changes) | `Get-SDDStatus.ps1` detects package copies outside the input folder; `-Fix` merges files that exist only there, moves the copy under `.previous/` and leaves anything Git tracks, and unrelated files in a shared folder, alone. |
| spec/plan saved on the Desktop or loose in the spec root | `Get-SDDStatus.ps1` finds them (Desktop and Documents too); `-Fix` moves repository files, or copies outside files, to `docs/sdd/changes/<id>-<Feature>/agent-draft/` for the agent to merge. The original outside the repository stays. |
| Input differs from the download | `-Fix` restores the original from a pristine copy or the recorded download; the edited version is kept in `.previous/edited-<stamp>/`. |
| Source staged before approval | `Get-SDDStatus.ps1` reports it as a blocking `Source` check and shows the stash command (the builder never runs Git write commands). |
| Unverified work committed | New pre-commit hook (`tools/Assert-SDDCommit.ps1`): staged application source is blocked while a PBI is in progress and its ImplementationVerified gate fails. Installed only if the repository has no pre-commit hook and no `core.hooksPath`; uninstall removes only the hook it wrote. The PBI is released automatically when PRReady passes. |
| Manual pasting of acceptance criteria and companion summaries | `Start-SDD` copies the acceptance criteria verbatim into spec.md and fills the sources table for DECISION-LOG (approved / not approved decisions) and OPEN-QUESTIONS (resolved / open). |
| `.\Install-DevelopmentBuilder.cmd is not recognized` | The guide and START-HERE use the full path form `& "<package>\Install-DevelopmentBuilder.cmd" DAB "<repo>" Both`; the guide has a package-folder field. |
| False completion claims, generated code misuse, broken edits | New Guardrails section in both agents: write only inside the repository, inputs read-only, never stage or commit, completion only with a quoted ImplementationVerified PASS (else `NOT VERIFIED`), check `.graphql` selections before using generated properties, read changed C# regions back. |

## New and changed files
- New: `tools/Get-SDDStatus.ps1`, `tools/Assert-SDDCommit.ps1`, `tests/Protection.Tests.ps1`.
- Changed: `SDD.Common.psm1`, `Start-SDD.ps1`, `Assert-SDDArtifacts.ps1`, `Approve-SDD.ps1`, installer and uninstaller, both developer agents (identical protocol block), HTML guide, START-HERE.
- Local state (never in Git Changes): `.sdd-builder/pbi-imports/<id>.baseline.json`, `active-pbis.json`.

## Verification
- Regression suite: see `release/TEST-REPORT.md` (13 new tests; the 305183 incident is replayed end to end).
- Not verified here: Visual Studio / VS Code agent sessions, Windows PowerShell 5.1, `.cmd` launchers under cmd.exe (see `guides/KNOWN-LIMITATIONS.md`).

## Upgrade
Run the installer from its full path. Existing PBI input folders are recorded and made read-only the next time `Start-SDD` or `Get-SDDStatus.ps1 -Fix` runs. If an input already differs from the original, `-Fix` restores it when a pristine copy or the recorded download exists; otherwise re-import the PBI Builder ZIP with `-UpdateChanged`.
