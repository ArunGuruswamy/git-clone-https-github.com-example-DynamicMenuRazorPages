# Workflow reference

The sole source is `core/.github/sdd/workflow.md`, installed as `.github/sdd/workflow.md`. Agents reference it; release tooling must not duplicate an embedded protocol.
