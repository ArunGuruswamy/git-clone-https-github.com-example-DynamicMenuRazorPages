# v2.5.2 root-cause audit

Baseline: all 150 supplied package files inventoried by content/hash, including 140 PowerShell functions and 110 registered tests. Inspected executable flows, agent/skill/prompt/configuration conflicts, installers, rollback, release tooling and domain/review references. Prior release reports and history are historical evidence, not current test claims. Full per-file inventory accompanies delivery.

Paths and line numbers below refer to the preserved **v2.5.1** source; fixes refer to v2.5.2.

| Root cause | Baseline evidence | Implemented correction |
|---|---|---|
| Conflicting continuous/STEP directions | `core/.github/agents/akzo-sdd-developer.agent.md:206` | Shared workflow replaces embedded competing lifecycle; both agents reference it. |
| Constitution per-file pauses | `core/.github/sdd/constitution.md:57` | Article 10 delegates execution modes to the shared workflow. |
| STEP default config | `core/.github/sdd/config.md:37` | FAST default, explicit STANDARD/STEP; legacy STEP_MODE ignored. |
| Handoffs re-enable STEP | `core/.github/agents/akzo-sdd-developer.agent.md:9` | Approval and reviewer handoffs preserve the explicit mode and continue FAST by default. |
| Per-file/redundant verification | `core/.github/skills/dab-development/SKILL.md:278` | Coherent task groups; successful matching final commands reuse source/log evidence. |
| Multiple lifecycle definitions | `core/.github/skills/sdd-workflow/SKILL.md:36` | Single phase/gate authority; layout and domain skills become references. |
| Repeated inventory and source searches | `tooling/tools/SDD.Common.psm1:843` | Content-keyed extraction and project maps; input hashes refreshed to detect changes. |
| Stale verification PASS | `tooling/tools/Assert-SDDArtifacts.ps1:153` | Current source/configuration fingerprint checked on each gate; stale task progress rejected. |
| Advertised tool mistaken for capability | `tooling/tools/Test-SDDCapabilities.ps1:19` | Probe success and real exit recorded separately from advertised/callable; unrun IDE/MCP UNKNOWN. |
| PBI selection not pinned; spec ownership checked late | `tooling/tools/Start-SDD.ps1:101` | Explicit/branch/persisted conflict handling, retained pin and collision guard before writes. |
| Solution edits not scoped | `tooling/tools/Get-SDDStatus.ps1:148` | Status and verification guard .sln/.slnx against exact approved plan paths; no automatic restore. |
| Repeated developer/manual work questions | `core/.github/agents/akzo-sdd-developer-concise.agent.md:136` | FAST continuous work; one persisted conflict answer; actual capability probes and automatic persistence. |
| Installer repeated Git subprocesses | `Install-DevelopmentBuilder.ps1:95` | One index snapshot for per-file membership; measured Git invocation reduction in external benchmark. |
| Rollback incomplete ownership | `Uninstall-DevelopmentBuilder.ps1:63` | Hash-owned hooks/backups; path validation; user modifications/settings retained; no-op upgrade rollback preserves earlier ownership. |
| Non-reproducible metadata | `release/Build-Release.ps1:67` | Run reports excluded, ordered payload/hash manifest and fixed ZIP metadata; repeat hashes tested. |
| End-to-end stops at approval | `tests/EndToEnd.Tests.ps1:31` | Scenario now executes seven mock-domain assertions, task workflow, PR gate and stale-source rejection. |
| Excess always-loaded instructions | `core/.github/agents/akzo-sdd-developer.agent.md:30` | Small agent entrypoints, one shared workflow, phase-specific context and measured byte budgets. |
| Generated hook bypasses policy | `Install-DevelopmentBuilder.ps1:438` | Removed policy bypass from generated hook; effective enterprise policy preserved. |
| Null exit code treated as zero | `tooling/tools/Assert-SDDArtifacts.ps1:159` | Null/missing exit rejected; successful log exit checked against recorded outcome. |
| No questions interpreted as business approval | `tooling/tools/SDD.Common.psm1:176` | Explicit business/status approval required; negative approval wins; refusing statement rejected. |
| Two baseline tests write protected files | `tests/PbiInput.Tests.ps1:311` | Tampering tests explicitly remove read-only protection before simulated edits; production protection remains. |

## Preserved behavior and boundaries

Specification/plan persistence, protected PBI imports, AC traceability, business approval, hash-bound implementation approval, architecture/domain references and approved historical PR-rule filtering are retained. Existing passing tests remain and are extended. Windows, live IDE and real application checks are explicitly NOT EXECUTED here. See `guides/KNOWN-LIMITATIONS.md`.

Performance reports, test outcomes, source diff and package hash are external release evidence so changing run times cannot change package bytes.
