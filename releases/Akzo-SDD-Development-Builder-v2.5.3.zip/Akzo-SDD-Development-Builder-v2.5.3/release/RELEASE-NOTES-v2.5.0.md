# Akzo SDD Development Builder v2.5.0 - release notes

Single PBI input folder and Azure DevOps attachments. The SDD phases, agents, gates, architecture rules and Caveman Concise behaviour of v2.4.0 are unchanged; v2.5 adds what happens before and inside the analysis.

## What the developer does

1. Drag the PBI Builder ZIP (or folder, or attachment files) onto `tools\Add-PbiInput.cmd`, or add `(source: <path>)` to the prompt.
2. `Start Development 305183 Complaint Imitation Request`

Only `REFINED-PBI.md` is required. No folder creation, copying, listing or explaining files.

## Findings on v2.4.0 with the real 305183 PBI Builder package (mock DAB repository)

| # | Finding | Fix in v2.5.0 |
|---|---|---|
| F-01 | Files copied into `docs/sdd/pbi-input/<id>/` appeared in Git Changes unless the repository was installed with the CMD (local-only) installer. | Import and Start Development add `/docs/sdd/pbi-input/<id>/` to `.git/info/exclude` (never `.gitignore`, never for tracked folders); the installer excludes `docs/sdd/pbi-input/` when the team tracks nothing there. |
| F-02 | PBI Builder `history/` snapshots and companion files (`DECISION-LOG.md`, `OPEN-QUESTIONS.md`, `EVIDENCE.md`) were treated as candidate requirement sources. | `REFINED-PBI.md` in the numbered folder is always the primary source; companions are supporting evidence; `history/`, `attachments/`, `.previous/` are never candidates. |
| F-03 | The PBI title was lost (`# 305183 - [CAA] ...` H1 was not read as the title or identity). | H1 `# <id> - <title>` declares identity and title; the full title goes into spec.md and plan.md. |
| F-04 | Attachments were neither listed, read nor traced. | Recursive inventory with type, role, status, referenced AC, SHA-256; DOCX/XLSX/PPTX text extraction; PDF via `pdftotext` when present; images flagged for agent review; every file must be cited in spec.md. |
| F-05 | `Status: Blocked`, pending business approval and feasibility review were not surfaced. | `PX-APPROVAL` discrepancy, warning at every gate, and `Approve-SDD.ps1 -AcknowledgeUnapprovedPbi` with the developer's explicit words. |
| F-06 | Contradictions between the package files were invisible (question resolved in one file, pending in another; decision only proposed; message wording only in the original request). | Deterministic discrepancy IDs (`PX-Qnn`, `PX-Dnn`, `PX-ACnn`, `PX-TEXT-*`, `PX-FOREIGN-*`) pre-filled in spec.md; the gate fails until each is answered. |

On the real package v2.5.0 imports 20 files (5 analysed, 15 history snapshots retained), finds 4 discrepancies (PX-APPROVAL, PX-Q01, PX-D01, PX-TEXT), and leaves nothing of the input folder or the extracted text in Git Changes. The package itself is confidential and is not part of this release; the tests use a mock package with the same layout.

## New and changed tools

| Tool | Change |
|---|---|
| `tools/Add-PbiInput.cmd` | New. Drag-and-drop launcher; asks for the PBI ID only when the files do not carry it. Never changes the execution policy. |
| `tools/Add-SDDPbiInput.ps1` | New. Safe import of ZIP / folder / files into `docs/sdd/pbi-input/<id>/`: ZIP path-traversal guard, wrapper folder unwrapped, junk skipped, layout and names kept, loose files to `attachments/`, no overwrite (`-UpdateChanged` keeps the old version in `.previous/`), identical files skipped, other-PBI documents refused, provenance in `.sdd-builder/pbi-imports/<id>.json`. Exit 0 / 4 (ID required) / 6 (conflict or mismatch). |
| `tools/Get-SDDPbiInventory.ps1` | New. Read-only inventory of one PBI's input package. |
| `tools/Start-SDD.ps1` | `-Source` / `(source: ...)` import; inventory to `docs/sdd/changes/<id>-<Feature>/pbi-analysis/` (local-only); v2.5 spec/plan templates with pre-filled sources and discrepancy tables; `pbiTitle`, `pbiApproval`, `discrepancies`, `needsAgentReview`, `unreadable`, `downloadCandidates` in the JSON; exit 6 for input conflicts. |
| `tools/Assert-SDDArtifacts.ps1` | AnalysisComplete: every input file cited with contribution or review result, every discrepancy ID answered, v2.5 sections (sources, discrepancies, status/versioning, impact matrix, CQRS handlers/validators, derived products/Paint System, PR-review lessons). ImplementationApproved: approval bound to the input-package fingerprint; unapproved PBI must be acknowledged. Features started before v2.5 keep the v2.4 rules (warnings only). |
| `tools/Approve-SDD.ps1` | Records `inputFingerprint`, PBI approval status, `-AcknowledgeUnapprovedPbi`. |
| `tools/Import-PBIBuilder.ps1` | Compatibility wrapper around `Add-SDDPbiInput.ps1`. |
| `tools/SDD.Common.psm1` | Package inventory, text extraction, discrepancy detection, local Git exclusion helpers. |

## Agents, prompts, templates, guide

- Protocol v2.5 (identical in Full and Caveman Concise): P-1 input folder, P1a input rules (refined PBI is the source of truth, attachments add no scope, never claim an unread file was analysed, one PBI per command).
- spec.md / plan.md templates carry the sections required by the brief.
- `Akzo-SDD-Development-Builder.html`: step 2 "Add the PBI Builder files" with the drag-and-drop command, a package field that adds `(source: ...)` to the prompt, and an ID check of the package name.

## Validation boundary

Executed: PowerShell 7 on Linux, mock DAB/CDMS/UI repositories, Git, `pdftotext` (also tested disabled). Not executed: Windows PowerShell 5.1, cmd.exe drag-and-drop, Visual Studio 2026 / VS Code Copilot sessions, real DAB repository. See `guides/KNOWN-LIMITATIONS.md` and `release/TEST-REPORT.md`.
