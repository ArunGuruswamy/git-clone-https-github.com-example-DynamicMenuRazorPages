# Akzo SDD Development Builder v2.5.3

This maintenance release addresses the reported PBI 306400 session: ordinary technical checks being offered as manual work, missing canonical spec/plan files, and inconclusive current-build/test evidence.

- Removes blanket "uncertain means stop" rules from the constitution and project guidance. Technical searches run automatically; unresolved business/scope decisions remain explicit.
- Adds a compact startup action to both agents and an applicable SDD instruction file. Draft artifacts are saved during analysis and rechecked at implementation approval; code editing requires saved, validated, hash-bound artifacts.
- Resolves the primary Git root from nested solution folders. DAB writes `src/.github/specs/<Feature>/spec.md` and `plan.md`, including `ComplaintPaintSystem` for the reported request. Read-back receipts expose absolute paths, sizes and hashes.
- Adds runtime hash diagnostics. An installer preserving old tracked or edited runtime assets now exits 3 with INSTALLATION INCOMPLETE, never "upgrade complete". User edits remain preserved.
- Discovers configured/workspace/known sibling reference repositories and collects source/history evidence read-only, without switching active PBI or spec root.
- Rejects zero-test output, failed-test counts, compile errors and last-successful-build fallback from IDE/custom wrappers even when their process exits zero. Missing/failed builds prevent tests against stale binaries.

The script suite and extracted release are validated on Linux/PowerShell fixtures. Live Visual Studio, Windows execution and the user's DAB application are NOT EXECUTED here. The builder cannot intercept native IDE calls; its agent must follow the startup and approval contract. Detailed evidence accompanies delivery.

Install from the extracted package using `Install-DevelopmentBuilder.cmd DAB "<repo>" Both`. If existing tracked builder assets remain, review and run `Install-DevelopmentBuilder.ps1 -Target DAB -Destination "<repo>" -UpdateExisting -TrackInstalledFiles`. This updates builder assets visibly without staging or committing them. It does not force-replace user-modified owned files; merge those listed changes first. Reopen Copilot Chat after a READY installation.

For the reported existing DAB installation, this single policy-preserving command explicitly refreshes tracked builder assets (their changes remain visible for review):

```powershell
.\Upgrade-DevelopmentBuilder.cmd DAB "C:\Users\RGA\source\repos\AN.ColorAppsAzure.BL" Both
```

It does not stage, commit or push. Modified owned files remain protected and are listed if a merge is required. After READY, reopen Copilot Chat, choose the updated agent and resume `Start Development 306400 Creation of Complaint PaintSystem` with the original approved source.
