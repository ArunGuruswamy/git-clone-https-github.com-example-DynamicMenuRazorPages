﻿[CmdletBinding()]
param(
    [string]$PackageRoot = (Split-Path -Parent $PSScriptRoot),
    [string]$OutputDirectory,
    [switch]$NormalizeOnly,
    [switch]$SkipTests
)
# Akzo SDD Builder v2.5.3. Deterministic package content; execution reports stay outside the ZIP.
$ErrorActionPreference = 'Stop'
$version = '2.5.3'
$name = "Akzo-SDD-Development-Builder-v$version"
$root = (Resolve-Path -LiteralPath $PackageRoot).Path.TrimEnd([char]92,[char]47)
$utf8 = New-Object Text.UTF8Encoding($false)
$utf8Bom = New-Object Text.UTF8Encoding($true)
function Package-Files([string]$Directory) {
    return @(Get-ChildItem -LiteralPath $Directory -Recurse -File -Force | Where-Object {
        $rel = $_.FullName.Substring($Directory.Length).TrimStart([char]92,[char]47).Replace('\','/')
        $rel -notmatch '(^|/)(\.git|\.sdd-builder|node_modules|bin|obj)(/|$)|^tests/results/|^release/(TEST-REPORT\.|SAMPLE-|RELEASE-MANIFEST\.json)|\.(zip|log)$'
    } | Sort-Object { $_.FullName.Substring($Directory.Length).Replace('\','/') })
}
function Normalize-Scripts([string]$Directory) {
    foreach ($f in (Package-Files $Directory)) {
        if ($f.Extension -notin @('.ps1','.psm1','.cmd')) { continue }
        $text = [IO.File]::ReadAllText($f.FullName).TrimStart([char]0xFEFF).Replace("`r`n","`n").Replace("`n","`r`n")
        if ($f.Extension -eq '.cmd') {
            if ($text -match '[^\x00-\x7F]') { throw "$($f.Name) must be ASCII." }
            [IO.File]::WriteAllText($f.FullName,$text,[Text.Encoding]::ASCII)
        } else { [IO.File]::WriteAllText($f.FullName,$text,$utf8Bom) }
    }
}
if ($NormalizeOnly) { Normalize-Scripts $root; Write-Host 'Script encoding normalization completed.'; return }
if (-not $OutputDirectory) { $OutputDirectory = Join-Path (Split-Path -Parent $root) 'akzo-releases' }
$output = [IO.Path]::GetFullPath($OutputDirectory).TrimEnd([char]92,[char]47)
if ($output -eq $root -or $output.StartsWith($root + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) { throw 'OutputDirectory must be outside PackageRoot.' }
[void][IO.Directory]::CreateDirectory($output)
$run = [guid]::NewGuid().ToString('N')
$reportDir = Join-Path $output "reports/$run"
if (-not $SkipTests) {
    & (Get-Process -Id $PID).Path -NoLogo -NoProfile -File (Join-Path $root 'tests/Run-Tests.ps1') -ReportDirectory $reportDir
    $code = $LASTEXITCODE
    $reportFile = Join-Path $reportDir 'test-report.json'
    if ($code -ne 0 -or -not (Test-Path -LiteralPath $reportFile)) { throw "Regression suite failed ($code); no release generated." }
    $report = Get-Content -LiteralPath $reportFile -Raw | ConvertFrom-Json
    if ($report.passed -le 0 -or $report.failed -ne 0) { throw 'No passing current-run test report; no release generated.' }
}
$stage = Join-Path ([IO.Path]::GetTempPath()) "akzo-release-$run"
[void][IO.Directory]::CreateDirectory($stage)
try {
    foreach ($f in (Package-Files $root)) {
        $rel = $f.FullName.Substring($root.Length).TrimStart([char]92,[char]47)
        $target = Join-Path $stage $rel
        [void][IO.Directory]::CreateDirectory((Split-Path -Parent $target))
        Copy-Item -LiteralPath $f.FullName -Destination $target
    }
    Normalize-Scripts $stage
    $files = @(Package-Files $stage)
    $entries = @($files | ForEach-Object { [ordered]@{ path = $_.FullName.Substring($stage.Length).TrimStart([char]92,[char]47).Replace('\','/'); bytes = $_.Length; sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant() } })
    $manifest = [ordered]@{ product = 'Akzo SDD Development Builder'; version = $version; fileCount = $entries.Count; files = $entries; verification = 'Run-specific test reports and benchmarks are external release evidence, not package content.' }
    $manifestPath = Join-Path $stage 'release/RELEASE-MANIFEST.json'
    [IO.File]::WriteAllText($manifestPath, (($manifest | ConvertTo-Json -Depth 6).Replace("`r`n","`n") + "`n"),$utf8)
    Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
    $zipPath = Join-Path $output "$name.zip"
    $tempZip = Join-Path $output "$name.$run.tmp"
    $stream = [IO.File]::Open($tempZip,[IO.FileMode]::CreateNew)
    $zip = New-Object IO.Compression.ZipArchive($stream,[IO.Compression.ZipArchiveMode]::Create)
    try {
        $all = @(Get-ChildItem -LiteralPath $stage -Recurse -File -Force | Sort-Object { $_.FullName.Substring($stage.Length).Replace('\','/') })
        foreach ($f in $all) {
            $rel = $f.FullName.Substring($stage.Length).TrimStart([char]92,[char]47).Replace('\','/')
            $e = $zip.CreateEntry("$name/$rel",[IO.Compression.CompressionLevel]::Optimal)
            $e.LastWriteTime = [DateTimeOffset]::new(2026,10,14,0,0,0,[TimeSpan]::Zero)
            $e.ExternalAttributes = 0
            $dest = $e.Open()
            try { $bytes = [IO.File]::ReadAllBytes($f.FullName); $dest.Write($bytes,0,$bytes.Length) } finally { $dest.Dispose() }
        }
    } finally { $zip.Dispose(); $stream.Dispose() }
    Move-Item -LiteralPath $tempZip -Destination $zipPath -Force
    $hash = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
    [IO.File]::WriteAllText(($zipPath + '.sha256'),"$hash  $name.zip`n",$utf8)
    Write-Host "Package: $zipPath"
    Write-Host "SHA-256: $hash"
    Write-Host $(if ($SkipTests) { 'Tests: NOT EXECUTED by this invocation (-SkipTests).' } else { "Tests: $($report.passed) passed; report $reportDir" })
} finally { if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force } }
