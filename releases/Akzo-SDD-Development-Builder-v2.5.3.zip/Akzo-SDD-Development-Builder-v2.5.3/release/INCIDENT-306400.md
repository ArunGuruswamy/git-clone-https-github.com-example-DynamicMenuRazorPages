# PBI 306400 incident: automation and missing artifact locations

The supplied screenshot shows the DAB repository and request `Start Development 306400 Creation of Complaint PaintSystem`. It also shows CS0234 errors in PaintSystemVersioningService.cs, zero-test runs, a fallback to the last successful build and a later run with two failures. The agent response admits new tests were not written. These results do not establish a completed, verified implementation.

The actual Windows checkout and approved 306400 input package were not available in the cloud workspace. The reported absence of files at the Windows path could not be independently inspected. v2.5.3 fixes confirmed builder defects and tests those paths with declared synthetic fixtures; it does not claim to repair or validate the real application's code.

## Confirmed v2.5.2 defects

| Code/guidance | Defect | v2.5.3 correction |
|---|---|---|
| tooling/tools/Start-SDD.ps1 and other command entrypoints | Repository argument used directly; a nested solution/project folder could become the wrong root or fail role detection. | Resolve primary Git root, with folder-workspace fallback; canonical DAB artifact path. |
| tooling/tools/SDD.Common.psm1 Get-SDDSpecRoot | An old custom specRoot could divert DAB artifacts to docs/sdd. | DAB Formula uses src/.github/specs; existing settings are preserved. |
| core/.github/agents/*developer*.agent.md | Short entrypoint delegated the actual persistence action to a separate workflow. | Both entrypoints explicitly run startup/read-back and recheck artifacts at approval; editor-only fallback remains. |
| core/.github/sdd/constitution.md Articles 1/2; project stop sections | Blanket uncertainty and PBI-vs-code stop rules conflicted with continuous technical discovery. | One question policy: investigate technical facts, persist drafts, ask only remaining required decisions. |
| Install-DevelopmentBuilder.ps1 final verification | Old tracked or modified runtime could be retained while printing upgrade complete. | Expected runtime hashes, health report, INCOMPLETE exit 3; explicit policy-preserving tracked upgrade launcher. |
| tooling/tools/Invoke-SDDVerification.ps1 | Custom/IDE wrapper exit zero could conceal empty tests, compiler errors or old-build execution. Missing build tool could allow the test command to run. | Parse observable failures/counts and require successful current build before tests; gate and checkpoint also reject invalid output. |
| Cross-repository guidance | Legacy-reference absence could become a manual schema/history question. | Discover known references and gather relevant source/history evidence without changing active PBI/root. |

## Required physical files

```text
C:\Users\RGA\source\repos\AN.ColorAppsAzure.BL\src\.github\specs\ComplaintPaintSystem\spec.md
C:\Users\RGA\source\repos\AN.ColorAppsAzure.BL\src\.github\specs\ComplaintPaintSystem\plan.md
```

Start creates missing drafts, reads them back and returns an artifact receipt. The agent fills them with analysis. When the user approves implementation, the agent ensures those files are completed and saved, records hash-bound approval and checks the same paths before source edits. Missing, empty, stale or wrong-PBI artifacts cannot be approved. A chat-only plan does not count.

The agent cannot be made to save the user's Windows files remotely by changing this cloud package. Install the corrected package and resume the PBI in the local agent. Native Visual Studio tool calls are not mechanically intercepted by a Markdown agent; the agent must follow the explicit startup contract and actual gate results.

## The three quoted questions

1. Product/PaintSystem association: automatically inspect the primary Formula schema/operations/generated types and discovered DAB config. Legacy N:N evidence alone does not identify a GraphQL entity or mutation; do not invent one.
2. Primary Complaint Color creation: first read approved decisions for the tool-2/tool-4 condition. A new AC may intentionally change legacy behavior. If the approved material still leaves that choice unresolved, one PO decision is legitimate; do not choose silently.
3. PBI 305183 dependency: inspect available integration history and current implementation directly. A commit-message hit is evidence only. Keep 306400 active; do not automatically exclude an AC or include another PBI's implementation work.

Recover existing local edits by preserving them, persisting the analysis/spec/plan from approved inputs and the current diff, and diagnosing the actual namespace/type and failed tests. Never manufacture a prior approval or accept old binaries as current verification.
