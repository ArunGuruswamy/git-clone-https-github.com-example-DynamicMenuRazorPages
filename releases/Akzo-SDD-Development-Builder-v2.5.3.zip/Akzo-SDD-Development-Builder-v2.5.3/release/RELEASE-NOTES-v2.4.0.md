# Akzo SDD Development Builder v2.4.0

Stabilisation release. No new phases or agents; the v2.3.x workflow is preserved and made executable. Every regression found in the v2.3.4 audit has a documented root cause (`release/ROOT-CAUSE-MATRIX.md`) and an automated regression test.

## Fixed
- **spec.md / plan.md never written** (RC-01): `Start-SDD.ps1` threw on every run (`TrimStart('\\','/')`) after creating the feature folder. Rewritten on a shared module; files are written and read back.
- **PBI discovery** (RC-03..05): identity by PBI-ID folder or `PBI ID:` header, never by a mention in the body; approved refined > refined > original; identical copies collapse; importer handoffs (`docs/sdd/pbi-sources/`) and configured sources are searched; existing artifacts resume.
- **Gates** (RC-06..09, RC-13): one implementation for `Assert-SDDArtifacts` and `Validate-SDD`. Verbatim PBI preserved and checked; acceptance criteria compared with the source; repository evidence must exist on disk; every AC traced in plan.md; spec **and** plan hashes bound to approval; new stages `Initialized`, `AnalysisComplete`, `ImplementationApproved`, `ImplementationVerified`, `PRReady` (`Draft`/`Approved` still accepted).
- **Approval** (RC-09): `tools/Approve-SDD.ps1` records the approver, the developer's verbatim statement and the hashes; agent/bot names are rejected; chat-only approval no longer unlocks implementation.
- **Tool fallback** (RC-02): capability preflight; scripts are optional verification, not a precondition; without a terminal the agent writes every file with its edit tool and reports `NOT EXECUTED`. `-ToolProfile Unrestricted` for Visual Studio sessions that lack edit/terminal tools.
- **Evidence-based verification**: `tools/Invoke-SDDVerification.ps1` records real exit codes and hashed logs; missing tools are `NOT EXECUTED`; tampered logs are detected.
- **State** (RC-10): re-running Start Development never resets the stage; history is kept.
- **Single spec and plan** (RC-11, RC-12): the published `src/.github/specs/<Feature>/spec.md` and `plan.md` are the only spec and plan; `08-analysis.md` and `07-tasks.md` used consistently.
- **Installer** (RC-14..18, RC-22, RC-23): one role-detection function; tracked files that were not updated are reported and recorded; backups moved to `.sdd-installer-backups/`; manifest and `Uninstall-DevelopmentBuilder.ps1` (full uninstall and `-RollbackLastUpgrade`); wrong repository stops instead of sleeping; team-owned config and docs are no longer overwritten; Windows-safe encodings.
- **PR review learning** (RC-19): `tools/Import-SDDReviewComments.ps1` normalises real exports into `register.csv` (candidate until approved); `tools/Get-SDDApplicableRules.ps1` loads only approved rules for the changed files.

## Added
`tools/SDD.Common.psm1`, `Approve-SDD.ps1`, `Invoke-SDDVerification.ps1`, `Test-SDDCapabilities.ps1`, `Import-SDDReviewComments.ps1`, `Get-SDDApplicableRules.ps1`, `Uninstall-DevelopmentBuilder.ps1`, `tests/` (dependency-free runner, mock repositories, end-to-end 305183 fixture), `release/Build-Release.ps1`.

## Changed
- Both developer agents carry one identical v2.4 protocol block (P0-P5) and a version marker; Caveman Concise shortens chat only.
- `New-SDDFeature.ps1` delegates to `Start-SDD.ps1`; `Validate-SDD.ps1` is a compatibility wrapper.
- Superseded start/release documents moved to `history/`.

## Validation boundary
See `release/TEST-REPORT.md` and `guides/KNOWN-LIMITATIONS.md`. Visual Studio 2026, VS Code Copilot sessions, cmd.exe and Windows PowerShell 5.1 were not executed in the build environment. Do not describe this package as production-ready until the Windows pilot checklist passes.
