# Developer quick start (one page)

| Step | You do | The agent does |
|---|---|---|
| 0 | Install once: `.\Install-DevelopmentBuilder.cmd DAB "<repo>" Both` | - |
| 1 | Drag the PBI Builder ZIP (and any attachments) onto `tools\Add-PbiInput.cmd`, or add `(source: <zip>)` to the prompt | Creates `docs/sdd/pbi-input/<PBI-ID>/`, copies without overwriting, hides it from Git Changes |
| 2 | Select **Akzo SDD Developer**, type `Start Development <PBI-ID> <Feature Name>` | Finds the PBI, reads every attachment, reports conflicts, selects DAB/CDMS/UI, analyses the code |
| 3 | Read the approval summary, open `src/.github/specs/<Feature>/spec.md` and `plan.md` | Writes both files, verifies them on disk, runs the `AnalysisComplete` gate |
| 4 | Answer only genuine questions (business decisions, approval) | Asks at most one question at a time |
| 5 | Approve in chat: `Approved, implement T1-Tn` | Records approval bound to the spec and plan hashes |
| 6 | Watch, or come back later | Implements task by task, builds, tests, fixes within scope |
| 7 | Review the diff and the completion report | Independent review, `ImplementationVerified` and `PRReady` gates, PR text |
| 8 | Commit and push (the agent never does) | - |

## What you never have to do
- Create folders, save Markdown, copy PBI files by hand, or copy text from chat.
- List or explain the attachments: the agent reads them and says which it could not read.
- Tell the agent whether the work is DAB, CDMS or UI.
- Repeat the PBI text.

## When the agent stops, it says why
| Message | Meaning | Your action |
|---|---|---|
| `PbiNotFound` | No file with that PBI ID | Drop the PBI Builder ZIP on `tools\Add-PbiInput.cmd` (a matching ZIP in Downloads is offered automatically) |
| `InputConflict` | A downloaded file differs from the one in the PBI folder | Say whether the PBI was re-refined; old version kept under `.previous/` |
| `not business-approved` | Refined PBI says Blocked / Draft / Pending | Get PO approval, or approve explicitly despite it |
| `PbiAmbiguous` | Two different versions of the PBI | Keep one, or mark the approved one `Status: Approved` |
| `RefinementRequired` | Only the original PBI exists | Review the drafted `REFINED-PBI.md` with the PO |
| `RoleAmbiguous` | Repo looks like two project types | Answer the single question (saved for next time) |
| `ReconcileExistingSpec` | Folder already holds another PBI's spec | Choose: extend that spec or use another feature name |
| `NOT EXECUTED` | No terminal/tool in this session | Run the printed command yourself, or let CI run it |
| `changed after approval` | Spec, plan, refined PBI or an attachment changed after you approved | Review the change and approve again |

## Caveman Concise
Same workflow and gates; only the chat is shorter. spec.md, plan.md and test evidence are written in full.
