# Visual Studio 2026 and VS Code compatibility

## Status of this guide
The builder's scripts and file contracts are tested automatically (see the delivered external test report). **No Visual Studio 2026 or VS Code Copilot session was executed** to produce this release. The table below is based on vendor documentation and on how the agents are written to behave. Treat each row marked "to verify" as a pilot checklist item.

## How the agents adapt
The developer agents start with a capability preflight (protocol P0). They distinguish advertised tools from callable, authorized, executed and successful operations through harmless probes:

| Capability | VS Code agent mode | Visual Studio 2026 agent | Agent behaviour when missing |
|---|---|---|---|
| Search / read files | `search`, `read` tool sets | built-in search/read tools | stops and reports the missing tool |
| Edit / create files | `edit` tool set | built-in edit tools | read-only: never claims a file was saved; reports `NEEDS EDIT TOOL` |
| Terminal | `execute` tool set (asks for approval per command unless auto-approved) | terminal tool availability and names differ (to verify) | continues; writes all files with the edit tool; records build/test/gates as `NOT EXECUTED` |
| Test runner | `execute/runTests` | Test Explorer tool (to verify) | uses it with filters; command-line gate still `NOT EXECUTED` until a terminal or CI run |
| Diagnostics | `read/problems` | error list (to verify) | reads build output instead |
| MCP servers | separate from terminal | separate from terminal | never requests Azure MCP for a local build |

GitHub's custom-agent reference states that unrecognised tool names in an agent's `tools:` list are ignored, and Microsoft notes that tool names vary across Copilot platforms. A `tools:` list written for VS Code can therefore leave a Visual Studio agent without edit or terminal tools. That is the most likely cause of "the agent asked me to save the files" in Visual Studio.

## Fix for missing tools in Visual Studio 2026
Reinstall with the unrestricted tool profile, which omits the `tools:` restriction and uses host defaults; it does not grant permissions or prove a tool is callable:

```cmd
set SDD_TOOL_PROFILE=Unrestricted
Install-DevelopmentBuilder.cmd DAB "<repo path>" Both
```

Then, in the agent picker, confirm that file editing and terminal tools are enabled for **Akzo SDD Developer**.

## Where `.github` is read from
- VS Code reads `.github/agents`, `.github/prompts`, `.github/instructions` and `.github/skills` at the **workspace root**. Open the repository root (or the multi-root workspace) so that both the agents and `src/.github/specs` are visible.
- Visual Studio 2026 reads `.github/agents` "in your repo". Whether a solution opened from `src/` resolves the repository root is **to verify** in the pilot. If the agents do not appear, open the folder at the repository root.
- The published specs stay in `src/.github/specs/<Feature>/`. That path does not affect agent discovery.

## Without a terminal: what still works
- PBI discovery, analysis, and writing spec.md, plan.md and every working file with the edit tool.
- The agent writes `sdd-state.json` itself and records `NOT EXECUTED` for each check it could not run.
- The developer (or CI) runs the gates later. They validate the files on disk, so they do not depend on how the files were written.
- Approval: the developer runs the one `tools/Approve-SDD.ps1` command printed by the agent. Approval is the developer's decision either way.

## Pilot checklist (run once per IDE, record the result in `release/IDE-PILOT.md`)
1. Agent appears in the picker after install.
2. `Start Development <id> <title>`: the agent reports its capability table.
3. spec.md and plan.md are written without any manual step and pass `AnalysisComplete`.
4. With a terminal: `Start-SDD.ps1` and the gates run from the agent. Without one: `NOT EXECUTED` is reported, never PASS.
5. After approval, the agent edits code, builds and runs the targeted tests (or records `NOT EXECUTED`).
6. `git status` shows only feature changes, spec.md and plan.md.

Claude Code can follow `.github/sdd/workflow.md` as shared instructions and invoke the PowerShell tools if available. Native agent discovery in Claude Code is not verified.
