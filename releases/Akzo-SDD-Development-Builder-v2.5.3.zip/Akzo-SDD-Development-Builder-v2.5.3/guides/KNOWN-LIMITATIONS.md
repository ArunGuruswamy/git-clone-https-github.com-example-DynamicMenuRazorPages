# v2.5.3 validation boundary

The release is validated on Linux with PowerShell 7 against temporary mock repositories. These are distinct from live IDE or application integration results.

| Capability | Boundary |
|---|---|
| Visual Studio 2026, Test Explorer, VS Code Copilot, Claude Code | NOT EXECUTED. Capability fallbacks and shared agent behavior are contract-tested. Pilot actual host discovery and tool authorization. |
| Windows PowerShell 5.1, cmd.exe and enterprise execution policies | NOT EXECUTED. Windows-compatible encodings and policy-preserving launcher/hook text are tested. Validate on Windows before broad rollout. |
| Real DAB, CDMS, Angular and PBI 305183 | NOT EXECUTED. The scenario uses a declared synthetic PBI, repository and executable PowerShell domain simulation. It does not compile real application projects. |
| Real PR history, CI, Sonar services and external MCP | NOT EXECUTED. Imported sample PR comments exercise provenance and filtering; no actual historical comments are invented. |
| Actual provider token usage or latency improvement | UNKNOWN. Instruction bytes and measured local command/time counts are reported separately as proxies. |

## Important limits
- Approval records bind person, statement, specification, plan and input hashes, but a local script cannot authenticate who typed a chat message. Approval must come from the user.
- Structural gates, local logs and hashes catch missing/stale/accidentally changed evidence; they do not replace independent business review or trusted CI and do not resist a user deliberately forging all local evidence.
- SDK-style .NET dependency selection reads literal ProjectReference links. Imports, unknown changes and ambiguous dependencies fall back to all tests. Custom build/test commands and UI scripts must be confirmed as noninteractive and must actually execute relevant tests; successful exit alone does not prove coverage.
- Hard process termination may leave an INTERRUPTED checkpoint. Resume by inspecting logs and rerunning verification; no success is inferred. Windows process-tree termination uses taskkill under Windows PowerShell 5.1 and remains unexecuted here.
- Source fingerprints intentionally exclude dependency/build output directories, local runtime state and PBI work notes. PBI inputs have a separate hash-bound approval gate. Put custom verification scripts and dependency declarations in normal source/configuration paths. Linked source paths fail closed; configure or inspect them before verification.
- Files already tracked by Git remain visible. Local-only upgrades preserve tracked assets and report them; a reviewed team update is required. User-modified installed files also remain unless explicitly replaced with -Force after review.
- Rollback of older manifests lacking backup hashes retains those files for manual review. A marker alone no longer permits removing an old hook. Backups, user settings, inputs and specifications remain available.
- PDF extraction needs pdftotext; images/scanned PDFs need an agent reader. Unsupported files are reported, never fabricated. Semantic conflicts require analysis beyond deterministic discrepancy checks.
- Preserved team-owned config/architecture documents may contain legacy instructions. The v2.5.3 workflow governs modes; review intentional team exceptions rather than overwriting their files silently.

For live-host validation use `guides/VS2026-COMPATIBILITY.md`. Build/test reports and benchmarks are delivered outside the deterministic ZIP.

## Native IDE execution and this incident
Agent instruction files and PowerShell gates cannot intercept every native Copilot/Visual Studio edit or test tool. The agent must execute startup/approval checks; installation diagnostics cannot prove which instructions an already-open chat loaded. Reopen the agent session after a READY installation.

The 306400 screenshot is evidence of missing-artifact reporting, CS0234 diagnostics, zero-test runs and a previous-build fallback; the actual Windows repository and its approved PBI were unavailable to this cloud task. No claim is made that its source errors were repaired. v2.5.3 tests use declared fixtures and simulated IDE output to reject these failure paths.

Reference searches are bounded to configured/workspace/known sibling repositories, 3,500 candidate files per repository and 100 matches. Skipped large files, inaccessible paths, linked directories and missing remote-tracking refs limit absence claims. Existing local Git history is not proof of an up-to-date remote or a merged business change.
