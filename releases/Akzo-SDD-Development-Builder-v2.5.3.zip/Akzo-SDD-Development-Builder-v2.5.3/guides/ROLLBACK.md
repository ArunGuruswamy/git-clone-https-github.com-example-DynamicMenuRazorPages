# Rollback and uninstall

Every v2.4.0+ install writes `.sdd-builder/manifest.json` (local-only). It records each file the installer created, replaced or left alone, with SHA256 hashes and backup locations.

## Undo the last upgrade
```powershell
.\Uninstall-DevelopmentBuilder.ps1 -Destination "<repo path>" -RollbackLastUpgrade -WhatIf   # preview
.\Uninstall-DevelopmentBuilder.ps1 -Destination "<repo path>" -RollbackLastUpgrade
```
Restores unchanged owned files with a matching backup hash that the upgrade replaced (from `.sdd-installer-backups/<timestamp>/`) and removes the files it newly added.

## Remove the builder completely
```powershell
.\Uninstall-DevelopmentBuilder.ps1 -Destination "<repo path>" -WhatIf
.\Uninstall-DevelopmentBuilder.ps1 -Destination "<repo path>"
```

## Guarantees
- Removes only files the builder wrote that are still byte-identical to what it wrote. Files you edited afterwards are kept and listed.
- Files that existed before the builder are restored only when current ownership and backup hashes match. Older manifests without backup hashes need manual review.
- Never touches `src/.github/specs/`, `docs/sdd/pbi-input/`, `docs/sdd/pbi-sources/`, `docs/sdd/changes/` or application code.
- Never deletes newly tracked files; restoring a previously updated tracked file requires matching installed and backup hashes.
- Never runs `git reset`, `git clean`, `git checkout` or `git rm`.
- Removes exact exclusions for removed owned files; keeps input/work/settings/backup exclusions.
- Backups stay in `.sdd-installer-backups/`; delete that folder yourself when you no longer need it.

## Installs before v2.4.0
Older installers wrote no manifest, so the uninstaller refuses to guess. Review `git status --ignored` and the old `*.backup-<timestamp>` files next to the agents, and remove builder files by hand.

Hooks require recorded hash ownership. Modified hooks remain. Rolling back a no-op upgrade keeps hooks created by an earlier install. User settings and unresolved ownership records are preserved.
