﻿[CmdletBinding()]
param(
    # Run only tests whose name matches this wildcard, e.g. 'Discovery.*'.
    [string]$Filter = '*',
    [string]$ReportDirectory
)
# Akzo SDD Builder - regression test runner. Works on Windows PowerShell 5.1 and PowerShell 7+ without Pester.
# Usage:  pwsh -File tests/Run-Tests.ps1      or      powershell -File tests\Run-Tests.ps1
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'TestHelpers.ps1')
if (-not $ReportDirectory) { $ReportDirectory = Join-Path $PSScriptRoot 'results' }

$script:Registered = New-Object System.Collections.Generic.List[object]
function Test([string]$Name, [scriptblock]$Body, [string]$Kind = 'Runtime') {
    $script:Registered.Add([pscustomobject]@{ Name = $Name; Body = $Body; Kind = $Kind })
}
foreach ($file in (Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.Tests.ps1' | Sort-Object Name)) { . $file.FullName }

$results = New-Object System.Collections.Generic.List[object]
$hasGit = [bool](Get-Command git -ErrorAction SilentlyContinue)
foreach ($t in ($script:Registered | Where-Object { $_.Name -like $Filter })) {
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $status = 'PASS'; $message = ''
    try {
        if ($t.Kind -eq 'RequiresGit' -and -not $hasGit) { $status = 'SKIPPED'; $message = 'git not available' }
        else { $null = & $t.Body }
    } catch { $status = 'FAIL'; $message = $_.Exception.Message }
    $sw.Stop()
    $color = switch ($status) { 'PASS' { 'Green' } 'FAIL' { 'Red' } default { 'Yellow' } }
    Write-Host ("[{0,-7}] {1} ({2:n1}s){3}" -f $status, $t.Name, $sw.Elapsed.TotalSeconds, $(if ($message) { " - $message" } else { '' })) -ForegroundColor $color
    $results.Add([pscustomobject][ordered]@{ name = $t.Name; kind = $t.Kind; status = $status; seconds = [Math]::Round($sw.Elapsed.TotalSeconds, 2); message = $message })
}

$pass = @($results | Where-Object status -eq 'PASS').Count
$fail = @($results | Where-Object status -eq 'FAIL').Count
$skip = @($results | Where-Object status -eq 'SKIPPED').Count
if (-not (Test-Path -LiteralPath $ReportDirectory)) { [void](New-Item -ItemType Directory -Path $ReportDirectory -Force) }
$envInfo = [ordered]@{
    psEdition = $PSVersionTable.PSEdition; psVersion = $PSVersionTable.PSVersion.ToString()
    os = $(if ($env:OS -eq 'Windows_NT') { 'Windows' } elseif ($IsLinux) { 'Linux' } elseif ($IsMacOS) { 'macOS' } else { 'Unknown' })
    git = $(if ($hasGit) { ((& git --version) | Out-String).Trim() } else { 'not available' })
    ranAtUtc = [DateTime]::UtcNow.ToString('o')
}
[ordered]@{ environment = $envInfo; passed = $pass; failed = $fail; skipped = $skip; results = $results } | ConvertTo-Json -Depth 5 |
    Set-Content -LiteralPath (Join-Path $ReportDirectory 'test-report.json') -Encoding UTF8
$md = New-Object System.Text.StringBuilder
[void]$md.AppendLine('# Builder regression test report')
[void]$md.AppendLine('')
[void]$md.AppendLine("- Environment: $($envInfo.os), PowerShell $($envInfo.psEdition) $($envInfo.psVersion), $($envInfo.git)")
[void]$md.AppendLine("- Run (UTC): $($envInfo.ranAtUtc)")
[void]$md.AppendLine("- Result: **$pass passed, $fail failed, $skip skipped** of $($results.Count)")
[void]$md.AppendLine('')
[void]$md.AppendLine('| Test | Kind | Result | Seconds | Message |')
[void]$md.AppendLine('|---|---|---|---|---|')
foreach ($r in $results) { [void]$md.AppendLine("| $($r.name) | $($r.kind) | $($r.status) | $($r.seconds) | $(($r.message -replace '\|', '/' -replace '\r?\n', ' '))  |") }
Set-Content -LiteralPath (Join-Path $ReportDirectory 'test-report.md') -Value $md.ToString() -Encoding UTF8
Write-Host ("`n{0} passed, {1} failed, {2} skipped. Report: {3}" -f $pass, $fail, $skip, (Join-Path $ReportDirectory 'test-report.md')) -ForegroundColor $(if ($fail) { 'Red' } else { 'Green' })
if ($results.Count -eq 0) { Write-Error 'No tests matched the selected filter; no validation executed.'; exit 2 }
exit $fail
