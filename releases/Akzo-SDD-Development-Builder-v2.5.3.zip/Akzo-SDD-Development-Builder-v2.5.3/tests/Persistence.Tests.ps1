﻿# spec.md / plan.md persistence and the deterministic stage gates (Phase D)

function Start-Fixture305183 {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $s = Invoke-Tool 'Start-SDD.ps1' @('-Repository', $r, '-Request', 'Start Development 305183 Complaint Imitation Request')
    if ($s.ExitCode -ne 0) { throw "Start-SDD failed: $($s.Output)" }
    return $r
}
function Assert-Stage([string]$Repo, [string]$Stage) { return Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $Repo, '-Feature', 'ComplaintImitationRequest', '-Stage', $Stage) }
$script:Spec = 'src/.github/specs/ComplaintImitationRequest/spec.md'
$script:Plan = 'src/.github/specs/ComplaintImitationRequest/plan.md'

Test 'Persistence.FeatureOnlyFolderName' {
    $r = Start-Fixture305183
    Assert-True (Test-Path "$r/src/.github/specs/ComplaintImitationRequest") 'PascalCase feature folder'
    Assert-True (@(Get-ChildItem "$r/src/.github/specs" -Directory | Where-Object Name -match '\d').Count -eq 0) 'no PBI number in any folder name'
}

Test 'Persistence.InitWritesSpecAndPlanOnDisk' {
    # Regression for RC-01: v2.3.4 threw at Start-SDD.ps1:56 before writing either file.
    $r = Start-Fixture305183
    foreach ($p in @($script:Spec, $script:Plan)) {
        Assert-True (Test-Path "$r/$p" -PathType Leaf) "$p exists"
        Assert-Match ([IO.File]::ReadAllText("$r/$p")) 'PBI ID: 305183' "$p declares the PBI"
    }
    Assert-Equal 'Initialized' (Get-Content "$r/docs/sdd/changes/305183-ComplaintImitationRequest/sdd-state.json" -Raw | ConvertFrom-Json).stage 'state stage'
    Assert-True (-not (Test-Path "$r/docs/sdd/changes/305183-ComplaintImitationRequest/04-spec.md")) 'no second working spec (RC-11)'
}

Test 'Persistence.PendingPlaceholdersRejected' {
    $r = Start-Fixture305183
    $a = Assert-Stage $r 'AnalysisComplete'
    Assert-Equal 1 $a.ExitCode 'skeleton must not pass'
    Assert-Match $a.Output 'unresolved placeholders' 'PENDING detected'
}

Test 'Persistence.MissingFileRejected' {
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    Remove-Item "$r/$script:Plan"
    $a = Assert-Stage $r 'AnalysisComplete'
    Assert-Equal 1 $a.ExitCode 'missing plan fails'
    Assert-Match $a.Output 'File not saved on disk: src/.github/specs/ComplaintImitationRequest/plan.md' 'names the missing file'
}

Test 'Persistence.CompletedAnalysisPasses' {
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $a = Assert-Stage $r 'AnalysisComplete'
    Assert-Equal 0 $a.ExitCode "complete analysis passes: $($a.Output)"
    Assert-Equal 'AnalysisComplete' (Get-Content "$r/docs/sdd/changes/305183-ComplaintImitationRequest/sdd-state.json" -Raw | ConvertFrom-Json).stage 'stage recorded'
}

Test 'Persistence.VerbatimTbdInPbiIsAllowed' {
    # Regression for RC-06: the PBI says "TBD"; quoting it is required, not a placeholder.
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    Assert-Match ([IO.File]::ReadAllText("$r/$script:Spec")) 'TBD by the PO' 'spec quotes TBD'
    Assert-Equal 0 (Assert-Stage $r 'AnalysisComplete').ExitCode 'still passes'
}

Test 'Persistence.HollowDocumentsRejected' {
    # Regression for RC-07: headings with N/A and padding passed in v2.3.4.
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $spec = [IO.File]::ReadAllText("$r/$script:Spec")
    $hollow = [regex]::Replace($spec, '(?s)## Existing implementation and repository evidence.*?(?=## Delta)', "## Existing implementation and repository evidence`n`nN/A`n`n")
    Write-File "$r/$script:Spec" $hollow
    $a = Assert-Stage $r 'AnalysisComplete'
    Assert-Equal 1 $a.ExitCode 'hollow section fails'
    Assert-Match $a.Output "no substantive content" 'reason'
}

Test 'Persistence.UnverifiedEvidenceRejected' {
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $spec = [IO.File]::ReadAllText("$r/$script:Spec") -replace 'src/AN\.ColorAppsAzure\.Formula', 'src/Invented.Project'
    $plan = [IO.File]::ReadAllText("$r/$script:Plan") -replace 'src/AN\.ColorAppsAzure\.Formula', 'src/Invented.Project'
    Write-File "$r/$script:Spec" $spec; Write-File "$r/$script:Plan" $plan
    $a = Assert-Stage $r 'AnalysisComplete'
    Assert-Equal 1 $a.ExitCode 'invented paths fail'
    Assert-Match $a.Output 'cites no repository file that exists on disk' 'reason'
}

Test 'Persistence.ChangedAcceptanceCriterionRejected' {
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $spec = [IO.File]::ReadAllText("$r/$script:Spec")
    $i = $spec.IndexOf('## Acceptance criteria')
    $spec = $spec.Substring(0, $i) + $spec.Substring($i).Replace('lowercase "c" suffix', 'uppercase "C" suffix')
    Write-File "$r/$script:Spec" $spec
    $a = Assert-Stage $r 'AnalysisComplete'
    Assert-Equal 1 $a.ExitCode 'altered AC fails'
    Assert-Match $a.Output 'Acceptance criterion changed or missing' 'reason'
}

Test 'Persistence.VerbatimBlockTamperingRejected' {
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    Write-File "$r/$script:Spec" ([IO.File]::ReadAllText("$r/$script:Spec").Replace('Reuse the existing CreateImitationRequest flow', 'Add a new endpoint'))
    $a = Assert-Stage $r 'AnalysisComplete'
    Assert-Equal 1 $a.ExitCode 'tampered verbatim PBI fails'
    Assert-Match $a.Output 'verbatim PBI block' 'reason'
}

Test 'Persistence.MissingTraceabilityRejected' {
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    Write-File "$r/$script:Plan" ([IO.File]::ReadAllText("$r/$script:Plan") -replace '\| AC-3 \|[^\n]*\n', '' -replace 'AC-3', 'the third criterion')
    $a = Assert-Stage $r 'AnalysisComplete'
    Assert-Equal 1 $a.ExitCode 'uncovered AC fails'
    Assert-Match $a.Output 'traceability does not cover: AC-3' 'reason'
}

Test 'Persistence.ExistingSpecPreservedOnRestart' {
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $before = Get-FileHash "$r/$script:Spec"
    $null = Invoke-Tool 'Start-SDD.ps1' @('-Repository', $r, '-Request', 'Start Development 305183 Complaint Imitation Request')
    Assert-Equal $before.Hash (Get-FileHash "$r/$script:Spec").Hash 'restart never overwrites spec.md'
}

Test 'Persistence.OtherPbiSpecNeverOverwritten' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $before = Get-FileHash "$r/src/.github/specs/TechnicalRemarks/spec.md"
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Feature', 'TechnicalRemarks', '-Title', 'Complaint Imitation Request')
    Assert-Equal 'ReconcileExistingSpec' $x.Data.status 'reconcile requested'
    Assert-Equal $before.Hash (Get-FileHash "$r/src/.github/specs/TechnicalRemarks/spec.md").Hash 'TechnicalRemarks untouched'
}

Test 'Approval.RequiredBeforeImplementation' {
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $null = Assert-Stage $r 'AnalysisComplete'
    $a = Assert-Stage $r 'ImplementationApproved'
    Assert-Equal 1 $a.ExitCode 'blocked without approval'
    Assert-Match $a.Output 'No approval recorded' 'reason'
}

Test 'Approval.AnalysisCompleteDoesNotNeedApproval' {
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $a = Assert-Stage $r 'AnalysisComplete'
    Assert-Equal 0 $a.ExitCode 'analysis gate independent of approval'
    Assert-NotMatch $a.Output 'approval' 'no approval demanded'
}

Test 'Approval.BotApproverRejected' {
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $a = Invoke-Tool 'Approve-SDD.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Statement', 'Approved', '-ApprovedBy', 'GitHub Copilot')
    Assert-True ($a.ExitCode -ne 0) 'agent identity cannot approve'
    Assert-True (-not (Test-Path "$r/docs/sdd/changes/305183-ComplaintImitationRequest/approval.json")) 'nothing recorded'
}

Test 'Approval.SelfWrittenApprovalMarkdownIsNotEnough' {
    # Regression for RC-09: v2.3.4 accepted a hand-written 'Approved by: Copilot' line.
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $h = (Get-FileHash "$r/$script:Spec" -Algorithm SHA256).Hash.ToLowerInvariant()
    Write-File "$r/docs/sdd/changes/305183-ComplaintImitationRequest/approval.md" "Approved by: Copilot`nSpec revision / SHA256: $h`n"
    Assert-Equal 1 (Assert-Stage $r 'ImplementationApproved').ExitCode 'approval.md alone does not approve'
}

Test 'Approval.RecordedApprovalPasses' {
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $a = Invoke-Tool 'Approve-SDD.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Statement', 'Approved - implement T1 to T4')
    Assert-Equal 0 $a.ExitCode "approval recorded: $($a.Output)"
    $j = Get-Content "$r/docs/sdd/changes/305183-ComplaintImitationRequest/approval.json" -Raw | ConvertFrom-Json
    Assert-Equal 'Asha Developer' $j.approvedBy 'approver from git identity'
    Assert-Equal 64 $j.planSha256.Length 'plan hash recorded'
    Assert-Equal 'ImplementationApproved' (Get-Content "$r/docs/sdd/changes/305183-ComplaintImitationRequest/sdd-state.json" -Raw | ConvertFrom-Json).stage 'stage'
}

Test 'Approval.SpecChangeRequiresReapproval' {
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $null = Invoke-Tool 'Approve-SDD.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Statement', 'Approved')
    Add-Content "$r/$script:Spec" "`n- Extra requirement added after approval.`n"
    $a = Assert-Stage $r 'ImplementationApproved'
    Assert-Equal 1 $a.ExitCode 'changed spec blocks implementation'
    Assert-Match $a.Output 'spec.md changed after approval' 'reason'
    Assert-Equal 'AnalysisComplete' (Get-Content "$r/docs/sdd/changes/305183-ComplaintImitationRequest/sdd-state.json" -Raw | ConvertFrom-Json).stage 'stage moved back'
}

Test 'Approval.PlanChangeRequiresReapproval' {
    # Regression for RC-08: v2.3.4 hashed spec.md only.
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $null = Invoke-Tool 'Approve-SDD.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Statement', 'Approved')
    Add-Content "$r/$script:Plan" "`n5. T5 delete the validator.`n"
    $a = Assert-Stage $r 'ImplementationApproved'
    Assert-Equal 1 $a.ExitCode 'changed plan blocks implementation'
    Assert-Match $a.Output 'plan.md changed after approval' 'reason'
}

Test 'Approval.LineEndingChangeKeepsApproval' {
    # Git autocrlf must not invalidate an approval.
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $null = Invoke-Tool 'Approve-SDD.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Statement', 'Approved')
    $t = [IO.File]::ReadAllText("$r/$script:Spec").Replace("`r`n", "`n").Replace("`n", "`r`n")
    [IO.File]::WriteAllText("$r/$script:Spec", $t, (New-Object System.Text.UTF8Encoding($true)))
    Assert-Equal 0 (Assert-Stage $r 'ImplementationApproved').ExitCode 'CRLF + BOM still approved'
}

Test 'State.RestartDoesNotResetStage' {
    # Regression for RC-10.
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    $null = Invoke-Tool 'Approve-SDD.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Statement', 'Approved')
    $null = Invoke-Tool 'Start-SDD.ps1' @('-Repository', $r, '-Request', 'Start Development 305183 Complaint Imitation Request')
    $s = Get-Content "$r/docs/sdd/changes/305183-ComplaintImitationRequest/sdd-state.json" -Raw | ConvertFrom-Json
    Assert-Equal 'ImplementationApproved' $s.stage 'stage kept'
    Assert-True (@($s.history).Count -ge 3) 'history appended'
}

Test 'State.LegacyStageAliasesStillWork' {
    $r = Start-Fixture305183; Complete-FixtureAnalysis $r
    Assert-Equal 0 (Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'Draft')).ExitCode 'Draft alias'
    Assert-Equal 1 (Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'Approved')).ExitCode 'Approved alias enforces approval'
    $v = Invoke-Tool 'Validate-SDD.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-ChangeFolder', 'docs/sdd/changes/305183-ComplaintImitationRequest')
    Assert-Equal 0 $v.ExitCode "Validate-SDD v2.3 command line: $($v.Output)"
}
