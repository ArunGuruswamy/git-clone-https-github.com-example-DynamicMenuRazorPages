﻿# Tool capability fallback and evidence-based verification (Phase F, Phase G)
# These tests exercise the scripts and file contracts. They do NOT run Visual Studio or VS Code.

function New-ApprovedFixture {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Invoke-Tool 'Start-SDD.ps1' @('-Repository', $r, '-Request', 'Start Development 305183 Complaint Imitation Request')
    Complete-FixtureAnalysis $r
    $a = Invoke-Tool 'Approve-SDD.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Statement', 'Approved')
    if ($a.ExitCode -ne 0) { throw $a.Output }
    return $r
}
$script:Work = 'docs/sdd/changes/305183-ComplaintImitationRequest'

Test 'Capability.FullTerminalPreflight' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Invoke-Tool 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    $x = Invoke-ToolJson 'Test-SDDCapabilities.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest')
    Assert-Equal 0 $x.ExitCode 'preflight runs'
    Assert-True $x.Data.terminal.available 'terminal proven by execution'
    Assert-Equal 'DAB' $x.Data.repository.role 'role'
    Assert-True ($x.Data.buildCapability -in @('EXECUTABLE', 'CI_ONLY', 'NOT_EXECUTABLE')) 'build capability classified'
    Assert-True (Test-Path "$r/$script:Work/capabilities.json") 'saved for the PBI'
}

Test 'Capability.FileEditingWithoutTerminal' {
    # The agent has only read/search/edit tools: it writes every file itself, including sdd-state.json.
    # No script runs during the session; the gate is run later (developer terminal or CI) and must pass.
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $state = [ordered]@{ version = '2.4.0'; pbiId = '305183'; title = 'Complaint Imitation Request'; feature = 'ComplaintImitationRequest'; role = 'DAB'; skill = 'dab-development'
        source = 'docs/sdd/pbi-input/305183/REFINED-PBI.md'; sourceKind = 'ApprovedRefined'; stage = 'None'; writtenBy = 'agent edit tool (no terminal)' }
    Write-File "$r/$script:Work/sdd-state.json" ($state | ConvertTo-Json)
    Complete-FixtureAnalysis $r
    Assert-True (Test-Path "$r/src/.github/specs/ComplaintImitationRequest/spec.md") 'spec persisted without any script'
    $a = Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'AnalysisComplete')
    Assert-Equal 0 $a.ExitCode "deferred gate passes on agent-written files: $($a.Output)"
}

Test 'Capability.NoTerminalRecordsNotExecuted' {
    $r = New-ApprovedFixture
    # What the agent writes with its edit tool when it cannot execute anything:
    $doc = [ordered]@{ pbiId = '305183'; feature = 'ComplaintImitationRequest'; checks = @(
        [ordered]@{ kind = 'build'; name = 'build'; executed = $false; reason = 'No terminal tool in this Visual Studio agent session' },
        [ordered]@{ kind = 'test'; name = 'test'; executed = $false; reason = 'No terminal tool in this Visual Studio agent session' }) }
    Write-File "$r/$script:Work/verification.json" ($doc | ConvertTo-Json -Depth 4)
    $a = Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'ImplementationVerified')
    Assert-Equal 1 $a.ExitCode 'not executed is never verified'
    Assert-Match $a.Output "build 'build' NOT EXECUTED" 'reported honestly'
    Assert-Equal 0 (Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'ImplementationApproved')).ExitCode 'completed work preserved: approval still valid'
}

Test 'Capability.MissingBuildToolRecordedNotExecuted' {
    $r = New-ApprovedFixture
    $v = Invoke-Tool 'Invoke-SDDVerification.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Build', 'definitely-not-a-real-tool-xyz build', '-Test', 'definitely-not-a-real-tool-xyz test')
    Assert-Equal 1 $v.ExitCode 'returns failure'
    $j = Get-Content "$r/$script:Work/verification.json" -Raw | ConvertFrom-Json
    Assert-True (@($j.checks | Where-Object { -not $_.executed }).Count -eq 2) 'both NOT EXECUTED, nothing fabricated'
}

Test 'Capability.ExecutedChecksWithRealExitCodes' {
    $r = New-ApprovedFixture
    $v = Invoke-Tool 'Invoke-SDDVerification.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Build', 'git --version', '-Test', 'git status --short')
    Assert-Equal 0 $v.ExitCode "checks ran: $($v.Output)"
    $a = Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'ImplementationVerified')
    Assert-Equal 0 $a.ExitCode "verified with logs: $($a.Output)"
} 'RequiresGit'

Test 'Capability.FailingTestBlocksVerification' {
    $r = New-ApprovedFixture
    $null = Invoke-Tool 'Invoke-SDDVerification.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Build', 'git --version', '-Test', 'git definitely-not-a-subcommand')
    $a = Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'ImplementationVerified')
    Assert-Equal 1 $a.ExitCode 'failing test blocks'
    Assert-Match $a.Output "test 'test' failed with exit code" 'real exit code reported'
} 'RequiresGit'

Test 'Capability.TamperedEvidenceRejected' {
    $r = New-ApprovedFixture
    $null = Invoke-Tool 'Invoke-SDDVerification.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Build', 'git --version', '-Test', 'git definitely-not-a-subcommand')
    $j = Get-Content "$r/$script:Work/verification.json" -Raw | ConvertFrom-Json
    foreach ($c in $j.checks) { $c.exitCode = 0 }
    Write-File "$r/$script:Work/verification.json" ($j | ConvertTo-Json -Depth 5)
    $log = @($j.checks | Where-Object kind -eq 'test')[0].logFile
    Add-Content "$r/$log" 'All tests passed'
    $a = Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'ImplementationVerified')
    Assert-Equal 1 $a.ExitCode 'edited log detected'
    Assert-Match $a.Output 'does not match its recorded hash' 'reason'
} 'RequiresGit'

Test 'Capability.VisualStudioTestExplorerOnlyPath' {
    # VS exposes a test-runner tool but no terminal: the agent records the Test Explorer result as
    # NOT EXECUTED for the command-line gate and keeps the IDE result as additional evidence only.
    $r = New-ApprovedFixture
    $v = Invoke-Tool 'Invoke-SDDVerification.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-NotExecutedKind', 'build', '-NotExecutedReason', 'VS 2026 agent: Test Explorer tool only, no terminal')
    Assert-Equal 0 $v.ExitCode 'recording works'
    $j = Get-Content "$r/$script:Work/verification.json" -Raw | ConvertFrom-Json
    Assert-Match ($j.checks[0].reason) 'Test Explorer' 'reason stored'
    Assert-Equal 1 (Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'ImplementationVerified')).ExitCode 'gate stays closed until a command-line or CI run'
}

Test 'Capability.ReadOnlySessionDoesNotWrite' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Invoke-Tool 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    $statePath = "$r/$script:Work/sdd-state.json"
    $before = Get-FileHash $statePath
    $null = Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'AnalysisComplete', '-NoStateUpdate')
    Assert-Equal $before.Hash (Get-FileHash $statePath).Hash 'validation-only run writes nothing'
}

Test 'Capability.AgentsDoNotRequireAzureMcpForBuilds' {
    foreach ($f in @('akzo-sdd-developer.agent.md', 'akzo-sdd-developer-concise.agent.md')) {
        $t = [IO.File]::ReadAllText((Join-Path $script:PackageRoot "core/.github/agents/$f"))
        Assert-Match $t 'MCP access is not terminal access' "$f separates MCP from terminal"
        Assert-Match $t 'NOT EXECUTED' "$f has the no-terminal fallback"
        Assert-Match $t 'Never ask the developer to run mkdir' "$f forbids manual file work"
    }
} 'Static'
