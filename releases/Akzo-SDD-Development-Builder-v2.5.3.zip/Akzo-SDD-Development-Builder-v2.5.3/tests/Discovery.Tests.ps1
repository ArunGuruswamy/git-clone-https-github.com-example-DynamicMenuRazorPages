﻿# PBI discovery and repository-role selection (Phase B, Phase C)

Test 'Discovery.NumberedInputFolder' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-Request', 'Start Development 305183 Complaint Imitation Request')
    Assert-Equal 0 $x.ExitCode 'exit code'
    Assert-Equal 'Initialized' $x.Data.status 'status'
    Assert-Equal 'docs/sdd/pbi-input/305183/REFINED-PBI.md' $x.Data.source 'selected source'
    Assert-Equal 'ApprovedRefined' $x.Data.sourceKind 'kind'
}

Test 'Discovery.FlatRefinedFileWithVerifiedIdentity' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r 'docs/sdd/pbi-input/refined-pbi.md'
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 0 $x.ExitCode 'exit code'
    Assert-Equal 'docs/sdd/pbi-input/refined-pbi.md' $x.Data.source 'flat file used after identity check'
}

Test 'Discovery.FlatFileForAnotherPbiIsNotUsed' {
    $r = New-FixtureRepo DAB
    Write-File "$r/docs/sdd/pbi-input/refined-pbi.md" "# Other`n`n- PBI ID: 309559`n- Status: Approved`n`n- AC-1 Given x When y Then z`n"
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 4 $x.ExitCode 'not found'
    Assert-Equal 'PbiNotFound' $x.Data.status 'status'
    Assert-True (@(Get-ChildItem "$r/src/.github/specs" -Directory).Name -notcontains 'ComplaintImitationRequest') 'no folder created for wrong PBI'
}

Test 'Discovery.MultipleUnrelatedPbisAndBodyMentionIgnored' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    Write-File "$r/docs/sdd/pbi-input/305200/REFINED-PBI.md" "# Other`n`n- PBI ID: 305200`n- Status: Approved`n`nDepends on 305183 being released first.`n"
    Write-File "$r/docs/sdd/pbi-input/309559/REFINED-PBI.md" "# Third`n`n- PBI ID: 309559`n"
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-Request', 'Start Development 305183 Complaint Imitation Request')
    Assert-Equal 0 $x.ExitCode 'exit code'
    Assert-Equal 'docs/sdd/pbi-input/305183/REFINED-PBI.md' $x.Data.source 'correct PBI chosen'
}

Test 'Discovery.DuplicateIdenticalCopiesCollapse' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r; Add-RefinedPbi $r 'docs/sdd/pbi-input/305183/copy/REFINED-PBI.md'
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 0 $x.ExitCode 'identical copies are not ambiguous'
    Assert-Match $x.Data.discovery 'Identical copies ignored' 'duplicate reported'
}

Test 'Discovery.DifferentCopiesAreAmbiguous' {
    $r = New-FixtureRepo DAB
    Write-File "$r/docs/sdd/pbi-input/305183/refined-a.md" "# A`n- PBI ID: 305183`n- Status: Approved`n- AC-1 Given a When b Then c`n"
    Write-File "$r/docs/sdd/pbi-input/305183/refined-b.md" "# B`n- PBI ID: 305183`n- Status: Approved`n- AC-1 Given a When b Then DIFFERENT`n"
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 5 $x.ExitCode 'ambiguous exit code'
    Assert-Equal 'PbiAmbiguous' $x.Data.status 'status'
}

Test 'Discovery.RefinedPreferredOverOriginal' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    Write-File "$r/docs/sdd/pbi-input/305183/ORIGINAL-PBI.md" "# Original`n- PBI ID: 305183`nAs a user I want complaint IRs.`n"
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 0 $x.ExitCode 'exit code'
    Assert-Equal 'docs/sdd/pbi-input/305183/REFINED-PBI.md' $x.Data.source 'refined wins'
}

Test 'Discovery.ApprovedRefinedPreferredOverDraftRefined' {
    $r = New-FixtureRepo DAB
    Write-File "$r/docs/sdd/pbi-input/305183/refined-draft.md" "# Draft`n- PBI ID: 305183`n- Status: Refined`n- AC-1 Given a When b Then c`n"
    Write-File "$r/docs/sdd/pbi-sources/305183-ComplaintImitationRequest/source/REFINED-PBI.md" ([IO.File]::ReadAllText("$script:FixtureData/305183/REFINED-PBI.md"))
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 'ApprovedRefined' $x.Data.sourceKind 'approved refined wins across tiers'
    Assert-Match $x.Data.source 'pbi-sources' 'handoff source chosen'
}

Test 'Discovery.OriginalOnlyStartsRefinement' {
    $r = New-FixtureRepo DAB
    Write-File "$r/docs/sdd/pbi-input/305183/ORIGINAL-PBI.md" "# Original`n- PBI ID: 305183`nAs a user I want complaint IRs.`n"
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 0 $x.ExitCode 'exit code'
    Assert-Equal 'RefinementRequired' $x.Data.status 'status'
    Complete-FixtureAnalysis $r -Feature 'ComplaintImitationRequest' 2>$null
    $a = Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'AnalysisComplete')
    Assert-Equal 1 $a.ExitCode 'cannot pass analysis on an unrefined PBI'
    Assert-Match $a.Output 'unrefined PBI' 'reason'
}

Test 'Discovery.ImporterHandoffFound' {
    $r = New-FixtureRepo DAB
    Write-File "$r/docs/sdd/pbi-sources/305183-ComplaintImitationRequest/HANDOFF.md" "# PBI Builder Handoff`n`n- PBI ID: 305183`n"
    Write-File "$r/docs/sdd/pbi-sources/305183-ComplaintImitationRequest/source/output.md" ([IO.File]::ReadAllText("$script:FixtureData/305183/REFINED-PBI.md"))
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183')
    Assert-Equal 0 $x.ExitCode 'exit code'
    Assert-Equal 'docs/sdd/pbi-sources/305183-ComplaintImitationRequest/source/output.md' $x.Data.source 'handoff source used'
    Assert-Equal 'ComplaintImitationRequest' $x.Data.feature 'feature derived from PBI title'
}

Test 'Discovery.ResumeFromExistingArtifacts' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Invoke-Tool 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Remove-Item "$r/docs/sdd/pbi-input" -Recurse -Force
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183')
    Assert-Equal 0 $x.ExitCode 'exit code'
    Assert-Equal 'Resumed' $x.Data.status 'resumes'
    Assert-Equal 'ComplaintImitationRequest' $x.Data.feature 'reuses existing feature folder'
}

Test 'Discovery.SinglePbiFolderNeedsNoId' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-Request', 'Start Development')
    Assert-Equal '305183' $x.Data.pbiId 'id inferred from the only folder'
}

Test 'Discovery.NotFoundCreatesNothing' {
    $r = New-FixtureRepo DAB
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 4 $x.ExitCode 'exit code'
    Assert-True (-not (Test-Path "$r/src/.github/specs/ComplaintImitationRequest")) 'no empty folder'
    Assert-True (-not (Test-Path "$r/docs/sdd/changes")) 'no working folder'
}

Test 'Role.DabSelectedFromEvidence' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 'DAB' $x.Data.role 'role'; Assert-Equal 'dab-development' $x.Data.skill 'skill'
}

Test 'Role.CdmsAndUiSelected' {
    $c = New-FixtureRepo CDMS; Add-RefinedPbi $c
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $c, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 'CDMS' $x.Data.role 'CDMS role'
    $u = New-FixtureRepo UI; Add-RefinedPbi $u
    $y = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $u, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 'UI' $y.Data.role 'UI role'
    Assert-Equal '.github/specs/ComplaintImitationRequest/spec.md' $y.Data.spec 'repository without src uses .github/specs'
}

Test 'Role.AmbiguousAsksOnceAndPersists' {
    $r = New-FixtureRepo Ambiguous; Add-RefinedPbi $r
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 3 $x.ExitCode 'ambiguous role stops'
    Write-File "$r/.sdd-builder/settings.json" '{ "role": "DAB" }'
    $y = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 0 $y.ExitCode 'persisted answer is reused'
    Assert-Equal 'DAB' $y.Data.role 'role from settings'
}

Test 'Role.UnknownRepositoryChangesNothing' {
    $r = New-FixtureRepo Unknown; Add-RefinedPbi $r
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 3 $x.ExitCode 'unresolved role'
    Assert-True (-not (Test-Path "$r/.github/specs")) 'nothing created'
}

Test 'Discovery.FlatNoteMentioningIdIsNotIdentity' {
    # Regression for RC-04: a mention in the body is not an identity.
    $r = New-FixtureRepo DAB
    Write-File "$r/docs/sdd/pbi-input/notes.md" "# Meeting notes`n`nWe discussed 305183 and 305200 yesterday.`n"
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-PbiId', '305183', '-Title', 'Complaint Imitation Request')
    Assert-Equal 4 $x.ExitCode 'a note that mentions the ID is not the PBI'
}

Test 'Discovery.ExplicitSpecFolderInPrompt' {
    # The HTML guide adds '(spec folder: X)' when the developer chose a folder name different from the derived one.
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $x = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-Request', 'Start Development 305183 Complaint Imitation Request (spec folder: ComplaintIR)')
    Assert-Equal 0 $x.ExitCode 'exit code'
    Assert-Equal 'ComplaintIR' $x.Data.feature 'explicit folder used'
    Assert-Equal 'Complaint Imitation Request' $x.Data.title 'folder hint not part of the title'
}

Test 'Guide.HtmlMatchesRelease' {
    $h = [IO.File]::ReadAllText((Join-Path $script:PackageRoot 'Akzo-SDD-Development-Builder.html'))
    Assert-Match $h '<title>Akzo SDD Builder 2\.5\.3</title>' 'HTML guide carries the release version'
    Assert-Match $h "'Start Development '" 'HTML guide builds the Start Development prompt'
    foreach ($tool in @('Install-DevelopmentBuilder.cmd', 'Add-PbiInput.cmd', 'Assert-SDDArtifacts.ps1', 'Approve-SDD.ps1', 'Invoke-SDDVerification.ps1', 'Uninstall-DevelopmentBuilder.ps1')) {
        Assert-Match $h ([regex]::Escape($tool)) "HTML guide references $tool"
        Assert-True ((Get-ChildItem $script:PackageRoot -Recurse -File -Filter $tool).Count -ge 1) "$tool exists in the package"
    }
} 'Static'
