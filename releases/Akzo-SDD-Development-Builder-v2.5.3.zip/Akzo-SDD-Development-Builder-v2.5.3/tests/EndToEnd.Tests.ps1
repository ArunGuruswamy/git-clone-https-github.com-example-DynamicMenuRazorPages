﻿# Complete fixture for: Start Development 305183 Complaint Imitation Request

Test 'E2E.StartDevelopment305183ComplaintImitationRequest' {
    $r = New-FixtureRepo DAB
    Add-RefinedPbi $r
    # 1. The developer types one line; the agent passes it through.
    $s = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository', $r, '-Request', 'Start Development 305183 Complaint Imitation Request')
    Assert-Equal 0 $s.ExitCode 'start succeeds'
    Assert-Equal 'docs/sdd/pbi-input/305183/REFINED-PBI.md' $s.Data.source 'refined PBI discovered'
    Assert-Equal 'DAB' $s.Data.role 'DAB role selected'
    Assert-Equal 'dab-development' $s.Data.skill 'DAB skill selected'
    Assert-Equal 'src/.github/specs/ComplaintImitationRequest/spec.md' $s.Data.spec 'spec path'
    Assert-Equal 'src/.github/specs/ComplaintImitationRequest/plan.md' $s.Data.plan 'plan path'
    # 2. Initialised files are not mistaken for analysis.
    Assert-Equal 1 (Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'AnalysisComplete')).ExitCode 'skeleton is not analysis'
    # 3. The agent writes the completed analysis with its edit tool; persisted files are validated from disk.
    Complete-FixtureAnalysis $r
    $fixturePlan = "$r/src/.github/specs/ComplaintImitationRequest/plan.md"
    $fixtureText = [IO.File]::ReadAllText($fixturePlan).Replace('## Affected source files and components',"## Affected source files and components`n`n- New ``src/ComplaintWorkflow.ps1`` and new ``tests/VerifyComplaint.ps1`` simulate these approved tasks and assertions; the mock C# repository is not compiled.")
    Write-File $fixturePlan $fixtureText
    $spec = [IO.File]::ReadAllText("$r/src/.github/specs/ComplaintImitationRequest/spec.md")
    Assert-Match $spec 'PBI ID: 305183' 'PBI ID inside spec'
    Assert-Match $spec 'Complaint Imitation Request' 'full title inside spec'
    $a = Invoke-ToolJson 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'AnalysisComplete')
    Assert-Equal 'PASS' $a.Data.result "analysis validation passes: $($a.Data.problems -join '; ')"
    Assert-True (@($a.Data.info.evidenceFiles).Count -ge 4) 'analysis backed by existing repository files'
    # 4. Implementation stays blocked until the developer approves.
    $b = Invoke-ToolJson 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'ImplementationApproved')
    Assert-Equal 'FAIL' $b.Data.result 'implementation blocked before approval'
    $ap = Invoke-Tool 'Approve-SDD.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Statement', 'Approved. Implement T1-T4.')
    Assert-Equal 0 $ap.ExitCode 'approval recorded'
    $c = Invoke-ToolJson 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'ImplementationApproved')
    Assert-Equal 'PASS' $c.Data.result 'implementation unblocked after approval'
    # 5. No test or build claim without evidence.
    Assert-Equal 1 (Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'ImplementationVerified')).ExitCode 'not verified without recorded runs'
    $state = Get-Content "$r/docs/sdd/changes/305183-ComplaintImitationRequest/sdd-state.json" -Raw | ConvertFrom-Json
    Assert-Equal 'ImplementationApproved' $state.stage 'final stage'
    # 6. Simulate approved implementation in the fixture. This is executable PowerShell domain logic,
    # not a claim that the mock C# projects compile or that Visual Studio was exercised.
    Write-File "$r/src/ComplaintWorkflow.ps1" @'
function Get-ComplaintVersion([string]$Version,[string]$Type) { if($Type -eq 'Complaint'){return $Version+'c'}; return $Version }
function Test-ComplaintAllowed([string]$Status,[bool]$Duplicate) { return $Status -eq 'Actual' -and -not $Duplicate }
'@
    Write-File "$r/tests/VerifyComplaint.ps1" @'
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '../src/ComplaintWorkflow.ps1')
if((Get-ComplaintVersion '2.1' 'Complaint') -ne '2.1c'){throw 'AC-1 suffix'}
if((Get-ComplaintVersion '2.1' 'New Sample') -ne '2.1'){throw 'New Sample regression'}
if((Get-ComplaintVersion '2.1' 'Technical') -ne '2.1'){throw 'Technical regression'}
if((Get-ComplaintVersion '2.1' 'Improved Formula') -ne '2.1'){throw 'Improved Formula regression'}
if(Test-ComplaintAllowed 'Actual' $true){throw 'AC-2 duplicate'}
if(Test-ComplaintAllowed 'Non-Actual' $false){throw 'AC-3 nonactual'}
if(-not (Test-ComplaintAllowed 'Actual' $false)){throw 'valid complaint'}
Write-Output 'SIMULATED DOMAIN: 7 assertions passed'
'@
    $buildCmd = New-RunnerCommand $r 'build-fixture' @'
$e=$null; $t=$null; $source=Join-Path $PSScriptRoot '../../src/ComplaintWorkflow.ps1'
[void][Management.Automation.Language.Parser]::ParseFile($source,[ref]$t,[ref]$e)
if($e){$e | Write-Error;exit 1}; Write-Output 'Fixture syntax build passed (PowerShell simulation)'
'@
    $testCmd = '"' + $script:Pwsh + '" -NoLogo -NoProfile -File "' + "$r/tests/VerifyComplaint.ps1" + '"'
    $v=Invoke-FixtureVerification $r $buildCmd $testCmd
    Assert-Equal 0 $v.ExitCode "simulated implementation executed: $($v.Output)"
    $j=Get-Content "$r/$script:Work/verification.json" -Raw | ConvertFrom-Json
    Assert-Match ([IO.File]::ReadAllText("$r/$($j.checks[1].logFile)")) '7 assertions passed' 'functional assertions actually ran'
    $p=Invoke-Tool 'Update-SDDProgress.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-Tasks','T1,T2,T3,T4','-Evidence','Simulated domain: seven functional assertions passed')
    Assert-Equal 0 $p.ExitCode "approved task workflow recorded: $($p.Output)"
    Write-File "$r/$script:Work/review.md" "# Simulated independent-review fixture (not a live reviewer)`nOpen findings: 0`n"
    Write-File "$r/$script:Work/completion.md" "# Simulated completion`nAC traceability: AC-1 -> Get-ComplaintVersion -> suffix and three regression assertions; AC-2 -> duplicate assertion; AC-3 -> Non-Actual assertion. Positive Actual assertion passed.`n"
    $ready=Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-Stage','PRReady')
    Assert-Equal 0 $ready.ExitCode "simulated readiness accurate: $($ready.Output)"
    # A later source edit must close readiness again.
    Add-Content "$r/src/ComplaintWorkflow.ps1" '# material source revision'
    Assert-Equal 1 (Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-Stage','PRReady')).ExitCode 'stale source closes readiness'
    # Sample output for the release documentation.
    $sample = Join-Path $script:PackageRoot 'tests/results/sample-305183'
    if (Test-Path $sample) { Remove-Item $sample -Recurse -Force }
    [void](New-Item -ItemType Directory -Path $sample -Force)
    Copy-Item "$r/src/.github/specs/ComplaintImitationRequest/spec.md", "$r/src/.github/specs/ComplaintImitationRequest/plan.md" $sample
    Copy-Item "$r/docs/sdd/changes/305183-ComplaintImitationRequest/sdd-state.json", "$r/docs/sdd/changes/305183-ComplaintImitationRequest/approval.md" $sample
}
