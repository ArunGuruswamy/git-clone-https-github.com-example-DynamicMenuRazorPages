﻿# v2.5.2 - inputs are protected evidence, files land in the right folders automatically, a local commit gate
# stops unverified source from being committed. Replays the real 305183 incident (stray package copy in tools/,
# edited refined PBI, spec saved outside the repository, source staged before approval).

function Start-Pbi([string]$Repo, [string[]]$Extra = @()) {
    return (Invoke-ToolJson 'Start-SDD.ps1' (@('-Repository', $Repo, '-PbiId', '305183', '-Title', 'Complaint Imitation Request') + $Extra))
}
function Get-Status([string]$Repo, [switch]$Fix) {
    $a = @('-Repository', $Repo); if ($Fix) { $a += '-Fix' }
    return (Invoke-ToolJson 'Get-SDDStatus.ps1' $a)
}
function New-FakeDesktop {
    $d = New-TestRoot
    $env:SDD_USER_FOLDERS = $d
    return $d
}
function Edit-InputFile([string]$Path, [string]$Append) {
    (Get-Item -LiteralPath $Path).IsReadOnly = $false
    [IO.File]::AppendAllText($Path, $Append)
}
function Test-Check($Status, [string]$Area, [string]$State) {
    return (@($Status.Data.checks | Where-Object { $_.area -eq $Area -and $_.status -eq $State }).Count -gt 0)
}

Test 'Protect.InputsRecordedAndReadOnlyAfterStart' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $x = Start-Pbi $r
    Assert-Equal 0 $x.ExitCode "start: $($x.Output)"
    $p = "$r/docs/sdd/pbi-input/305183/REFINED-PBI.md"
    Assert-True (Test-Path "$r/.sdd-builder/pbi-imports/305183.baseline.json") 'baseline recorded'
    Assert-True ((Get-Item $p).IsReadOnly) 'refined PBI is read-only'
    $act = [IO.File]::ReadAllText("$r/.sdd-builder/pbi-imports/active-pbis.json")
    Assert-Match $act '305183' 'PBI listed as in progress'
    Assert-Equal '' (((& git -C $r status --porcelain --untracked-files=all -- .sdd-builder docs/sdd/pbi-input) | Out-String).Trim()) 'baseline and inputs stay out of Git Changes'
} 'RequiresGit'

Test 'Protect.EditedInputIsDetectedAndBlocksGateAndApproval' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Start-Pbi $r
    Complete-PackageAnalysis $r
    Edit-InputFile "$r/docs/sdd/pbi-input/305183/REFINED-PBI.md" "`nReview status: Developer-approved for development start`n"
    $g = Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Stage', 'AnalysisComplete')
    Assert-True ($g.ExitCode -ne 0) 'gate fails'
    Assert-Match $g.Output 'PBI input edited after import' 'gate names the edited input'
    $s = Start-Pbi $r
    Assert-Equal 'InputEdited' $s.Data.status 'Start-SDD reports InputEdited'
    Assert-Match $s.Data.next 'Get-SDDStatus' 'tells the agent which tool repairs it'
    $a = Invoke-Tool 'Approve-SDD.ps1' @('-Repository', $r, '-Feature', 'ComplaintImitationRequest', '-Statement', 'Approved to implement')
    Assert-True ($a.ExitCode -ne 0) 'approval refused'
    Assert-Match $a.Output '(?i)edited|changed after' 'approval says why'
}

Test 'Status.FixRestoresEditedInputFromRecordedDownload' {
    $r = New-FixtureRepo DAB
    $pkg = Copy-PackageFixture (Join-Path (New-TestRoot) 'download')
    $i = Invoke-ToolJson 'Add-SDDPbiInput.ps1' @('-Repository', $r, '-PbiId', '305183', $pkg)
    Assert-Equal 0 $i.ExitCode "import: $($i.Output)"
    $null = Start-Pbi $r
    $p = "$r/docs/sdd/pbi-input/305183/REFINED-PBI.md"
    $orig = (Get-FileHash $p -Algorithm SHA256).Hash
    Edit-InputFile $p "`nEdited by an agent`n"
    $bad = Get-Status $r
    Assert-Equal 1 $bad.ExitCode 'status reports the problem'
    Assert-True (Test-Check $bad 'PBI input' 'FAIL') 'edited input is a FAIL'
    $fix = Get-Status $r -Fix
    Assert-True (-not (Test-Check $fix 'PBI input' 'FAIL')) 'no input problem left'
    Assert-Equal $orig (Get-FileHash $p -Algorithm SHA256).Hash 'original restored byte for byte'
    Assert-True ((Get-Item $p).IsReadOnly) 'read-only again'
    $kept = @(Get-ChildItem "$r/docs/sdd/pbi-input/305183/.previous" -Recurse -File -Filter 'REFINED-PBI.md' | Where-Object { (Get-Content $_.FullName -Raw) -match 'Edited by an agent' })
    Assert-True ($kept.Count -ge 1) 'edited version kept under .previous'
}

Test 'Status.ReplayOf305183Incident' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Start-Pbi $r
    $in = "$r/docs/sdd/pbi-input/305183/REFINED-PBI.md"
    $orig = (Get-FileHash $in -Algorithm SHA256).Hash
    # 1. the ZIP was extracted into tools/ (the agent's copy shows in Git Changes)
    $stray = "$r/tools/2026-10-07-305183-complaint-imitation-request"
    Write-File "$stray/REFINED-PBI.md" ([IO.File]::ReadAllText($in))
    Write-File "$stray/EVIDENCE-EXTRA.md" "# Evidence`n`n- PBI ID: 305183`n`nExtra evidence for AC-1.`n"
    # 2. the refined PBI was edited in place
    Edit-InputFile $in "`nReview status: In Development`n"
    # 3. the spec was saved on the Desktop and copied loose into the spec root
    $desk = New-FakeDesktop
    Write-File "$desk/changes/305183-ComplaintImitationRequest/spec.md" "# Spec`n`n- PBI ID: 305183`n"
    Write-File "$r/src/.github/specs/spec.md" "# Spec`n`n- PBI ID: 305183`n"
    try {
        $before = Get-Status $r
        Assert-Equal 1 $before.ExitCode 'problems reported'
        foreach ($a in @('PBI input', 'Stray copy', 'Misplaced')) { Assert-True (@($before.Data.checks | Where-Object { $_.area -eq $a -and $_.status -in @('FAIL', 'WARN') }).Count -ge 1) "$a reported" }
        $fix = Get-Status $r -Fix
        foreach ($a in @('PBI input', 'Stray copy', 'Misplaced')) { Assert-Equal 0 @($fix.Data.checks | Where-Object { $_.area -eq $a -and $_.status -in @('FAIL', 'WARN') }).Count "$a clean after -Fix" }
        # the original input is back, the extra evidence is merged, nothing is lost
        Assert-Equal $orig (Get-FileHash $in -Algorithm SHA256).Hash 'refined PBI restored'
        Assert-True (Test-Path "$r/docs/sdd/pbi-input/305183/EVIDENCE-EXTRA.md") 'file only present in the stray copy was merged into the input folder'
        Assert-True (-not (Test-Path $stray)) 'stray copy gone from tools/'
        Assert-True (@(Get-ChildItem "$r/docs/sdd/pbi-input/305183/.previous" -Recurse -File -Filter 'REFINED-PBI.md').Count -ge 2) 'stray and edited copies are kept, not deleted'
        # misplaced documents ended up in the work folder for the agent to merge; the Desktop original is untouched
        Assert-True (-not (Test-Path "$r/src/.github/specs/spec.md")) 'loose spec left the spec root'
        Assert-True (@(Get-ChildItem "$r/docs/sdd/changes/305183-ComplaintImitationRequest/agent-draft" -File).Count -ge 2) 'drafts collected in agent-draft/'
        Assert-True (Test-Path "$desk/changes/305183-ComplaintImitationRequest/spec.md") 'original outside the repository not deleted'
        # Git Changes shows only the real spec/plan folder
        $changes = ((& git -C $r status --porcelain --untracked-files=all) | Out-String).Trim()
        Assert-NotMatch $changes 'tools/' 'no stray tools/ copy in Git Changes'
        Assert-NotMatch $changes 'pbi-input|agent-draft|\.sdd-builder' 'inputs, drafts and builder state stay local'
        Assert-Match $changes 'src/\.github/specs/ComplaintImitationRequest/' 'the real spec and plan remain visible'
    } finally { Remove-Item Env:SDD_USER_FOLDERS -ErrorAction SilentlyContinue }
} 'RequiresGit'

Test 'Status.TrackedFilesAreNeverMoved' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Start-Pbi $r
    Write-File "$r/team-docs/305183-notes/REFINED-PBI.md" ([IO.File]::ReadAllText("$r/docs/sdd/pbi-input/305183/REFINED-PBI.md"))
    Invoke-Git $r @('add', 'team-docs') | Out-Null; Invoke-Git $r @('commit', '-q', '-m', 'team copy') | Out-Null
    $env:SDD_USER_FOLDERS = (New-TestRoot)
    try { $fix = Get-Status $r -Fix } finally { Remove-Item Env:SDD_USER_FOLDERS -ErrorAction SilentlyContinue }
    Assert-True (Test-Path "$r/team-docs/305183-notes/REFINED-PBI.md") 'tracked copy untouched'
    Assert-Equal '' (((& git -C $r status --porcelain -- team-docs) | Out-String).Trim()) 'no change to tracked files'
} 'RequiresGit'

Test 'Status.SharedFolderOnlyLosesPackageFiles' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Start-Pbi $r
    Write-File "$r/tools/REFINED-PBI.md" ([IO.File]::ReadAllText("$r/docs/sdd/pbi-input/305183/REFINED-PBI.md"))
    Write-File "$r/tools/MyScript.ps1" "Write-Host 'mine'`n"
    $env:SDD_USER_FOLDERS = (New-TestRoot)
    try { $null = Get-Status $r -Fix } finally { Remove-Item Env:SDD_USER_FOLDERS -ErrorAction SilentlyContinue }
    Assert-True (Test-Path "$r/tools/MyScript.ps1") 'unrelated file in a shared folder is not touched'
    Assert-True (-not (Test-Path "$r/tools/REFINED-PBI.md")) 'package file moved out'
}

Test 'Status.CleanRepositoryReportsNoProblem' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Start-Pbi $r
    $env:SDD_USER_FOLDERS = (New-TestRoot)
    try { $s = Get-Status $r } finally { Remove-Item Env:SDD_USER_FOLDERS -ErrorAction SilentlyContinue }
    Assert-True (Test-Check $s 'PBI input' 'OK') 'input ok'
    Assert-True (Test-Check $s 'Protection' 'OK') 'protected'
    Assert-True (Test-Check $s 'Spec/plan' 'OK') 'spec and plan exist'
    Assert-Equal 0 @($s.Data.checks | Where-Object { $_.area -in @('Stray copy', 'Misplaced') }).Count 'nothing misplaced'
}

Test 'Status.SourceChangedBeforeApprovalIsFlagged' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Start-Pbi $r
    $f = "$r/src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Common/Constants.cs"
    [IO.File]::AppendAllText($f, "// edited before approval`n")
    Invoke-Git $r @('add', $f) | Out-Null
    $env:SDD_USER_FOLDERS = (New-TestRoot)
    try { $s = Get-Status $r } finally { Remove-Item Env:SDD_USER_FOLDERS -ErrorAction SilentlyContinue }
    Assert-True (Test-Check $s 'Source' 'FAIL') 'unapproved source change is a FAIL'
    $d = @($s.Data.checks | Where-Object area -eq 'Source')[0].detail
    Assert-Match $d '1 staged' 'staged count reported'
} 'RequiresGit'

Test 'Prefill.AcceptanceCriteriaAndCompanionSummariesCopiedFromPackage' {
    $r = New-FixtureRepo DAB
    $null = Copy-PackageFixture (Join-Path $r 'docs/sdd/pbi-input/305183')
    $x = Start-Pbi $r
    Assert-Equal 0 $x.ExitCode "start: $($x.Output)"
    $spec = [IO.File]::ReadAllText("$r/src/.github/specs/ComplaintImitationRequest/spec.md")
    Assert-Match $spec 'Copied verbatim from the refined PBI by Start-SDD' 'acceptance criteria prefilled'
    Assert-Match $spec 'AC-1' 'criteria present'
    Assert-Match $spec 'Read by Start-SDD: approved D-02; not approved D-01 \(Proposed\)' 'decision log summarised'
    Assert-Match $spec 'resolved Q-01' 'open questions summarised'
}

Test 'Commit.GateBlocksUnverifiedSourceAndAllowsEverythingElse' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Start-Pbi $r
    $cs = "$r/src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Common/Constants.cs"
    [IO.File]::AppendAllText($cs, "// change`n")
    Invoke-Git $r @('add', $cs) | Out-Null
    $blocked = Invoke-ToolJson 'Assert-SDDCommit.ps1' @('-Repository', $r)
    Assert-Equal 1 $blocked.ExitCode 'unverified source is blocked'
    Assert-Equal 'BLOCKED' $blocked.Data.result 'result'
    Assert-Match ($blocked.Data.blocked[0].problem) 'ImplementationVerified' 'reason names the gate'
    # a documents-only commit is never blocked
    Invoke-Git $r @('reset', '-q') | Out-Null
    Write-File "$r/src/.github/specs/ComplaintImitationRequest/notes.md" "note`n"
    Invoke-Git $r @('add', 'src/.github/specs') | Out-Null
    Assert-Equal 0 (Invoke-ToolJson 'Assert-SDDCommit.ps1' @('-Repository', $r)).ExitCode 'documents allowed'
    # switch off
    Invoke-Git $r @('reset', '-q') | Out-Null; Invoke-Git $r @('add', $cs) | Out-Null
    Invoke-Git $r @('config', 'sdd.commitGate', 'false') | Out-Null
    Assert-Equal 0 (Invoke-ToolJson 'Assert-SDDCommit.ps1' @('-Repository', $r)).ExitCode 'git config sdd.commitGate false turns it off'
    Invoke-Git $r @('config', '--unset', 'sdd.commitGate') | Out-Null
    # no PBI in progress -> normal commits are untouched
    Remove-Item "$r/.sdd-builder/pbi-imports/active-pbis.json" -Force
    Assert-Equal 0 (Invoke-ToolJson 'Assert-SDDCommit.ps1' @('-Repository', $r)).ExitCode 'no active PBI, no gate'
} 'RequiresGit'

Test 'Commit.HookInstalledBlocksRealCommitAndUninstallRemovesOnlyOurs' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $i = Invoke-Installer $r
    Assert-Equal 0 $i.ExitCode "installer: $($i.Output)"
    $hook = (& git -C $r rev-parse --path-format=absolute --git-path hooks | Out-String).Trim() + '/pre-commit'
    Assert-True (Test-Path $hook) 'pre-commit hook installed'
    Assert-Match ([IO.File]::ReadAllText($hook)) 'Akzo SDD Development Builder commit gate' 'hook is marked as ours'
    $null = Start-Pbi $r
    $cs = "$r/src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Common/Constants.cs"
    [IO.File]::AppendAllText($cs, "// change`n")
    Invoke-Git $r @('add', $cs) | Out-Null
    $oldPath = $env:PATH
    $env:PATH = (Split-Path -Parent $script:Pwsh) + [IO.Path]::PathSeparator + $env:PATH
    try {
        $out = & git -C $r commit -q -m 'unverified' 2>&1 | Out-String
        Assert-True ($LASTEXITCODE -ne 0) "commit blocked: $out"
        Assert-Match $out 'commit blocked' 'developer sees why'
        & git -C $r commit -q --no-verify -m 'bypass' 2>&1 | Out-Null
        Assert-Equal 0 $LASTEXITCODE '--no-verify bypasses the gate'
    } finally { $env:PATH = $oldPath }
    $u = & $script:Pwsh -NoLogo -NoProfile -File $script:Uninstaller -Destination $r 2>&1 | Out-String
    Assert-True (-not (Test-Path $hook)) "uninstall removed our hook: $u"
} 'RequiresGit'

Test 'Commit.ExistingTeamHookIsNeverReplaced' {
    $r = New-FixtureRepo DAB
    $hookDir = (& git -C $r rev-parse --path-format=absolute --git-path hooks | Out-String).Trim()
    [void](New-Item -ItemType Directory -Path $hookDir -Force)
    Write-File "$hookDir/pre-commit" "#!/bin/sh`n# team hook`nexit 0`n"
    $i = Invoke-Installer $r
    Assert-Equal 0 $i.ExitCode 'installer'
    Assert-Match ([IO.File]::ReadAllText("$hookDir/pre-commit")) 'team hook' 'team hook kept'
    Assert-NotMatch ([IO.File]::ReadAllText("$hookDir/pre-commit")) 'Akzo SDD' 'ours not written over it'
    $null = & $script:Pwsh -NoLogo -NoProfile -File $script:Uninstaller -Destination $r 2>&1
    Assert-True (Test-Path "$hookDir/pre-commit") 'uninstall leaves the team hook'
} 'RequiresGit'

Test 'Commit.ActivePbiReleasedWhenPrReadyPasses' {
    $r = New-FixtureRepo DAB; Add-RefinedPbi $r
    $null = Start-Pbi $r
    Assert-Match ([IO.File]::ReadAllText("$r/.sdd-builder/pbi-imports/active-pbis.json")) '305183' 'active after start'
    Import-Module (Join-Path $script:Tools 'SDD.Common.psm1') -Force
    Set-SDDActivePbi -Repository $r -PbiId '305183' -Active $false
    Assert-Equal 0 @(Get-SDDActivePbis $r).Count 'released'
}
