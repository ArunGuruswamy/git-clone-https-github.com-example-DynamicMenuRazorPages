﻿# Akzo SDD Builder - dependency-free test helpers (PowerShell 5.1 and 7+). No Pester required, because
# corporate machines ship Pester 3.4 while current Pester is 5.x with different syntax.

$script:PackageRoot = Split-Path -Parent $PSScriptRoot
$script:Tools = Join-Path $script:PackageRoot 'tooling/tools'
$script:FixtureData = Join-Path $PSScriptRoot 'fixtures'
$script:Pwsh = (Get-Process -Id $PID).Path

function Assert-True($Condition, [string]$Message) { if (-not $Condition) { throw "Assertion failed: $Message" } }
function Assert-Equal($Expected, $Actual, [string]$Message) { if ($Expected -ne $Actual) { throw "Assertion failed: $Message (expected '$Expected', got '$Actual')" } }
function Assert-Match([string]$Text, [string]$Pattern, [string]$Message) { if ($Text -notmatch $Pattern) { throw "Assertion failed: $Message (pattern '$Pattern' not found in: $($Text.Substring(0, [Math]::Min(600, $Text.Length))))" } }
function Assert-NotMatch([string]$Text, [string]$Pattern, [string]$Message) { if ($Text -match $Pattern) { throw "Assertion failed: $Message (pattern '$Pattern' found)" } }

function New-TestRoot {
    $root = Join-Path ([IO.Path]::GetTempPath()) ('sdd-test-' + [guid]::NewGuid().ToString('N').Substring(0, 10))
    [void](New-Item -ItemType Directory -Path $root -Force)
    return $root
}

function Write-File([string]$Path, [string]$Text) {
    $dir = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Path $dir -Force) }
    [IO.File]::WriteAllText($Path, $Text, (New-Object System.Text.UTF8Encoding($false)))
}

function Invoke-Git([string]$Repo, [string[]]$GitArgs) {
    $out = & git -C $Repo @GitArgs 2>&1
    if ($LASTEXITCODE -ne 0) { throw "git $($GitArgs -join ' ') failed: $out" }
    return $out
}

function New-FixtureRepo {
    # Mock repositories that mirror the documented layouts (dab/docs/architecture/ARCHITECTURE-SUMMARY.md).
    param([ValidateSet('DAB', 'CDMS', 'UI', 'Ambiguous', 'Unknown')][string]$Kind = 'DAB', [switch]$NoGit)
    $repo = Join-Path (New-TestRoot) 'repo'
    [void](New-Item -ItemType Directory -Path $repo -Force)
    $f = 'src/AN.ColorAppsAzure.Formula'
    switch ($Kind) {
        'DAB' {
            Write-File "$repo/AN.ColorAppsAzure.BL.sln" "Microsoft Visual Studio Solution File`n"
            Write-File "$repo/$f/AN.ColorAppsAzure.Formula.Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestHandler.cs" "public sealed class CreateImitationRequestHandler { /* resolves version via VersioningHelper */ }`n"
            Write-File "$repo/$f/AN.ColorAppsAzure.Formula.Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestValidator.cs" "public sealed class CreateImitationRequestValidator { /* duplicate active IR rule */ }`n"
            Write-File "$repo/$f/AN.ColorAppsAzure.Formula.Application/PaintSystem/Shared/VersioningHelper.cs" "public static class VersioningHelper { }`n"
            Write-File "$repo/$f/AN.ColorAppsAzure.Formula.Common/Constants.cs" "public static class Constants { public const string RequestTypeComplaint = ""Complaint""; }`n"
            Write-File "$repo/$f/AN.ColorAppsAzure.Formula.Data/Graphql/GraphqlAssets/Formula/ImitationRequest/Formula_CreateImitationRequest.graphql" "mutation CreateImitationRequest { createImitationRequest { id } }`n"
            Write-File "$repo/src/AN.ColorAppsAzure.Formula.Tests/AN.ColorAppsAzure.Formula.Application.Tests/ImitationRequest/CreateImitationRequestHandlerTests.cs" "[TestClass] public class CreateImitationRequestHandlerTests { }`n"
            Write-File "$repo/src/.github/specs/TechnicalRemarks/spec.md" "# TechnicalRemarks - Specification`n`n- PBI ID: 300100`n`nExisting approved specification. Must never be modified by another PBI.`n"
            Write-File "$repo/src/.github/specs/TechnicalRemarks/plan.md" "# TechnicalRemarks - Plan`n`n- PBI ID: 300100`n"
        }
        'CDMS' {
            Write-File "$repo/src/AN.ColorAppsAzure.BL.ColorDMS.sln" "Microsoft Visual Studio Solution File`n"
            Write-File "$repo/src/AN.ColorAppsAzure.ColorDMS.Formula.Application/PaintSystem/CreatePaintSystemHandler.cs" "public class CreatePaintSystemHandler { }`n"
        }
        'UI' {
            Write-File "$repo/angular.json" "{ ""projects"": { ""formulas"": {} } }`n"
            Write-File "$repo/projects/formulas/src/app/app.component.ts" "export class AppComponent {}`n"
        }
        'Ambiguous' {
            Write-File "$repo/angular.json" "{ }`n"
            Write-File "$repo/$f/AN.ColorAppsAzure.Formula.Application/X.cs" "class X {}`n"
        }
        'Unknown' { Write-File "$repo/README.md" "# Something else`n" }
    }
    if (-not $NoGit -and (Get-Command git -ErrorAction SilentlyContinue)) {
        Invoke-Git $repo @('init', '-q') | Out-Null
        Invoke-Git $repo @('config', 'user.email', 'dev@example.com') | Out-Null
        Invoke-Git $repo @('config', 'user.name', 'Asha Developer') | Out-Null
        Invoke-Git $repo @('config', 'core.autocrlf', 'false') | Out-Null
        Invoke-Git $repo @('add', '-A') | Out-Null
        Invoke-Git $repo @('commit', '-q', '-m', 'fixture') | Out-Null
    }
    return $repo
}

function Add-RefinedPbi([string]$Repo, [string]$RelativePath = 'docs/sdd/pbi-input/305183/REFINED-PBI.md', [string]$Text) {
    if (-not $Text) { $Text = [IO.File]::ReadAllText((Join-Path $script:FixtureData '305183/REFINED-PBI.md')) }
    Write-File (Join-Path $Repo $RelativePath) $Text
}

function Invoke-Tool {
    # Runs a tool in a child PowerShell so 'exit' codes are observable, exactly as an agent terminal would.
    param([string]$Name, [string[]]$ToolArgs)
    $script = Join-Path $script:Tools $Name
    $out = & $script:Pwsh -NoLogo -NoProfile -File $script @ToolArgs 2>&1 | Out-String
    return [pscustomobject]@{ ExitCode = $LASTEXITCODE; Output = ($out -replace "\x1b\[[0-9;]*m", '') }
}

function Invoke-ToolJson([string]$Name, [string[]]$ToolArgs) {
    $r = Invoke-Tool $Name ($ToolArgs + '-Json')
    $start = $r.Output.IndexOf('{')
    if ($start -lt 0) { throw "No JSON from $Name : $($r.Output)" }
    $obj = $r.Output.Substring($start) | ConvertFrom-Json
    return [pscustomobject]@{ ExitCode = $r.ExitCode; Data = $obj; Output = $r.Output }
}

function Complete-FixtureAnalysis([string]$Repo, [string]$Feature = 'ComplaintImitationRequest') {
    # Simulates the agent writing the completed analysis with its edit tool (no terminal needed).
    $folder = Join-Path $Repo "src/.github/specs/$Feature"
    $pbiPath = Join-Path $Repo 'docs/sdd/pbi-input/305183/REFINED-PBI.md'
    if (-not (Test-Path -LiteralPath $pbiPath)) { $pbiPath = Join-Path $script:FixtureData '305183/REFINED-PBI.md' }
    $pbi = [IO.File]::ReadAllText($pbiPath)
    $spec = [IO.File]::ReadAllText((Join-Path $script:FixtureData '305183/spec.completed.md')).Replace('{{PBI_SOURCE}}', $pbi.TrimEnd())
    Write-File (Join-Path $folder 'spec.md') $spec
    Write-File (Join-Path $folder 'plan.md') ([IO.File]::ReadAllText((Join-Path $script:FixtureData '305183/plan.completed.md')))
    Write-File (Join-Path $Repo "docs/sdd/changes/305183-$Feature/pr-review-audit.md") "# PR review rule audit`n`nApplicable rules: NONE - no approved rules in docs/sdd/review-lessons/register.csv yet; candidate checks C-003, C-006 reviewed.`nEvidence: CreateImitationRequestValidator.cs and VersioningHelper.cs inspected; tests planned in plan.md.`nStatus: PASS`n"
}

# ------------------------------------------------------------------ v2.5 PBI input package helpers

function Add-Bytes([System.Collections.Generic.List[byte]]$List, [byte[]]$Bytes) { foreach ($b in $Bytes) { $List.Add($b) } }
function ConvertTo-BE32([long]$v) { return [byte[]]@((($v -shr 24) -band 255), (($v -shr 16) -band 255), (($v -shr 8) -band 255), ($v -band 255)) }

function New-PngFile([string]$Path, [int]$Width = 640, [int]$Height = 480) {
    $b = New-Object System.Collections.Generic.List[byte]
    Add-Bytes $b ([byte[]](0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0, 0, 0, 13))
    Add-Bytes $b ([Text.Encoding]::ASCII.GetBytes('IHDR')); Add-Bytes $b (ConvertTo-BE32 $Width); Add-Bytes $b (ConvertTo-BE32 $Height)
    Add-Bytes $b ([byte[]](8, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)); Add-Bytes $b ([Text.Encoding]::ASCII.GetBytes('IEND')); Add-Bytes $b ([byte[]](0xAE, 0x42, 0x60, 0x82))
    $dir = Split-Path -Parent $Path; if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Path $dir -Force) }
    [IO.File]::WriteAllBytes($Path, $b.ToArray())
}

function New-JpegFile([string]$Path, [int]$Width = 800, [int]$Height = 600) {
    $b = New-Object System.Collections.Generic.List[byte]
    Add-Bytes $b ([byte[]](0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10)); Add-Bytes $b ([Text.Encoding]::ASCII.GetBytes('JFIF')); Add-Bytes $b ([byte[]](0, 1, 1, 0, 0, 1, 0, 1, 0, 0))
    Add-Bytes $b ([byte[]](0xFF, 0xC0, 0x00, 0x11, 0x08, [byte](($Height -shr 8) -band 255), [byte]($Height -band 255), [byte](($Width -shr 8) -band 255), [byte]($Width -band 255), 3, 1, 0x22, 0, 2, 0x11, 1, 3, 0x11, 1))
    Add-Bytes $b ([byte[]](0xFF, 0xD9))
    $dir = Split-Path -Parent $Path; if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Path $dir -Force) }
    [IO.File]::WriteAllBytes($Path, $b.ToArray())
}

function New-ZipWithEntries([string]$Path, [System.Collections.IDictionary]$Entries) {
    # Entries: name -> string content (UTF-8). Names are written exactly as given (used for unsafe-path tests too).
    Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    $dir = Split-Path -Parent $Path; if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Path $dir -Force) }
    $fs = [IO.File]::Open($Path, [IO.FileMode]::Create)
    try {
        $zip = New-Object IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Create)
        try {
            foreach ($k in $Entries.Keys) {
                $e = $zip.CreateEntry($k)
                $w = New-Object IO.StreamWriter($e.Open(), (New-Object System.Text.UTF8Encoding($false)))
                try { $w.Write([string]$Entries[$k]) } finally { $w.Dispose() }
            }
        } finally { $zip.Dispose() }
    } finally { $fs.Dispose() }
}

function New-DocxFile([string]$Path, [string[]]$Paragraphs) {
    $body = ($Paragraphs | ForEach-Object { '<w:p><w:r><w:t xml:space="preserve">' + [System.Net.WebUtility]::HtmlEncode($_) + '</w:t></w:r></w:p>' }) -join ''
    New-ZipWithEntries $Path ([ordered]@{
            '[Content_Types].xml' = '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/></Types>'
            'word/document.xml'   = '<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' + $body + '</w:body></w:document>'
        })
}

function New-XlsxFile([string]$Path, [string]$SheetName, [string[][]]$Rows) {
    $shared = New-Object System.Collections.Generic.List[string]
    $sb = New-Object System.Text.StringBuilder
    $r = 0
    foreach ($row in $Rows) {
        $r++; [void]$sb.Append("<row r=""$r"">")
        foreach ($cell in $row) {
            if ($cell -match '^\d+$') { [void]$sb.Append("<c><v>$cell</v></c>") }
            else { $shared.Add($cell); [void]$sb.Append("<c t=""s""><v>$($shared.Count - 1)</v></c>") }
        }
        [void]$sb.Append('</row>')
    }
    $sst = ($shared | ForEach-Object { '<si><t>' + [System.Net.WebUtility]::HtmlEncode($_) + '</t></si>' }) -join ''
    New-ZipWithEntries $Path ([ordered]@{
            '[Content_Types].xml'        = '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="xml" ContentType="application/xml"/></Types>'
            'xl/workbook.xml'            = '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="' + $SheetName + '" sheetId="1" r:id="rId1"/></sheets></workbook>'
            'xl/_rels/workbook.xml.rels' = '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>'
            'xl/sharedStrings.xml'       = '<?xml version="1.0" encoding="UTF-8"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' + $sst + '</sst>'
            'xl/worksheets/sheet1.xml'   = '<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>' + $sb.ToString() + '</sheetData></worksheet>'
        })
}

function New-PdfFile([string]$Path, [string]$Text) {
    # Minimal single-page PDF with a text layer (Helvetica), correct xref offsets.
    $stream = "BT /F1 12 Tf 72 720 Td ($($Text -replace '([\\()])', '\$1')) Tj ET"
    $objs = @(
        '<< /Type /Catalog /Pages 2 0 R >>',
        '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
        '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>',
        "<< /Length $($stream.Length) >>`nstream`n$stream`nendstream",
        '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'
    )
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append("%PDF-1.4`n")
    $offsets = @()
    for ($i = 0; $i -lt $objs.Count; $i++) { $offsets += $sb.Length; [void]$sb.Append("$($i + 1) 0 obj`n$($objs[$i])`nendobj`n") }
    $xref = $sb.Length
    [void]$sb.Append("xref`n0 $($objs.Count + 1)`n0000000000 65535 f `n")
    foreach ($o in $offsets) { [void]$sb.Append(('{0:D10} 00000 n ' -f $o) + "`n") }
    [void]$sb.Append("trailer`n<< /Size $($objs.Count + 1) /Root 1 0 R >>`nstartxref`n$xref`n%%EOF`n")
    $dir = Split-Path -Parent $Path; if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Path $dir -Force) }
    [IO.File]::WriteAllBytes($Path, [Text.Encoding]::ASCII.GetBytes($sb.ToString()))
}

function Copy-PackageFixture([string]$Destination) {
    # The mock PBI Builder package (REFINED-PBI.md is 'Status: Blocked') copied to a folder outside the repository.
    $src = Join-Path $script:FixtureData 'package-305183'
    [void](New-Item -ItemType Directory -Path $Destination -Force)
    Copy-Item -Path (Join-Path $src '*') -Destination $Destination -Recurse -Force
    return $Destination
}

function Get-TreeHashes([string]$Root) {
    $h = [ordered]@{}
    foreach ($f in (Get-ChildItem -LiteralPath $Root -Recurse -File -Force | Sort-Object FullName)) { $h[$f.FullName.Substring($Root.Length)] = (Get-FileHash -LiteralPath $f.FullName -Algorithm SHA256).Hash }
    return $h
}

function Get-Inventory([string]$Repo, [string]$Feature = 'ComplaintImitationRequest', [string]$PbiId = '305183') {
    return ([IO.File]::ReadAllText((Join-Path $Repo "docs/sdd/changes/$PbiId-$Feature/pbi-analysis/pbi-inventory.json")) | ConvertFrom-Json)
}

function Complete-PackageAnalysis([string]$Repo, [string]$Feature = 'ComplaintImitationRequest', [string[]]$SkipFiles = @(), [string[]]$SkipDiscrepancies = @()) {
    # Simulates the agent: completed fixture analysis + one cited row per input file + every discrepancy addressed.
    Complete-FixtureAnalysis $Repo $Feature
    $inv = Get-Inventory $Repo $Feature
    $specPath = Join-Path $Repo "src/.github/specs/$Feature/spec.md"
    $spec = [IO.File]::ReadAllText($specPath)
    $rows = New-Object System.Text.StringBuilder
    foreach ($it in $inv.items) {
        if ($it.role -in @('Primary', 'History', 'Metadata') -or $it.status -eq 'Duplicate' -or $SkipFiles -contains $it.packagePath) { continue }
        $result = switch ($it.status) {
            'Unreadable' { "Unreadable: $($it.reason -replace '\|', '/') Not used; a readable copy was requested." }
            'Unsupported' { "Unsupported: $($it.reason -replace '\|', '/') Not used." }
            'ForeignPbi' { 'Not relevant: belongs to another PBI; excluded.' }
            'RequiresAgentReview' { 'Reviewed with the image/PDF tool: shows the Complaint IR screen; supports AC-1.' }
            default { 'Reviewed: supporting evidence for AC-1; adds no scope.' }
        }
        [void]$rows.AppendLine("| ``$($it.packagePath)`` | $($it.type) | $($it.role) | $($it.status) | | $result |")
    }
    $primaryRow = '| `REFINED-PBI.md` | md | Primary | Read | AC-1, AC-2, AC-3 | Primary requirements source (verbatim above). |'
    $spec = $spec.Replace($primaryRow, $primaryRow + "`n" + $rows.ToString().TrimEnd())
    $disc = @($inv.discrepancies | Where-Object { $SkipDiscrepancies -notcontains $_.id })
    if ($disc.Count) {
        $t = "| ID | Type | Resolution or open question |`n|---|---|---|`n" + (($disc | ForEach-Object { "| $($_.id) | $($_.type) | Recorded as open question for the PO; the implementation follows REFINED-PBI.md until it is answered. |" }) -join "`n")
        $spec = $spec.Replace('No discrepancy was found by the deterministic checks of the input package.', $t + "`n")
    }
    Write-File $specPath $spec
}
