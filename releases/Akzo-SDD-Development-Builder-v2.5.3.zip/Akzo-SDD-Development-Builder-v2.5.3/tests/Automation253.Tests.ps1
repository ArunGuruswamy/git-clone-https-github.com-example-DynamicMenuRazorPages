﻿# Incident regressions: PBI 306400, nested Visual Studio folders and stale IDE test results.
Test 'V253.Start306400FromNestedSolutionWritesCanonicalArtifacts' {
    $r = New-FixtureRepo DAB
    $text = [IO.File]::ReadAllText("$script:FixtureData/305183/REFINED-PBI.md").Replace('305183','306400').Replace('Complaint Imitation Request','Creation of Complaint PaintSystem')
    Add-RefinedPbi $r 'docs/sdd/pbi-input/306400/REFINED-PBI.md' $text
    $s = Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',"$r/src/AN.ColorAppsAzure.Formula",'-Request','Start Development 306400 Creation of Complaint PaintSystem')
    Assert-Equal 0 $s.ExitCode $s.Output
    Assert-Equal $r $s.Data.repository 'primary root resolved from nested folder'
    Assert-Equal 'ComplaintPaintSystem' $s.Data.feature 'incident feature name'
    Assert-True $s.Data.artifacts.persisted 'files read back'
    Assert-Equal "$r/src/.github/specs/ComplaintPaintSystem/spec.md" $s.Data.specAbsolute 'absolute specification path'
    Assert-Equal "$r/src/.github/specs/ComplaintPaintSystem/plan.md" $s.Data.planAbsolute 'absolute plan path'
    Assert-True (-not (Test-Path "$r/src/src/.github")) 'no doubled src'
    foreach ($f in $s.Data.artifacts.files) { Assert-True ($f.bytes -gt 0 -and (Test-Path $f.path)) 'physical nonempty file'; Assert-True ([bool]$f.sha256) 'read-back hash' }
    Assert-True (Test-Path "$r/docs/sdd/changes/306400-ComplaintPaintSystem/artifact-receipt.json") 'receipt saved'
} 'RequiresGit'

Test 'V253.NestedFolderWithoutGitUsesDabRoot' {
    $r=New-FixtureRepo DAB -NoGit; Add-RefinedPbi $r
    $s=Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',"$r/src/AN.ColorAppsAzure.Formula",'-PbiId','305183','-Title','Complaint Imitation Request')
    Assert-Equal 0 $s.ExitCode $s.Output
    Assert-Equal "$r/src/.github/specs/ComplaintImitationRequest/plan.md" $s.Data.planAbsolute 'folder-mode canonical path'
}

Test 'V253.DabCanonicalFolderWinsOverLegacySetting' {
    $r=New-FixtureRepo DAB; Add-RefinedPbi $r
    Write-File "$r/.sdd-builder/settings.json" '{"specRoot":"docs/sdd"}'
    $s=Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',$r,'-PbiId','305183','-Title','Complaint Imitation Request')
    Assert-Equal 0 $s.ExitCode $s.Output
    Assert-Equal 'src/.github/specs/ComplaintImitationRequest/spec.md' $s.Data.spec 'DAB fixed check-in convention'
    Assert-NotMatch ([IO.File]::ReadAllText("$r/.sdd-builder/settings.json")) 'src/.github' 'user settings preserved'
}

Test 'V253.ApprovalRechecksPhysicalCanonicalFiles' {
    $r=New-FixtureRepo DAB; Add-RefinedPbi $r
    $null=Invoke-Tool 'Start-SDD.ps1' @('-Repository',"$r/src",'-PbiId','305183','-Title','Complaint Imitation Request')
    Complete-FixtureAnalysis $r
    $a=Invoke-Tool 'Approve-SDD.ps1' @('-Repository',"$r/src/AN.ColorAppsAzure.Formula",'-Feature','ComplaintImitationRequest','-Statement','Approved, implement T1-T4')
    Assert-Equal 0 $a.ExitCode $a.Output
    $j=Get-Content "$r/docs/sdd/changes/305183-ComplaintImitationRequest/approval.json" -Raw | ConvertFrom-Json
    Assert-Equal $r $j.repository 'approval stays in primary repository'
    Assert-True $j.artifactReceipt.persisted 'approved disk receipt'
    Assert-Equal "$r/src/.github/specs/ComplaintImitationRequest/plan.md" $j.artifactReceipt.files[1].path 'approved exact path'
    Remove-Item "$r/src/.github/specs/ComplaintImitationRequest/plan.md"
    $gate=Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository',"$r/src",'-Feature','ComplaintImitationRequest','-Stage','ImplementationApproved')
    Assert-Equal 1 $gate.ExitCode 'no source edit permission with missing plan'
    Assert-Match $gate.Output 'File not saved on disk' 'exact missing file reported'
}

Test 'V253.EmptyExistingDocumentNeverClaimsPersistence' {
    $r=New-FixtureRepo DAB; Add-RefinedPbi $r
    Write-File "$r/src/.github/specs/ComplaintImitationRequest/spec.md" ''
    $s=Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',$r,'-PbiId','305183','-Title','Complaint Imitation Request')
    Assert-Equal 8 $s.ExitCode 'empty file blocks persistence receipt'
    Assert-Equal 'ArtifactPersistenceFailed' $s.Data.status 'specific problem'
    Assert-Equal '' ([IO.File]::ReadAllText("$r/src/.github/specs/ComplaintImitationRequest/spec.md")) 'existing content not overwritten'
    Assert-True (-not (Test-Path "$r/docs/sdd/changes/305183-ComplaintImitationRequest/sdd-state.json")) 'no false Initialized state'
}

Test 'V253.InstalledRuntimeHashesAndTamperDetection' {
    $r=New-FixtureRepo DAB
    $i=Invoke-Installer $r; Assert-Equal 0 $i.ExitCode $i.Output
    $h=Invoke-ToolJson 'Test-SDDInstallation.ps1' @('-Repository',"$r/src")
    Assert-Equal 0 $h.ExitCode $h.Output
    Assert-True ($h.Data.ready -and $h.Data.checkedFiles -gt 10) 'actual runtime compared to requested package'
    Add-Content "$r/.github/agents/akzo-sdd-developer.agent.md" 'old team customization'
    $bad=Invoke-ToolJson 'Test-SDDInstallation.ps1' @('-Repository',$r)
    Assert-Equal 3 $bad.ExitCode 'edited runtime detected'
    Assert-Match ($bad.Data.problems -join ';') 'akzo-sdd-developer.agent.md' 'specific active agent'
} 'RequiresGit'

Test 'V253.PartialUpgradeDoesNotPrintComplete' {
    $r=New-FixtureRepo DAB
    Write-File "$r/.github/agents/akzo-sdd-developer.agent.md" '# old tracked agent'
    Invoke-Git $r @('add','.github/agents/akzo-sdd-developer.agent.md') | Out-Null
    Invoke-Git $r @('commit','-qm','tracked prior agent') | Out-Null
    $i=Invoke-Installer $r
    Assert-Equal 3 $i.ExitCode 'incomplete upgrade exits nonzero'
    Assert-Match $i.Output 'INSTALLATION INCOMPLETE' 'unambiguous status'
    Assert-NotMatch $i.Output 'Version-managed upgrade complete' 'no false completion'
    Assert-Equal '# old tracked agent' ([IO.File]::ReadAllText("$r/.github/agents/akzo-sdd-developer.agent.md")) 'team file retained'
} 'RequiresGit'

Test 'V253.ZeroTestsFromIdeWrapperCannotPass' {
    $r=New-ApprovedFixture
    $test=New-RunnerCommand $r 'zero' "Write-Output 'Test run completed. Ran 0 test(s). 0 Passed, 0 Failed'"
    $v=Invoke-FixtureVerification $r 'git --version' $test
    Assert-Equal 1 $v.ExitCode 'exit-zero wrapper rejected'
    $j=Get-Content "$r/$script:Work/verification.json" -Raw | ConvertFrom-Json
    Assert-Equal 0 $j.checks[1].testCount 'actual zero count recorded'
    Assert-Match $j.checks[1].reason 'Zero tests' 'diagnosis'
}

Test 'V253.PreviousBuildAndFailuresCannotPass' {
    $r=New-ApprovedFixture
    $test=New-RunnerCommand $r 'old-build' "Write-Output 'Continuing with last successful build'; Write-Output 'Test run completed. Ran 958 test(s). 956 Passed, 2 Failed'"
    $v=Invoke-FixtureVerification $r 'git --version' $test
    Assert-Equal 1 $v.ExitCode 'stale IDE run rejected'
    $j=Get-Content "$r/$script:Work/verification.json" -Raw | ConvertFrom-Json
    Assert-Match $j.checks[1].reason 'previous successful build' 'stale binaries classified'
    Assert-Match $j.checks[1].reason '2 failing tests' 'failure count retained'
    Assert-Equal 1 (Invoke-Tool 'Assert-SDDArtifacts.ps1' @('-Repository',$r,'-Feature','ComplaintImitationRequest','-Stage','ImplementationVerified')).ExitCode 'not verified'
}

Test 'V253.CompilerErrorsBlockTestsEvenWithZeroExit' {
    $r=New-ApprovedFixture
    $build=New-RunnerCommand $r 'compile-error' "Write-Output 'PaintSystemVersioningService.cs(66,1): error CS0234: Shared.Exceptions does not exist'"
    $test=New-RunnerCommand $r 'must-not-run' "throw 'Tests must not run against stale binaries'"
    $v=Invoke-FixtureVerification $r $build $test
    Assert-Equal 1 $v.ExitCode 'compile errors cannot be ignored'
    $j=Get-Content "$r/$script:Work/verification.json" -Raw | ConvertFrom-Json
    Assert-True (-not $j.checks[1].executed) 'test runner not invoked'
    Assert-Match $j.checks[0].reason 'Compiler/build errors' 'compiler error diagnosed'
}

Test 'V253.MissingBuilderCannotRunOldTests' {
    $r=New-ApprovedFixture
    $test=New-RunnerCommand $r 'must-not-run' "Write-Output 'Ran 10 tests. 10 Passed, 0 Failed'"
    $v=Invoke-FixtureVerification $r 'nonexistent-253-build-tool build' $test
    Assert-Equal 1 $v.ExitCode 'missing build tool is not success'
    $j=Get-Content "$r/$script:Work/verification.json" -Raw | ConvertFrom-Json
    Assert-True (-not $j.checks[1].executed) 'no old binary test run'
}

Test 'V253.RealPositiveCountsRemainUsable' {
    $r=New-ApprovedFixture
    $test=New-RunnerCommand $r 'positive' "Write-Output 'Passed! - Failed: 0, Passed: 7, Skipped: 0, Total: 7'"
    $v=Invoke-FixtureVerification $r 'git --version' $test
    Assert-Equal 0 $v.ExitCode $v.Output
    $j=Get-Content "$r/$script:Work/verification.json" -Raw | ConvertFrom-Json
    Assert-Equal 7 $j.checks[1].testCount 'count parsed'
}

Test 'V253.ReferenceSearchKeepsPrimaryPbiAndArtifacts' {
    $r=New-FixtureRepo DAB; Add-RefinedPbi $r
    $legacy=New-FixtureRepo Unknown
    Write-File "$legacy/PaintSystemOperations.cs" 'class PaintSystemOperations { string relationship = "cdms_ConversionToProductAllowed"; }'
    Write-File "$r/dab-config.json" '{"entities":{"AllowedProducts":{"source":"cdms_conversiontoproductallowed"}}}'
    Write-File "$r/.github/sdd/config.md" "| Key | Value |`n| LEGACY_REPO | $legacy |`n"
    $null=Invoke-Tool 'Start-SDD.ps1' @('-Repository',$r,'-PbiId','305183','-Title','Complaint Imitation Request')
    $pin=[IO.File]::ReadAllText("$r/.sdd-builder/active-pbi.json")
    Invoke-Git $r @('branch','dependency-306400') | Out-Null
    $ref=(Invoke-Git $r @('rev-parse','HEAD') | Out-String).Trim()
    Invoke-Git $r @('update-ref','refs/remotes/origin/develop',$ref) | Out-Null
    $x=Invoke-ToolJson 'Get-SDDDependencyEvidence.ps1' @('-Repository',"$r/src",'-DependencyPbiId','306400','-Symbols','cdms_ConversionToProductAllowed')
    Assert-Equal 0 $x.ExitCode $x.Output
    Assert-Equal $r $x.Data.primaryRepository 'legacy not active target'
    Assert-Equal 2 @($x.Data.results).Count 'configured reference discovered automatically'
    Assert-True (@($x.Data.results[0].matches).Count -gt 0) 'DAB config searched'
    Assert-True (@($x.Data.results[1].matches).Count -gt 0) 'legacy behavior searched'
    Assert-True $x.Data.results[0].integrationRefAvailable 'history inspected without asking'
    Assert-Equal $pin ([IO.File]::ReadAllText("$r/.sdd-builder/active-pbi.json")) 'dependency did not change active pin'
    Assert-True (-not (Test-Path "$legacy/src/.github/specs/ComplaintImitationRequest")) 'no artifacts in reference repo'
} 'RequiresGit'

Test 'V253.EntryPointsAndQuestionPolicyAgree' {
    $workflow=[IO.File]::ReadAllText("$script:PackageRoot/core/.github/sdd/workflow.md")
    Assert-Match $workflow 'Automatic evidence and question policy' 'one question authority'
    Assert-Match $workflow 'An approved AC intentionally changing legacy behavior is an implementation gap' 'not every gap needs PO approval'
    foreach ($f in @('core/.github/sdd/constitution.md','core/.github/skills/dab-development/SKILL.md','dab/.github/instructions/dab-formula-development.instructions.md','cdms/.github/instructions/cdms-development.instructions.md')) {
        $s=[IO.File]::ReadAllText((Join-Path $script:PackageRoot $f))
        Assert-NotMatch $s 'Unsure\? Output.*and stop|When something cannot be proven.*and wait|STOP\. Report:' 'no blanket uncertainty stop'
    }
    foreach ($a in @('akzo-sdd-developer.agent.md','akzo-sdd-developer-concise.agent.md')) {
        $s=[IO.File]::ReadAllText("$script:PackageRoot/core/.github/agents/$a")
        Assert-Match $s 'Required startup action' 'bootstrap in entrypoint'
        Assert-Match $s 'read them back' 'persistence action'
        Assert-Match $s 'spec.md.*plan.md' 'canonical artifacts required'
        Assert-True ($s.Length -lt 3500) 'bounded entrypoint size'
    }
} 'Static'

Test 'V253.AmbiguousDownloadsAreNotChosenByRecency' {
    $r=New-FixtureRepo DAB; $dl=New-TestRoot; $old=$env:SDD_DOWNLOADS_DIR
    try {
        $env:SDD_DOWNLOADS_DIR=$dl
        Write-File "$dl/305183-first.zip" 'candidate one'
        Write-File "$dl/305183-second.zip" 'candidate two'
        $s=Invoke-ToolJson 'Start-SDD.ps1' @('-Repository',$r,'-PbiId','305183','-Title','Complaint Imitation Request')
        Assert-Equal 4 $s.ExitCode 'no guessed input package'
        Assert-Equal 2 @($s.Data.downloadCandidates).Count 'precise candidates'
        Assert-Match $s.Data.next 'never choose by recency' 'one source decision'
        Assert-True (-not (Test-Path "$r/docs/sdd/pbi-input/305183")) 'nothing imported'
    } finally { $env:SDD_DOWNLOADS_DIR=$old }
}
