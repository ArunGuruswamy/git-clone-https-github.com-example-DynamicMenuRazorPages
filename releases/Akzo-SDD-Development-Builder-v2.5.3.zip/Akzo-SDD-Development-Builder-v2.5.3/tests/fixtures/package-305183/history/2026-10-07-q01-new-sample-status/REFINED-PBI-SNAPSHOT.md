# 305183 - [CAA][DAB API] Complaint Imitation Request (snapshot)

Status: Draft

Superseded snapshot (fixture).
