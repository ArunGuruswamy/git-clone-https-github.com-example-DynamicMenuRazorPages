# Evidence

- CONFIRMED: versioning lives in VersioningHelper (supports AC-1).
- The old design note also mentioned AC-7 for Salcomix products.
