# Open questions

| ID | Question | Status |
|---|---|---|
| Q-01 | May an inactive New Sample paint system satisfy the prerequisite? | Resolved: either active or inactive qualifies. |
