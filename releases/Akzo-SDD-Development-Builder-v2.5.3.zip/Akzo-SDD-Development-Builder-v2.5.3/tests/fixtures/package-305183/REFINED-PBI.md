# 305183 - [CAA][DAB API] Complaint Imitation Request

Status: Blocked

Mock fixture modelled on the PBI Builder package layout for builder regression tests; not the real PBI text.

## Acceptance criteria
- AC-1 Given an Actual paint system When a Complaint IR is created Then the new paint system version uses the lowercase "c" suffix (for example 2.1c).
- AC-2 Given an active Complaint IR for the same product and paint system When another Complaint IR is created Then the API returns ValidationFailed with the existing duplicate-IR message.
- AC-3 Given a Non-Actual paint system When a Complaint IR is requested Then the API returns ValidationFailed and no IR is created.

## Validation
- A Due Date in the past is rejected with the specified past-date message.

## Open questions
- Q-01 pending: may an inactive New Sample paint system satisfy the prerequisite?

## Review status
- Business approval: Pending
- Readiness: Blocked
