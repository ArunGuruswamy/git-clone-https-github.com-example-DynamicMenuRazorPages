# Decision log

| ID | Decision | Status | Affects |
|---|---|---|---|
| D-01 | Treat the complaint suffix as a lowercase c for every derived product | Proposed | AC-1 |
| D-02 | Reuse the existing CreateImitationRequest endpoint | Approved | AC-1, AC-2 |
