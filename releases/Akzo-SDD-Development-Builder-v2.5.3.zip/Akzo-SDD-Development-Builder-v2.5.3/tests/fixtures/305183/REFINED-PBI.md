# [CAA][DAB API] Complaint Imitation Request

- PBI ID: 305183
- Title: Complaint Imitation Request
- Status: Approved
- Source: PBI Builder output (mock fixture for builder regression tests; not the real PBI text)

## Business intent
Allow a Complaint Imitation Request to be created for an Actual paint system so a complaint can be investigated against the released formula.

## Acceptance criteria
- AC-1 Given an Actual paint system When a Complaint IR is created Then the new paint system version uses the lowercase "c" suffix (for example 2.1c).
- AC-2 Given an active Complaint IR for the same product and paint system When another Complaint IR is created Then the API returns ValidationFailed with the existing duplicate-IR message.
- AC-3 Given a Non-Actual paint system When a Complaint IR is requested Then the API returns ValidationFailed and no IR is created.

## Technical remarks
- Reuse the existing CreateImitationRequest flow; do not add a new endpoint.
- Industrialization rules are TBD by the PO and out of scope for this PBI.
