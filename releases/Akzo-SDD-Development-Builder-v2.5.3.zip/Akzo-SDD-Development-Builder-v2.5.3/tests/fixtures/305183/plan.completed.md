# ComplaintImitationRequest - Implementation Plan

- PBI ID: 305183
- PBI title: Complaint Imitation Request
- Feature folder: ComplaintImitationRequest
- Primary project role: DAB (skill: dab-development)
- SDD builder: v2.5.2
- Note: SAMPLE produced against the builder's mock DAB fixture.

## Current implementation inventory

- `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestHandler.cs` orchestrates creation and versioning.
- `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestValidator.cs` holds the duplicate active IR rule.
- `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Application/PaintSystem/Shared/VersioningHelper.cs` computes versions.
- `src/AN.ColorAppsAzure.Formula.Tests/AN.ColorAppsAzure.Formula.Application.Tests/ImitationRequest/CreateImitationRequestHandlerTests.cs` existing tests.

## Implementation impact matrix

| Area | File or component | Change (new/modify) | AC | Risk |
|---|---|---|---|---|
| Versioning | VersioningHelper.cs | Modify: complaint suffix | AC-1 | Version ordering |
| Validation | CreateImitationRequestValidator.cs | Modify: duplicate key, Actual status | AC-2, AC-3 | Other request types |
| Tests | CreateImitationRequestValidatorTests.cs | New | AC-1, AC-2, AC-3 | None |

## Traceability (AC -> code -> test)

| AC | Requirement | Code | Test |
|---|---|---|---|
| AC-1 | R-1 | VersioningHelper.cs (complaint suffix) | CreateImitationRequestHandlerTests.Complaint_AppendsLowercaseC |
| AC-2 | R-2 | CreateImitationRequestValidator.cs (duplicate key) | CreateImitationRequestValidatorTests.Complaint_DuplicateActive_Fails |
| AC-3 | R-3 | CreateImitationRequestValidator.cs (Actual status rule) | CreateImitationRequestValidatorTests.Complaint_NonActual_Fails |

## Affected source files and components

- Modify `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Application/PaintSystem/Shared/VersioningHelper.cs`.
- Modify `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestValidator.cs`.
- Add new test class `src/AN.ColorAppsAzure.Formula.Tests/AN.ColorAppsAzure.Formula.Application.Tests/ImitationRequest/CreateImitationRequestValidatorTests.cs` (new).
- Extend `src/AN.ColorAppsAzure.Formula.Tests/AN.ColorAppsAzure.Formula.Application.Tests/ImitationRequest/CreateImitationRequestHandlerTests.cs`.

## Reusable existing logic

- `Constants.RequestTypeComplaint` in `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Common/Constants.cs`.
- Existing duplicate-IR message constant and FluentValidation rule set; existing handler orchestration.

## CQRS handlers, validators and GraphQL contracts

- `CreateImitationRequestHandler` keeps its orchestration; it calls the complaint suffix through `VersioningHelper` (no new command).
- `CreateImitationRequestValidator` gains the Complaint duplicate key and the Actual-status rule (FluentValidation, existing message constants).
- GraphQL: `Formula_CreateImitationRequest.graphql` unchanged; no StrawberryShake regeneration.

## Derived products and Paint System relationships

- The Complaint version applies to the paint system of the requested product only; derived-product propagation is unchanged because the refined PBI does not ask for it (no product-family change).

## Implementation changes

1. T1 VersioningHelper: add complaint suffix resolution (AC-1).
2. T2 Validator: include request type in the duplicate key for Complaint (AC-2).
3. T3 Validator: reject Complaint for Non-Actual paint systems (AC-3).
4. T4 Tests for T1-T3, positive and negative.

## Regression impact and test strategy

- Regression: New Sample, Improved Formula and Technical IR versioning must not gain a suffix; duplicate rule for other request types unchanged.
- Unit tests per AC plus regression tests for New Sample versioning; run the Application test project, then the solution.

## Dependency and contract checks

- No DI change (validator and helper already registered). No `.graphql` change, so no StrawberryShake regeneration. No CDMS routing change. UI contract unchanged.

## Applicable PR-review lessons

- None registered in `docs/sdd/review-lessons/register.csv` yet; candidate checks C-003 (constants, no magic strings) and C-006 (negative tests per validator rule) are followed in T2-T4.

## Build and test verification

- `dotnet build AN.ColorAppsAzure.BL.sln`
- `dotnet test AN.ColorAppsAzure.BL.sln --logger trx --settings coverlet.runsettings --collect:"XPlat Code Coverage"`
- Recorded through `tools/Invoke-SDDVerification.ps1`; NOT EXECUTED when no terminal is available.

## Security and quality checks

- Sonar: keep validator rules small, no magic strings (use constants), cover both branches.
- No secrets or configuration changes. Approved PR review rules: none registered yet.

## Risks and implementation sequence

- Risk: case-sensitive suffix comparison in existing version parsing; mitigated by a regression test for 2.1 vs 2.1c ordering.
- Sequence: T1 -> T2 -> T3 -> T4, verify coherent task groups, then final regression.
