# ComplaintImitationRequest - Specification

- PBI ID: 305183
- PBI title: Complaint Imitation Request
- Feature folder: ComplaintImitationRequest
- Primary project role: DAB (skill: dab-development)
- Refined PBI source: docs/sdd/pbi-input/305183/REFINED-PBI.md (ApprovedRefined)
- Refined PBI approval: Approved (Status: Approved)
- PBI input package: docs/sdd/pbi-input/305183/ (1 file)
- SDD builder: v2.5.2
- Note: SAMPLE produced against the builder's mock DAB fixture. Paths are fixture paths; a real run cites the real repository.

## Refined PBI (verbatim source)

<!-- sdd:pbi-source:begin -->
{{PBI_SOURCE}}
<!-- sdd:pbi-source:end -->

## Acceptance criteria

- AC-1 Given an Actual paint system When a Complaint IR is created Then the new paint system version uses the lowercase "c" suffix (for example 2.1c).
- AC-2 Given an active Complaint IR for the same product and paint system When another Complaint IR is created Then the API returns ValidationFailed with the existing duplicate-IR message.
- AC-3 Given a Non-Actual paint system When a Complaint IR is requested Then the API returns ValidationFailed and no IR is created.

## PBI sources and attachments

The refined PBI is the source of truth. Attachments are supporting evidence and add no scope by themselves.

| File | Type | Role | Status | AC referenced | Contribution / review result |
|---|---|---|---|---|---|
| `REFINED-PBI.md` | md | Primary | Read | AC-1, AC-2, AC-3 | Primary requirements source (verbatim above). |

- Every file of the package is listed above.

## Discrepancies and source conflicts

No discrepancy was found by the deterministic checks of the input package. Semantic review: the refined PBI is the only input file, so there is nothing to compare; no conflict recorded.

## Existing implementation and repository evidence

| Area | Evidence | Current behaviour |
|---|---|---|
| Handler | `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestHandler.cs` | Creates the IR and resolves the paint-system version through `VersioningHelper`. No Complaint-specific branch. |
| Validator | `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestValidator.cs` | Contains the duplicate active IR rule; the request type is not part of the duplicate key. |
| Versioning | `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Application/PaintSystem/Shared/VersioningHelper.cs` | Default/minor/major groups; no complaint suffix. |
| Constants | `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Common/Constants.cs` | `RequestTypeComplaint` already exists and is reused. |
| GraphQL | `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Data/Graphql/GraphqlAssets/Formula/ImitationRequest/Formula_CreateImitationRequest.graphql` | Existing mutation; no schema change needed. |
| Tests | `src/AN.ColorAppsAzure.Formula.Tests/AN.ColorAppsAzure.Formula.Application.Tests/ImitationRequest/CreateImitationRequestHandlerTests.cs` | Covers New Sample creation only. |

AC coverage: AC-1 MISSING, AC-2 PARTIAL (duplicate rule exists without complaint scope), AC-3 MISSING.

## Delta requirements (ADDED / MODIFIED / REMOVED)

### ADDED
- R-1 (AC-1) The system SHALL assign the lowercase `c` suffix to the version created by a Complaint IR on an Actual paint system.
- R-3 (AC-3) The system SHALL reject a Complaint IR for a Non-Actual paint system before any write.

### MODIFIED
- R-2 (AC-2) Previously the duplicate active IR rule ignored the request type. Now the duplicate key SHALL include request type Complaint, product and paint system.

### REMOVED
- None. No existing behaviour is removed; New Sample and Improved Formula flows are unchanged.

## Business rules and state transitions

- Complaint IRs are allowed only when the paint system status is Actual; status is not changed by this PBI.
- Version suffix `c` is case-sensitive and appended to the resolved version (2.1 becomes 2.1c).
- Industrialization behaviour is out of scope (TBD by PO per the refined PBI).

## Status and versioning rules

- Only an Actual paint system can receive a Complaint IR; the paint-system status is not changed.
- The Complaint version is the resolved version plus the lowercase `c` suffix (2.1 becomes 2.1c); New Sample and Improved Formula versions are unchanged.

## API and GraphQL contracts

- Route and verb unchanged (existing CreateImitationRequest endpoint); request body unchanged.
- GraphQL mutation `Formula_CreateImitationRequest.graphql` unchanged; generated StrawberryShake client not regenerated.
- Response envelope unchanged: success data, or `ValidationFailed` with the error list.

## Validation rules and response envelope

- Duplicate active Complaint IR for the same product and paint system returns `ValidationFailed` with the existing duplicate-IR message constant (no new text).
- Non-Actual paint system returns `ValidationFailed`; no data is written.

## Testable scenarios

- Scenario AC-1: GIVEN an Actual paint system at version 2.1 WHEN a Complaint IR is created THEN the new version is 2.1c.
- Scenario AC-2: GIVEN an active Complaint IR for product P and paint system S WHEN another Complaint IR for P and S is created THEN ValidationFailed is returned.
- Scenario AC-3: GIVEN a Non-Actual paint system WHEN a Complaint IR is requested THEN ValidationFailed is returned and the command service is not called.
- Negative: GIVEN a New Sample IR WHEN created THEN the version has no `c` suffix (regression).

## Open questions, assumptions, decisions and dependencies

- Decision: reuse the existing endpoint (refined PBI technical remark).
- Assumption: the duplicate-IR message constant is reused verbatim; confirmed in the validator.
- Dependency: none on CDMS or UI; UI contract unchanged.
- Open questions: none blocking; industrialization rules stay out of scope (TBD by the PO in `REFINED-PBI.md`).
