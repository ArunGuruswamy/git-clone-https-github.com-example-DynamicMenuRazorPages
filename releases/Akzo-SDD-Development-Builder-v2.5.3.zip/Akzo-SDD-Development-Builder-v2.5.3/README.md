# Akzo SDD Development Builder v2.5.3

A developer-side, spec-driven workflow for DAB, CDMS and Angular UI, downstream of approved PBI Builder inputs. Start with [START-HERE.md](START-HERE.md) or open [the package interface](Akzo-SDD-Development-Builder.html).

[Release notes](release/RELEASE-NOTES-v2.5.3.md) · [Configuration](guides/CONFIGURATION.md) · [Known limitations](guides/KNOWN-LIMITATIONS.md) · [Root-cause audit](release/ROOT-CAUSE-MATRIX.md)

## Workflow

[core/.github/sdd/workflow.md](core/.github/sdd/workflow.md) is the sole lifecycle and mode authority. Full and Caveman Concise use identical gates and behavior; only response length differs.

Type `Start Development <PBI-ID> <Feature Name>`. The agent discovers and pins the input, detects DAB/CDMS/UI from repository evidence, inspects existing behavior, and writes and validates the specification and plan. Conflicting identity or unresolved required business decisions trigger a precise question.

Implementation requires hash-bound user approval. After approval, **FAST** completes coherent task groups continuously, with targeted checks, independent review and comprehensive final regression. **STANDARD** adds intermediate checks; **STEP** pauses after one task only when explicitly requested. Current source/configuration fingerprints and actual command logs govern evidence reuse and readiness. No automatic Git stage, commit, push or deployment occurs.

## Install or upgrade

From the extracted package on Windows:

```powershell
.\Install-DevelopmentBuilder.cmd DAB "C:\src\AN.ColorAppsAzure.BL" Both
```

Use CDMS or UI and the corresponding repository path as needed; see START-HERE for multi-repository UI arguments. The HTML interface prepares commands; run the bundled launcher under the machine's existing execution policy. RemoteSigned is respected; enforced signing or execution restrictions require an IT-approved package. The installer never bypasses policy or requests elevation.

The launcher updates unchanged owned local assets, preserves tracked team files and user edits, and records ownership hashes and backups. Local assets use `.git/info/exclude`; approved spec/plan files, application source, tests and tracked standards remain visible. Existing team configuration and architecture are retained. See [START-HERE](START-HERE.md) for reviewed team updates and [rollback guidance](guides/ROLLBACK.md) for ownership rules.

Preview or roll back the latest install:

```powershell
.\Uninstall-DevelopmentBuilder.ps1 -Destination "C:\src\AN.ColorAppsAzure.BL" -RollbackLastUpgrade -WhatIf
.\Uninstall-DevelopmentBuilder.ps1 -Destination "C:\src\AN.ColorAppsAzure.BL" -RollbackLastUpgrade
```

Only hash-owned files and verified backups are changed. User edits and backups are retained; older manifests without sufficient ownership evidence require manual review.

## Source and validation

`core/` contains shared agents, prompts, skills and SDD definitions. `dab/`, `cdms/`, `ui/`, `backend/` and `shared/` supply applicable project guidance. `tooling/tools/` contains executable discovery, approval, verification, progress and status tools. `tests/` contains the regression suite and the declared synthetic PBI 305183 scenario.

```powershell
.\tests\Run-Tests.ps1 -ReportDirectory "C:\temp\akzo-tests"
.\release\Build-Release.ps1 -OutputDirectory "C:\temp\akzo-releases"
```

Release output must be outside the source directory. Builds run the suite by default; run-specific reports stay outside the deterministic ZIP. Compare repeat-build SHA-256 values for identical inputs/runtime. Linux fixture tests do not establish Windows, Visual Studio, VS Code, Claude Code or real application integration; see the delivered test report and known limitations.

For the reported missing-artifact/IDE verification problem, see [the 306400 incident and recovery notes](release/INCIDENT-306400.md). `Upgrade-DevelopmentBuilder.cmd` explicitly updates tracked builder assets through the policy-preserving launcher; its changes remain visible for review.
