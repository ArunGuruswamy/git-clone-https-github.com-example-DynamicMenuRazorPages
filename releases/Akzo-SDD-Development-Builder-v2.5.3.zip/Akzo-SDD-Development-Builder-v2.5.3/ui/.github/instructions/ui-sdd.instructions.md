---
applyTo: "projects/**"
---

# UI rules for SDD work (in addition to `.github/copilot-instructions.md`)

- One UI, two backends (CDMS via DAB routing, DAB). Never branch behaviour on the backend. The UX stays identical.
- Interfaces in `**/shared/interfaces/*.ts` are the API contract. Change them together with the service and its spec.
- Reuse before create: generic form builder (JSON config), view-list, existing stores, lookup and option-set services, common dialogs, snackbar service.
- Permissions come from `shared-libs/src/lib/enums/*-permissions.enum.ts`. User texts use ngx-translate keys.
- Signal Store: typed state, `patchState`, `computed`, status enum (`store-status-type.enum.ts`).
- New spec files must be matched by `jest.config.js` `testMatch`. Otherwise they never run.
- Follow `.github/sdd/workflow.md`: FAST approved groups, targeted checkpoints and final regression. STEP requires an explicit request.
- Spec/plan convention for UI-only PBIs: `docs/<feature>/<op>-<feature>-{spec,plan}.md`.
