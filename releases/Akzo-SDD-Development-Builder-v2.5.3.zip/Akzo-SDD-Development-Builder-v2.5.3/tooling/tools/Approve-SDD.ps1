﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Repository,
    [Parameter(Mandatory = $true)][string]$Feature,
    # The developer's own words, copied verbatim from chat (e.g. "Approved, implement T1-T6").
    [Parameter(Mandatory = $true)][string]$Statement,
    # Defaults to the Git identity of the person running the tool.
    [string]$ApprovedBy,
    [string]$Scope = 'All tasks in plan.md',
    [string]$PbiId,
    # Only when the developer explicitly accepts implementing against a refined PBI that is not business-approved
    # (for example 'Status: Blocked'). The statement must say so in the developer's own words.
    [switch]$AcknowledgeUnapprovedPbi
)
# Akzo SDD Builder v2.5.3 - records implementation approval bound to the exact spec.md, plan.md and PBI input package.
# Limitation: a script cannot prove that a human typed the statement. Approval must come from the developer;
# agents must never call this tool without an explicit approval message in the conversation.
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$repo = Resolve-SDDRepositoryRoot $Repository

if (-not $ApprovedBy) {
    $ApprovedBy = (& git -C $repo config user.name 2>$null | Out-String).Trim()
}
if (Test-SDDBotIdentity $ApprovedBy) { throw "Approval must name a person (got '$ApprovedBy'). Pass -ApprovedBy '<developer name>'." }
if ($Statement -match '(?i)^\s*(?:no\b|not\s+approved|do\s+not\s+(?:approve|implement)|don.t\s+(?:approve|implement)|approval\s+(?:denied|rejected))') { throw 'The statement refuses approval; no approval was recorded.' }
if ($Statement -notmatch '(?i)\b(approve[ds]?|go ahead|proceed|lgtm|yes)\b') { throw 'The statement does not contain an approval. Copy the developer''s approval message verbatim.' }

# Approval is only possible on a complete analysis.
& (Join-Path $PSScriptRoot 'Assert-SDDArtifacts.ps1') -Repository $repo -Feature $Feature -Stage AnalysisComplete -PbiId $PbiId | Out-Host
if ($LASTEXITCODE -ne 0) { throw 'AnalysisComplete gate fails; approval was not recorded.' }

$folder = Join-Path (Get-SDDSpecRoot $repo) $Feature
$specPath = Join-Path $folder 'spec.md'
$planPath = Join-Path $folder 'plan.md'
if (-not $PbiId) { $PbiId = @(Get-SDDDeclaredPbiIds (Read-SDDText $specPath))[0] }
$statePath = @(Find-SDDStateFile -Repository $repo -Feature $Feature -PbiId $PbiId)[0]
$state = Read-SDDState $statePath
$work = Split-Path -Parent $statePath

# Approval must refer to the actual canonical files, never a chat-only plan or another checkout.
$receipt = Get-SDDArtifactReceipt -Repository $repo -Feature $Feature -PbiId $PbiId
if (-not $receipt.persisted) { throw ($receipt.problems -join '; ') }
Write-SDDText (Join-Path $work 'artifact-receipt.json') (($receipt | ConvertTo-Json -Depth 8) + "`n")
Write-Host "Persisted specification: $specPath"
Write-Host "Persisted implementation plan: $planPath"

# The approval is also bound to the PBI input package (refined PBI + attachments) as it is now.
$inv = $null
if ($state['source'] -and (Test-Path -LiteralPath (Join-Path $repo ([string]$state['source'])) -PathType Leaf)) {
    $inv = New-SDDPbiInventory -Repository $repo -PbiId $PbiId -Selected ([string]$state['source'])
}
$edited = @(if ($inv) { $inv.items | Where-Object { $_.editedAfterImport } | ForEach-Object { $_.packagePath } })
if ($edited.Count) { throw "PBI input file(s) were changed after import: $($edited -join ', '). Approval was NOT recorded. Restore the originals with tools/Get-SDDStatus.ps1 -Fix." }
$pbiApproved = if ($inv) { [bool]$inv.primaryApproval.approved } else { $true }
if (-not $pbiApproved) {
    if (-not $AcknowledgeUnapprovedPbi) {
        throw "The refined PBI is not business-approved ($($inv.primaryApproval.summary)). Approval was NOT recorded. Show this to the developer; only if they explicitly accept it, rerun with -AcknowledgeUnapprovedPbi and their verbatim words."
    }
    if ($Statement -notmatch '(?i)acknowledg|unapproved|not\s+(yet\s+)?approved|blocked|pending|despite|at\s+(my|our)\s+risk') {
        throw 'With -AcknowledgeUnapprovedPbi the statement must show that the developer knows the PBI is not approved (for example "Approved despite PBI status Blocked").'
    }
}

$record = [ordered]@{
    pbiId         = $PbiId
    feature       = $Feature
    approvedBy    = $ApprovedBy
    statement     = $Statement
    scope         = $Scope
    approvedAtUtc = [DateTime]::UtcNow.ToString('o')
    repository    = $repo
    artifactReceipt = $receipt
    specPath      = Get-SDDRelativePath $repo $specPath
    specSha256    = Get-SDDContentHash $specPath
    planPath      = Get-SDDRelativePath $repo $planPath
    planSha256    = Get-SDDContentHash $planPath
    sourcePath    = $state['source']
    sourceSha256  = $state['sourceHash']
    inputPackage  = $(if ($inv) { $inv.packageRoot } else { $null })
    inputFingerprint = $(if ($inv) { $inv.fingerprint } else { $null })
    inputFiles    = $(if ($inv) { $inv.summary.files } else { 0 })
    pbiApproved   = $pbiApproved
    pbiApprovalStatus = $(if ($inv) { $inv.primaryApproval.summary } else { 'No refined PBI file' })
    pbiApprovalAcknowledged = [bool]($AcknowledgeUnapprovedPbi -and -not $pbiApproved)
    gitHead       = ((& git -C $repo rev-parse HEAD 2>$null) | Out-String).Trim()
    gitBranch     = ((& git -C $repo branch --show-current 2>$null) | Out-String).Trim()
    tool          = "Approve-SDD.ps1 v$(Get-SDDVersion)"
}
Write-SDDText (Join-Path $work 'approval.json') (($record | ConvertTo-Json -Depth 4) + "`n")
$md = @"
# Approval - $PbiId $($state['title'])

- Feature folder: $Feature
- Approved by: $ApprovedBy
- Approval statement (verbatim): "$Statement"
- Approved scope: $Scope
- Approval date (UTC): $($record.approvedAtUtc)
- Spec: $($record.specPath)
- Spec revision / SHA256: $($record.specSha256)
- Plan: $($record.planPath)
- Plan revision / SHA256: $($record.planSha256)
- PBI input package / fingerprint: $($record.inputPackage) ($($record.inputFiles) files) / $($record.inputFingerprint)
- Refined PBI business approval: $(if ($pbiApproved) { 'Approved' } else { "NOT approved ($($record.pbiApprovalStatus)); acknowledged by $ApprovedBy" })
- Branch / HEAD at approval: $($record.gitBranch) / $($record.gitHead)
- Re-approval needed when spec.md, plan.md, the refined PBI or any input attachment change: Yes (enforced by Assert-SDDArtifacts -Stage ImplementationApproved)
"@
Write-SDDText (Join-Path $work 'approval.md') $md
$state['sourceHashAtApproval'] = $state['sourceHash']
Save-SDDState $statePath $state

& (Join-Path $PSScriptRoot 'Assert-SDDArtifacts.ps1') -Repository $repo -Feature $Feature -Stage ImplementationApproved -PbiId $PbiId | Out-Host
if ($LASTEXITCODE -ne 0) { throw 'Approval recorded but the ImplementationApproved gate failed.' }
Write-Host "Approval recorded for $PbiId by $ApprovedBy." -ForegroundColor Green
