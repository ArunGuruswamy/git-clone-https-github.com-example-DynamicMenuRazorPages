﻿[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$Repository,
    [Parameter(Mandatory)][string]$Feature,
    [string]$PbiId,
    [Parameter(Mandatory)][string[]]$Tasks,
    [Parameter(Mandatory)][string]$Evidence,
    [ValidateSet('FAST','STANDARD','STEP')][string]$Mode,
    [ValidateRange(0,1000000)][int]$FilesRead = 0,
    [ValidateRange(0,1000000)][int]$RepeatedReads = 0,
    [ValidateRange(0,1000000)][int]$ToolCalls = 0
)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$repo = Resolve-SDDRepositoryRoot $Repository
& (Join-Path $PSScriptRoot 'Assert-SDDArtifacts.ps1') -Repository $repo -Feature $Feature -PbiId $PbiId -Stage ImplementationApproved -NoStateUpdate | Out-Host
if ($LASTEXITCODE -ne 0) { throw 'Implementation approval is required before recording completed tasks.' }
$stateFiles = @(Find-SDDStateFile -Repository $repo -Feature $Feature -PbiId $PbiId)
if ($stateFiles.Count -ne 1) { throw 'Unique feature state required.' }
$work = Split-Path -Parent $stateFiles[0]
$ap = Read-SDDText (Join-Path $work 'approval.json') | ConvertFrom-Json
$plan = Read-SDDText (Join-Path $repo $ap.planPath)
$section = [regex]::Match($plan,'(?ims)^## (?:Implementation changes|Tasks)[^\r\n]*\r?\n(.*?)(?=^## |\z)').Groups[1].Value
$approvedTasks = @([regex]::Matches($section,'\bT\d+\b') | ForEach-Object Value | Select-Object -Unique)
$taskIds = @($Tasks | ForEach-Object { $_ -split ',' } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
foreach ($id in $taskIds) { if ($approvedTasks -notcontains $id) { throw "Task $id is not in the approved plan." } }
if ([string]::IsNullOrWhiteSpace($Evidence)) { throw 'Task evidence must be nonempty.' }
$fp = (Get-SDDSourceFingerprint $repo).sha256
$vpath = Join-Path $work 'verification.json'
if (-not (Test-Path -LiteralPath $vpath)) { throw 'Run targeted verification before recording a verified checkpoint.' }
$ver = Read-SDDText $vpath | ConvertFrom-Json
if ($ver.sourceFingerprint -ne $fp -or @($ver.checks | Where-Object { -not $_.executed -or $_.exitCode -ne 0 }).Count -gt 0 -or @($ver.checks).Count -lt 2) { throw 'Checkpoint requires successful current-source verification.' }
foreach ($check in $ver.checks) {
    if ($null -eq $check.exitCode) { throw 'Checkpoint has an incomplete process exit.' }
    if (-not $check.logFile -or -not (Test-Path -LiteralPath (Join-Path $repo $check.logFile)) -or (Get-SDDContentHash (Join-Path $repo $check.logFile)) -ne $check.logSha256) { throw 'Checkpoint log evidence is missing or changed.' }
    $outcome = Get-SDDCommandOutcome -Kind $check.kind -Output (Read-SDDText (Join-Path $repo $check.logFile))
    if (-not $outcome.valid) { throw ($outcome.issues -join '; ') }
}
$path = Join-Path $work 'progress.json'
$prior = if (Test-Path -LiteralPath $path) { Read-SDDText $path | ConvertFrom-Json } else { $null }
if ($prior -and $prior.planSha256 -ne $ap.planSha256) { throw 'Approved plan changed; preserve prior progress and reconcile tasks before resuming.' }
$modeValue = if ($Mode) { $Mode } elseif ($prior) { $prior.mode } else { Get-SDDExecutionMode $repo }
$done = @($taskIds)
if ($prior) { $done += @($prior.completedTasks) }
$record = [ordered]@{ pbiId = $ap.pbiId; feature = $Feature; mode = $modeValue; planSha256 = $ap.planSha256; specSha256 = $ap.specSha256; sourceFingerprint = $fp; completedTasks = @($done | Sort-Object -Unique); evidence = $Evidence; verificationSha256 = Get-SDDContentHash $vpath; recordedAtUtc = [DateTime]::UtcNow.ToString('o'); metrics = [ordered]@{ filesRead = $FilesRead; repeatedReads = $RepeatedReads; toolCalls = $ToolCalls; actualTokens = 'UNKNOWN'; note = 'Read/call counters are caller-observed values for this checkpoint, not inferred provider usage.' } }
Write-SDDText $path (($record | ConvertTo-Json -Depth 6) + "`n")
Write-Host "Recorded verified tasks $($taskIds -join ', ') in $modeValue mode."
