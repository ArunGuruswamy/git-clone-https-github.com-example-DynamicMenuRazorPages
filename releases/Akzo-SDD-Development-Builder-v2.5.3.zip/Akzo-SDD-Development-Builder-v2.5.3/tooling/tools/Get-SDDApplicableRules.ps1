﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Repository,
    # Files being changed. Defaults to Git changes against the integration branch plus the working tree.
    [string[]]$Paths,
    [string]$Base = 'origin/develop',
    [switch]$IncludeCandidates,
    [switch]$Json
)
# Akzo SDD Builder v2.5.3 - selects only the APPROVED review rules relevant to the files in this change,
# so agents load a short, focused rule set instead of the whole history.
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$repo = Resolve-SDDRepositoryRoot $Repository
$register = Join-Path $repo 'docs/sdd/review-lessons/register.csv'
if (-not (Test-Path -LiteralPath $register -PathType Leaf)) {
    if ($Json) { '{"rules":[],"note":"No register.csv. Import real PR comments with Import-SDDReviewComments.ps1."}' } else { Write-Host 'No review register yet. Applicable rules: NONE (import real PR comments first).' -ForegroundColor Yellow }
    exit 0
}
if (-not $Paths) {
    $Paths = @()
    $diff = & git -C $repo diff --name-only "$Base...HEAD" 2>$null; if ($LASTEXITCODE -eq 0) { $Paths += $diff }
    $Paths += @(& git -C $repo diff --name-only 2>$null) + @(& git -C $repo diff --name-only --cached 2>$null)
    $Paths = @($Paths | Where-Object { $_ } | Select-Object -Unique)
}
$role = (Get-SDDRepositoryRole $repo).Role
$areas = New-Object System.Collections.Generic.HashSet[string]
[void]$areas.Add('All'); [void]$areas.Add($role)
if ($role -in @('DAB', 'CDMS')) { [void]$areas.Add('Backend') }
foreach ($p in $Paths) { if ($p -match '(?i)\.(ts|html|scss)$') { [void]$areas.Add('UI') } elseif ($p -match '(?i)\.graphql$') { [void]$areas.Add('DAB') } }
$statuses = if ($IncludeCandidates) { @('Approved', 'Candidate') } else { @('Approved') }
$rules = @(Import-Csv -LiteralPath $register | Where-Object { $statuses -contains $_.ApprovalStatus -and $areas.Contains($_.Applicability) })
if ($Json) { [ordered]@{ role = $role; changedFiles = $Paths; rules = $rules } | ConvertTo-Json -Depth 5; exit 0 }
Write-Host "Applicable review rules for $role ($($Paths.Count) changed file(s)): $($rules.Count)" -ForegroundColor Cyan
foreach ($r in $rules) { Write-Host ("  {0} [{1}/{2}] {3}" -f $r.RuleId, $r.Severity, $r.ApprovalStatus, $r.ReviewerConcern) }
