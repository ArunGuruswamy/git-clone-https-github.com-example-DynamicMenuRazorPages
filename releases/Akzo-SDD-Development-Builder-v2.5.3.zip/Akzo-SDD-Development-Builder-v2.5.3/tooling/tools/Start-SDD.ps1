﻿[CmdletBinding()]
param(
    [string]$Repository = (Get-Location).Path,
    # Free text as typed by the developer, e.g. "Start Development 305183 Complaint Imitation Request".
    [string]$Request,
    [string]$PbiId,
    # Only after the user resolves an identity conflict explicitly.
    [switch]$ConfirmPbiSelection,
    [string]$Title,
    [string]$Feature,
    # Optional: downloaded PBI package(s) to copy into docs/sdd/pbi-input/<PBI-ID>/ first (ZIP, folder or files).
    [string[]]$Source,
    # With -Source: replace input files whose content changed (previous versions kept under .previous/).
    [switch]$UpdateChangedInput,
    # Emit a single JSON object (for agents) instead of human-readable lines.
    [switch]$Json
)
# Akzo SDD Builder v2.5.3 - Start Development
# Discovers the PBI by identity, inventories its input package (refined PBI + attachments), selects the project
# role from repository evidence, and initialises the published spec/plan and working artifacts WITHOUT
# overwriting anything that already exists. PBI inputs and extracted text stay out of Git Changes.
# Exit codes: 0 initialised/resumed, 3 role unresolved/ambiguous, 4 PBI not found / ID required,
#             5 PBI source ambiguous, 6 input package conflict or PBI mismatch.
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force

$repo = Resolve-SDDRepositoryRoot $Repository
if (-not (Test-Path -LiteralPath $repo -PathType Container)) { throw "Repository not found: $Repository" }

if ($Request) {
    # Optional trailing hints, in any order:
    #   (spec folder: ComplaintImitationRequest)      explicit published folder name
    #   (source: C:\Users\me\Downloads\x.zip)         PBI Builder package to import first (';' separates several)
    $requestSources = New-Object System.Collections.Generic.List[string]
    while ($true) {
        $sf = [regex]::Match($Request, '(?i)\s*\(\s*spec\s+folder\s*:\s*([A-Za-z]+)\s*\)\s*$')
        if ($sf.Success) {
            if (-not $Feature) { $Feature = $sf.Groups[1].Value }
            $Request = $Request.Substring(0, $sf.Index); continue
        }
        $so = [regex]::Match($Request, '(?i)\s*\(\s*(?:pbi\s+)?(?:source|files|package)\s*:\s*(.+)\)\s*$')
        if ($so.Success) {
            foreach ($p in ($so.Groups[1].Value -split ';')) { $q = $p.Trim().Trim('"', "'").Trim(); if ($q) { $requestSources.Add($q) } }
            $Request = $Request.Substring(0, $so.Index); continue
        }
        break
    }
    if ($requestSources.Count -and -not $Source) { $Source = $requestSources.ToArray() }
    $m = [regex]::Match($Request, '(?i)^\s*(?:/?start[\s-]*development)?\s*#?(\d{4,8})\b\s*[-:]?\s*(.*)$')
    if ($m.Success) {
        if ($PbiId -and $PbiId -ne $m.Groups[1].Value) { throw 'Request and -PbiId conflict. Supply the same explicit identity.' }
        $PbiId = $m.Groups[1].Value
        if (-not $Title -and $m.Groups[2].Value.Trim()) { $Title = $m.Groups[2].Value.Trim() }
    }
}

function Complete([int]$code, [System.Collections.IDictionary]$summary) {
    $summary['exitCode'] = $code
    if ($Json) { ($summary | ConvertTo-Json -Depth 8) | Write-Output }
    else {
        $color = if ($code -eq 0) { 'Green' } else { 'Red' }
        Write-Host ("SDD start: {0}" -f $summary['status']) -ForegroundColor $color
        foreach ($k in @('repository', 'pbiId', 'pbiTitle', 'feature', 'role', 'skill', 'source', 'sourceKind', 'specAbsolute', 'planAbsolute', 'workFolder', 'inventory', 'stage')) {
            if ($summary.Contains($k) -and $summary[$k]) { Write-Host ("  {0,-11} {1}" -f $k, $summary[$k]) }
        }
        if ($summary.Contains('import') -and $summary['import'] -and $summary['import'].message -ne $summary['message']) { Write-Host ("  import      {0}" -f $summary['import'].message) }
        foreach ($e in @($summary['inputEdited'])) { if ($e) { Write-Host ("  EDITED      {0}" -f $e) -ForegroundColor Red } }
        if ($summary.Contains('pbiApproval') -and $summary['pbiApproval'] -and -not $summary['pbiApproval'].approved) { Write-Host ("  WARNING     refined PBI is NOT business-approved: {0}" -f $summary['pbiApproval'].summary) -ForegroundColor Yellow }
        if ($summary.Contains('inputs') -and $summary['inputs']) {
            $s = $summary['inputs']
            Write-Host ("  inputs      {0} files: read {1}, extracted {2}, needs agent review {3}, unreadable {4}, unsupported {5}, history {6}, duplicates {7}, other PBI {8}" -f $s.files, $s.read, $s.extracted, $s.requiresAgentReview, $s.unreadable, $s.unsupported, $s.history, $s.duplicates, $s.otherPbi)
        }
        foreach ($d in @($summary['discrepancies'])) { if ($d) { Write-Host ("  discrepancy {0}" -f $d) -ForegroundColor Yellow } }
        foreach ($d in @($summary['downloadCandidates'])) { if ($d) { Write-Host ("  download    {0} ({1}, {2})" -f $d.path, $d.kind, $d.modified) } }
        if ($summary['message']) { Write-Host ("  {0}" -f $summary['message']) -ForegroundColor Yellow }
        if ($summary['next']) { Write-Host ("NEXT: {0}" -f $summary['next']) -ForegroundColor Cyan }
    }
    exit $code
}

$summary = [ordered]@{ version = (Get-SDDVersion); repository = $repo; status = ''; pbiId = $PbiId; title = $Title }

# ---------------------------------------------------------------- 1. project role from repository evidence
$role = Get-SDDRepositoryRole $repo
$summary['role'] = $role.Role; $summary['skill'] = $role.Skill; $summary['roleEvidence'] = $role.Evidence
if ($role.Role -in @('UNRESOLVED', 'AMBIGUOUS')) {
    $summary['status'] = "Role$($role.Role.Substring(0,1))$($role.Role.Substring(1).ToLowerInvariant())"
    $summary['message'] = if ($role.Role -eq 'AMBIGUOUS') { "Repository evidence matches $($role.Candidates -join ' and '). Ask the developer ONE question and record the answer as {""role"":""DAB""} in .sdd-builder/settings.json." } else { 'No DAB/CDMS/UI signature found. Confirm the repository root; no files were changed.' }
    Complete 3 $summary
}

$identity = Resolve-SDDPbiIdentity -Repository $repo -ExplicitId $PbiId -ConfirmPbiSelection:$ConfirmPbiSelection
$summary['identitySources'] = $identity.sources
if ($identity.status -eq 'PbiConflict') { $summary['status'] = 'PbiConflict'; $summary['message'] = $identity.message; Complete 7 $summary }
if ($identity.pbiId) { $PbiId = $identity.pbiId; $summary['pbiId'] = $PbiId }

# ---------------------------------------------------------------- 2. optional import of a downloaded PBI package
if ($Source) {
    $imp = Import-SDDPbiInput -Repository $repo -Source $Source -PbiId $PbiId -UpdateChanged:$UpdateChangedInput
    $summary['import'] = [pscustomobject][ordered]@{ status = $imp.status; message = $imp.message; counts = $imp.counts; warnings = $imp.warnings; git = $imp.git; files = $imp.files }
    if ($imp.pbiId) { $PbiId = $imp.pbiId; $summary['pbiId'] = $PbiId }
    switch ($imp.status) {
        'PbiIdRequired' { $summary['status'] = 'PbiIdRequired'; $summary['message'] = $imp.message; $summary['next'] = 'Say: Start Development <PBI-ID> <Feature Name>.'; Complete 4 $summary }
        'PbiMismatch' { $summary['status'] = 'PbiMismatch'; $summary['message'] = $imp.message; Complete 6 $summary }
        'InputConflict' { $summary['status'] = 'InputConflict'; $summary['message'] = $imp.message; $summary['next'] = 'Ask the developer whether the PBI was re-refined; only then re-run with -UpdateChangedInput.'; Complete 6 $summary }
    }
}

# ---------------------------------------------------------------- 3. PBI discovery by identity
if (-not $PbiId) {
    $ids = @()
    $inputRoot = Join-Path $repo 'docs/sdd/pbi-input'
    if (Test-Path -LiteralPath $inputRoot) { $ids = @([IO.Directory]::GetDirectories($inputRoot) | ForEach-Object { [IO.Path]::GetFileName($_) } | Where-Object { $_ -match '^\d{4,8}$' }) }
    if ($ids.Count -eq 1) { $PbiId = $ids[0] }
    else {
        $summary['status'] = 'PbiIdRequired'
        $summary['message'] = if ($ids.Count) { "Several PBI folders exist ($($ids -join ', ')). Say: Start Development <PBI-ID> <Feature Name>." } else { 'Say: Start Development <PBI-ID> <Feature Name>.' }
        Complete 4 $summary
    }
}
$summary['pbiId'] = $PbiId
$found = Find-SDDPbiSource -Repository $repo -PbiId $PbiId
if ($found.Status -eq 'NotFound') {
    $availableDownloads = @(Find-SDDDownloadCandidates $PbiId)
    if ($availableDownloads.Count -eq 1) {
        $autoImport = Import-SDDPbiInput -Repository $repo -Source $availableDownloads[0].path -PbiId $PbiId
        $summary['autoImport'] = [pscustomobject]@{ status = $autoImport.status; message = $autoImport.message }
        if ($autoImport.status -in @('PbiMismatch','InputConflict','PbiIdRequired')) { $summary['status'] = $autoImport.status; $summary['message'] = $autoImport.message; Complete 6 $summary }
        $found = Find-SDDPbiSource -Repository $repo -PbiId $PbiId
    }
}
$summary['source'] = $found.Selected; $summary['sourceKind'] = $found.Kind; $summary['discovery'] = $found.Reason
$summary['candidates'] = @($found.Candidates | ForEach-Object { "$($_.Path) [tier $($_.Tier), $($_.Kind), $($_.IdentityBy)]" })
if ($found.Excluded.Count) { $summary['excluded'] = $found.Excluded }
switch ($found.Status) {
    'NotFound' {
        $summary['status'] = 'PbiNotFound'; $summary['message'] = $found.Reason
        $dl = @($availableDownloads)
        $summary['downloadCandidates'] = $dl
        $summary['next'] = if ($dl.Count -ge 1) {
            "Import the downloaded package, then continue: tools/Start-SDD.ps1 -Repository . -Request '$($Request -replace "'", "''")' -Source '$($dl[0].path)'" + $(if ($dl.Count -gt 1) { " ($($dl.Count) candidates found; ask one source selection question, never choose by recency)" } else { '' })
        } else { "Copy the refined PBI package into docs/sdd/pbi-input/$PbiId/ (drag the downloaded ZIP onto tools\Add-PbiInput.cmd), or pass -Source <zip or folder>." }
        Complete 4 $summary
    }
    'Ambiguous' { $summary['status'] = 'PbiAmbiguous'; $summary['message'] = $found.Reason; Complete 5 $summary }
}

$sourceText = ''
if ($found.Selected) { $sourceText = Read-SDDText (Join-Path $repo $found.Selected) }

# ---------------------------------------------------------------- 4. title and feature folder
$pbiTitle = if ($sourceText) { Get-SDDPbiTitle $sourceText } else { '' }
if (-not $Title -and $pbiTitle) { $Title = $pbiTitle }
if (-not $Feature) {
    if ($found.ExistingFeature) { $Feature = $found.ExistingFeature }
    elseif ($Title) { $Feature = ConvertTo-SDDFeatureName $Title }
    else { throw 'Cannot derive a feature name. Say: Start Development <PBI-ID> <Feature Name>.' }
}
if (-not (Test-SDDFeatureName $Feature)) { throw "Feature folder must be short PascalCase letters with no PBI number: '$Feature'." }
if (-not $Title) { $Title = $Feature }
if (-not $pbiTitle) { $pbiTitle = $Title }
$summary['title'] = $Title; $summary['pbiTitle'] = $pbiTitle; $summary['feature'] = $Feature

$specRoot = Get-SDDSpecRoot $repo
$folder = Join-Path $specRoot $Feature
$specPath = Join-Path $folder 'spec.md'
$planPath = Join-Path $folder 'plan.md'
$work = Get-SDDWorkFolder $repo $PbiId $Feature
$analysis = Join-Path $work 'pbi-analysis'
$summary['spec'] = Get-SDDRelativePath $repo $specPath
$summary['plan'] = Get-SDDRelativePath $repo $planPath
$summary['workFolder'] = Get-SDDRelativePath $repo $work

# Existing published files: reuse when they belong to this PBI, never overwrite when they belong to another one.
$reconcile = @()
foreach ($p in @($specPath, $planPath)) {
    if (Test-Path -LiteralPath $p -PathType Leaf) {
        $ids = @(Get-SDDDeclaredPbiIds (Read-SDDText $p))
        if ($ids.Count -and $ids -notcontains $PbiId) { $reconcile += (Get-SDDRelativePath $repo $p) }
    }
}

if ($reconcile.Count) {
    $summary['status'] = 'ReconcileExistingSpec'; $summary['message'] = 'Existing documents belong to another PBI: ' + ($reconcile -join ', ')
    Complete 6 $summary
}

# ---------------------------------------------------------------- 5. PBI input package inventory (one PBI only)
$inv = $null
if ($found.Selected) {
    # Inputs are evidence: record their hashes once and keep them read-only.
    $baseline = Update-SDDInputBaseline -Repository $repo -PbiId $PbiId
    if ($baseline -and $baseline.Added.Count) { $summary['inputBaselineAdded'] = $baseline.Added }
    Set-SDDActivePbi -Repository $repo -PbiId $PbiId -Active $true
    $inv = New-SDDPbiInventory -Repository $repo -PbiId $PbiId -Selected $found.Selected -WorkFolder $analysis -Write
    $summary['inputEdited'] = @($inv.items | Where-Object { $_.editedAfterImport } | ForEach-Object { "$($_.path) was changed after import" })
    $summary['inventory'] = Get-SDDRelativePath $repo (Join-Path $analysis 'pbi-inventory.md')
    $summary['inputs'] = $inv.summary
    $summary['pbiApproval'] = [pscustomobject][ordered]@{ approved = $inv.primaryApproval.approved; summary = $inv.primaryApproval.summary }
    $summary['discrepancies'] = @($inv.discrepancies | ForEach-Object { "$($_.id) $($_.type): $($_.detail)" })
    $summary['needsAgentReview'] = @($inv.items | Where-Object { $_.status -eq 'RequiresAgentReview' } | ForEach-Object { "$($_.path): $($_.reason)" })
    $summary['unreadable'] = @($inv.items | Where-Object { $_.status -in @('Unreadable', 'Unsupported') } | ForEach-Object { "$($_.path): $($_.status) - $($_.reason)" })
}
# Local-only: PBI inputs and the text extracted from them never appear in Git Changes (unless the team tracks them).
$localDirs = @()
if (Test-Path -LiteralPath (Join-Path $repo "docs/sdd/pbi-input/$PbiId") -PathType Container) { $localDirs += "docs/sdd/pbi-input/$PbiId" }
if (Test-Path -LiteralPath $analysis -PathType Container) { $localDirs += (Get-SDDRelativePath $repo $analysis) }
if ($localDirs.Count) { $summary['localOnly'] = Add-SDDLocalExclude -Repository $repo -RelativeDirs $localDirs }

$pinPath = Join-Path $repo '.sdd-builder/active-pbi.json'
$previousPin = if (Test-Path -LiteralPath $pinPath) { Read-SDDText $pinPath | ConvertFrom-Json } else { $null }
$resolved = [bool]($ConfirmPbiSelection -or ($previousPin -and $previousPin.PSObject.Properties['conflictResolved'] -and $previousPin.conflictResolved -and $previousPin.pbiId -eq $PbiId -and $previousPin.branchIdentity -eq $identity.sources['branch']))
Write-SDDText $pinPath (([ordered]@{ pbiId = $PbiId; feature = $Feature; conflictResolved = $resolved; branchIdentity = $identity.sources['branch'] } | ConvertTo-Json) + "`n")
if ($ConfirmPbiSelection) {
    $settingsPath = Join-Path $repo '.sdd-builder/settings.json'
    if (Test-Path -LiteralPath $settingsPath) {
        $settingsObject = Read-SDDText $settingsPath | ConvertFrom-Json
        if ($settingsObject.PSObject.Properties['activePbi']) { $settingsObject.activePbi = $PbiId; Write-SDDText $settingsPath (($settingsObject | ConvertTo-Json -Depth 20) + "`n") }
    }
}
$null = Add-SDDLocalExclude -Repository $repo -RelativeDirs @('.sdd-builder')
$summary['executionMode'] = Get-SDDExecutionMode $repo

# ---------------------------------------------------------------- 6. initial documents (only when missing)
$sourceRel = if ($found.Selected) { $found.Selected } else { '(resumed from existing SDD artifacts)' }
$markers = Get-SDDPbiSourceMarkers
$esc = { param($t) ([string]$t -replace '\|', '/' -replace '\r?\n', ' ').Trim() }
function Code([string]$t) { return ([string][char]96) + $t + ([string][char]96) }
$approvalLine = if ($inv) { if ($inv.primaryApproval.approved) { "Approved ($($inv.primaryApproval.summary))" } else { "NOT business-approved ($($inv.primaryApproval.summary))" } } else { 'Unknown (no refined PBI file)' }
$header = @"
- PBI ID: $PbiId
- PBI title: $pbiTitle
- Feature folder: $Feature
- Primary project role: $($role.Role) (skill: $($role.Skill))
- Refined PBI source: $sourceRel ($($found.Kind))
- Refined PBI approval: $approvalLine
- PBI input package: $(if ($inv -and $inv.packageRoot) { "$($inv.packageRoot)/ ($($inv.summary.files) files; inventory $($summary['inventory']))" } else { 'none' })
- SDD builder: v$(Get-SDDVersion)
"@
$verbatim = if ($sourceText) { "$($markers[0])`n$($sourceText.TrimEnd())`n$($markers[1])" } else { "$($markers[0])`n(PBI source not present; see existing artifacts)`n$($markers[1])" }

$sourcesSection = New-Object System.Text.StringBuilder
$discrepancySection = New-Object System.Text.StringBuilder
if ($inv) {
    [void]$sourcesSection.AppendLine("The refined PBI is the source of truth. Attachments are supporting evidence and add no scope by themselves. Inventory: " + (Code $summary['inventory']) + ' (extracted text under ' + (Code 'pbi-analysis/pbi-extracted/') + ').')
    [void]$sourcesSection.AppendLine()
    [void]$sourcesSection.AppendLine('| File | Type | Role | Status | AC referenced | Contribution / review result |')
    [void]$sourcesSection.AppendLine('|---|---|---|---|---|---|')
    foreach ($it in $inv.items) {
        if ($it.role -in @('History', 'Metadata') -or $it.status -eq 'Duplicate') { continue }
        $statusCell = $it.status
        if ($it.status -in @('Unreadable', 'Unsupported', 'RequiresAgentReview') -and $it.reason) { $statusCell = "$($it.status): $(& $esc $it.reason)" }
        $companion = $null
        if ($it.role -in @('DecisionLog', 'OpenQuestions') -and $it.status -eq 'Read') { $companion = Get-SDDCompanionSummary $it.role (Read-SDDText (Join-Path $repo $it.path)) }
        $contribution = switch ($it.status) {
            'ForeignPbi' { "Not relevant: declares PBI $(@($it.declaredPbiIds) -join ', '); excluded from analysis." }
            default { if ($it.role -eq 'Primary') { 'Primary requirements source (verbatim above).' } elseif ($companion) { $companion } else { 'PENDING' } }
        }
        [void]$sourcesSection.AppendLine("| $(Code $it.packagePath) | $($it.type) | $($it.role) | $statusCell | $((@($it.criteria) -join ', ')) | $contribution |")
    }
    $hist = @($inv.items | Where-Object { $_.role -eq 'History' })
    $dups = @($inv.items | Where-Object { $_.status -eq 'Duplicate' })
    $meta = @($inv.items | Where-Object { $_.role -eq 'Metadata' -and $_.status -ne 'Duplicate' })
    [void]$sourcesSection.AppendLine()
    if ($hist.Count) { [void]$sourcesSection.AppendLine("- Not analysed as requirements: $($hist.Count) PBI Builder history snapshot(s) (superseded versions, kept for reference).") }
    if ($dups.Count) { [void]$sourcesSection.AppendLine("- Duplicates analysed once: " + (($dups | ForEach-Object { (Code $_.packagePath) + ' = ' + (Code $_.duplicateOf) }) -join '; ') + '.') }
    if ($meta.Count) { [void]$sourcesSection.AppendLine("- Metadata only: " + (($meta | ForEach-Object { Code $_.packagePath }) -join ', ') + '.') }
    if (-not ($hist.Count -or $dups.Count -or $meta.Count)) { [void]$sourcesSection.AppendLine('- Every file of the package is listed above.') }

    if (@($inv.discrepancies).Count) {
        [void]$discrepancySection.AppendLine('Found by the deterministic checks of the input package. None is resolved automatically.')
        [void]$discrepancySection.AppendLine()
        [void]$discrepancySection.AppendLine('| ID | Type | Sources | Detail | Resolution or open question |')
        [void]$discrepancySection.AppendLine('|---|---|---|---|---|')
        foreach ($d in $inv.discrepancies) {
            $files = (@($d.files) | ForEach-Object { Code $_ }) -join ', '
            [void]$discrepancySection.AppendLine("| $($d.id) | $($d.type) | $files | $(& $esc $d.detail) | PENDING |")
        }
    } else {
        [void]$discrepancySection.AppendLine('No discrepancy was found by the deterministic checks of the input package.')
    }
    [void]$discrepancySection.AppendLine()
    [void]$discrepancySection.AppendLine('PENDING: semantic review of every supporting file against the refined PBI (conflicting or obsolete rules, examples, constraints). Record each conflict as SX-01, SX-02 ... with its source file, or state that none was found and which files were compared.')
} else {
    [void]$sourcesSection.AppendLine('PENDING: no PBI input package was found; cite the sources this analysis is based on.')
    [void]$discrepancySection.AppendLine('PENDING: conflicts between sources, or N/A - <reason>.')
}

$acBlock = if ($sourceText) { Get-SDDAcceptanceBlock $sourceText } else { $null }
$acceptanceSection = if ($acBlock) { "Copied verbatim from the refined PBI by Start-SDD.`n`n$acBlock" } else { 'PENDING: list every acceptance criterion verbatim from the source above, with its AC ID.' }

$specTemplate = @"
# $Feature - Specification

$header

## Refined PBI (verbatim source)

$verbatim

## Acceptance criteria

$acceptanceSection

## PBI sources and attachments

$($sourcesSection.ToString().TrimEnd())

## Discrepancies and source conflicts

$($discrepancySection.ToString().TrimEnd())

## Existing implementation and repository evidence

PENDING: current behaviour with file paths, class.method and test evidence from this repository; what exists versus what is required.

## Delta requirements (ADDED / MODIFIED / REMOVED)

PENDING: ADDED, MODIFIED (quote current behaviour) and REMOVED requirements, each linked to AC IDs.

## Business rules and state transitions

PENDING: approved business rules only, each with its source file; unapproved or conflicting rules go to open questions.

## Status and versioning rules

PENDING: status, version numbering, naming, derived-product and Local/Global rules that apply, or 'N/A - <reason>'.

## API and GraphQL contracts

PENDING: route, verb, request, response, GraphQL operation and nullability.

## Validation rules and response envelope

PENDING: validator rules, exact error codes/messages (with source file) and the response envelope.

## Testable scenarios

PENDING: GIVEN / WHEN / THEN scenarios per AC, positive and negative.

## Open questions, assumptions, decisions and dependencies

PENDING: confirmed decisions (with source file), open questions with their implementation impact, assumptions, dependencies.
"@

$contractHeading = switch ($role.Role) { 'DAB' { 'CQRS handlers, validators and GraphQL contracts' } 'CDMS' { 'CQRS handlers, validators and API contracts' } default { 'Components, services and API contracts' } }
$derivedSection = if ($role.Role -in @('DAB', 'CDMS')) { "## Derived products and Paint System relationships`n`nPENDING: Primary/Secondary derived-product, product-family, Paint System version and association effects, or 'N/A - <reason>'.`n`n" } else { '' }
$planTemplate = @"
# $Feature - Implementation Plan

$header

## Current implementation inventory (existing source-code analysis)

PENDING: files, classes, handlers, validators, GraphQL operations and tests that exist today.

## Implementation impact matrix

| Area | File or component | Change (new/modify) | AC | Risk |
|---|---|---|---|---|
| PENDING | | | | |

## Traceability (AC -> code -> test)

PENDING: one row per AC: requirement, source file, test name.

## Affected source files and components

PENDING: every file to change or add (mark new files as new).

## Reusable existing logic

PENDING: existing handlers, helpers and constants that will be reused.

## $contractHeading

PENDING: per handler/validator/component: current behaviour, required change, contract impact (or no change, with evidence).

$($derivedSection)## Implementation changes (tasks)

PENDING: ordered tasks, coherent related changes with checkpoint verification.

## Unit and regression tests (test strategy)

PENDING: new unit tests per AC, regression tests for neighbouring flows, and the test projects they belong to.

## Dependency and contract checks

PENDING: DI registration, GraphQL client regeneration, CDMS routing, UI contract.

## Applicable PR-review lessons

PENDING: approved review rules from tools/Get-SDDApplicableRules.ps1 that apply and how this plan satisfies each, or 'None registered - <evidence>'.

## Build and test verification

PENDING: exact build and test commands for this repository.

## Security and quality checks

PENDING: Sonar rules, secrets, confidential attachments not committed.

## Risks and implementation sequence

PENDING: risks with mitigation, and the order of work.
"@

$created = @()
$createdSpec = $false
if ($reconcile.Count -eq 0) {
    if (-not (Test-Path -LiteralPath $specPath -PathType Leaf)) { Write-SDDText $specPath $specTemplate; $created += $summary['spec']; $createdSpec = $true }
    if (-not (Test-Path -LiteralPath $planPath -PathType Leaf)) { Write-SDDText $planPath $planTemplate; $created += $summary['plan'] }
}

$working = [ordered]@{
    '00-intake.md'            = "# Intake $PbiId - $pbiTitle`n`n$header`n- Published spec: $($summary['spec'])`n- Published plan: $($summary['plan'])`n- Discovery: $($found.Reason)`n"
    '01-feature-inventory.md' = "# Feature inventory`n`nPENDING: route ownership, backend/UI flow trace, AC coverage (EXISTS/PARTIAL/MISSING/CONFLICT) with evidence.`n"
    '02-clarifications.md'    = "# Clarifications`n`nPENDING: CONFIRMED / ASSUMPTION / OPEN QUESTION for every requirement.`n"
    '06-test-plan.md'         = "# Test plan`n`nPENDING: test cases per AC, regression suite, commands.`n"
    '07-tasks.md'             = "# Tasks`n`nPENDING: T1..Tn, coherent approved task groups with AC traceability and checkpoint verification. Tick tasks here, not in plan.md.`n"
    '08-analysis.md'          = "# Analysis`n`nPENDING: AC -> requirement -> task -> test matrix and constitution check.`n"
    'regression-impact.md'    = "# Regression impact`n`nPENDING`n"
    'contract-matrix.md'      = "# Contract matrix`n`nPENDING`n"
    'token-usage.md'          = "# Token usage`n`nRecord provider-reported token counts only. Otherwise write: Unknown.`n"
    'pr-review-audit.md'      = "# PR review rule audit`n`nApplicable rules: PENDING`nEvidence: PENDING`nStatus: PENDING`n"
}
foreach ($name in $working.Keys) {
    $p = Join-Path $work $name
    if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { Write-SDDText $p $working[$name]; $created += (Get-SDDRelativePath $repo $p) }
}

$receipt = Get-SDDArtifactReceipt -Repository $repo -Feature $Feature -PbiId $PbiId
$summary['artifacts'] = $receipt
$summary['specAbsolute'] = $specPath; $summary['planAbsolute'] = $planPath
if (-not $receipt.persisted) { $summary['status'] = 'ArtifactPersistenceFailed'; $summary['message'] = $receipt.problems -join '; '; Complete 8 $summary }
Write-SDDText (Join-Path $work 'artifact-receipt.json') (($receipt | ConvertTo-Json -Depth 8) + "`n")
$summary['installation'] = Get-SDDInstallationHealth $repo

# ---------------------------------------------------------------- 7. state (merged, never reset)
$statePath = Join-Path $work 'sdd-state.json'
$stateExisted = Test-Path -LiteralPath $statePath -PathType Leaf
$state = if ($stateExisted) { Read-SDDState $statePath } else { [ordered]@{} }
$updates = [ordered]@{
    version = (Get-SDDVersion); pbiId = $PbiId; title = $Title; pbiTitle = $pbiTitle; feature = $Feature; role = $role.Role; skill = $role.Skill
    source = $found.Selected; sourceKind = $found.Kind
    sourceHash = $(if ($found.Selected) { Get-SDDContentHash (Join-Path $repo $found.Selected) } else { $null })
    spec = $summary['spec']; plan = $summary['plan']; workFolder = $summary['workFolder']
}
if ($inv) {
    $updates['inputPackage'] = $inv.packageRoot; $updates['inputFingerprint'] = $inv.fingerprint
    $updates['inventory'] = $summary['inventory']; $updates['pbiApproved'] = $inv.primaryApproval.approved
}
foreach ($k in $updates.Keys) { $state[$k] = $updates[$k] }
# Documents created by v2.4 keep the v2.4 rules; documents created now follow the v2.5 template.
if (-not $state.Contains('templateVersion') -or -not $state['templateVersion']) {
    $state['templateVersion'] = if ($createdSpec) { Get-SDDVersion } else { '2.4.0' }
}
if (-not $state.Contains('stage')) { $state['stage'] = 'None' }
if ($found.Status -eq 'RefinementRequired') { $state['refinementRequired'] = $true }
elseif ($state.Contains('refinementRequired')) { $state['refinementRequired'] = $false }
if ($state.Contains('sourceHashAtApproval') -and $state['sourceHashAtApproval'] -and $state['sourceHashAtApproval'] -ne $state['sourceHash']) {
    $state['sourceChangedSinceApproval'] = $true
}
$init = if ($reconcile.Count) { 'BLOCKED' } else { 'PASS' }
$previousStage = [string]$state['stage']
Add-SDDStageRecord $state 'Initialized' $init ($(if ($reconcile.Count) { "Existing files belong to another PBI: $($reconcile -join ', ')" } else { 'Initial documents present.' + $(if ($inv) { " Input package $($inv.summary.files) files, $($inv.summary.discrepancies) discrepancies, fingerprint $($inv.fingerprint.Substring(0, 12))." } else { '' }) }))
# Re-running Start Development must never move a PBI back to an earlier stage.
if ($previousStage -and $previousStage -ne 'None') { $state['stage'] = $previousStage }
Save-SDDState $statePath $state

$summary['templateVersion'] = $state['templateVersion']
$summary['stage'] = $state['stage']
$summary['created'] = $created
if ($reconcile.Count) {
    $summary['status'] = 'ReconcileExistingSpec'
    $summary['message'] = "$($reconcile -join ', ') already describe another PBI. Nothing was overwritten. Reconcile: extend that spec with a section for PBI $PbiId, or choose another -Feature."
    $summary['next'] = 'Inspect the existing spec, then rerun with -Feature <OtherName> or extend it deliberately.'
    Complete 0 $summary
}
if ($found.Status -eq 'RefinementRequired') {
    $summary['status'] = 'RefinementRequired'
    $summary['message'] = $found.Reason
    $summary['next'] = "Run the refinement phases (inventory + clarify) and write docs/sdd/pbi-input/$PbiId/REFINED-PBI.md with 'Status: Draft'. Do not treat it as approved."
    Complete 0 $summary
}
$summary['status'] = if ($stateExisted -or $found.Status -eq 'ResumeExisting') { 'Resumed' } else { 'Initialized' }
if ($inv -and -not $inv.primaryApproval.approved) { $summary['message'] = "The refined PBI is not business-approved ($($inv.primaryApproval.summary)). Analysis may continue; implementation approval must acknowledge it (PX-APPROVAL)." }
if (@($summary['inputEdited'] | Where-Object { $_ }).Count) {
    $summary['status'] = 'InputEdited'
    $summary['message'] = "PBI input files were changed after import: $(@($summary['inputEdited']) -join '; '). Inputs are evidence and must not be edited. The gates fail until the originals are restored."
    $summary['next'] = 'Run tools/Get-SDDStatus.ps1 -Fix to restore the originals (the edited versions are kept under .previous/), then rerun Start Development.'
    Complete 0 $summary
}
$summary['next'] = "$(if ($inv) { "Read $($summary['inventory']) and every listed input file, " } else { '' })Analyse the repository, replace every PENDING in spec.md and plan.md (sources table and discrepancy IDs included), then run tools/Assert-SDDArtifacts.ps1 -Repository . -Feature $Feature -Stage AnalysisComplete."
Complete 0 $summary
