﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Repository,
    [Parameter(Mandatory = $true)][string]$Feature,
    [string]$PbiId,
    [string]$Build,
    [string]$Test,
    [ValidateSet('Targeted','Final')][string]$Scope = 'Final',
    [string[]]$ChangedFiles,
    [ValidateSet('build','test','regression','lint')][string]$NotExecutedKind,
    [string]$NotExecutedReason,
    [ValidateRange(1,1440)][int]$TimeoutMinutes = 30,
    [ValidateRange(0,86400)][int]$TimeoutSeconds = 0,
    [ValidateRange(0,2)][int]$MaxRetries = 0,
    # Retry only a diagnosed transient exit (75 by convention), never an implementation failure.
    [int[]]$TransientExitCodes = @(75),
    [switch]$Force
)
# Akzo SDD Builder v2.5.3 - real execution and current-source evidence; no printed-command PASS.
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$repo = Resolve-SDDRepositoryRoot $Repository
$stateFiles = @(Find-SDDStateFile -Repository $repo -Feature $Feature -PbiId $PbiId)
if ($stateFiles.Count -ne 1) { throw 'A unique feature state is required. Pass -PbiId.' }
$work = Split-Path -Parent $stateFiles[0]
$state = Read-SDDState $stateFiles[0]
$logDir = Join-Path $work 'verification-logs'
$verFile = Join-Path $work 'verification.json'
$source = Get-SDDSourceFingerprint $repo
$checks = New-Object 'System.Collections.Generic.List[object]'
$plan = $null
$prior = if (Test-Path -LiteralPath $verFile) { Read-SDDText $verFile | ConvertFrom-Json } else { $null }
function Save-Checks {
    $doc = [ordered]@{ pbiId = $state['pbiId']; feature = $Feature; tool = "Invoke-SDDVerification.ps1 v$(Get-SDDVersion)"; updatedAtUtc = [DateTime]::UtcNow.ToString('o'); sourceFingerprint = $source.sha256; sourceFiles = $source.files; scope = $Scope; fullRegression = ($Scope -eq 'Final'); checks = @($checks.ToArray()) }
    # Atomic replacement; interruption leaves either the previous checkpoint or a complete new record.
    $temp = $verFile + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    Write-SDDText $temp (($doc | ConvertTo-Json -Depth 10) + "`n")
    Move-Item -LiteralPath $temp -Destination $verFile -Force
}
if ($NotExecutedKind) {
    if (-not $NotExecutedReason) { throw '-NotExecutedReason is required.' }
    if ($prior) { foreach ($c in $prior.checks) { if ($c.kind -ne $NotExecutedKind) { $checks.Add($c) } } }
    $checks.Add([pscustomobject]@{ kind = $NotExecutedKind; name = $NotExecutedKind; executed = $false; reason = $NotExecutedReason; exitCode = $null; sourceFingerprint = $source.sha256 })
    Save-Checks
    Write-Host "Recorded $NotExecutedKind as NOT EXECUTED: $NotExecutedReason"
    exit 0
}
# Do not execute commands for a feature that has lost its scope approval.
& (Join-Path $PSScriptRoot 'Assert-SDDArtifacts.ps1') -Repository $repo -Feature $Feature -PbiId $state['pbiId'] -Stage ImplementationApproved -NoStateUpdate | Out-Host
if ($LASTEXITCODE -ne 0) { throw 'ImplementationApproved gate failed; no verification commands executed.' }
$approved = Read-SDDText (Join-Path $work 'approval.json') | ConvertFrom-Json
$guard = @(Get-SDDSolutionChanges -Repository $repo -PlanPath (Join-Path (Join-Path (Get-SDDSpecRoot $repo) $Feature) 'plan.md') -BaseRef $approved.gitHead)
if ($guard.Count) { throw (($guard | ForEach-Object { "$($_.reason): $($_.path). Review: $($_.restoreCommand)" }) -join "`n") }
$defaultTests = $false
$runId = [guid]::NewGuid().ToString('N')
$trxDir = Join-Path $logDir "trx-$runId"
function Quote-Argument([string]$s) {
    if ($env:OS -eq 'Windows_NT') { if ($s -match '["%\r\n]') { throw 'Unsupported shell metacharacter in target path.' }; return '"' + $s + '"' }
    return "'" + $s.Replace("'", "'" + [char]34 + "'" + [char]34 + "'") + "'"
}
if (-not $Build -or -not $Test) {
    $cfgPath = Join-Path $repo '.sdd-builder/verification-config.json'
    $cfg = if (Test-Path -LiteralPath $cfgPath) { Read-SDDText $cfgPath | ConvertFrom-Json } else { $null }
    if ($cfg) { if (-not $Build) { $Build = $cfg.build }; if (-not $Test) { $Test = $cfg.test } }
    if (-not $Build -or -not $Test) {
        if (Test-Path -LiteralPath (Join-Path $repo 'angular.json')) {
            $pkg = Read-SDDText (Join-Path $repo 'package.json') | ConvertFrom-Json
            if (-not $Build -and $pkg.scripts.PSObject.Properties['build']) { $Build = 'npm run build' }
            if (-not $Test -and $pkg.scripts.PSObject.Properties['test:ci']) { $Test = 'npm run test:ci' }
            if (-not $Build -or -not $Test) { throw 'Confirm noninteractive npm build/test commands in .sdd-builder/verification-config.json.' }
        } else {
            $plan = Get-SDDVerificationPlan -Repository $repo -ChangedFiles $ChangedFiles -Scope $Scope
            if (@($plan.map.projects | Where-Object { -not $_.sdkStyle }).Count) { throw 'Classic MSBuild projects require confirmed build/test commands in .sdd-builder/verification-config.json. No SDK assumptions made.' }
            if (-not $Build) {
                if (-not @($plan.buildTargets).Count) { throw 'No build target found; supply the confirmed -Build command.' }
                $Build = (@($plan.buildTargets | ForEach-Object { 'dotnet build ' + (Quote-Argument $_) + ' --nologo' })) -join ' && '
            }
            if (-not $Test) {
                if (-not @($plan.testTargets).Count) { throw 'No test projects found; supply a meaningful -Test command.' }
                $defaultTests = $true
                $Test = (@($plan.testTargets | ForEach-Object { 'dotnet test ' + (Quote-Argument $_) + ' --no-restore --nologo --logger trx --results-directory ' + (Quote-Argument $trxDir) })) -join ' && '
            }
        }
    }
}
# Stable identity excludes unique result-directory names; it includes selected targets and commands.
$commandIdentity = ($Build + "`n" + $Test).Replace($trxDir, '<current-trx-results>')
$commandHash = Get-SDDTextSha256 $commandIdentity
if (-not $Force -and $prior -and $prior.sourceFingerprint -eq $source.sha256 -and $prior.scope -eq $Scope) {
    $valid = @($prior.checks).Count -eq 2
    foreach ($c in $prior.checks) {
        $log = if ($c.logFile) { Join-Path $repo $c.logFile } else { '' }
        if (-not $c.executed -or $null -eq $c.exitCode -or $c.exitCode -ne 0 -or $c.sourceFingerprint -ne $source.sha256 -or $c.commandSetHash -ne $commandHash -or -not $log -or -not (Test-Path -LiteralPath $log) -or (Get-SDDContentHash $log) -ne $c.logSha256) { $valid = $false }
    }
    if ($valid) { foreach ($c in $prior.checks) { if (-not (Get-SDDCommandOutcome -Kind $c.kind -Output (Read-SDDText (Join-Path $repo $c.logFile))).valid) { $valid = $false } } }
    if ($valid) { Write-Host 'REUSED: matching successful commands, source/configuration fingerprint and log hashes; no duplicate build/test.'; exit 0 }
}
[void][IO.Directory]::CreateDirectory($logDir)
$deadline = if ($TimeoutSeconds -gt 0) { $TimeoutSeconds } else { $TimeoutMinutes * 60 }
foreach ($pair in @(@('build',$Build), @('test',$Test))) {
    $kind = $pair[0]; $cmd = $pair[1]
    if ($kind -eq 'test' -and -not @($checks | Where-Object { $_.kind -eq 'build' -and $_.executed -and $null -ne $_.exitCode -and $_.exitCode -eq 0 }).Count) {
        $checks.Add([pscustomobject]@{ kind = 'test'; name = 'test'; executed = $false; exitCode = $null; reason = 'Current build did not succeed; previous binaries must not be tested'; sourceFingerprint = $source.sha256 })
        Save-Checks; break
    }
    $entry = [pscustomobject][ordered]@{ kind = $kind; name = $kind; command = $cmd; commandSetHash = $commandHash; executed = $false; exitCode = $null; reason = 'INTERRUPTED or NOT EXECUTED: no completed process evidence yet'; classification = 'TerminalCancellation'; sourceFingerprint = $source.sha256; attempts = @(); logFile = $null; logSha256 = $null; testCount = $null }
    $checks.Add($entry); Save-Checks
    $exeMatch = [regex]::Match($cmd, '^\s*(?:"([^"]+)"|''([^'']+)''|(\S+))')
    $exe = @($exeMatch.Groups[1].Value,$exeMatch.Groups[2].Value,$exeMatch.Groups[3].Value | Where-Object { $_ })[0]
    if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) { $entry.reason = "'$exe' is not available on this machine"; $entry.classification = 'EnvironmentProblem'; Save-Checks; continue }
    for ($attempt = 0; $attempt -le $MaxRetries; $attempt++) {
        $log = Join-Path $logDir "$kind-$runId-$attempt.log"
        $psi = New-Object Diagnostics.ProcessStartInfo
        if ($env:OS -eq 'Windows_NT') { $psi.FileName = 'cmd.exe'; $psi.Arguments = "/d /s /c `"$cmd`"" }
        else { $psi.FileName = '/bin/sh'; $psi.ArgumentList.Add('-c'); $psi.ArgumentList.Add($cmd) }
        $psi.WorkingDirectory = $repo; $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
        $proc = $null; $exit = -2; $out = ''; $err = ''; $note = ''; $class = 'TerminalCancellation'
        $sw = [Diagnostics.Stopwatch]::StartNew()
        try {
            Write-Host "RUN $kind attempt $($attempt + 1): $cmd"
            $proc = [Diagnostics.Process]::Start($psi)
            $entry.executed = $true
            $outTask = $proc.StandardOutput.ReadToEndAsync(); $errTask = $proc.StandardError.ReadToEndAsync()
            if (-not $proc.WaitForExit($deadline * 1000)) {
                if ($PSVersionTable.PSVersion.Major -ge 7) { $proc.Kill($true) } elseif ($env:OS -eq 'Windows_NT') { & taskkill.exe /PID $proc.Id /T /F | Out-Null } else { $proc.Kill() }
                $exit = -1; $note = "Timed out after $deadline seconds"; $class = 'TestInfrastructureFailure'
                [void]$proc.WaitForExit(5000)
            } else { $proc.WaitForExit(); $exit = $proc.ExitCode; $class = if ($exit -eq 0) { 'Success' } elseif ($TransientExitCodes -contains $exit) { 'EnvironmentProblem' } else { 'ImplementationDefect' } }
            if ($outTask.Wait(5000)) { $out = $outTask.Result } else { $note += '; stdout did not close'; $exit = -1 }
            if ($errTask.Wait(5000)) { $err = $errTask.Result } else { $note += '; stderr did not close'; $exit = -1 }
        } catch { $note = $_.Exception.Message; $class = 'EnvironmentProblem' }
        finally {
            if ($proc) { if (-not $proc.HasExited) { if ($PSVersionTable.PSVersion.Major -ge 7) { $proc.Kill($true) } else { $proc.Kill() } }; $proc.Dispose() }
            $sw.Stop()
            $outcome = Get-SDDCommandOutcome -Kind $kind -Output ($out + "`n" + $err)
            if ($kind -eq 'test') { $entry.testCount = $outcome.testCount }
            if ($exit -eq 0 -and -not $outcome.valid) { $exit = 1; $note = $outcome.issues -join '; '; $class = 'TestInfrastructureFailure' }
            Write-SDDText $log ("# command: $cmd`n# cwd: $repo`n# stdout`n$out`n# stderr`n$err`n# exit code: $exit $note`n")
            $entry.exitCode = $exit; $entry.reason = $note; $entry.classification = $class
            $entry.logFile = Get-SDDRelativePath $repo $log; $entry.logSha256 = Get-SDDContentHash $log
            $entry.attempts += [pscustomobject]@{ number = $attempt + 1; exitCode = $exit; elapsedSeconds = [Math]::Round($sw.Elapsed.TotalSeconds,3); logFile = $entry.logFile; logSha256 = $entry.logSha256; classification = $class }
            Save-Checks
        }
        if ($exit -eq 0 -or $TransientExitCodes -notcontains $exit) { break }
        Write-Host "Transient exit $exit; retry budget remaining: $($MaxRetries - $attempt)"
    }
    if ($kind -eq 'test' -and $defaultTests -and $entry.exitCode -eq 0) {
        $total = 0; $failed = 0
        foreach ($trx in @(Get-ChildItem -LiteralPath $trxDir -Filter '*.trx' -Recurse -ErrorAction SilentlyContinue)) {
            [xml]$result = Read-SDDText $trx.FullName
            foreach ($counter in $result.SelectNodes('//*[local-name()="Counters"]')) { $total += [int]$counter.executed; $failed += [int]$counter.failed }
        }
        $entry.testCount = $total
        if ($total -eq 0 -or $failed -gt 0) { $entry.exitCode = 1; $entry.reason = "TRX result validation failed: executed $total, failed $failed"; $entry.classification = 'TestInfrastructureFailure' }
        Save-Checks
    }
    if ($entry.exitCode -ne 0 -and $kind -eq 'build') {
        $checks.Add([pscustomobject]@{ kind = 'test'; name = 'test'; executed = $false; exitCode = $null; reason = 'Build failed; tests not run'; sourceFingerprint = $source.sha256 })
        Save-Checks; break
    }
}
$after = Get-SDDSourceFingerprint $repo
if ($source.sha256 -ne $after.sha256) { Write-Host 'Source/configuration changed during verification. Evidence remains bound to the starting fingerprint; rerun required.'; exit 1 }
Save-Checks
if (@($checks | Where-Object { -not $_.executed -or $_.exitCode -ne 0 }).Count) { exit 1 }
Write-Host "Verification completed ($Scope), source $($source.sha256)."
exit 0
