﻿[CmdletBinding()]
param([string]$Repository = (Get-Location).Path, [ValidatePattern('^\d{4,8}$')][string]$DependencyPbiId, [string[]]$Symbols, [ValidatePattern('^[A-Za-z0-9][A-Za-z0-9._/-]*$')][string]$IntegrationRef = 'origin/develop', [switch]$Json)
# Read-only evidence collection. A historical commit match is not proof a dependency is merged/current.
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$context = Get-SDDRepositoryContext $Repository
$results = @()
foreach ($item in $context.repositories) {
    $repo = $item.path; $matches = @(); $history = @(); $refPresent = $false
    $files = @(Get-SDDFiles -Root $repo -Include @('*.cs','*.graphql','dab-config*.json','*.graphqlrc.json') -MaxDepth 12)
    $selected = @($files | Select-Object -First 3500)
    foreach ($file in $selected) {
        if ((Get-Item -LiteralPath $file).Length -gt 2MB) { continue }
        $lines = (Read-SDDText $file) -split "`n"
        for ($i = 0; $i -lt $lines.Count; $i++) {
            foreach ($symbol in $Symbols) {
                if ($symbol -and $lines[$i].IndexOf($symbol,[StringComparison]::OrdinalIgnoreCase) -ge 0 -and $matches.Count -lt 100) { $matches += [pscustomobject]@{ path = Get-SDDRelativePath $repo $file; line = $i + 1; symbol = $symbol; text = $lines[$i].Trim() } }
            }
        }
    }
    if (Get-Command git -ErrorAction SilentlyContinue) {
        $null = & git -C $repo rev-parse --verify --end-of-options "$IntegrationRef^{commit}" 2>$null
        $refPresent = $LASTEXITCODE -eq 0
        if ($DependencyPbiId -and $refPresent) { $history = @(& git -C $repo log -20 --format='%h %s' "--grep=$DependencyPbiId" --fixed-strings $IntegrationRef -- 2>$null) }
    }
    $results += [pscustomobject]@{ repository = $repo; role = $item.role; purpose = $item.purpose; filesScanned = $selected.Count; searchLimited = ($files.Count -gt 3500 -or $matches.Count -ge 100); matches = $matches; integrationRef = $IntegrationRef; integrationRefAvailable = $refPresent; dependencyHistory = $history; historyMeaning = 'Local remote-tracking snapshot; a matching message alone is not merge or current-code proof.' }
}
$report = [pscustomobject]@{ primaryRepository = $context.repository; specRoot = $context.specRoot; dependencyPbiId = $DependencyPbiId; results = $results; next = 'Inspect actual matched contracts and current implementation. Missing local schema is a dependency gap, not permission to invent a mutation. Keep active PBI and approved scope unchanged.' }
if ($Json) { $report | ConvertTo-Json -Depth 10 } else { $report }
