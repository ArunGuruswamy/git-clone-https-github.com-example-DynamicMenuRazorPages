﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Repository,
    # Exported PR comments: .csv or .md. Defaults to every file in docs/sdd/review-lessons/inbox/.
    [string[]]$Path
)
# Akzo SDD Builder v2.5.3 - normalises REAL exported PR review comments into a rule register.
# It never invents comments: every register row is traceable to an exported comment (PR reference + file).
# New rows are 'Candidate'; only a developer changes ApprovalStatus to 'Approved'.
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$repo = Resolve-SDDRepositoryRoot $Repository
$lessons = Join-Path $repo 'docs/sdd/review-lessons'
$register = Join-Path $lessons 'register.csv'
if (-not $Path) {
    $inbox = Join-Path $lessons 'inbox'
    $Path = @(Get-ChildItem -LiteralPath $inbox -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in @('.csv', '.md') -and $_.Name -ne 'README.md' } | ForEach-Object { $_.FullName })
}
if (-not $Path -or $Path.Count -eq 0) { throw 'No exported PR comments found. Put the export (.csv or .md) in docs/sdd/review-lessons/inbox/. The export script alone is not the data.' }

function Get-Field($row, [string[]]$names) {
    foreach ($n in $names) { foreach ($p in $row.PSObject.Properties) { if ($p.Name -ieq $n -and "$($p.Value)".Trim()) { return "$($p.Value)".Trim() } } }
    return ''
}
function Get-Normalized([string]$t) { return (($t.ToLowerInvariant() -replace '`[^`]*`', ' code ' -replace '[^a-z0-9 ]', ' ' -replace '\s+', ' ').Trim()) }
function Get-Applicability([string]$file) {
    if ($file -match '(?i)\.(ts|html|scss)$' -or $file -match '(?i)projects/') { return 'UI' }
    if ($file -match '(?i)ColorDMS') { return 'CDMS' }
    if ($file -match '(?i)\.graphql$|Formula') { return 'DAB' }
    if ($file -match '(?i)\.cs$') { return 'Backend' }
    return 'All'
}

$comments = New-Object System.Collections.Generic.List[object]
foreach ($file in $Path) {
    $full = Resolve-SDDFullPath $file
    if ([IO.Path]::GetExtension($full) -ieq '.csv') {
        foreach ($row in (Import-Csv -LiteralPath $full)) {
            $text = Get-Field $row @('Comment', 'Content', 'Body', 'Text', 'ReviewerComment', 'Reviewer Comment')
            if (-not $text) { continue }
            $comments.Add([pscustomobject]@{
                    Pr = Get-Field $row @('PR', 'PullRequestId', 'Pull Request', 'PRId', 'PR ID', 'PullRequest')
                    File = Get-Field $row @('File', 'FilePath', 'Path', 'Changed File', 'ThreadFile')
                    Line = Get-Field $row @('Line', 'LineNumber', 'Line Number')
                    Reviewer = Get-Field $row @('Reviewer', 'Author', 'CommentedBy', 'Commented By')
                    Comment = $text
                    Disposition = Get-Field $row @('Status', 'Disposition', 'Resolution', 'ThreadStatus')
                    SourceFile = [IO.Path]::GetFileName($full)
                })
        }
    } else {
        # Markdown export: one block per comment, headed "## PR <id> - <file>:<line>" followed by the comment text.
        $text = Read-SDDText $full
        foreach ($m in [regex]::Matches($text, '(?ms)^#{2,3}\s*PR\s*#?(\d+)\s*[-:–—]?\s*([^\r\n:]*)(?::(\d+))?\s*\r?\n(.*?)(?=^#{2,3}\s*PR\s*#?\d+|\z)')) {
            $body = $m.Groups[4].Value.Trim()
            if (-not $body) { continue }
            $comments.Add([pscustomobject]@{ Pr = $m.Groups[1].Value; File = $m.Groups[2].Value.Trim(); Line = $m.Groups[3].Value; Reviewer = ''; Comment = $body; Disposition = ''; SourceFile = [IO.Path]::GetFileName($full) })
        }
    }
}
if ($comments.Count -eq 0) { throw "No comments could be read from: $($Path -join ', '). Expected CSV columns PR, File, Line, Comment (aliases accepted) or Markdown '## PR <id> - <file>:<line>' blocks." }

$rows = [ordered]@{}
if (Test-Path -LiteralPath $register -PathType Leaf) { foreach ($r in (Import-Csv -LiteralPath $register)) { $rows[$r.NormalizedKey] = $r } }
$added = 0; $merged = 0
foreach ($c in $comments) {
    $key = Get-Normalized $c.Comment
    if (-not $key) { continue }
    $ref = "PR $($c.Pr) $($c.File)$(if ($c.Line) { ':' + $c.Line })".Trim()
    if ($rows.Contains($key)) {
        $r = $rows[$key]
        if ($r.PullRequests -notmatch [regex]::Escape($ref)) { $r.PullRequests = "$($r.PullRequests); $ref"; $r.Occurrences = [string]([int]$r.Occurrences + 1); $merged++ }
        continue
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    $id = 'RR-' + (($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($key)) | Select-Object -First 3 | ForEach-Object { $_.ToString('x2') }) -join '').ToUpperInvariant()
    $sha.Dispose()
    $rows[$key] = [pscustomobject][ordered]@{
        RuleId = $id; PullRequests = $ref; File = $c.File; Line = $c.Line; ReviewerConcern = ($c.Comment -replace '\s+', ' ')
        RootCause = 'TO CLASSIFY'; RecommendedCorrection = 'TO CLASSIFY'; Applicability = (Get-Applicability $c.File)
        Severity = 'UNCLASSIFIED'; PreventionCheck = 'TO DEFINE'; ApprovalStatus = 'Candidate'; Occurrences = '1'
        Reviewer = $c.Reviewer; Disposition = $c.Disposition; SourceExport = $c.SourceFile; NormalizedKey = $key
    }
    $added++
}
if (-not (Test-Path -LiteralPath $lessons)) { [void](New-Item -ItemType Directory -Path $lessons -Force) }
$rows.Values | Export-Csv -LiteralPath $register -NoTypeInformation -Encoding UTF8
Write-Host "Review register: $added new candidate rule(s), $merged duplicate occurrence(s) merged, $($rows.Count) total." -ForegroundColor Green
Write-Host "Register: $(Get-SDDRelativePath $repo $register). Classify RootCause/Severity/PreventionCheck and set ApprovalStatus=Approved only after review." -ForegroundColor Cyan
