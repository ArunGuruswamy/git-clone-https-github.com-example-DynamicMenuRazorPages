﻿# Startup, installation and observable execution checks shared by all SDD commands.
function Resolve-SDDRepositoryRoot([Parameter(Mandatory)][string]$Repository) {
    $path = Resolve-SDDFullPath $Repository
    if (Test-Path -LiteralPath $path -PathType Leaf) { $path = Split-Path -Parent $path }
    if (-not (Test-Path -LiteralPath $path -PathType Container)) { throw "Repository path not found: $Repository" }
    if (Get-Command git -ErrorAction SilentlyContinue) {
        $root = (& git -C $path rev-parse --show-toplevel 2>$null | Out-String).Trim()
        if ($LASTEXITCODE -eq 0 -and $root) { return Resolve-SDDFullPath $root }
    }
    # Folder workspaces without Git: walk ancestors, never sibling application roots.
    $cursor = $path
    for ($n = 0; $n -lt 12 -and $cursor; $n++) {
        if ((Test-Path -LiteralPath (Join-Path $cursor '.github/sdd/workflow.md')) -or
            (Test-Path -LiteralPath (Join-Path $cursor 'src/AN.ColorAppsAzure.Formula')) -or
            (Test-Path -LiteralPath (Join-Path $cursor 'angular.json')) -or
            (Test-Path -LiteralPath (Join-Path $cursor 'AN.ColorAppsAzure.BL.sln'))) { return $cursor }
        $parent = Split-Path -Parent $cursor
        if ($parent -eq $cursor) { break }; $cursor = $parent
    }
    return $path
}

function Get-SDDArtifactReceipt([string]$Repository, [string]$Feature, [string]$PbiId) {
    if (-not (Test-SDDFeatureName $Feature)) { throw 'A valid feature name is required for an artifact receipt.' }
    $repo = Resolve-SDDRepositoryRoot $Repository
    $folder = Join-Path (Get-SDDSpecRoot $repo) $Feature
    $files = @(); $problems = @()
    foreach ($name in @('spec.md','plan.md')) {
        $path = Join-Path $folder $name
        $exists = Test-Path -LiteralPath $path -PathType Leaf
        $text = if ($exists) { Read-SDDText $path } else { '' }
        $ids = @(Get-SDDDeclaredPbiIds $text)
        if (-not $exists -or -not $text.Trim()) { $problems += "Missing or empty artifact: $path" }
        elseif ($PbiId -and ($ids -notcontains $PbiId -or @($ids | Where-Object { $_ -ne $PbiId }).Count)) { $problems += "Artifact identity does not match PBI $PbiId : $path" }
        $files += [pscustomobject][ordered]@{ name = $name; path = $path; relativePath = Get-SDDRelativePath $repo $path; exists = [bool]$exists; bytes = $(if ($exists) { (Get-Item -LiteralPath $path).Length } else { 0 }); sha256 = $(if ($exists) { Get-SDDContentHash $path } else { $null }) }
    }
    return [pscustomobject][ordered]@{ repository = $repo; pbiId = $PbiId; feature = $Feature; folder = $folder; persisted = ($problems.Count -eq 0); files = $files; problems = $problems; meaning = 'Disk persistence only; analysis and approval gates remain separate.' }
}

function Get-SDDInstallationHealth([string]$Repository) {
    $repo = Resolve-SDDRepositoryRoot $Repository
    $manifest = Join-Path $repo '.sdd-builder/manifest.json'
    $problems = @(); $checked = 0
    if (-not (Test-Path -LiteralPath $manifest)) { return [pscustomobject]@{ status = 'UNVERIFIED'; ready = $false; problems = @('No installed runtime manifest.'); checkedFiles = 0 } }
    $doc = Read-SDDText $manifest | ConvertFrom-Json
    if (-not $doc.PSObject.Properties['runtimeFiles'] -or -not @($doc.runtimeFiles).Count) { $problems += 'Old installer manifest has no expected runtime hashes; install the current package.' }
    else {
        foreach ($f in $doc.runtimeFiles) {
            if ($f.path -notmatch '^(tools/|\.github/(agents/|instructions/|sdd/(workflow|constitution)\.md))' -or $f.path -match '(^|[\\/])\.\.([\\/]|$)') { $problems += 'Unsafe runtime manifest path.'; continue }
            $path = Join-Path $repo $f.path; $checked++
            if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { $problems += "Missing runtime file: $($f.path)" }
            elseif ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $f.expectedSha256) { $problems += "Runtime file differs from installed release: $($f.path)" }
        }
    }
    return [pscustomobject]@{ status = $(if ($problems.Count) { 'INCOMPLETE' } else { 'READY' }); ready = ($problems.Count -eq 0); version = $doc.currentVersion; checkedFiles = $checked; problems = $problems }
}

function Get-SDDCommandOutcome([string]$Kind, [string]$Output) {
    $issues = @(); $count = $null; $failed = $null
    if ($Output -match '(?i)(continu(?:e|ing)|us(?:e|ing)|run(?:ning)?)\s+(?:with\s+|the\s+)*(?:last|previous)\s+successful\s+build') { $issues += 'Runner used a previous successful build; current source was not verified.' }
    if ($Output -match '(?im)\berror\s+(?:CS|MSB|NETSDK|NU)\d+\b|^\s*Build FAILED\.') { $issues += 'Compiler/build errors were reported even though the process may have returned zero.' }
    if ($Kind -eq 'test') {
        if ($Output -match '(?im)^\s*Test Run Failed\.') { $issues += 'Test runner reported a failed run.' }
        if ($Output -match '(?i)No tests? (?:matches|is available|are available|were found)') { $count = 0 }
        $m = [regex]::Match($Output,'(?i)\bRan\s+(\d+)\s+test(?:\(s\)|s)?')
        if (-not $m.Success) { $m = [regex]::Match($Output,'(?i)\bTotal(?: tests)?\s*:\s*(\d+)') }
        if (-not $m.Success) { $m = [regex]::Match($Output,'(?i)\b(\d+)\s+assertions?\s+passed\b') }
        if ($m.Success) { $count = [int]$m.Groups[1].Value }
        $failures = @([regex]::Matches($Output,'(?i)\bFailed\s*:\s*(\d+)|\b(\d+)\s+Failed\b') | ForEach-Object { if ($_.Groups[1].Success) { [int]$_.Groups[1].Value } else { [int]$_.Groups[2].Value } })
        if ($failures.Count) { $failed = ($failures | Measure-Object -Maximum).Maximum }
        if ($null -ne $count -and $count -eq 0) { $issues += 'Zero tests executed. Discover actual test names/project and rerun a matching selection.' }
        if ($null -ne $failed -and $failed -gt 0) { $issues += "$failed failing tests reported. Inspect failures and fix in-scope defects." }
    }
    return [pscustomobject]@{ valid = ($issues.Count -eq 0); issues = $issues; testCount = $count; failedCount = $failed }
}

function Get-SDDRepositoryContext([string]$Repository) {
    $repo = Resolve-SDDRepositoryRoot $Repository
    $paths = New-Object 'System.Collections.Generic.List[string]'; $paths.Add($repo)
    $config = Join-Path $repo '.github/sdd/config.md'
    if (Test-Path -LiteralPath $config) {
        foreach ($m in [regex]::Matches((Read-SDDText $config),'(?m)^\|\s*`?(?:DAB|CDMS|UI|LEGACY)_REPO`?\s*\|\s*`?([^`|\r\n]+)')) {
            $p = $m.Groups[1].Value.Trim()
            if (-not [IO.Path]::IsPathRooted($p)) { $p = Join-Path $repo $p }
            if (Test-Path -LiteralPath $p -PathType Container) { $p = Resolve-SDDRepositoryRoot $p; if (-not $paths.Contains($p)) { $paths.Add($p) } }
        }
    }
    $workspace = Join-Path $repo '.github/sdd/AkzoColorApps.code-workspace'
    if (Test-Path -LiteralPath $workspace) {
        $w = Read-SDDText $workspace | ConvertFrom-Json
        foreach ($f in @($w.folders)) {
            $p = [string]$f.path
            if (-not $p) { continue }
            if (-not [IO.Path]::IsPathRooted($p)) { $p = Join-Path (Split-Path -Parent $workspace) $p }
            if (Test-Path -LiteralPath $p -PathType Container) { $p = Resolve-SDDRepositoryRoot $p; if (-not $paths.Contains($p)) { $paths.Add($p) } }
        }
    }
    $parent = Split-Path -Parent $repo
    foreach ($d in @(Get-ChildItem -LiteralPath $parent -Directory -Filter 'AN.ColorAppsAzure*' -ErrorAction SilentlyContinue | Select-Object -First 12)) {
        if (-not ($d.Attributes -band [IO.FileAttributes]::ReparsePoint) -and ((Test-Path (Join-Path $d.FullName '.git')) -or (Test-Path (Join-Path $d.FullName 'angular.json'))) -and -not $paths.Contains($d.FullName)) { $paths.Add($d.FullName) }
    }
    $items = @($paths | ForEach-Object { $role = Get-SDDRepositoryRole $_; [pscustomobject]@{ path = $_; role = $role.Role; purpose = $(if ($_ -eq $repo) { 'Primary implementation repository' } else { 'Read-only reference; never switches active PBI or artifact root' }); evidence = $role.Evidence } })
    return [pscustomobject]@{ repository = $repo; specRoot = Get-SDDSpecRoot $repo; repositories = $items }
}
