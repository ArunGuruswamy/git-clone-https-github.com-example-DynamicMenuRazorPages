﻿[CmdletBinding()]
param(
    [string]$Repository = (Get-Location).Path,
    # When given, the report is also saved as capabilities.json in the PBI working folder.
    [string]$Feature,
    [switch]$Json
)
# Akzo SDD Builder v2.5.3 - environment capability preflight.
# If this script runs at all, the agent HAS a working terminal. The agent records the capabilities it could
# not test from a script (file edit tool, VS Test Explorer, MCP) in the 'agent' section of capabilities.json.
# MCP access is not terminal access, and Azure MCP is never needed for a local .NET build.
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$repo = Resolve-SDDRepositoryRoot $Repository

function Probe([string]$exe, [string[]]$versionArgs) {
    $cmd = Get-Command $exe -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $cmd) { return [ordered]@{ available = $false; advertised = $false; callable = $false; authorized = 'UNKNOWN'; executed = $false; succeeded = $false; exitCode = $null; path = $null; version = $null } }
    $v = $null; $code = $null; $executed = $false; $reason = ''
    try { $v = ((& $cmd.Source @versionArgs 2>&1) | Select-Object -First 1 | Out-String).Trim(); $code = $LASTEXITCODE; $executed = $true } catch { $reason = $_.Exception.Message }
    $success = $executed -and $code -eq 0
    return [ordered]@{ available = $success; advertised = $true; callable = $executed; authorized = $(if ($executed) { 'YES' } else { 'UNKNOWN' }); executed = $executed; succeeded = $success; exitCode = $code; path = $cmd.Source; version = $v; reason = $reason }

}

$isWin = ($env:OS -eq 'Windows_NT')
$policy = try { [string](Get-ExecutionPolicy) } catch { 'Unknown' }
$msbuild = Probe 'msbuild' @('-version')
if (-not $msbuild.available -and $isWin) {
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
    if (Test-Path -LiteralPath $vswhere) {
        $found = & $vswhere -latest -requires Microsoft.Component.MSBuild -find 'MSBuild/**/Bin/MSBuild.exe' 2>$null | Select-Object -First 1
        if ($found) { $msbuild = [ordered]@{ available = $true; path = $found; version = 'via vswhere' } }
    }
}
$ci = @()
foreach ($pattern in @('azure-pipelines*.yml', '.azure-pipelines/*.yml', '.github/workflows/*.yml', 'pipelines/*.yml')) {
    $ci += @(Get-ChildItem -Path (Join-Path $repo $pattern) -File -ErrorAction SilentlyContinue | ForEach-Object { Get-SDDRelativePath $repo $_.FullName })
}
$role = Get-SDDRepositoryRole $repo
$report = [ordered]@{
    tool             = "Test-SDDCapabilities.ps1 v$(Get-SDDVersion)"
    checkedAtUtc     = [DateTime]::UtcNow.ToString('o')
    terminal         = [ordered]@{ available = $true; evidence = 'this script executed'; shell = $PSVersionTable.PSEdition; psVersion = $PSVersionTable.PSVersion.ToString(); executionPolicy = $policy }
    repository       = [ordered]@{ path = $repo; role = $role.Role; skill = $role.Skill; specRoot = (Get-SDDRelativePath $repo (Get-SDDSpecRoot $repo)) }
    tools            = [ordered]@{
        git     = Probe 'git' @('--version')
        dotnet  = Probe 'dotnet' @('--version')
        msbuild = $msbuild
        vstest  = Probe 'vstest.console' @('/?')
        node    = Probe 'node' @('--version')
        npm     = Probe 'npm' @('--version')
        # PBI attachments: PDF text extraction (DOCX/XLSX/PPTX need no external tool).
        pdftotext = Probe 'pdftotext' @('-v')
    }
    ciVerification   = [ordered]@{ available = ($ci.Count -gt 0); configured = ($ci.Count -gt 0); executed = $false; succeeded = $null; status = 'NOT EXECUTED'; files = $ci }
    agent            = [ordered]@{
        note           = 'Filled in by the agent: what its own tool list provides. Never inferred from this script.'
        searchFiles    = 'UNKNOWN'; readFiles = 'UNKNOWN'; writeFiles = 'UNKNOWN'; terminal = 'AVAILABLE (script ran)'
        testExplorer   = 'UNKNOWN'; diagnostics = 'UNKNOWN'; externalServices = 'UNKNOWN'; readImages = 'UNKNOWN'; readPdf = 'UNKNOWN'
    }
}
$buildTool = switch ($role.Role) { 'CDMS' { if ($report.tools.msbuild.available -or $report.tools.dotnet.available) { 'available' } else { 'missing' } } 'UI' { if ($report.tools.npm.available) { 'available' } else { 'missing' } } default { if ($report.tools.dotnet.available) { 'available' } else { 'missing' } } }
$report['buildCapability'] = if ($buildTool -eq 'available') { 'EXECUTABLE' } elseif ($report.ciVerification.available) { 'CI_ONLY' } else { 'NOT_EXECUTABLE' }

if ($Feature) {
    $stateFile = @(Find-SDDStateFile -Repository $repo -Feature $Feature)
    if ($stateFile.Count -eq 1) {
        $target = Join-Path (Split-Path -Parent $stateFile[0]) 'capabilities.json'
        if (Test-Path -LiteralPath $target -PathType Leaf) {
            # Keep what the agent already recorded about its own tools.
            $old = Read-SDDText $target | ConvertFrom-Json
            if ($old.agent) { $report['agent'] = $old.agent }
        }
        Write-SDDText $target (($report | ConvertTo-Json -Depth 6) + "`n")
    }
}
if ($Json) { $report | ConvertTo-Json -Depth 6 | Write-Output; exit 0 }
Write-Host "SDD capability preflight (v$(Get-SDDVersion))" -ForegroundColor Cyan
Write-Host ("  Terminal        : available ({0} {1}, execution policy {2})" -f $PSVersionTable.PSEdition, $PSVersionTable.PSVersion, $policy)
Write-Host ("  Repository role : {0} ({1})" -f $role.Role, $role.Skill)
foreach ($k in $report.tools.Keys) { $t = $report.tools[$k]; Write-Host ("  {0,-15} : {1}" -f $k, $(if ($t.available) { "available $($t.version)" } else { 'not found' })) }
Write-Host ("  CI verification : {0}" -f $(if ($ci.Count) { $ci -join ', ' } else { 'none found' }))
Write-Host ("  Build/test      : {0}" -f $report.buildCapability)
exit 0
