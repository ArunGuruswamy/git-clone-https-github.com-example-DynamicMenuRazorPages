﻿[CmdletBinding()]
param(
    [string]$Repository = (Get-Location).Path,
    [switch]$Json
)
# Akzo SDD Builder v2.5.3 - local commit gate (run by the pre-commit hook the installer sets up).
# Blocks a commit that stages application source while a PBI is in progress and its ImplementationVerified gate
# does not pass. Documents, tools, .github and docs are never blocked. It only reads; it never changes anything.
# Local advisory gate; independent CI and reviewed approval remain required.
# Exit codes: 0 allowed, 1 blocked.
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$repo = Resolve-SDDRepositoryRoot $Repository
$result = [ordered]@{ tool = "Assert-SDDCommit.ps1 v$(Get-SDDVersion)"; result = 'ALLOWED'; reason = ''; blocked = @(); staged = @() }
function Finish([int]$Code) {
    if ($Json) { $result | ConvertTo-Json -Depth 5 | Write-Output }
    elseif ($Code -ne 0) {
        Write-Host 'Akzo SDD commit gate: commit blocked.' -ForegroundColor Red
        foreach ($b in $result.blocked) { Write-Host "  PBI $($b.pbiId) ($($b.stage)): $($b.problem)" -ForegroundColor Red }
        Write-Host "  Staged application files: $((@($result.staged) | Select-Object -First 5) -join ', ')$(if (@($result.staged).Count -gt 5) { ', ...' })" -ForegroundColor Yellow
        Write-Host '  Finish the plan: approval, implementation, then tools/Invoke-SDDVerification.ps1 (ImplementationVerified).' -ForegroundColor Yellow
        Write-Host '  Details: tools/Get-SDDStatus.ps1. Resolve the reported evidence or approval issue before committing.' -ForegroundColor Yellow
    }
    exit $Code
}
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Finish 0 }
$switch = (& git -C $repo config --get sdd.commitGate 2>$null | Out-String).Trim()
if ($switch -match '^(?i)(false|off|0|no)$') { $result.reason = 'Disabled by git config sdd.commitGate.'; Finish 0 }
$active = @(Get-SDDActivePbis $repo)
if ($active.Count -eq 0) { $result.reason = 'No PBI in progress.'; Finish 0 }
$staged = @(& git -C $repo diff --cached --name-only --diff-filter=ACMRD 2>$null | Where-Object { $_ -and (Test-SDDApplicationPath $_) })
$result.staged = $staged
if ($staged.Count -eq 0) { $result.reason = 'No application source staged.'; Finish 0 }
$blocked = New-Object System.Collections.Generic.List[object]
foreach ($id in $active) {
    $feature = $null; $stage = 'None'
    $changes = Join-Path $repo 'docs/sdd/changes'
    $dirs = @()
    if (Test-Path -LiteralPath $changes) { $dirs = @([IO.Directory]::GetDirectories($changes, "$id-*") | Where-Object { Test-Path -LiteralPath (Join-Path $_ 'sdd-state.json') }) }
    if ($dirs.Count -ge 1) { $feature = ([IO.Path]::GetFileName($dirs[0])).Substring($id.Length + 1) }
    if (-not $feature) { $blocked.Add([pscustomobject]@{ pbiId = $id; stage = 'None'; problem = 'Start Development has not produced spec.md and plan.md for this PBI.' }); continue }
    $state = Find-SDDStateFile -Repository $repo -Feature $feature -PbiId $id | Select-Object -First 1
    if ($state) { $stage = [string](Read-SDDState $state)['stage'] }
    $raw = & (Join-Path $PSScriptRoot 'Assert-SDDArtifacts.ps1') -Repository $repo -Feature $feature -PbiId $id -Stage ImplementationVerified -Json -NoStateUpdate | Out-String
    $gate = $null
    try { $gate = $raw.Substring($raw.IndexOf('{')) | ConvertFrom-Json } catch { $gate = $null }
    if (-not $gate -or $gate.result -ne 'PASS') {
        $first = if ($gate) { (@($gate.problems) | Select-Object -First 2) -join ' | ' } else { 'The ImplementationVerified gate could not be evaluated.' }
        $blocked.Add([pscustomobject]@{ pbiId = $id; stage = $stage; problem = "ImplementationVerified gate does not pass. $first" })
    }
}
if ($blocked.Count) { $result.result = 'BLOCKED'; $result.blocked = $blocked.ToArray(); Finish 1 }
$result.reason = 'Every active PBI passes ImplementationVerified.'
Finish 0
