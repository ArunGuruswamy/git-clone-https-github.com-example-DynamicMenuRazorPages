﻿[CmdletBinding()]
param([string]$Repository = (Get-Location).Path, [switch]$Json)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$result = Get-SDDInstallationHealth $Repository
if ($Json) { $result | ConvertTo-Json -Depth 8 } else { Write-Host "SDD runtime: $($result.status)"; $result.problems | ForEach-Object { Write-Host $_ } }
if (-not $result.ready) { exit 3 }
exit 0
