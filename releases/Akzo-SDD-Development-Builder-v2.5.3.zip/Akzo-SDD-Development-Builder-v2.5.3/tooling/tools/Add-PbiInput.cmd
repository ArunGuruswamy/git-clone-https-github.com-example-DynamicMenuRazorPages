@echo off
setlocal EnableExtensions
rem Akzo SDD Builder v2.5.2 - drag the downloaded PBI ZIP (or a folder, or files) onto this file.
rem It creates docs\sdd\pbi-input\<PBI-ID>\ in this repository, copies the files without overwriting anything,
rem and keeps them out of Visual Studio / VS Code Git Changes (.git\info\exclude, local to this clone).
rem It never changes the PowerShell execution policy and never needs administrator rights.
if "%~1"=="" goto usage
set "SDD_TOOLS=%~dp0"
powershell.exe -NoLogo -NoProfile -File "%SDD_TOOLS%Add-SDDPbiInput.ps1" -Repository "%SDD_TOOLS%.." %*
set "RC=%ERRORLEVEL%"
if not "%RC%"=="4" goto done
echo.
set "SDD_PBI="
set /p "SDD_PBI=PBI ID (numbers only, Enter to cancel): "
if "%SDD_PBI%"=="" goto done
powershell.exe -NoLogo -NoProfile -File "%SDD_TOOLS%Add-SDDPbiInput.ps1" -Repository "%SDD_TOOLS%.." -PbiId %SDD_PBI% %*
set "RC=%ERRORLEVEL%"
:done
echo.
pause
exit /b %RC%

:usage
echo Drag the downloaded PBI ZIP, folder or files onto Add-PbiInput.cmd,
echo or run:  tools\Add-PbiInput.cmd "C:\Users\me\Downloads\2026-10-07-305183-complaint-imitation-request.zip"
echo Result:  docs\sdd\pbi-input\305183\  (local-only, not shown in Git Changes)
pause
exit /b 2
