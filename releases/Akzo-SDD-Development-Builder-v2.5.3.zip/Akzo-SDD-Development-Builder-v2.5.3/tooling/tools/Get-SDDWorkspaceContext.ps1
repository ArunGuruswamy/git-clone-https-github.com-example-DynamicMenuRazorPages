﻿[CmdletBinding()]
param([string]$Repository = (Get-Location).Path, [switch]$Json)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$context = Get-SDDRepositoryContext $Repository
if ($Json) { $context | ConvertTo-Json -Depth 8 } else { $context }
