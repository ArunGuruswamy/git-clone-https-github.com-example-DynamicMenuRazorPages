﻿# Shared execution, identity and evidence primitives. Loaded by SDD.Common.psm1.
function Get-SDDTextSha256([string]$Text) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text)))).Replace('-', '').ToLowerInvariant() } finally { $sha.Dispose() }
}

function Get-SDDExecutionMode([string]$Repository, [string]$ExplicitMode) {
    if ($ExplicitMode) { return $ExplicitMode.ToUpperInvariant() }
    $s = Get-SDDSettings $Repository
    if ($s -and $s.PSObject.Properties['executionMode'] -and $s.executionMode -in @('FAST','STANDARD','STEP')) { return ([string]$s.executionMode).ToUpperInvariant() }
    return 'FAST'
}

function Resolve-SDDPbiIdentity([string]$Repository, [string]$ExplicitId, [switch]$ConfirmPbiSelection) {
    $sources = [ordered]@{}
    if ($ExplicitId) { $sources['explicit'] = $ExplicitId }
    if (Get-Command git -ErrorAction SilentlyContinue) {
        $branch = (& git -C $Repository branch --show-current 2>$null | Out-String).Trim()
        if ($LASTEXITCODE -eq 0 -and $branch -match '(?i)^(?:feature|bugfix|fix|pbi)[/-](\d{4,8})(?:[-_/]|$)') { $sources['branch'] = $Matches[1] }
    }
    $settings = Get-SDDSettings $Repository
    if ($settings -and $settings.PSObject.Properties['activePbi'] -and $settings.activePbi) { $sources['persisted'] = [string]$settings.activePbi }
    $pinFile = Join-Path $Repository '.sdd-builder/active-pbi.json'
    if (-not $sources.Contains('persisted') -and (Test-Path -LiteralPath $pinFile)) { $sources['persisted'] = [string](Read-SDDText $pinFile | ConvertFrom-Json).pbiId }
    if (Test-Path -LiteralPath $pinFile) {
        $pin = Read-SDDText $pinFile | ConvertFrom-Json
        if ($pin.PSObject.Properties['conflictResolved'] -and $pin.conflictResolved -and $pin.branchIdentity -eq $sources['branch'] -and (-not $ExplicitId -or $ExplicitId -eq $pin.pbiId) -and (-not $sources.Contains('persisted') -or $sources['persisted'] -eq $pin.pbiId)) {
            return [pscustomobject]@{ status = 'Resolved'; pbiId = [string]$pin.pbiId; sources = $sources; message = 'Reusing the explicit conflict resolution for this branch.' }
        }
    }
    $ids = @($sources.Values | Select-Object -Unique)
    foreach ($id in $ids) { if ($id -notmatch '^\d{4,8}$') { throw "Invalid PBI identity: $id" } }
    if ($ids.Count -gt 1 -and -not ($ConfirmPbiSelection -and $ExplicitId)) {
        return [pscustomobject]@{ status = 'PbiConflict'; pbiId = $null; sources = $sources; message = "PBI sources conflict ($((@($sources.Keys | ForEach-Object { $_ + '=' + $sources[$_] })) -join ', ')). Which PBI should this session use? After the answer, pass its explicit ID with -ConfirmPbiSelection." }
    }
    $selected = if ($ExplicitId) { $ExplicitId } elseif ($sources.Contains('branch')) { $sources['branch'] } elseif ($sources.Contains('persisted')) { $sources['persisted'] } else { $null }
    return [pscustomobject]@{ status = 'Resolved'; pbiId = $selected; sources = $sources; message = '' }
}

function Get-SDDSourceFiles([string]$Repository) {
    $root = Resolve-SDDFullPath $Repository
    $queue = New-Object 'System.Collections.Generic.Queue[string]'
    $queue.Enqueue($root)
    $files = New-Object 'System.Collections.Generic.List[string]'
    $skip = @('.git','.vs','node_modules','bin','obj','packages','TestResults','dist','coverage','.sdd-installer-backups','.sdd-builder')
    while ($queue.Count) {
        $dir = $queue.Dequeue()
        foreach ($item in (Get-ChildItem -LiteralPath $dir -Force -ErrorAction Stop)) {
            $rel = Get-SDDRelativePath $root $item.FullName
            if ($item.PSIsContainer -and ($skip -contains $item.Name -or $rel -match '^docs/sdd/(changes|pbi-input|pbi-sources)(/|$)')) { continue }
            if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Cannot fingerprint linked source path safely: $rel" }
            if ($item.PSIsContainer) { $queue.Enqueue($item.FullName) }
            else { $files.Add($item.FullName) }
        }
    }
    # Settings affect selection and commands; caches and runtime state do not.
    foreach ($name in @('settings.json','verification-config.json')) {
        $f = Join-Path $root ".sdd-builder/$name"
        if (Test-Path -LiteralPath $f -PathType Leaf) { $files.Add($f) }
    }
    return @($files | Sort-Object)
}

function Get-SDDSourceFingerprint([string]$Repository) {
    $files = @(Get-SDDSourceFiles $Repository)
    $lines = @($files | ForEach-Object { (Get-SDDRelativePath $Repository $_) + '|' + (Get-SDDFileSha256 $_) })
    return [pscustomobject]@{ sha256 = Get-SDDTextSha256 ($lines -join "`n"); files = $files.Count; algorithm = 'SHA256/path-and-content/v1' }
}

function Get-SDDChangedFiles([string]$Repository, [string]$BaseRef) {
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) { return @() }
    $base = if ($BaseRef) { $BaseRef } else { 'HEAD' }
    $raw = (& git -C $Repository -c core.quotepath=false diff --name-only --no-renames $base -- 2>$null | Out-String)
    if ($LASTEXITCODE -ne 0) { return @() }
    $untracked = (& git -C $Repository -c core.quotepath=false ls-files --others --exclude-standard 2>$null | Out-String)
    return @(($raw + "`n" + $untracked) -split '\r?\n' | Where-Object { $_ } | Sort-Object -Unique)
}

function Get-SDDSolutionChanges([string]$Repository, [string]$PlanPath, [string]$BaseRef) {
    $allowed = @()
    if ($PlanPath -and (Test-Path -LiteralPath $PlanPath)) {
        $plan = Read-SDDText $PlanPath
        # Exact backtick paths in the Affected source files section constitute approved scope.
        $section = [regex]::Match($plan, '(?ims)^## Affected source files[^\r\n]*\r?\n(.*?)(?=^## |\z)').Groups[1].Value
        $allowed = @([regex]::Matches($section, '`([^`\r\n]+\.slnx?)`') | ForEach-Object { $_.Groups[1].Value.Replace('\','/') })
    }
    $base = if ($BaseRef) { $BaseRef } else { 'HEAD' }
    $changed = @(& git -C $Repository -c core.quotepath=false diff --name-only --no-renames $base -- '*.sln' '*.slnx' 2>$null)
    if ($LASTEXITCODE -ne 0) { return @() }
    return @($changed | Where-Object { $_ -and $allowed -notcontains $_ } | ForEach-Object {
        [pscustomobject]@{ path = $_; reason = 'Tracked solution change outside approved plan'; restoreCommand = "git restore --source=HEAD --staged --worktree -- `"$_`"" }
    })
}

function Get-SDDProjectMap([string]$Repository) {
    $repo = Resolve-SDDRepositoryRoot $Repository
    $files = @(Get-SDDSourceFiles $repo | Where-Object { $_ -match '\.(csproj|props|targets|sln|slnx)$|[\\/](global|angular|package)\.json$|[\\/](packages\.lock\.json|package-lock\.json|yarn\.lock|pnpm-lock\.yaml|nuget\.config)$' })
    $fp = Get-SDDTextSha256 ((@($files | ForEach-Object { (Get-SDDRelativePath $repo $_) + '|' + (Get-SDDFileSha256 $_) })) -join "`n")
    $cache = Join-Path $repo '.sdd-builder/cache/project-map.json'
    if (Test-Path -LiteralPath $cache) {
        try { $m = Read-SDDText $cache | ConvertFrom-Json; if ($m.fingerprint -eq $fp -and $m.version -eq (Get-SDDVersion)) { $m.cacheHit = $true; return $m } } catch { }
    }
    $projects = @(); $warnings = @()
    foreach ($f in @($files | Where-Object { $_ -like '*.csproj' })) {
        [xml]$xml = Read-SDDText $f
        $rel = Get-SDDRelativePath $repo $f
        $refs = @($xml.SelectNodes('//*[local-name()="ProjectReference"]') | ForEach-Object { $_.GetAttribute('Include') })
        if (@($refs | Where-Object { $_ -match '\$\(|\*' }).Count) { $warnings += "Unresolved project references in $rel" }
        $resolved = @($refs | Where-Object { $_ -notmatch '\$\(|\*' } | ForEach-Object { Get-SDDRelativePath $repo ([IO.Path]::GetFullPath((Join-Path (Split-Path -Parent $f) $_.Replace('\','/')))) })
        $text = Read-SDDText $f
        $projects += [pscustomobject]@{ path = $rel; directory = (Get-SDDRelativePath $repo (Split-Path -Parent $f)); references = $resolved; isTest = ($text -match 'Microsoft.NET.Test.Sdk|<IsTestProject>\s*true|MSTest.Sdk|[xn]unit' -or $rel -match '(?i)tests?\.csproj$'); sdkStyle = ($text -match '<Project\s+[^>]*Sdk='); frameworks = @($xml.SelectNodes('//*[local-name()="TargetFramework" or local-name()="TargetFrameworks" or local-name()="TargetFrameworkVersion"]') | ForEach-Object { $_.InnerText }) }
    }
    if (@($files | Where-Object { $_ -match '\.(props|targets)$' }).Count) { $warnings += 'MSBuild imports may add dependencies; targeted selection falls back to full tests.' }
    $map = [pscustomobject][ordered]@{ version = Get-SDDVersion; fingerprint = $fp; cacheHit = $false; projects = $projects; solutions = @($files | Where-Object { $_ -match '\.slnx?$' } | ForEach-Object { Get-SDDRelativePath $repo $_ }); warnings = $warnings }
    Write-SDDText $cache (($map | ConvertTo-Json -Depth 8) + "`n")
    $null = Add-SDDLocalExclude -Repository $repo -RelativeDirs @('.sdd-builder')
    return $map
}

function Get-SDDVerificationPlan([string]$Repository, [string[]]$ChangedFiles, [ValidateSet('Targeted','Final')][string]$Scope = 'Final') {
    $map = Get-SDDProjectMap $Repository
    if (-not $ChangedFiles) { $ChangedFiles = @(Get-SDDChangedFiles $Repository) }
    $tests = @($map.projects | Where-Object isTest)
    $affected = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    $fallback = ($Scope -eq 'Final' -or -not $ChangedFiles.Count -or @($map.warnings).Count -gt 0)
    foreach ($file in $ChangedFiles) {
        if ($file -match '^docs/|^src/\.github/specs/') { continue }
        if ($file -match '\.(props|targets|sln|slnx)$|(^|/)(global.json|NuGet.Config|nuget.config|Directory.Packages.props|packages.lock.json)$') { $fallback = $true }
        $owner = @($map.projects | Where-Object { $_.directory -eq '' -or $file.StartsWith($_.directory + '/', [StringComparison]::OrdinalIgnoreCase) } | Sort-Object { $_.directory.Length } -Descending) | Select-Object -First 1
        if ($owner) { [void]$affected.Add($owner.path) } else { $fallback = $true }
    }
    do {
        $added = $false
        foreach ($p in $map.projects) {
            if (-not $affected.Contains($p.path) -and @($p.references | Where-Object { $affected.Contains($_) }).Count) { [void]$affected.Add($p.path); $added = $true }
        }
    } while ($added)
    $selected = if ($fallback) { $tests } else { @($tests | Where-Object { $affected.Contains($_.path) }) }
    if (-not @($selected).Count -and $tests.Count) { $selected = $tests; $fallback = $true }
    $buildTargets = if ($Scope -eq 'Final' -and @($map.solutions).Count -eq 1) { @($map.solutions) } elseif ($Scope -eq 'Final' -or $fallback) { @($map.projects | ForEach-Object path) } else { @($map.projects | Where-Object { $affected.Contains($_.path) } | ForEach-Object path) }
    return [pscustomobject]@{ scope = $Scope; changedFiles = @($ChangedFiles); buildTargets = @($buildTargets); testTargets = @($selected | ForEach-Object path); fullRegression = ($Scope -eq 'Final'); fallbackToFull = [bool]$fallback; map = $map }
}
