﻿[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$Repository,
  [Parameter(Mandatory=$true)][string]$ChangeFolder,
  [switch]$Strict
)
$ErrorActionPreference = 'Stop'
$repo = (Resolve-Path -LiteralPath $Repository).Path
$work = (Resolve-Path -LiteralPath $ChangeFolder).Path
$audit = Join-Path $work 'pr-review-audit.md'
$rules = Join-Path $repo 'docs/sdd/review-lessons/approved-rules.md'
if (-not (Test-Path -LiteralPath $audit)) { throw "Review audit missing: $audit" }
if (-not (Test-Path -LiteralPath $rules)) { throw "Approved rule register missing: $rules" }
$content = Get-Content -LiteralPath $audit -Raw
if ($content -match '(?im)^\s*PENDING:') { throw 'Review audit still has PENDING entries.' }
if ($content -notmatch '(?im)^\s*Status:\s*(PASS|WAIVED)\s*$') { throw 'Review audit must contain Status: PASS or WAIVED.' }
if ($content -match '(?im)^\s*Status:\s*WAIVED\s*$' -and $content -notmatch '(?im)^\s*Waiver approver:\s*\S+') { throw 'WAIVED must name an approver.' }
if ($Strict) {
    if ($content -notmatch '(?im)^\s*Evidence:\s*\S+') { throw 'Strict mode needs file/test evidence.' }
    if ($content -notmatch '(?im)^\s*Applicable rules:\s*\S+') { throw 'Strict mode needs explicit applicable rules (or NONE with rationale).' }
}
Write-Host 'Review audit structure passed; semantic review and actual tests are still required.' -ForegroundColor Green
