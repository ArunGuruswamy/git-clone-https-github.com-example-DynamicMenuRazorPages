﻿[CmdletBinding()]
param([Parameter(Mandatory)][string]$Repository,[Parameter(Mandatory)][string]$Feature,[string]$PbiId,[switch]$Json)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$repo = Resolve-SDDRepositoryRoot $Repository
$states = @(Find-SDDStateFile -Repository $repo -Feature $Feature -PbiId $PbiId)
if ($states.Count -ne 1) { throw 'Unique feature state required.' }
$work = Split-Path -Parent $states[0]
$path = Join-Path $work 'progress.json'
$plan = Join-Path (Join-Path (Get-SDDSpecRoot $repo) $Feature) 'plan.md'
$section = [regex]::Match((Read-SDDText $plan),'(?ims)^## (?:Implementation changes|Tasks)[^\r\n]*\r?\n(.*?)(?=^## |\z)').Groups[1].Value
$tasks = @([regex]::Matches($section,'\bT\d+\b') | ForEach-Object Value | Select-Object -Unique)
$doc = if (Test-Path -LiteralPath $path) { Read-SDDText $path | ConvertFrom-Json } else { $null }
$stale = $false; $done = @()
if ($doc) { $stale = ($doc.planSha256 -ne (Get-SDDContentHash $plan) -or $doc.sourceFingerprint -ne (Get-SDDSourceFingerprint $repo).sha256); if (-not $stale) { $done = @($doc.completedTasks) } }
[ordered]@{ feature = $Feature; mode = $(if ($doc) { $doc.mode } else { Get-SDDExecutionMode $repo }); status = $(if ($stale) { 'STALE - inspect changed files and reverify before reusing completion evidence' } elseif ($doc) { 'VERIFIED CHECKPOINT' } else { 'NO CHECKPOINT' }); completed = $done; remaining = @($tasks | Where-Object { $done -notcontains $_ }); previous = $doc } | ConvertTo-Json -Depth 8
