﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Repository,
    [Parameter(Mandatory = $true)][string]$Feature,
    # Stages are cumulative. Draft and Approved are accepted as v2.3.x aliases.
    [ValidateSet('Initialized', 'AnalysisComplete', 'ImplementationApproved', 'ImplementationVerified', 'PRReady', 'Draft', 'Approved')]
    [string]$Stage = 'AnalysisComplete',
    [string]$PbiId,
    [switch]$Json,
    # Validate only; do not record the result in sdd-state.json.
    [switch]$NoStateUpdate
)
# Akzo SDD Builder v2.5.3 - deterministic stage gate. Reads files from disk; chat text never counts.
# v2.5: every file of the PBI input package must be cited in spec.md with its contribution or review result,
# every input discrepancy ID must be addressed, and approval is bound to the exact input package.
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force

$aliases = @{ Draft = 'Initialized'; Approved = 'ImplementationApproved' }
if ($aliases.ContainsKey($Stage)) { $Stage = $aliases[$Stage] }
$order = @('Initialized', 'AnalysisComplete', 'ImplementationApproved', 'ImplementationVerified', 'PRReady')
$level = [array]::IndexOf($order, $Stage)

$repo = Resolve-SDDRepositoryRoot $Repository
$problems = New-Object System.Collections.Generic.List[string]
$warnings = New-Object System.Collections.Generic.List[string]
$info = [ordered]@{}
function Fail([string]$m) { $problems.Add($m) }

if (-not (Test-SDDFeatureName $Feature)) { Fail "Feature must be short PascalCase letters without a PBI number: '$Feature'." }
$folder = Join-Path (Get-SDDSpecRoot $repo) $Feature
$specPath = Join-Path $folder 'spec.md'
$planPath = Join-Path $folder 'plan.md'
$info['spec'] = Get-SDDRelativePath $repo $specPath
$info['plan'] = Get-SDDRelativePath $repo $planPath
$info['repository'] = $repo; $info['specAbsolute'] = $specPath; $info['planAbsolute'] = $planPath

# ---------------------------------------------------------------- Initialized
foreach ($p in @($specPath, $planPath)) {
    if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { Fail "File not saved on disk: $(Get-SDDRelativePath $repo $p)" }
}
foreach ($p in @($specPath,$planPath)) { if ((Test-Path -LiteralPath $p -PathType Leaf) -and [string]::IsNullOrWhiteSpace((Read-SDDText $p))) { Fail "Empty document: $p" } }
$specText = if (Test-Path -LiteralPath $specPath -PathType Leaf) { Read-SDDText $specPath } else { '' }
if (-not $PbiId -and $specText) { $ids = @(Get-SDDDeclaredPbiIds $specText); if ($ids.Count -eq 1) { $PbiId = $ids[0] } }
foreach ($p in @($specPath, $planPath)) {
    if ((Test-Path -LiteralPath $p -PathType Leaf) -and @(Get-SDDDeclaredPbiIds (Read-SDDText $p)).Count -eq 0) { Fail "$([IO.Path]::GetFileName($p)) does not declare 'PBI ID: <number>'." }
}
$stateFiles = @(Find-SDDStateFile -Repository $repo -Feature $Feature -PbiId $PbiId)
$statePath = $null; $state = $null
if ($stateFiles.Count -eq 1) { $statePath = $stateFiles[0]; $state = Read-SDDState $statePath }
elseif ($stateFiles.Count -gt 1) { Fail "Several SDD working folders match feature $Feature. Pass -PbiId." }
$work = if ($statePath) { Split-Path -Parent $statePath } else { $null }
if ($work) { $info['workFolder'] = Get-SDDRelativePath $repo $work }
$info['pbiId'] = $PbiId

$templateVersion = if ($state -and $state['templateVersion']) { [string]$state['templateVersion'] } else { '2.4.0' }
$level25 = (Get-SDDTemplateLevel $templateVersion) -ge 25
$roleName = if ($state -and $state['role']) { [string]$state['role'] } else { '' }
$info['templateVersion'] = $templateVersion
$inv = $null
$specHash = if (Test-Path -LiteralPath $specPath -PathType Leaf) { Get-SDDContentHash $specPath } else { '' }
$planHash = if (Test-Path -LiteralPath $planPath -PathType Leaf) { Get-SDDContentHash $planPath } else { '' }
$info['specSha256'] = $specHash; $info['planSha256'] = $planHash

# ---------------------------------------------------------------- AnalysisComplete
if ($level -ge 1 -and $specHash -and $planHash) {
    $sourceText = ''
    if ($state -and $state['source']) {
        $src = Join-Path $repo ([string]$state['source'])
        if (Test-Path -LiteralPath $src -PathType Leaf) { $sourceText = Read-SDDText $src } else { $warnings.Add("Recorded PBI source no longer exists: $($state['source'])") }
    }
    if ($state -and $state['refinementRequired']) { Fail 'Only an unrefined PBI is available. Complete refinement and obtain PO approval of REFINED-PBI.md first.' }
    $acIds = if ($sourceText) { @(Get-SDDAcceptanceIds $sourceText) } else { @(Get-SDDAcceptanceIds (Remove-SDDVerbatimBlock $specText)) }
    $info['acceptanceCriteria'] = $acIds
    $s = Test-SDDDocument -Repository $repo -Path $specPath -Kind 'spec' -PbiId $PbiId -RequiredAcIds $acIds -TemplateVersion $templateVersion -Role $roleName
    $p = Test-SDDDocument -Repository $repo -Path $planPath -Kind 'plan' -PbiId $PbiId -RequiredAcIds $acIds -TemplateVersion $templateVersion -Role $roleName
    foreach ($x in @($s.Problems + $p.Problems)) { Fail $x }
    foreach ($x in @($s.Warnings + $p.Warnings)) { $warnings.Add($x) }
    $info['evidenceFiles'] = @($s.ExistingRefs + $p.ExistingRefs | Select-Object -Unique)
    if ($sourceText) {
        foreach ($m in (Test-SDDVerbatimAcceptance -SpecText (Remove-SDDVerbatimBlock $specText) -SourceText $sourceText)) { Fail "Acceptance criterion changed or missing in spec.md 'Acceptance criteria': '$m'" }
        $mk = Get-SDDPbiSourceMarkers
        $bm = [regex]::Match($specText, [regex]::Escape($mk[0]) + '\r?\n?([\s\S]*?)\r?\n?' + [regex]::Escape($mk[1]))
        $normalize = { param($t) ($t -replace "`r`n", "`n").Trim() }
        if (-not $bm.Success) { Fail 'spec.md must keep the refined PBI verbatim between the sdd:pbi-source markers.' }
        elseif ((& $normalize $bm.Groups[1].Value) -ne (& $normalize $sourceText)) { Fail "The verbatim PBI block in spec.md differs from $($state['source']). Restore it exactly; record deviations as decisions." }
    }
    # PBI input package: refined PBI + attachments of THIS PBI only, re-inventoried from disk on every run.
    if ($PbiId -and $state -and $state['source'] -and $sourceText) {
        $inv = New-SDDPbiInventory -Repository $repo -PbiId $PbiId -Selected ([string]$state['source'])
        $info['inputPackage'] = $inv.packageRoot
        $info['inputFingerprint'] = $inv.fingerprint
        $info['inputs'] = $inv.summary
        $info['pbiApproval'] = [pscustomobject][ordered]@{ approved = $inv.primaryApproval.approved; summary = $inv.primaryApproval.summary }
        # Edited inputs fail every gate, whatever the document version: the evidence itself is no longer trustworthy.
        foreach ($d in @($inv.discrepancies | Where-Object { $_.type -eq 'InputEditedAfterImport' })) {
            Fail "PBI input edited after import: $($d.detail) Fix: tools/Get-SDDStatus.ps1 -Fix"
        }
        foreach ($x in (Get-SDDInventoryProblems -Inventory $inv -SpecAuthored (Remove-SDDVerbatimBlock $specText))) {
            if ($level25) { Fail $x } else { $warnings.Add("(not enforced for documents created before v2.5) $x") }
        }
        if ($state['inputFingerprint'] -and [string]$state['inputFingerprint'] -ne $inv.fingerprint) {
            $warnings.Add('The PBI input package changed since Start Development (a file was added, changed or removed). Re-run Start Development to refresh pbi-analysis/, then update spec.md.')
        }
        if (-not $inv.primaryApproval.approved) {
            $warnings.Add("The refined PBI is not business-approved ($($inv.primaryApproval.summary)). Implementation approval must acknowledge this explicitly (Approve-SDD.ps1 -AcknowledgeUnapprovedPbi).")
        }
    }
    if (-not $work) { Fail 'No SDD working folder (sdd-state.json) found. Run tools/Start-SDD.ps1, or create docs/sdd/changes/<PBI-ID>-<Feature>/sdd-state.json.' }
    else {
        $audit = Join-Path $work 'pr-review-audit.md'
        if (-not (Test-Path -LiteralPath $audit -PathType Leaf)) { Fail 'pr-review-audit.md is missing in the working folder.' }
        else {
            $a = Read-SDDText $audit
            if ($a -match '(?im)^\s*[^\r\n]*:\s*PENDING\s*$' -or $a -match '(?im)^\s*PENDING\s*:') { Fail 'pr-review-audit.md still contains PENDING entries.' }
            if ($a -notmatch '(?im)^\s*Status:\s*(PASS|WAIVED)\s*$') { Fail 'pr-review-audit.md must record Status: PASS (or WAIVED with Waiver approver).' }
            if ($a -match '(?im)^\s*Status:\s*WAIVED\s*$' -and $a -notmatch '(?im)^\s*Waiver approver:\s*\S+') { Fail 'pr-review-audit.md waiver must name a Waiver approver.' }
        }
    }
}

# ---------------------------------------------------------------- ImplementationApproved
if ($level -ge 2 -and $work) {
    $approvalJson = Join-Path $work 'approval.json'
    if (-not (Test-Path -LiteralPath $approvalJson -PathType Leaf)) { Fail 'No approval recorded. The developer approves; the agent then runs tools/Approve-SDD.ps1 (approval.json).' }
    else {
        $ap = Read-SDDText $approvalJson | ConvertFrom-Json
        if (Test-SDDBotIdentity ([string]$ap.approvedBy)) { Fail "Approver '$($ap.approvedBy)' is not a named person." }
        if ([string]::IsNullOrWhiteSpace([string]$ap.statement)) { Fail 'Approval has no recorded approval statement.' }
        if ($ap.specSha256 -ne $specHash) { Fail 'spec.md changed after approval. Re-approval required.' }
        if ($ap.planSha256 -ne $planHash) { Fail 'plan.md changed after approval. Re-approval required.' }
        if ($state -and $ap.PSObject.Properties['sourceSha256'] -and $ap.sourceSha256 -and $state['sourceHash'] -and $ap.sourceSha256 -ne $state['sourceHash']) { Fail 'The refined PBI changed after approval. Re-analyse and re-approve.' }
        if ($inv) {
            if ($ap.PSObject.Properties['inputFingerprint'] -and $ap.inputFingerprint -and [string]$ap.inputFingerprint -ne $inv.fingerprint) {
                Fail 'The PBI input package (refined PBI or attachments) changed after approval. Re-run Start Development, update spec.md and plan.md, and re-approve.'
            }
            if (-not $inv.primaryApproval.approved) {
                $ack = [bool]($ap.PSObject.Properties['pbiApprovalAcknowledged'] -and $ap.pbiApprovalAcknowledged)
                if (-not $ack) {
                    $m = "The refined PBI is not business-approved ($($inv.primaryApproval.summary)) and the approval does not acknowledge it."
                    if ($level25) { Fail $m } else { $warnings.Add($m) }
                }
            }
        }
        $info['approvedBy'] = $ap.approvedBy; $info['approvedAtUtc'] = $ap.approvedAtUtc
    }
}

# ---------------------------------------------------------------- ImplementationVerified
if ($level -ge 3 -and $work) {
    $verFile = Join-Path $work 'verification.json'
    if (-not (Test-Path -LiteralPath $verFile -PathType Leaf)) { Fail 'No verification evidence (verification.json). Run tools/Invoke-SDDVerification.ps1; without a terminal, record NOT EXECUTED.' }
    else {
        $ver = Read-SDDText $verFile | ConvertFrom-Json
        $entries = @($ver.checks)
        $currentFingerprint = (Get-SDDSourceFingerprint $repo).sha256
        if (-not $ver.PSObject.Properties['sourceFingerprint'] -or $ver.sourceFingerprint -ne $currentFingerprint) { Fail 'Verification evidence is stale: source or configuration fingerprint changed (or is missing). Run verification again.' }
        foreach ($e in $entries) {
            if ($e.executed -and (-not $e.PSObject.Properties['sourceFingerprint'] -or $e.sourceFingerprint -ne $currentFingerprint)) { Fail "Stale $($e.kind) evidence: source/configuration fingerprint differs." }
        }
        if ($level -ge 4 -and (-not $ver.PSObject.Properties['scope'] -or $ver.scope -ne 'Final' -or -not $ver.fullRegression)) { Fail 'Final regression verification is required before PRReady.' }
        $baseRef = if ($ap -and $ap.PSObject.Properties['gitHead']) { [string]$ap.gitHead } else { '' }
        $solutionChanges = @(Get-SDDSolutionChanges -Repository $repo -PlanPath $planPath -BaseRef $baseRef)
        foreach ($c in $solutionChanges) { Fail "$($c.reason): $($c.path). Review before restoring: $($c.restoreCommand)" }

        foreach ($kind in @('build', 'test')) {
            $k = @($entries | Where-Object { $_.kind -eq $kind })
            if ($k.Count -eq 0) { Fail "No $kind check recorded."; continue }
            foreach ($e in $k) {
                if (-not $e.executed) { Fail "$kind '$($e.name)' NOT EXECUTED: $($e.reason)"; continue }
                if ($null -eq $e.exitCode -or [string]$e.exitCode -notmatch '^0$') { Fail "$kind '$($e.name)' failed with exit code $($e.exitCode) (log: $($e.logFile))." }
                $log = Join-Path $repo ([string]$e.logFile)
                if (-not (Test-Path -LiteralPath $log -PathType Leaf)) { Fail "$kind '$($e.name)' log file missing: $($e.logFile)" }
                elseif ((Get-SDDContentHash $log) -ne $e.logSha256) { Fail "$kind '$($e.name)' log does not match its recorded hash." }
                elseif ((Read-SDDText $log) -notmatch '(?m)^# exit code: 0(?: |\r?$)') { Fail "$kind '$($e.name)' log does not record a successful process exit." }
                else { foreach ($issue in (Get-SDDCommandOutcome -Kind $kind -Output (Read-SDDText $log)).issues) { Fail "$kind evidence: $issue" } }
            }
        }
        $info['verification'] = @($entries | ForEach-Object { "$($_.kind): $($_.name) -> $(if ($_.executed) { 'exit ' + $_.exitCode } else { 'NOT EXECUTED' })" })
    }
}

# ---------------------------------------------------------------- PRReady
if ($level -ge 4 -and $work) {
    if ([version]$templateVersion -ge [version]'2.5.2') {
        $progressPath = Join-Path $work 'progress.json'
        if (-not (Test-Path -LiteralPath $progressPath)) { Fail 'Verified task progress is required before PRReady. Record approved completed tasks with Update-SDDProgress.ps1.' }
        else {
            $progress = Read-SDDText $progressPath | ConvertFrom-Json
            $taskSection = [regex]::Match((Read-SDDText $planPath),'(?ims)^## (?:Implementation changes|Tasks)[^\r\n]*\r?\n(.*?)(?=^## |\z)').Groups[1].Value
            $requiredTasks = @([regex]::Matches($taskSection,'\bT\d+\b') | ForEach-Object Value | Select-Object -Unique)
            if (-not $requiredTasks.Count) { Fail 'No identifiable approved tasks in plan.md.' }
            $remaining = @($requiredTasks | Where-Object { @($progress.completedTasks) -notcontains $_ })
            if ($remaining.Count) { Fail "Approved tasks are incomplete: $($remaining -join ', ')" }
            if ($progress.planSha256 -ne $planHash -or $progress.specSha256 -ne $specHash -or $progress.sourceFingerprint -ne (Get-SDDSourceFingerprint $repo).sha256) { Fail 'Task progress is stale; reverify the current implementation before PRReady.' }
        }
    }

    $review = Join-Path $work 'review.md'
    if (-not (Test-Path -LiteralPath $review -PathType Leaf)) { Fail 'review.md (independent pre-PR review) is missing.' }
    else {
        $r = Read-SDDText $review
        $open = @(($r -split "`n") | Where-Object { $_ -match '\b(BLOCKER|MAJOR)\b' -and $_ -match '(?i)\bopen\b' })
        if ($open.Count) { Fail "review.md has $($open.Count) open BLOCKER/MAJOR finding(s)." }
        if ($r -notmatch '(?im)^\s*Open findings:\s*0\s*$') { Fail "review.md must end with 'Open findings: 0' (NIT waivers recorded)." }
    }
    $completion = Join-Path $work 'completion.md'
    if (-not (Test-Path -LiteralPath $completion -PathType Leaf)) { Fail 'completion.md is missing.' }
    elseif ((Read-SDDText $completion) -notmatch '(?i)traceab') { Fail 'completion.md must contain the AC -> file -> test traceability.' }
}

# ---------------------------------------------------------------- result
$result = if ($problems.Count) { 'FAIL' } else { 'PASS' }
# A PBI that reached PRReady no longer holds the local commit gate.
if ($result -eq 'PASS' -and $Stage -eq 'PRReady' -and $PbiId -and -not $NoStateUpdate) { Set-SDDActivePbi -Repository $repo -PbiId $PbiId -Active $false }
if ($state -and $statePath -and -not $NoStateUpdate) {
    $current = [array]::IndexOf($order, [string]$state['stage'])
    $detail = if ($problems.Count) { ($problems | Select-Object -First 5) -join ' | ' } else { "spec $($specHash.Substring(0,12)) plan $($planHash.Substring(0,12))" }
    Add-SDDStageRecord $state $Stage $result $detail
    if ($result -eq 'PASS' -and $current -gt $level) { $state['stage'] = $order[$current] }
    if ($result -eq 'FAIL' -and $current -ge $level) {
        # A failed gate (e.g. spec edited after approval) moves the PBI back below that stage.
        $state['stage'] = if ($level -gt 0) { $order[$level - 1] } else { 'None' }
    }
    Save-SDDState $statePath $state
}
if ($Json) {
    [ordered]@{ stage = $Stage; result = $result; problems = $problems.ToArray(); warnings = $warnings.ToArray(); info = $info } | ConvertTo-Json -Depth 6 | Write-Output
} else {
    foreach ($w in $warnings) { Write-Host "WARN: $w" -ForegroundColor Yellow }
    foreach ($p in $problems) { Write-Host "FAIL: $p" -ForegroundColor Red }
    if ($result -eq 'PASS') {
        Write-Host "SDD $Stage gate PASS" -ForegroundColor Green
        Write-Host "  $($info['spec'])  sha256 $specHash"
        Write-Host "  $($info['plan'])  sha256 $planHash"
    } else {
        Write-Host "SDD $Stage gate FAIL ($($problems.Count) problem(s)). The agent fixes the files and re-runs; the developer is not asked to save anything." -ForegroundColor Red
    }
}
if ($result -eq 'FAIL') { exit 1 }
exit 0
