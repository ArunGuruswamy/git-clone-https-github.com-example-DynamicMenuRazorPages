﻿# Akzo SDD Builder - shared functions for every SDD tool.
# Compatible with Windows PowerShell 5.1 and PowerShell 7+. Uses forward slashes only (valid on Windows).
# All tools import this module so that discovery, naming, role detection and validation never diverge again.

$script:SDDVersion = '2.5.3'
$script:Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$script:SkipDirs = @('.git', 'node_modules', 'bin', 'obj', 'packages', 'TestResults', '.vs', '.sdd-installer-backups', 'dist', 'coverage')

function Get-SDDVersion { $script:SDDVersion }

# ------------------------------------------------------------------ files and paths

function Read-SDDText([Parameter(Mandatory)][string]$Path) {
    # ReadAllText honours a BOM when present and defaults to UTF-8 otherwise (PS 5.1 Get-Content would use ANSI).
    return [IO.File]::ReadAllText((Resolve-SDDFullPath $Path), $script:Utf8NoBom)
}

function Write-SDDText([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][AllowEmptyString()][string]$Text) {
    $full = Resolve-SDDFullPath $Path
    $dir = [IO.Path]::GetDirectoryName($full)
    if (-not [IO.Directory]::Exists($dir)) { [void][IO.Directory]::CreateDirectory($dir) }
    [IO.File]::WriteAllText($full, $Text, $script:Utf8NoBom)
    # Read back: persistence is proven by the file system, not by the write call.
    if (-not [IO.File]::Exists($full)) { throw "Write failed, file not present after write: $full" }
    $back = [IO.File]::ReadAllText($full, $script:Utf8NoBom)
    if ($back.Length -ne $Text.Length) { throw "Write verification failed for $full (length $($back.Length) vs $($Text.Length))." }
}

function Resolve-SDDFullPath([Parameter(Mandatory)][string]$Path) {
    if ([IO.Path]::IsPathRooted($Path)) { return [IO.Path]::GetFullPath($Path) }
    return [IO.Path]::GetFullPath((Join-Path (Get-Location).ProviderPath $Path))
}

function Get-SDDRelativePath([Parameter(Mandatory)][string]$Base, [Parameter(Mandatory)][string]$Path) {
    # [IO.Path]::GetRelativePath is not available on .NET Framework (PS 5.1).
    $b = (Resolve-SDDFullPath $Base).TrimEnd([char]'/', [char]'\') + [IO.Path]::DirectorySeparatorChar
    $p = Resolve-SDDFullPath $Path
    $cmp = if ($IsWindows -or $env:OS -eq 'Windows_NT') { [StringComparison]::OrdinalIgnoreCase } else { [StringComparison]::Ordinal }
    if ($p.StartsWith($b, $cmp)) { return $p.Substring($b.Length).Replace('\', '/') }
    return $p.Replace('\', '/')
}

function Get-SDDContentHash([Parameter(Mandatory)][string]$Path) {
    # Normalised hash: BOM removed, CRLF -> LF, trailing whitespace at end of file ignored.
    # Git autocrlf therefore cannot invalidate an approval; any real content change does.
    $text = Read-SDDText $Path
    $text = $text.TrimStart([char]0xFEFF).Replace("`r`n", "`n").TrimEnd()
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $bytes = $sha.ComputeHash($script:Utf8NoBom.GetBytes($text)) } finally { $sha.Dispose() }
    return (($bytes | ForEach-Object { $_.ToString('x2') }) -join '')
}

function Get-SDDFiles([string]$Root, [string[]]$Include = @('*'), [int]$MaxDepth = 6) {
    # Bounded walker that skips build output and dependency folders (Get-ChildItem -Recurse on a full
    # repository with node_modules is slow and can hit path-length limits on Windows).
    $results = New-Object System.Collections.Generic.List[string]
    if (-not [IO.Directory]::Exists($Root)) { return @() }
    $queue = New-Object System.Collections.Generic.Queue[object]
    $queue.Enqueue(@($Root, 0))
    while ($queue.Count -gt 0) {
        $item = $queue.Dequeue(); $dir = $item[0]; $depth = $item[1]
        try {
            foreach ($f in [IO.Directory]::GetFiles($dir)) {
                $name = [IO.Path]::GetFileName($f)
                foreach ($pattern in $Include) { if ($name -like $pattern) { $results.Add($f); break } }
            }
            if ($depth -lt $MaxDepth) {
                foreach ($d in [IO.Directory]::GetDirectories($dir)) {
                    if ($script:SkipDirs -notcontains [IO.Path]::GetFileName($d) -and -not ((Get-Item -LiteralPath $d -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { $queue.Enqueue(@($d, $depth + 1)) }
                }
            }
        } catch { continue }
    }
    return $results.ToArray()
}

# ------------------------------------------------------------------ repository conventions

function Get-SDDSettings([Parameter(Mandatory)][string]$Repository) {
    $file = Join-Path $Repository '.sdd-builder/settings.json'
    if (Test-Path -LiteralPath $file -PathType Leaf) {
        try { return (Read-SDDText $file | ConvertFrom-Json) } catch { throw "Invalid JSON in $file : $($_.Exception.Message)" }
    }
    return $null
}

function Get-SDDSpecRoot([Parameter(Mandatory)][string]$Repository) {
    $Repository = Resolve-SDDRepositoryRoot $Repository
    # Approved convention: src/.github/specs when the repository has src, otherwise .github/specs.
    # A repository with a different layout records its resolved root once in .sdd-builder/settings.json (specRoot).
    if (Test-Path -LiteralPath (Join-Path $Repository 'src/AN.ColorAppsAzure.Formula') -PathType Container) { return (Join-Path $Repository 'src/.github/specs') }
    $settings = Get-SDDSettings $Repository
    if ($settings -and $settings.PSObject.Properties['specRoot'] -and $settings.specRoot) {
        $root = [IO.Path]::GetFullPath((Join-Path $Repository ([string]$settings.specRoot)))
        $prefix = $Repository.TrimEnd([char]92,[char]47) + [IO.Path]::DirectorySeparatorChar
        if (-not $root.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) { throw 'specRoot must remain inside the primary repository.' }
        return $root
    }
    if (Test-Path -LiteralPath (Join-Path $Repository 'src') -PathType Container) { return (Join-Path $Repository 'src/.github/specs') }
    return (Join-Path $Repository '.github/specs')
}

function Get-SDDRepositoryRole([Parameter(Mandatory)][string]$Repository) {
    $repo = Resolve-SDDFullPath $Repository
    $evidence = @{ DAB = New-Object System.Collections.Generic.List[string]; CDMS = New-Object System.Collections.Generic.List[string]; UI = New-Object System.Collections.Generic.List[string] }
    if (Test-Path -LiteralPath (Join-Path $repo 'angular.json') -PathType Leaf) { $evidence.UI.Add('angular.json') }
    if (Test-Path -LiteralPath (Join-Path $repo 'src/AN.ColorAppsAzure.Formula') -PathType Container) { $evidence.DAB.Add('src/AN.ColorAppsAzure.Formula/') }
    foreach ($sln in (Get-SDDFiles -Root $repo -Include @('*.sln', '*.slnx') -MaxDepth 3)) {
        $name = [IO.Path]::GetFileName($sln)
        $rel = Get-SDDRelativePath $repo $sln
        if ($name -match '(?i)ColorDMS|CDMS') { $evidence.CDMS.Add($rel) }
        elseif ($name -match '(?i)^AN\.ColorAppsAzure\.BL\.slnx?$') { $evidence.DAB.Add($rel) }
    }
    if ($evidence.DAB.Count -gt 0 -or $evidence.CDMS.Count -eq 0) {
        $gql = @(Get-SDDFiles -Root (Join-Path $repo 'src') -Include @('*.graphql') -MaxDepth 8 | Select-Object -First 1)
        if ($gql.Count) { $evidence.DAB.Add((Get-SDDRelativePath $repo $gql[0])) }
    }
    $roles = @('DAB', 'CDMS', 'UI') | Where-Object { $evidence[$_].Count -gt 0 }
    $role = if (@($roles).Count -eq 1) { @($roles)[0] } elseif (@($roles).Count -eq 0) { 'UNRESOLVED' } else { 'AMBIGUOUS' }
    $settings = Get-SDDSettings $repo
    if ($role -in @('UNRESOLVED', 'AMBIGUOUS') -and $settings -and $settings.PSObject.Properties['role'] -and $settings.role -in @('DAB', 'CDMS', 'UI')) {
        $role = [string]$settings.role
        $evidence[$role].Add('.sdd-builder/settings.json role')
    }
    $skill = switch ($role) { 'DAB' { 'dab-development' } 'CDMS' { 'cdms-development' } 'UI' { 'ui-development' } default { '' } }
    return [pscustomobject]@{
        Role       = $role
        Skill      = $skill
        Candidates = @($roles)
        Evidence   = [pscustomobject]@{ DAB = $evidence.DAB.ToArray(); CDMS = $evidence.CDMS.ToArray(); UI = $evidence.UI.ToArray() }
    }
}

function ConvertTo-SDDFeatureName([Parameter(Mandatory)][string]$Title) {
    $s = $Title -replace '\[[^\]]*\]', ' '
    $s = $s -replace '(?i)\b(PBI|work\s*item|bug|task)\s*#?\s*\d+\b', ' '
    $s = $s -replace '\b\d{3,}\b', ' '
    $s = $s -replace '(?i)\b(creation|implementation|development)\s+of\b', ' '
    $s = $s -replace '(?i)\b(functionality|feature|changes?|the|a|an|for|of|and|to|in|on)\b', ' '
    $words = @([regex]::Matches($s, '[A-Za-z][A-Za-z0-9]*') | ForEach-Object { $_.Value })
    $name = ''
    foreach ($w in ($words | Select-Object -First 5)) {
        $piece = if ($w.Length -le 3 -and $w -ceq $w.ToUpperInvariant()) { $w } else { $w.Substring(0, 1).ToUpperInvariant() + $w.Substring(1) }
        if (($name + $piece).Length -gt 40) { break }
        $name += $piece
    }
    $name = $name -replace '[0-9]', ''
    if (-not (Test-SDDFeatureName $name)) { throw "Could not derive a short PascalCase feature name from '$Title'. Pass -Feature explicitly." }
    return $name
}

function Test-SDDFeatureName([string]$Name) {
    return ($Name -cmatch '^[A-Z][A-Za-z]{2,59}$')
}

# ------------------------------------------------------------------ PBI identity and discovery

function Get-SDDDeclaredPbiIds([string]$Text) {
    # A declared identity is a header line, not any mention in the body.
    $head = (($Text -split "`n") | Select-Object -First 40) -join "`n"
    $ids = New-Object System.Collections.Generic.List[string]
    $patterns = @(
        '(?im)^\s*[-*|]?\s*\**\s*(?:PBI|Work\s*Item|Product\s*Backlog\s*Item)\s*(?:ID|#|No\.?|Number)?\s*\**\s*[:#|-]\s*\**\s*#?(\d{4,8})\b',
        '(?im)^\s*#{1,3}\s*(?:PBI|Work\s*Item)\s*#?\s*(\d{4,8})\b',
        '(?m)^\s*#\s+#?(\d{4,8})\s*[-\u2013\u2014:]\s'
    )
    foreach ($p in $patterns) { foreach ($m in [regex]::Matches($head, $p)) { if (-not $ids.Contains($m.Groups[1].Value)) { $ids.Add($m.Groups[1].Value) } } }
    return $ids.ToArray()
}

function Get-SDDPbiApprovalState([string]$Text) {
    # Reads every status-like field of a refined PBI (header AND review-status sections).
    # Approved only when at least one field says approved/ready and none says blocked/pending/draft/...
    $fields = New-Object System.Collections.Generic.List[string]
    $pattern = '(?im)^\s*[-*|]?\s*\**\s*(Status|State|Approval|Business\s+approval|PO\s+approval|Technical\s+feasibility\s+review|Feasibility\s+review|Readiness|Blocking\s+questions)\s*\**\s*[:|]\s*\**\s*([^\r\n|*]+)'
    foreach ($m in [regex]::Matches($Text, $pattern)) {
        $f = ($m.Groups[1].Value.Trim() + ': ' + $m.Groups[2].Value.Trim())
        if (-not $fields.Contains($f)) { $fields.Add($f) }
    }
    $negative = @($fields | Where-Object { $_ -match '(?i):\s*(blocked|pending|draft|proposed|in\s+review|not\s+(?:yet\s+)?(?:ready|approved)|on\s+hold|rejected|open|q-?\d+\s+pending)' })
    $positive = @($fields | Where-Object { $_ -match '(?i)^(Status|State|Approval|Business\s+approval|PO\s+approval|Readiness):\s*(approved|ready(?:\s+for\s+development)?|refined\s+and\s+approved)\b' })
    $approved = ($positive.Count -gt 0 -and $negative.Count -eq 0)
    $summary = if ($fields.Count) { $fields -join '; ' } else { 'no approval status recorded in the document' }
    return [pscustomobject]@{ Approved = $approved; Fields = $fields.ToArray(); NotApprovedFields = $negative; Summary = $summary }
}

function Test-SDDSupportingDocName([string]$FileName) {
    # PBI Builder companion documents: evidence for the refined PBI, never the requirements source itself.
    return ($FileName -match '(?i)^(decision[-_ ]?log|decisions?|open[-_ ]?questions?|evidence|handoff|readme|changelog|notes?)([-_. ]|$)')
}

function Test-SDDNonCandidatePath([string]$RelativePath) {
    # Attachments, PBI Builder history snapshots and superseded copies are never requirement sources.
    $segments = @($RelativePath.Replace('\', '/').Split('/') | Select-Object -SkipLast 1)
    foreach ($seg in $segments) { if ($seg -match '(?i)^(attachments?|history|\.previous|superseded|archive)$') { return $true } }
    return $false
}

function Get-SDDPbiKind([string]$FileName, [string]$Text) {
    if (Test-SDDSupportingDocName $FileName) { return 'Supporting' }
    $approved = (Get-SDDPbiApprovalState $Text).Approved
    if ($FileName -match '(?i)refined') { if ($approved) { return 'ApprovedRefined' } return 'Refined' }
    if ($FileName -match '(?i)original|raw|^(pbi|request)([-_. ]|$)') { return 'Original' }
    $head = (($Text -split "`n") | Select-Object -First 40) -join "`n"
    if ($head -match '(?im)^\s*[-*|]?\s*\**\s*(?:status|state)\s*\**\s*[:|]\s*\**\s*refined') { return 'Refined' }
    if ($approved) { return 'ApprovedRefined' }
    return 'Unspecified'
}

function Get-SDDKindRank([string]$Kind) {
    switch ($Kind) { 'ApprovedRefined' { 0 } 'ApprovedHandoff' { 1 } 'Refined' { 1 } 'Unspecified' { 2 } 'Original' { 3 } 'ExistingArtifact' { 4 } default { 9 } }
}

function Get-SDDConfiguredPbiSources([string]$Repository) {
    $cfg = Join-Path $Repository '.github/sdd/config.md'
    if (-not (Test-Path -LiteralPath $cfg -PathType Leaf)) { return @() }
    $line = ((Read-SDDText $cfg) -split "`n") | Where-Object { $_ -match '`PBI_SOURCES`' } | Select-Object -First 1
    if (-not $line) { return @() }
    $cells = $line -split '\|'
    if ($cells.Count -lt 3) { return @() }
    return @([regex]::Matches($cells[2], '`([^`]+)`') | ForEach-Object { $_.Groups[1].Value.Trim() } |
        Where-Object { $_ -and $_ -notmatch '<' -and $_ -notmatch '^\.?/?\.github/specs/?$' -and $_ -notmatch '^docs/sdd/changes/?$' })
}

function Find-SDDPbiSource {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Repository, [Parameter(Mandatory)][string]$PbiId)
    $repo = Resolve-SDDFullPath $Repository
    if ($PbiId -notmatch '^\d{4,8}$') { throw "PBI ID must be numeric (4-8 digits): $PbiId" }
    $candidates = New-Object System.Collections.Generic.List[object]
    $excluded = New-Object System.Collections.Generic.List[string]
    $seen = New-Object System.Collections.Generic.HashSet[string]

    $add = {
        param([string]$file, [int]$tier, [string]$identityBy, [bool]$requireDeclared)
        $full = Resolve-SDDFullPath $file
        if (-not $seen.Add($full)) { return }
        $name = [IO.Path]::GetFileName($full)
        if ($name -in @('README.md')) { return }
        $relCheck = Get-SDDRelativePath $repo $full
        if ((Test-SDDNonCandidatePath $relCheck) -or ((Test-SDDSupportingDocName $name) -and $name -ine 'HANDOFF.md')) { return }
        $reader = [IO.File]::OpenText($full)
        try { $headLines = @(); for ($n=0; $n -lt 40 -and -not $reader.EndOfStream; $n++) { $headLines += $reader.ReadLine() } } finally { $reader.Dispose() }
        $declared = @(Get-SDDDeclaredPbiIds ($headLines -join "`n"))
        $rel = Get-SDDRelativePath $repo $full
        if ($declared.Count -gt 0 -and $declared -notcontains $PbiId) { $excluded.Add("$rel declares PBI $($declared -join ',')"); return }
        $by = $identityBy
        if ($declared -contains $PbiId) { $by = if ($by) { "$by+header" } else { 'header' } }
        elseif ($requireDeclared) {
            if ($name -match "(^|[^0-9])$PbiId([^0-9]|$)") { $by = 'filename' } else { $excluded.Add("$rel has no declared PBI identity"); return }
        }
        $text = Read-SDDText $full
        $kind = if ($name -ieq 'HANDOFF.md') { if ((Get-SDDPbiApprovalState $text).Approved -and @(Get-SDDAcceptanceIds $text).Count -gt 0) { 'ApprovedHandoff' } else { 'Handoff' } } else { Get-SDDPbiKind $name $text }
        $candidates.Add([pscustomobject]@{ Path = $rel; FullPath = $full; Tier = $tier; Kind = $kind; IdentityBy = $by; Hash = (Get-SDDContentHash $full) })
    }

    # Tier 1/2: docs/sdd/pbi-input/<id>/
    $idDir = Join-Path $repo "docs/sdd/pbi-input/$PbiId"
    if (Test-Path -LiteralPath $idDir -PathType Container) {
        $preferred = @([IO.Directory]::GetFiles($idDir, '*.md') | Where-Object { [IO.Path]::GetFileName($_) -ieq 'REFINED-PBI.md' }) | Select-Object -First 1
        if ($preferred) { & $add $preferred 1 'folder' $false }
        foreach ($f in (Get-SDDFiles -Root $idDir -Include @('*.md') -MaxDepth 3)) { & $add $f 2 'folder' $false }
    }
    # Tier 3: flat files directly in docs/sdd/pbi-input (identity must be verified)
    $inputRoot = Join-Path $repo 'docs/sdd/pbi-input'
    if (Test-Path -LiteralPath $inputRoot -PathType Container) {
        foreach ($f in [IO.Directory]::GetFiles($inputRoot, '*.md')) { & $add $f 3 '' $true }
    }
    # Tier 4: PBI Builder handoff folders created by Import-PBIBuilder.ps1
    $sources = Join-Path $repo 'docs/sdd/pbi-sources'
    if (Test-Path -LiteralPath $sources -PathType Container) {
        foreach ($d in [IO.Directory]::GetDirectories($sources, "$PbiId-*")) {
            foreach ($f in (Get-SDDFiles -Root $d -Include @('*.md') -MaxDepth 4)) { & $add $f 4 'handoff-folder' $false }
        }
    }
    # Tier 5: configured PBI_SOURCES (identity must be verified)
    foreach ($src in (Get-SDDConfiguredPbiSources $repo)) {
        $dir = Join-Path $repo $src
        if (Test-Path -LiteralPath $dir -PathType Container) { foreach ($f in (Get-SDDFiles -Root $dir -Include @('*.md') -MaxDepth 4)) { & $add $f 5 '' $true } }
    }
    # Tier 6: already generated SDD artifacts (resume)
    $changes = Join-Path $repo 'docs/sdd/changes'
    $existingWork = @()
    if (Test-Path -LiteralPath $changes -PathType Container) { $existingWork = @([IO.Directory]::GetDirectories($changes, "$PbiId-*")) }
    $existingFeature = Find-SDDFeatureFolder -Repository $repo -PbiId $PbiId

    $usable = @($candidates | Where-Object { $_.Kind -ne 'Handoff' })
    # Convention: docs/sdd/pbi-input/<id>/REFINED-PBI.md is THE primary source. Other Markdown in that folder
    # (approved technical remarks, clarifications) is supporting evidence, whatever its own status says.
    $conventional = @($usable | Where-Object { $_.Tier -eq 1 })
    if ($conventional.Count -eq 1) { $usable = $conventional }
    $result = [ordered]@{ PbiId = $PbiId; Status = 'NotFound'; Selected = $null; Kind = $null; Candidates = @($candidates.ToArray()); Excluded = @($excluded.ToArray()); ExistingFeature = $existingFeature; ExistingWorkFolders = @($existingWork | ForEach-Object { Get-SDDRelativePath $repo $_ }); Reason = '' }
    if ($usable.Count -eq 0) {
        if ($existingFeature -or $existingWork.Count) {
            $result.Status = 'ResumeExisting'; $result.Kind = 'ExistingArtifact'
            $result.Reason = 'No PBI input file, but SDD artifacts for this PBI already exist. Resume from them.'
        } else {
            $result.Reason = "No Markdown identified as PBI $PbiId. Searched docs/sdd/pbi-input/$PbiId/, docs/sdd/pbi-input/*.md, docs/sdd/pbi-sources/$PbiId-*/, configured PBI_SOURCES, docs/sdd/changes/$PbiId-*/."
        }
        return [pscustomobject]$result
    }
    $bestRank = ($usable | ForEach-Object { Get-SDDKindRank $_.Kind } | Measure-Object -Minimum).Minimum
    $best = @($usable | Where-Object { (Get-SDDKindRank $_.Kind) -eq $bestRank })
    $bestTier = ($best | Measure-Object -Property Tier -Minimum).Minimum
    $best = @($best | Where-Object { $_.Tier -eq $bestTier })
    $distinct = @($best | Group-Object Hash)
    if ($distinct.Count -gt 1) {
        $result.Status = 'Ambiguous'
        $result.Reason = "Several different $($best[0].Kind) documents identify PBI $PbiId at the same priority: " + (($best | ForEach-Object { $_.Path }) -join ', ') + '. Keep one, or mark the approved one with "Status: Approved".'
        return [pscustomobject]$result
    }
    $chosen = $best | Sort-Object { $_.Path.Length } | Select-Object -First 1
    $result.Selected = $chosen.Path
    $result.Kind = $chosen.Kind
    if ($chosen.Kind -eq 'Original') {
        $result.Status = 'RefinementRequired'
        $result.Reason = 'Only an original (unrefined) PBI was found. Run the refinement workflow; do not treat it as approved requirements.'
    } else {
        $result.Status = 'Found'
        $dupes = @($candidates | Where-Object { $_.Hash -eq $chosen.Hash -and $_.Path -ne $chosen.Path })
        $result.Reason = "Selected $($chosen.Kind) source (priority tier $($chosen.Tier), identity by $($chosen.IdentityBy))." + $(if ($dupes.Count) { " Identical copies ignored: $(($dupes | ForEach-Object { $_.Path }) -join ', ')." } else { '' })
    }
    return [pscustomobject]$result
}

function Find-SDDFeatureFolder([Parameter(Mandatory)][string]$Repository, [Parameter(Mandatory)][string]$PbiId) {
    $root = Get-SDDSpecRoot $Repository
    if (-not (Test-Path -LiteralPath $root -PathType Container)) { return $null }
    foreach ($d in [IO.Directory]::GetDirectories($root)) {
        foreach ($f in @('spec.md', 'plan.md')) {
            $p = Join-Path $d $f
            if ((Test-Path -LiteralPath $p -PathType Leaf) -and (@(Get-SDDDeclaredPbiIds (Read-SDDText $p)) -contains $PbiId)) { return [IO.Path]::GetFileName($d) }
        }
    }
    return $null
}

# ------------------------------------------------------------------ state

function Get-SDDWorkFolder([string]$Repository, [string]$PbiId, [string]$Feature) {
    return (Join-Path $Repository "docs/sdd/changes/$PbiId-$Feature")
}

function Find-SDDStateFile([Parameter(Mandatory)][string]$Repository, [Parameter(Mandatory)][string]$Feature, [string]$PbiId) {
    $changes = Join-Path $Repository 'docs/sdd/changes'
    if (-not (Test-Path -LiteralPath $changes -PathType Container)) { return @() }
    $found = New-Object System.Collections.Generic.List[string]
    foreach ($d in [IO.Directory]::GetDirectories($changes)) {
        $f = Join-Path $d 'sdd-state.json'
        if (-not (Test-Path -LiteralPath $f -PathType Leaf)) { continue }
        try { $s = Read-SDDText $f | ConvertFrom-Json } catch { continue }
        if ($s.feature -eq $Feature -and (-not $PbiId -or [string]$s.pbiId -eq $PbiId)) { $found.Add($f) }
    }
    return $found.ToArray()
}

function Read-SDDState([Parameter(Mandatory)][string]$Path) {
    $o = Read-SDDText $Path | ConvertFrom-Json
    $h = [ordered]@{}
    foreach ($p in $o.PSObject.Properties) { $h[$p.Name] = $p.Value }
    return $h
}

function Save-SDDState([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][System.Collections.IDictionary]$State) {
    Write-SDDText $Path (($State | ConvertTo-Json -Depth 10) + "`n")
}

function Add-SDDStageRecord([System.Collections.IDictionary]$State, [string]$Stage, [string]$Result, [string]$Detail) {
    $history = @()
    if ($State.Contains('history') -and $State['history']) { $history = @($State['history']) }
    $history += [pscustomobject]@{ stage = $Stage; result = $Result; at = [DateTime]::UtcNow.ToString('o'); detail = $Detail }
    $State['history'] = @($history | Select-Object -Last 50)
    if ($Result -eq 'PASS') { $State['stage'] = $Stage }
}

# ------------------------------------------------------------------ content validation

$script:SourceBegin = '<!-- sdd:pbi-source:begin -->'
$script:SourceEnd = '<!-- sdd:pbi-source:end -->'

function Get-SDDPbiSourceMarkers { return @($script:SourceBegin, $script:SourceEnd) }

function Remove-SDDVerbatimBlock([string]$Text) {
    # The verbatim PBI may legitimately contain TBD/TODO; it is preserved, not authored by the agent.
    $pattern = [regex]::Escape($script:SourceBegin) + '[\s\S]*?' + [regex]::Escape($script:SourceEnd)
    return [regex]::Replace($Text, $pattern, '')
}

function Get-SDDAcceptanceIds([string]$Text) {
    $ids = New-Object System.Collections.Generic.List[string]
    foreach ($m in [regex]::Matches($Text, '(?i)\b(?:[A-Z][A-Z0-9]+-)?AC[- ]?0*(\d{1,3})\b')) {
        $id = 'AC-' + [int]$m.Groups[1].Value
        if (-not $ids.Contains($id)) { $ids.Add($id) }
    }
    return $ids.ToArray()
}

function Get-SDDSections([string]$Text) {
    # Returns heading -> body for ATX headings (## ...). Nested headings are folded into their parent body.
    $sections = New-Object System.Collections.Generic.List[object]
    $current = $null
    foreach ($line in ($Text -split "`n")) {
        if ($line -match '^\s{0,3}(#{1,4})\s+(.+?)\s*#*\s*$') {
            $level = $Matches[1].Length
            if ($level -le 3) {
                $current = [pscustomobject]@{ Heading = $Matches[2].Trim(); Level = $level; Body = New-Object System.Text.StringBuilder }
                $sections.Add($current); continue
            }
        }
        if ($current) { [void]$current.Body.AppendLine($line) }
    }
    return $sections.ToArray()
}

function Test-SDDSubstantive([string]$Body) {
    $lines = @(($Body -split "`n") | ForEach-Object { $_.Trim() } | Where-Object { $_ -and $_ -notmatch '^\|?\s*[-:| ]+\|?$' })
    $joined = ($lines -join ' ')
    if ($joined -match '(?i)^\s*N/?A\s*[-:.–—]\s*\S.{9,}') { return $true }  # "N/A - reason" is a valid answer
    $letters = ($joined -replace '[^A-Za-z0-9]', '').Length
    return ($letters -ge 40 -and $joined -notmatch '(?i)^\s*(N/?A|none|tbd|todo|pending)\s*\.?\s*$')
}

function Get-SDDRepoPathReferences([string]$Repository, [string]$Text) {
    $refs = New-Object System.Collections.Generic.List[object]
    $seen = New-Object System.Collections.Generic.HashSet[string]
    $pattern = '(?<![\w/.-])((?:[\w.-]+/)+[\w.-]+\.(?:cs|csproj|ts|html|scss|json|graphql|gql|ps1|yml|yaml|sln|slnx|xml|config|md))\b'
    foreach ($m in [regex]::Matches($Text, $pattern)) {
        $p = $m.Groups[1].Value.TrimStart('.', '/')
        if (-not $seen.Add($p)) { continue }
        $exists = (Test-Path -LiteralPath (Join-Path $Repository $p) -PathType Leaf) -or (Test-Path -LiteralPath (Join-Path $Repository "src/$p") -PathType Leaf)
        $lineStart = $Text.LastIndexOf("`n", [Math]::Max(0, $m.Index - 1)) + 1
        $lineEnd = $Text.IndexOf("`n", $m.Index); if ($lineEnd -lt 0) { $lineEnd = $Text.Length }
        $line = $Text.Substring($lineStart, $lineEnd - $lineStart)
        $markedNew = $line -match '(?i)\b(new|create|created|add(ed)?|to be added)\b'
        $refs.Add([pscustomobject]@{ Path = $p; Exists = $exists; MarkedNew = $markedNew })
    }
    return $refs.ToArray()
}

$script:SpecRequirements = [ordered]@{
    'Acceptance criteria'                    = '(?i)acceptance\s+criteria'
    'Existing implementation and evidence'   = '(?i)existing|current\s+(implementation|behaviou?r)|inventory'
    'ADDED / MODIFIED / REMOVED behaviour'   = '(?i)\b(added|modified|removed|delta)\b'
    'Business rules and state transitions'   = '(?i)business\s+rules|state\s+transition|status'
    'API and GraphQL contracts'              = '(?i)contract|graphql|\bapi\b'
    'Validation rules and response envelope' = '(?i)validation|response\s+envelope|error'
    'Testable scenarios'                     = '(?i)scenario|test(able)?\s+cases?'
    'Assumptions, decisions and dependencies'= '(?i)assumption|decision|dependenc'
}
$script:PlanRequirements = [ordered]@{
    'Current implementation inventory'       = '(?i)inventory|current\s+implementation'
    'AC-to-code and AC-to-test traceability' = '(?i)traceab'
    'Affected source files'                  = '(?i)affected|files?\b|components?'
    'Reusable existing logic'                = '(?i)reus'
    'Implementation changes'                 = '(?i)implementation\s+(changes|tasks|steps)|changes\s+required|tasks'
    'Regression impact and test strategy'    = '(?i)regression|test\s+strategy'
    'Dependency and contract checks'         = '(?i)dependenc|contract'
    'Build and test verification'            = '(?i)build|verification'
    'Security and quality checks'            = '(?i)security|quality|sonar'
    'Risks and implementation sequence'      = '(?i)risk|sequence|order'
}

$script:SpecRequirements25 = [ordered]@{
    'PBI sources and attachments'            = '(?i)sources?\s+and\s+attachments|attachments?|pbi\s+sources?'
    'Discrepancies and source conflicts'     = '(?i)discrepanc|conflict'
    'Status and versioning rules'            = '(?i)versioning'
    'Open questions and decisions'           = '(?i)open\s+questions?|decision'
}
$script:PlanRequirements25 = [ordered]@{
    'Implementation impact matrix'           = '(?i)impact\s+matrix'
    'Applicable PR-review lessons'           = '(?i)pr[-\s]?review|review\s+(lessons|rules)'
}
$script:PlanRequirementsBackend = [ordered]@{
    'CQRS handler and validator changes'     = '(?i)cqrs|handlers?|validators?'
    'Derived-product and Paint System considerations' = '(?i)derived|paint\s+system'
}

function Get-SDDTemplateLevel([string]$TemplateVersion) {
    # 24 for features initialised before v2.5 (their documents keep the v2.4 rules), 25 otherwise.
    if (-not $TemplateVersion) { return 24 }
    $v = $null
    if ([version]::TryParse($TemplateVersion, [ref]$v)) { if ($v -lt [version]'2.5.0') { return 24 } }
    return 25
}

function Test-SDDDocument([string]$Repository, [string]$Path, [string]$Kind, [string]$PbiId, [string[]]$RequiredAcIds, [string]$TemplateVersion = '2.4.0', [string]$Role) {
    $problems = New-Object System.Collections.Generic.List[string]
    $warnings = New-Object System.Collections.Generic.List[string]
    $name = [IO.Path]::GetFileName($Path)
    $raw = Read-SDDText $Path
    $authored = Remove-SDDVerbatimBlock $raw
    if (@(Get-SDDDeclaredPbiIds $raw).Count -eq 0) { $problems.Add("$name does not declare 'PBI ID: <number>' in its header.") }
    elseif ($PbiId -and @(Get-SDDDeclaredPbiIds $raw) -notcontains $PbiId) { $problems.Add("$name declares a different PBI ID than $PbiId.") }
    if ($authored -match '(?im)^\s*[-*]?\s*(PENDING|TODO|TBD)\s*:' -or $authored -cmatch '(?m)\|\s*(PENDING|TODO|TBD)\s*(\||$)' -or $authored -match '<(?:Insert|Write|Fill|Actual|Full|PBI-ID|Title|name|description)[^>]{0,40}>') {
        $problems.Add("$name contains unresolved placeholders (PENDING:/TODO:/<...> or a PENDING table cell).")
    }
    $required = [ordered]@{}
    $base = if ($Kind -eq 'spec') { $script:SpecRequirements } else { $script:PlanRequirements }
    foreach ($k in $base.Keys) { $required[$k] = $base[$k] }
    if ((Get-SDDTemplateLevel $TemplateVersion) -ge 25) {
        $extra = if ($Kind -eq 'spec') { @($script:SpecRequirements25) } else { @($script:PlanRequirements25) }
        if ($Kind -ne 'spec' -and $Role -in @('DAB', 'CDMS')) { $extra += $script:PlanRequirementsBackend }
        foreach ($set in $extra) { foreach ($k in $set.Keys) { $required[$k] = $set[$k] } }
    }
    $sections = @(Get-SDDSections $authored)
    foreach ($label in $required.Keys) {
        $matching = @($sections | Where-Object { $_.Heading -match $required[$label] })
        if ($matching.Count -eq 0) { $problems.Add("$name is missing a section for: $label."); continue }
        $body = ($matching | ForEach-Object { $_.Body.ToString() }) -join "`n"
        if (-not (Test-SDDSubstantive $body)) { $problems.Add("$name section '$($matching[0].Heading)' has no substantive content (write the analysis, or 'N/A - <reason>').") }
    }
    if ($Kind -eq 'spec' -and $authored -notmatch '(?is)\bGIVEN\b.+?\bWHEN\b.+?\bTHEN\b') { $problems.Add("$name has no GIVEN/WHEN/THEN scenario.") }
    $refs = @(Get-SDDRepoPathReferences $Repository $authored)
    $existing = @($refs | Where-Object { $_.Exists })
    if ($existing.Count -eq 0) { $problems.Add("$name cites no repository file that exists on disk; analysis must be backed by source evidence.") }
    foreach ($r in ($refs | Where-Object { -not $_.Exists -and -not $_.MarkedNew })) { $warnings.Add("$name cites '$($r.Path)', which does not exist and is not marked as new.") }
    if ($Kind -eq 'plan' -and $RequiredAcIds) {
        $planIds = @(Get-SDDAcceptanceIds $authored)
        $missing = @($RequiredAcIds | Where-Object { $planIds -notcontains $_ })
        if ($missing.Count) { $problems.Add("$name traceability does not cover: $($missing -join ', ').") }
    }
    return [pscustomobject]@{ Problems = $problems.ToArray(); Warnings = $warnings.ToArray(); ExistingRefs = @($existing | ForEach-Object { $_.Path }) }
}

function Test-SDDVerbatimAcceptance([string]$SpecText, [string]$SourceText) {
    # Every acceptance-criterion line of the source PBI must survive unchanged in the spec.
    $norm = { param($s) ($s -replace '\s+', ' ').Trim() }
    $specNorm = & $norm $SpecText
    $missing = New-Object System.Collections.Generic.List[string]
    foreach ($line in ($SourceText -split "`n")) {
        if ($line -match '(?i)\b(?:[A-Z][A-Z0-9]+-)?AC[- ]?\d+\b' -and $line.Trim().Length -gt 8) {
            $l = & $norm ($line -replace '^\s*[-*]\s*', '')
            if (-not $specNorm.Contains($l)) { $missing.Add($l) }
        }
    }
    return $missing.ToArray()
}

function Test-SDDBotIdentity([string]$Name) {
    return ([string]::IsNullOrWhiteSpace($Name) -or $Name -match '(?i)copilot|\bagent\b|\bbot\b|assistant|claude|\bgpt|openai|automation|\bai\b|pending|^<')
}


# ------------------------------------------------------------------ PBI input package and attachments (v2.5)

$script:JunkFiles = @('Thumbs.db', '.DS_Store', 'desktop.ini')
$script:TextExt = @('.md', '.markdown', '.txt', '.csv', '.json', '.xml', '.yml', '.yaml', '.html', '.htm', '.log', '.eml')
$script:ImageExt = @('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp')
$script:OfficeExt = @('.docx', '.xlsx', '.pptx')
$script:ProseExt = @('.md', '.markdown', '.txt', '.docx', '.pdf', '.pptx', '.html', '.htm', '.eml')
$script:ExcludeMarker = '# Added by Akzo SDD Development Builder (local-only files)'

function Get-SDDFileSha256([string]$Path) { return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }

function Get-SDDShortHash([string]$Text) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $b = $sha.ComputeHash($script:Utf8NoBom.GetBytes($Text)) } finally { $sha.Dispose() }
    return (($b | Select-Object -First 2 | ForEach-Object { $_.ToString('X2') }) -join '')
}

function Get-SDDPbiTitle([string]$Text) {
    $t = [regex]::Match($Text, '(?im)^\s*[-*]?\s*\**\s*(?:PBI\s*Title|Title)\s*\**\s*:\s*(.+)$')
    if (-not $t.Success) { $t = [regex]::Match($Text, '(?m)^#\s+(.+)$') }
    if (-not $t.Success) { return '' }
    return ($t.Groups[1].Value.Trim() -replace '^#?\d{4,8}\s*[-–—:]\s*', '').Trim()
}

function Get-SDDPbiPackage([string]$Repository, [string]$PbiId, [string]$Selected) {
    # The package is the PBI's own folder: docs/sdd/pbi-input/<id>/ (or the PBI Builder folder the source came from).
    # Files of other PBIs are never part of it.
    $repo = Resolve-SDDFullPath $Repository
    $idDir = Join-Path $repo "docs/sdd/pbi-input/$PbiId"
    $root = $null
    $sel = $null
    if ($Selected) {
        $sel = Resolve-SDDFullPath (Join-Path $repo $Selected)
        $rel = $Selected.Replace('\', '/')
        $selDir = Split-Path -Parent $sel
        if ($rel -like "docs/sdd/pbi-input/$PbiId/*") { $root = $idDir }
        elseif ($rel -match '^docs/sdd/pbi-sources/([^/]+)/') { $root = Join-Path $repo ('docs/sdd/pbi-sources/' + $Matches[1]) }
        elseif ([IO.Path]::GetFileName($selDir) -match "(^|[^0-9])$PbiId([^0-9]|$)") { $root = $selDir }
    }
    if (-not $root -and (Test-Path -LiteralPath $idDir -PathType Container)) { $root = $idDir }
    if ($root) { $root = Resolve-SDDFullPath $root }
    $files = New-Object System.Collections.Generic.List[string]
    if ($root) {
        foreach ($f in (Get-SDDFiles -Root $root -Include @('*') -MaxDepth 12)) {
            if ($script:JunkFiles -notcontains [IO.Path]::GetFileName($f)) { $files.Add((Resolve-SDDFullPath $f)) }
        }
    }
    if ($sel -and -not $files.Contains($sel) -and (Test-Path -LiteralPath $sel -PathType Leaf)) { $files.Add($sel) }
    return [pscustomobject]@{ Root = $root; RootRel = $(if ($root) { Get-SDDRelativePath $repo $root } else { $null }); Files = $files.ToArray() }
}

function Get-SDDInputRole([string]$PackagePath, [bool]$IsPrimary) {
    if ($IsPrimary) { return 'Primary' }
    $p = $PackagePath.Replace('\', '/')
    $name = [IO.Path]::GetFileName($p)
    $dirs = @($p.Split('/') | Select-Object -SkipLast 1)
    foreach ($d in $dirs) { if ($d -match '(?i)^(history|\.previous|superseded|archive)$') { return 'History' } }
    foreach ($d in $dirs) { if ($d -match '(?i)^attachments?$') { return 'Attachment' } }
    if ($name -match '(?i)^decision') { return 'DecisionLog' }
    if ($name -match '(?i)^open[-_ ]?questions?') { return 'OpenQuestions' }
    if ($name -match '(?i)^evidence') { return 'Evidence' }
    if ($name -match '(?i)^(handoff|readme)([-_. ]|$)') { return 'Metadata' }
    if ($name -match '(?i)original|^(pbi|request)([-_. ]|$)') { return 'Original' }
    if ([IO.Path]::GetExtension($name).ToLowerInvariant() -in @('.md', '.markdown', '.txt')) { return 'Supporting' }
    return 'Attachment'
}

function ConvertFrom-SDDMarkupXml([string]$Xml, [string]$Paragraph) {
    $x = $Xml -replace '<w:tab\b[^>]*/>', "`t" -replace '<(w|a):br\b[^>]*/>', "`n" -replace "</$Paragraph>", "`n" -replace '</w:tc>', ' | ' -replace '</w:tr>', "`n"
    $x = [regex]::Replace($x, '<[^>]+>', '')
    $x = [System.Net.WebUtility]::HtmlDecode($x)
    return ([regex]::Replace($x, '(\r?\n[ \t]*){3,}', "`n`n")).Trim()
}

function Get-SDDOfficeText([string]$Path, [string]$Ext) {
    Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    $zip = $null
    try { $zip = [IO.Compression.ZipFile]::OpenRead($Path) }
    catch { throw "Not a readable Office file (password-protected or damaged): $($_.Exception.Message.Split("`n")[0])" }
    try {
        $read = {
            param($name)
            $e = $zip.GetEntry($name)
            if (-not $e) { return $null }
            $sr = New-Object IO.StreamReader($e.Open(), [Text.Encoding]::UTF8)
            try { return $sr.ReadToEnd() } finally { $sr.Dispose() }
        }
        if ($Ext -eq '.docx') {
            $xml = & $read 'word/document.xml'
            if ($null -eq $xml) { throw 'word/document.xml not found (not a Word document).' }
            return (ConvertFrom-SDDMarkupXml $xml 'w:p')
        }
        if ($Ext -eq '.pptx') {
            $slides = @($zip.Entries | Where-Object { $_.FullName -match '^ppt/slides/slide(\d+)\.xml$' } | Sort-Object { [int]([regex]::Match($_.FullName, '(\d+)\.xml$').Groups[1].Value) })
            if ($slides.Count -eq 0) { throw 'No slides found (not a PowerPoint document).' }
            $sb = New-Object System.Text.StringBuilder
            $n = 0
            foreach ($s in $slides) { $n++; [void]$sb.AppendLine("## Slide $n"); [void]$sb.AppendLine((ConvertFrom-SDDMarkupXml (& $read $s.FullName) 'a:p')); [void]$sb.AppendLine() }
            return $sb.ToString().Trim()
        }
        # .xlsx: shared strings + every sheet, one line per row, cells separated by ' | '
        $shared = New-Object System.Collections.Generic.List[string]
        $ss = & $read 'xl/sharedStrings.xml'
        if ($ss) {
            foreach ($si in [regex]::Matches($ss, '(?s)<si\b[^>]*>(.*?)</si>')) {
                $shared.Add([System.Net.WebUtility]::HtmlDecode((([regex]::Matches($si.Groups[1].Value, '(?s)<t\b[^>]*>(.*?)</t>') | ForEach-Object { $_.Groups[1].Value }) -join '')))
            }
        }
        $wb = & $read 'xl/workbook.xml'
        $rels = & $read 'xl/_rels/workbook.xml.rels'
        if (-not $wb) { throw 'xl/workbook.xml not found (not an Excel workbook).' }
        $targets = @{}
        if ($rels) {
            foreach ($m in [regex]::Matches($rels, '<Relationship\b([^>]*)/?>')) {
                $id = [regex]::Match($m.Groups[1].Value, '\bId="([^"]+)"').Groups[1].Value
                $tg = [regex]::Match($m.Groups[1].Value, '\bTarget="([^"]+)"').Groups[1].Value
                if ($id) { $targets[$id] = $tg }
            }
        }
        $sb = New-Object System.Text.StringBuilder
        foreach ($m in [regex]::Matches($wb, '<sheet\b([^>]*)/?>')) {
            $name = [System.Net.WebUtility]::HtmlDecode([regex]::Match($m.Groups[1].Value, '\bname="([^"]*)"').Groups[1].Value)
            $rid = [regex]::Match($m.Groups[1].Value, '\br:id="([^"]+)"').Groups[1].Value
            $tg = $targets[$rid]
            if (-not $tg) { continue }
            $entry = if ($tg.StartsWith('/')) { $tg.TrimStart('/') } else { 'xl/' + $tg }
            $sheet = & $read $entry
            if (-not $sheet) { continue }
            [void]$sb.AppendLine("## Sheet: $name")
            foreach ($row in [regex]::Matches($sheet, '(?s)<row\b[^>]*>(.*?)</row>')) {
                $cells = New-Object System.Collections.Generic.List[string]
                foreach ($c in [regex]::Matches($row.Groups[1].Value, '(?s)<c\b([^>]*?)(?:/>|>(.*?)</c>)')) {
                    $attrs = $c.Groups[1].Value; $inner = $c.Groups[2].Value
                    $type = [regex]::Match($attrs, '\bt="([^"]+)"').Groups[1].Value
                    $v = [regex]::Match($inner, '(?s)<v>(.*?)</v>').Groups[1].Value
                    $val = switch ($type) {
                        's' { if ($v -match '^\d+$' -and [int]$v -lt $shared.Count) { $shared[[int]$v] } else { '' } }
                        'inlineStr' { [System.Net.WebUtility]::HtmlDecode((([regex]::Matches($inner, '(?s)<t\b[^>]*>(.*?)</t>') | ForEach-Object { $_.Groups[1].Value }) -join '')) }
                        'b' { if ($v -eq '1') { 'TRUE' } else { 'FALSE' } }
                        default { [System.Net.WebUtility]::HtmlDecode($v) }
                    }
                    $cells.Add([string]$val)
                }
                $line = ($cells -join ' | ').Trim(' ', '|')
                if ($line) { [void]$sb.AppendLine($line) }
            }
            [void]$sb.AppendLine()
        }
        return $sb.ToString().Trim()
    } finally { $zip.Dispose() }
}

function Get-SDDImageInfo([string]$Path) {
    $buf = New-Object byte[] 65536
    $fs = [IO.File]::OpenRead($Path)
    try { $n = $fs.Read($buf, 0, $buf.Length) } finally { $fs.Dispose() }
    $be16 = { param($i) ([int]$buf[$i] * 256) + [int]$buf[$i + 1] }
    $be32 = { param($i) ([long]$buf[$i] * 16777216) + ([long]$buf[$i + 1] * 65536) + ([long]$buf[$i + 2] * 256) + [long]$buf[$i + 3] }
    if ($n -ge 24 -and $buf[0] -eq 0x89 -and $buf[1] -eq 0x50 -and $buf[2] -eq 0x4E -and $buf[3] -eq 0x47) { return [pscustomobject]@{ Valid = $true; Format = 'PNG'; Width = & $be32 16; Height = & $be32 20 } }
    if ($n -ge 10 -and $buf[0] -eq 0x47 -and $buf[1] -eq 0x49 -and $buf[2] -eq 0x46) { return [pscustomobject]@{ Valid = $true; Format = 'GIF'; Width = [int]$buf[6] + 256 * [int]$buf[7]; Height = [int]$buf[8] + 256 * [int]$buf[9] } }
    if ($n -ge 26 -and $buf[0] -eq 0x42 -and $buf[1] -eq 0x4D) { return [pscustomobject]@{ Valid = $true; Format = 'BMP'; Width = [BitConverter]::ToInt32($buf, 18); Height = [Math]::Abs([BitConverter]::ToInt32($buf, 22)) } }
    if ($n -ge 12 -and $buf[0] -eq 0x52 -and $buf[1] -eq 0x49 -and $buf[8] -eq 0x57 -and $buf[9] -eq 0x45) { return [pscustomobject]@{ Valid = $true; Format = 'WEBP'; Width = 0; Height = 0 } }
    if ($n -ge 4 -and $buf[0] -eq 0xFF -and $buf[1] -eq 0xD8) {
        $i = 2
        while ($i + 9 -lt $n) {
            if ($buf[$i] -ne 0xFF) { $i++; continue }
            $marker = [int]$buf[$i + 1]
            if ($marker -in @(0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF)) { return [pscustomobject]@{ Valid = $true; Format = 'JPEG'; Width = & $be16 ($i + 7); Height = & $be16 ($i + 5) } }
            if ($marker -eq 0xD8 -or $marker -eq 0x01 -or ($marker -ge 0xD0 -and $marker -le 0xD7) -or $marker -eq 0xFF) { $i += 1; continue }
            $i += 2 + (& $be16 ($i + 2))
        }
        return [pscustomobject]@{ Valid = $true; Format = 'JPEG'; Width = 0; Height = 0 }
    }
    return [pscustomobject]@{ Valid = $false; Format = ''; Width = 0; Height = 0 }
}

function Get-SDDDocumentText {
    # Returns Status: Read | Extracted | RequiresAgentReview | Unreadable | Unsupported, with the reason.
    # Nothing is ever reported as analysed unless its text was actually obtained.
    param([Parameter(Mandatory)][string]$Path, [switch]$NoExternalTools)
    $ext = [IO.Path]::GetExtension($Path).ToLowerInvariant()
    $r = [ordered]@{ Status = ''; Text = $null; Reason = ''; Method = '' }
    if ((Get-Item -LiteralPath $Path).Length -eq 0) { $r.Status = 'Unreadable'; $r.Reason = 'File is empty (0 bytes).'; return [pscustomobject]$r }
    try {
        if ($script:TextExt -contains $ext) {
            $t = Read-SDDText $Path
            if ($t.IndexOf([char]0) -ge 0) { $r.Status = 'Unreadable'; $r.Reason = 'Binary content in a text file.'; return [pscustomobject]$r }
            $r.Status = 'Read'; $r.Text = $t; $r.Method = 'text'
            if ($ext -eq '.json') { try { $null = $t | ConvertFrom-Json } catch { $r.Reason = 'Invalid JSON; read as plain text.' } }
        }
        elseif ($script:OfficeExt -contains $ext) {
            $t = Get-SDDOfficeText $Path $ext
            if (-not $t -or -not $t.Trim()) { $r.Status = 'Unreadable'; $r.Reason = 'The document contains no extractable text.' }
            else { $r.Status = 'Extracted'; $r.Text = $t; $r.Method = $ext.TrimStart('.') + '-xml' }
        }
        elseif ($ext -eq '.pdf') {
            $head = New-Object byte[] 5
            $fs = [IO.File]::OpenRead($Path); try { [void]$fs.Read($head, 0, 5) } finally { $fs.Dispose() }
            if ([Text.Encoding]::ASCII.GetString($head) -ne '%PDF-') { $r.Status = 'Unreadable'; $r.Reason = 'Not a valid PDF file.'; return [pscustomobject]$r }
            $tool = Get-Command pdftotext -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($NoExternalTools -or $env:SDD_DISABLE_EXTERNAL_EXTRACTORS -eq '1' -or -not $tool) {
                $r.Status = 'RequiresAgentReview'
                $r.Reason = 'No PDF text extractor on this machine. Open the PDF with a PDF-capable tool and record it as Reviewed, or as Unreadable with the reason.'
                return [pscustomobject]$r
            }
            $tmp = [IO.Path]::GetTempFileName()
            try {
                & $tool.Source -layout -enc UTF-8 $Path $tmp 2>$null | Out-Null
                $code = $LASTEXITCODE
                if ($code -ne 0) { $r.Status = 'Unreadable'; $r.Reason = "pdftotext failed (exit $code): encrypted or damaged PDF."; return [pscustomobject]$r }
                $t = [IO.File]::ReadAllText($tmp, $script:Utf8NoBom)
            } finally { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
            if (($t -replace '\s', '').Length -lt 20) { $r.Status = 'RequiresAgentReview'; $r.Reason = 'The PDF has no text layer (scanned image?). Review it visually.' }
            else { $r.Status = 'Extracted'; $r.Text = $t.Trim(); $r.Method = 'pdftotext' }
        }
        elseif ($script:ImageExt -contains $ext) {
            $info = Get-SDDImageInfo $Path
            if (-not $info.Valid) { $r.Status = 'Unreadable'; $r.Reason = "Not a valid image file (extension $ext)." }
            else {
                $dims = if ($info.Width -gt 0) { " $($info.Width)x$($info.Height)" } else { '' }
                $r.Status = 'RequiresAgentReview'; $r.Method = 'image'
                $r.Reason = "$($info.Format) image$dims. Review it with an image-capable tool and record what it shows, or Unreadable with the reason."
            }
        }
        else {
            $r.Status = 'Unsupported'
            $r.Reason = if ($ext -in @('.zip', '.7z', '.rar')) { 'Nested archive. Add its contents with tools/Add-SDDPbiInput.ps1.' } else { "Format '$ext' is not supported. Convert it to PDF, PNG or text, or summarise it in the refined PBI." }
        }
    } catch {
        $r.Status = 'Unreadable'; $r.Text = $null; $r.Reason = $_.Exception.Message.Split("`n")[0]
    }
    return [pscustomobject]$r
}

function Get-SDDCriteriaRefs([string]$Text) {
    $set = New-Object 'System.Collections.Generic.SortedSet[int]'
    foreach ($m in [regex]::Matches($Text, '(?i)\bAC[- ]?0*(\d{1,3})\s*(?:to|through|–|—)\s*(?:AC[- ]?)?0*(\d{1,3})\b')) {
        $a = [int]$m.Groups[1].Value; $b = [int]$m.Groups[2].Value
        if ($b -ge $a -and ($b - $a) -le 50) { for ($i = $a; $i -le $b; $i++) { [void]$set.Add($i) } }
    }
    foreach ($m in [regex]::Matches($Text, '(?i)\b(?:[A-Z][A-Z0-9]+-)?AC[- ]?0*(\d{1,3})\b')) { [void]$set.Add([int]$m.Groups[1].Value) }
    return @($set | ForEach-Object { "AC-$_" })
}

function Get-SDDTableRows([string]$Text, [string]$IdPattern) {
    # Markdown table rows whose first cell matches the ID pattern; returns the ID number and the remaining cells.
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($line in ($Text -split "`n")) {
        $m = [regex]::Match($line, '^\s*\|\s*(?:[A-Z][A-Z0-9]*-)?' + $IdPattern + '0*(\d{1,3})\s*\|(.*)$')
        if (-not $m.Success) { continue }
        $cells = @($m.Groups[2].Value.TrimEnd().TrimEnd('|').Split('|') | ForEach-Object { $_.Trim() })
        $rows.Add([pscustomobject]@{ Number = [int]$m.Groups[1].Value; Cells = $cells })
    }
    return $rows.ToArray()
}

function ConvertTo-SDDPlainItem($Item) {
    $o = [ordered]@{}
    foreach ($p in $Item.PSObject.Properties) { if ($p.Name -notin @('full', 'text')) { $o[$p.Name] = $p.Value } }
    return [pscustomobject]$o
}

function New-SDDPbiInventory {
    # Inventories every file of ONE PBI's input package, extracts what can be extracted, and lists the
    # deterministic discrepancies the specification must address. Writes only to the SDD working folder.
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Repository,
        [Parameter(Mandatory)][string]$PbiId,
        [string]$Selected,
        [string]$WorkFolder,
        [switch]$Write,
        [switch]$NoExternalTools
    )
    $repo = Resolve-SDDFullPath $Repository
    $pkg = Get-SDDPbiPackage -Repository $repo -PbiId $PbiId -Selected $Selected
    $baseline = Read-SDDInputBaseline $repo $PbiId
    $primaryFull = if ($Selected) { Resolve-SDDFullPath (Join-Path $repo $Selected) } else { $null }
    $rootFull = $pkg.Root
    $roleOrder = @{ Primary = 0; Original = 1; DecisionLog = 2; OpenQuestions = 3; Evidence = 4; Supporting = 5; Attachment = 6; Metadata = 7; History = 8 }
    $items = New-Object System.Collections.Generic.List[object]
    foreach ($f in $pkg.Files) {
        $pkgRel = if ($rootFull -and $f.StartsWith($rootFull)) { Get-SDDRelativePath $rootFull $f } else { [IO.Path]::GetFileName($f) }
        $role = Get-SDDInputRole $pkgRel ([bool]($primaryFull -and $f -eq $primaryFull))
        $relevance = switch ($role) { 'Primary' { 'Primary' } 'History' { 'Superseded' } 'Metadata' { 'Metadata' } default { 'Supporting' } }
        $items.Add([pscustomobject][ordered]@{
                path = Get-SDDRelativePath $repo $f; packagePath = $pkgRel; name = [IO.Path]::GetFileName($f)
                type = [IO.Path]::GetExtension($f).TrimStart('.').ToLowerInvariant(); bytes = (Get-Item -LiteralPath $f).Length
                sha256 = Get-SDDFileSha256 $f; role = $role; relevance = $relevance
                status = ''; reason = ''; method = ''; textPath = $null; textChars = 0
                declaredPbiIds = @(); criteria = @(); duplicateOf = $null; editedAfterImport = $false; full = $f; text = $null
            })
    }
    # Root files before nested ones, so the first copy of a duplicate is the shallowest one.
    if ($baseline) {
        foreach ($it in $items) {
            if ($it.role -ne 'History' -and $baseline.ContainsKey($it.packagePath) -and $baseline[$it.packagePath] -ne $it.sha256) { $it.editedAfterImport = $true }
        }
    }
    $sorted = @($items | Sort-Object @{ Expression = { $roleOrder[$_.role] } }, @{ Expression = { $_.packagePath.Split('/').Count } }, @{ Expression = { $_.packagePath } })
    $seenHash = @{}
    foreach ($it in $sorted) {
        if ($it.role -eq 'History') { $it.status = 'History'; $it.reason = 'PBI Builder history snapshot: retained, not analysed as requirements.'; continue }
        if ($seenHash.ContainsKey($it.sha256)) { $it.status = 'Duplicate'; $it.duplicateOf = $seenHash[$it.sha256]; $it.reason = "Identical to $($seenHash[$it.sha256]); not analysed twice."; continue }
        $seenHash[$it.sha256] = $it.packagePath
        $extractor = Get-Command pdftotext -ErrorAction SilentlyContinue | Select-Object -First 1
        $extractorIdentity = if ($extractor -and $it.type -eq 'pdf') { $extractor.Source + '|' + (Get-SDDFileSha256 $extractor.Source) } else { 'builtin' }
        $cacheKey = Get-SDDTextSha256 ("$(Get-SDDVersion)|$($it.sha256)|$($it.type)|$NoExternalTools|$extractorIdentity")
        $cachePath = Join-Path $repo ".sdd-builder/cache/extraction/$cacheKey.json"
        $doc = $null
        if (Test-Path -LiteralPath $cachePath) {
            try {
                $cached = Read-SDDText $cachePath | ConvertFrom-Json
                if ($cached.key -eq $cacheKey -and $cached.payloadHash -eq (Get-SDDTextSha256 $cached.payload)) { $doc = $cached.payload | ConvertFrom-Json }
            } catch { $doc = $null }
        }
        if (-not $doc) {
            $doc = Get-SDDDocumentText -Path $it.full -NoExternalTools:$NoExternalTools
            if ($Write -and $doc.Status -in @('Read','Extracted')) {
                $payload = $doc | ConvertTo-Json -Depth 6 -Compress
                Write-SDDText $cachePath (([ordered]@{ key = $cacheKey; payloadHash = Get-SDDTextSha256 $payload; payload = $payload } | ConvertTo-Json -Depth 8) + "`n")
            }
        }
        $it.status = $doc.Status; $it.reason = $doc.Reason; $it.method = $doc.Method; $it.text = $doc.Text
        if ($doc.Text) {
            $it.textChars = $doc.Text.Length
            $it.declaredPbiIds = @(Get-SDDDeclaredPbiIds $doc.Text)
            $it.criteria = @(Get-SDDCriteriaRefs $doc.Text)
            if ($it.role -ne 'Primary' -and $it.declaredPbiIds.Count -gt 0 -and $it.declaredPbiIds -notcontains $PbiId) {
                $it.status = 'ForeignPbi'; $it.reason = "Declares PBI $($it.declaredPbiIds -join ', '), not $PbiId. Excluded from analysis to prevent cross-PBI contamination."
            }
        }
    }

    # ------------------------------------------------ discrepancies (deterministic; never resolved automatically)
    $disc = New-Object System.Collections.Generic.List[object]
    $addDisc = { param($id, $type, $files, $detail, $action) $disc.Add([pscustomobject][ordered]@{ id = $id; type = $type; files = @($files); detail = $detail; action = $action }) }
    $primary = @($sorted | Where-Object { $_.role -eq 'Primary' }) | Select-Object -First 1
    $analysed = @($sorted | Where-Object { $_.text -and $_.status -notin @('ForeignPbi', 'Duplicate', 'History') -and $_.role -ne 'Metadata' })
    $approval = $null
    if ($primary -and $primary.text) {
        $approval = Get-SDDPbiApprovalState $primary.text
        if (-not $approval.Approved) {
            & $addDisc 'PX-APPROVAL' 'PbiNotApproved' @($primary.packagePath) "The refined PBI is not business-approved: $($approval.Summary)." 'Analysis may continue. Implementation approval must explicitly acknowledge this, or the PO approves the refined PBI first.'
        }
    }
    # Question status: OPEN-QUESTIONS tables against mentions elsewhere
    $qStatus = @{}
    foreach ($oq in @($analysed | Where-Object { $_.role -eq 'OpenQuestions' })) {
        foreach ($row in (Get-SDDTableRows $oq.text 'Q-?')) {
            $statusCell = @($row.Cells | Where-Object { $_ }) | Select-Object -Last 1
            $state = if ($statusCell -match '(?i)^(resolved|closed|answered|not\s+relevant|decided)') { 'Resolved' } elseif ($statusCell -match '(?i)^(open|pending|blocking|unresolved)') { 'Open' } else { '' }
            if ($state) { $qStatus['Q-{0:D2}' -f $row.Number] = [pscustomobject]@{ State = $state; File = $oq.packagePath; Cell = $statusCell; Question = $row.Cells[0] } }
        }
    }
    foreach ($q in ($qStatus.Keys | Sort-Object { [int]($_ -replace '\D', '') })) {
        $info = $qStatus[$q]; $num = [int]($q -replace '\D', ''); $id = 'PX-Q{0:D2}' -f $num
        if ($info.State -eq 'Open') {
            & $addDisc $id 'OpenQuestion' @($info.File) "$($info.File) lists $q as open: $($info.Question)" 'Record the question and its impact in spec.md; it blocks only if it changes a contract, persisted value, error or test expectation.'
            continue
        }
        $pattern = '(?i)\bQ-?0*' + $num + '\b\s*(?:is\s+|remains\s+|still\s+)?(pending|open|unresolved|unanswered)|\b(pending|open|unresolved)\s+(?:question\s+)?Q-?0*' + $num + '\b'
        $mentions = @($analysed | Where-Object { $_.role -ne 'OpenQuestions' -and $_.text -match $pattern })
        if ($mentions.Count) {
            $where = ($mentions | ForEach-Object { $_.packagePath }) -join ', '
            & $addDisc $id 'QuestionStatusConflict' (@($mentions | ForEach-Object { $_.packagePath }) + $info.File) "$where says $q is pending; $($info.File) records it as resolved ('$($info.Cell)')." 'State which source is current in spec.md; follow the resolved decision only if it is approved.'
        }
    }
    # Decisions that are not approved
    foreach ($dl in @($analysed | Where-Object { $_.role -eq 'DecisionLog' })) {
        foreach ($row in (Get-SDDTableRows $dl.text 'D-?')) {
            $statusCell = @($row.Cells | Where-Object { $_ -match '(?i)^(proposed|pending|draft|open|tentative|under\s+review)$' }) | Select-Object -First 1
            if (-not $statusCell) { continue }
            $affects = @($row.Cells | Where-Object { $_ }) | Select-Object -Last 1
            & $addDisc ('PX-D{0:D2}' -f $row.Number) 'DecisionNotApproved' @($dl.packagePath) "$($dl.packagePath): decision D-$('{0:D2}' -f $row.Number) is $statusCell, not approved: $($row.Cells[0]) Affects: $affects." 'Do not treat it as an approved requirement; record it as an assumption or ask the PO.'
        }
    }
    if ($primary -and $primary.text) {
        # Acceptance criteria referenced by supporting files but not defined in the refined PBI
        $defined = @(Get-SDDAcceptanceIds $primary.text)
        if ($defined.Count) {
            $unknown = [ordered]@{}
            foreach ($it in @($analysed | Where-Object { $_.role -ne 'Primary' })) {
                foreach ($ac in $it.criteria) {
                    if ($defined -contains $ac) { continue }
                    if (-not $unknown.Contains($ac)) { $unknown[$ac] = New-Object System.Collections.Generic.List[string] }
                    if (-not $unknown[$ac].Contains($it.packagePath)) { $unknown[$ac].Add($it.packagePath) }
                }
            }
            foreach ($ac in @($unknown.Keys | Sort-Object { [int]($_ -replace '\D', '') })) {
                & $addDisc ('PX-AC{0:D2}' -f [int]($ac -replace '\D', '')) 'UnknownCriterion' $unknown[$ac].ToArray() "$($unknown[$ac] -join ', ') reference $ac, which the refined PBI does not define." 'Attachments add no scope by themselves: ignore it, or ask whether the refined PBI is incomplete.'
            }
        }
        # Exact quoted text (messages, rules) that exists only in a supporting document
        $norm = { param($t) (($t -replace '\s+', ' ').Trim().TrimEnd('.', ' ')).ToLowerInvariant() }
        $primaryNorm = & $norm $primary.text
        $quotes = [ordered]@{}
        foreach ($it in @($analysed | Where-Object { $_.role -in @('Original', 'Supporting', 'Evidence', 'Attachment') -and ('.' + $_.type) -in $script:ProseExt })) {
            foreach ($m in [regex]::Matches($it.text, '`([^`\r\n]{25,300})`|"([^"\r\n]{25,300})"|“([^”\r\n]{25,300})”')) {
                $q = (@($m.Groups[1].Value, $m.Groups[2].Value, $m.Groups[3].Value) | Where-Object { $_ }) | Select-Object -First 1
                if (($q -split '\s+').Count -lt 4 -or $q -match '[\\/]|^https?:') { continue }
                $n = & $norm $q
                if ($primaryNorm.Contains($n)) { continue }
                if (-not $quotes.Contains($n)) { $quotes[$n] = [pscustomobject]@{ Text = $q.Trim(); Files = (New-Object System.Collections.Generic.List[string]) } }
                if (-not $quotes[$n].Files.Contains($it.packagePath)) { $quotes[$n].Files.Add($it.packagePath) }
            }
        }
        foreach ($k in @($quotes.Keys)) {
            $qq = $quotes[$k]
            & $addDisc ('PX-TEXT-' + (Get-SDDShortHash $k)) 'TextOnlyInSupportingSource' $qq.Files.ToArray() "Exact text found only in $($qq.Files -join ', '), not in the refined PBI: '$($qq.Text)'" 'If it is the wording the PBI refers to (for example a message), use it verbatim and cite the file; otherwise record why it does not apply.'
        }
    }
    # Files referenced by name in the PBI documents but absent from the package (never assumed or invented)
    $leaves = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($it in $sorted) { [void]$leaves.Add($it.name) }
    $missing = [ordered]@{}
    foreach ($it in @($analysed | Where-Object { $_.role -in @('Primary', 'Original', 'DecisionLog', 'OpenQuestions', 'Evidence', 'Supporting') })) {
        foreach ($m in [regex]::Matches($it.text, '(?i)(?<![\w./\\-])((?:attachments?/)?[\w()-][\w.()-]{0,120}\.(?:pdf|docx?|xlsx?|pptx?|png|jpe?g|gif|bmp|csv|json|txt|msg|eml|zip|md))(?![\w-])')) {
            $leaf = ($m.Groups[1].Value -replace '^(?i)attachments?/', '')
            if ($leaves.Contains($leaf)) { continue }
            $k = $leaf.ToLowerInvariant()
            if (-not $missing.Contains($k)) { $missing[$k] = [pscustomobject]@{ Name = $leaf; Files = (New-Object System.Collections.Generic.List[string]) } }
            if (-not $missing[$k].Files.Contains($it.packagePath)) { $missing[$k].Files.Add($it.packagePath) }
        }
    }
    foreach ($k in @($missing.Keys)) {
        $mm = $missing[$k]
        & $addDisc ('PX-MISSING-' + (Get-SDDShortHash $k)) 'ReferencedFileMissing' $mm.Files.ToArray() "$($mm.Files -join ', ') reference '$($mm.Name)', which is not in the PBI input folder." 'Add the file from the PBI attachments, or record that it is not needed. Never assume its content.'
    }
    foreach ($it in @($sorted | Where-Object { $_.editedAfterImport })) {
        & $addDisc ('PX-EDITED-' + (Get-SDDShortHash $it.packagePath)) 'InputEditedAfterImport' @($it.packagePath) "$($it.packagePath) was changed after it was imported (expected SHA-256 $($baseline[$it.packagePath].Substring(0, 12))..., now $($it.sha256.Substring(0, 12))...). PBI inputs are evidence and must never be edited." 'Restore the original with tools/Get-SDDStatus.ps1 -Fix (pristine copy or recorded download), or tools/Add-SDDPbiInput.ps1 <original package> -UpdateChanged. A real requirement change comes as a new PBI Builder export.'
    }
    foreach ($it in @($sorted | Where-Object { $_.status -eq 'ForeignPbi' })) {
        & $addDisc ('PX-FOREIGN-' + (Get-SDDShortHash $it.packagePath)) 'OtherPbiDocument' @($it.packagePath) "$($it.packagePath) declares PBI $($it.declaredPbiIds -join ', ') and was excluded." 'Move it to its own PBI folder, or confirm it belongs to this PBI by correcting its header.'
    }

    # ------------------------------------------------ fingerprint (binds approval to the exact input package)
    $fpLines = @($sorted | ForEach-Object { "$($_.packagePath)|$($_.sha256)" } | Sort-Object)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $fp = (($sha.ComputeHash($script:Utf8NoBom.GetBytes(($fpLines -join "`n"))) | ForEach-Object { $_.ToString('x2') }) -join '') } finally { $sha.Dispose() }

    $count = { param($s) @($sorted | Where-Object { $_.status -eq $s }).Count }
    if ($Write -and $WorkFolder) {
        $extractDir = Join-Path $WorkFolder 'pbi-extracted'
        if (Test-Path -LiteralPath $extractDir) { Remove-Item -LiteralPath $extractDir -Recurse -Force }
        foreach ($it in $sorted) {
            if ($it.status -eq 'Extracted' -and $it.text) {
                $safe = ($it.packagePath -replace '[\\/:*?"<>|]', '__') + '.txt'
                $target = Join-Path $extractDir $safe
                $text = $it.text
                if ($text.Length -gt 2000000) { $text = $text.Substring(0, 2000000) + "`n[truncated at 2,000,000 characters]" }
                Write-SDDText $target ("# Extracted text of $($it.path) ($($it.method))`n`n" + $text + "`n")
                $it.textPath = Get-SDDRelativePath $repo $target
            } elseif ($it.status -in @('Read', 'ForeignPbi') -and $it.text) { $it.textPath = $it.path }
        }
    }
    $inv = [ordered]@{
        tool = "SDD.Common v$(Get-SDDVersion)"; generatedAtUtc = [DateTime]::UtcNow.ToString('o'); pbiId = $PbiId
        packageRoot = $pkg.RootRel; primary = $(if ($primary) { $primary.path } else { $null })
        primaryApproval = $(if ($approval) { [pscustomobject][ordered]@{ approved = $approval.Approved; summary = $approval.Summary; fields = $approval.Fields } } else { [pscustomobject][ordered]@{ approved = $false; summary = 'No refined PBI available.'; fields = @() } })
        fingerprint = $fp
        summary = [pscustomobject][ordered]@{
            files = $sorted.Count; read = (& $count 'Read'); extracted = (& $count 'Extracted'); requiresAgentReview = (& $count 'RequiresAgentReview')
            unreadable = (& $count 'Unreadable'); unsupported = (& $count 'Unsupported'); duplicates = (& $count 'Duplicate'); otherPbi = (& $count 'ForeignPbi')
            history = (& $count 'History'); edited = @($sorted | Where-Object { $_.editedAfterImport }).Count; discrepancies = $disc.Count
        }
        items = @($sorted | ForEach-Object { ConvertTo-SDDPlainItem $_ })
        discrepancies = $disc.ToArray()
    }
    $result = [pscustomobject]$inv
    if ($Write -and $WorkFolder) {
        Write-SDDText (Join-Path $WorkFolder 'pbi-inventory.json') (($result | ConvertTo-Json -Depth 6) + "`n")
        Write-SDDText (Join-Path $WorkFolder 'pbi-inventory.md') (ConvertTo-SDDInventoryMarkdown $result)
    }
    return $result
}

function ConvertTo-SDDInventoryMarkdown($Inv) {
    $esc = { param($t) ([string]$t -replace '\|', '/' -replace '\r?\n', ' ') }
    $s = $Inv.summary
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine("# PBI input inventory - $($Inv.pbiId)")
    [void]$sb.AppendLine()
    [void]$sb.AppendLine("Generated $($Inv.generatedAtUtc) by $($Inv.tool). The refined PBI is the source of truth; attachments are supporting evidence and add no scope by themselves.")
    [void]$sb.AppendLine()
    [void]$sb.AppendLine("- Package: ``$($Inv.packageRoot)`` ($($s.files) files)")
    [void]$sb.AppendLine("- Primary: ``$($Inv.primary)`` - $(if ($Inv.primaryApproval.approved) { 'approved' } else { 'NOT business-approved' }) ($($Inv.primaryApproval.summary))")
    [void]$sb.AppendLine("- Read $($s.read), extracted $($s.extracted), needs agent review $($s.requiresAgentReview), unreadable $($s.unreadable), unsupported $($s.unsupported), duplicates $($s.duplicates), other-PBI files excluded $($s.otherPbi), history snapshots $($s.history)")
    [void]$sb.AppendLine("- Discrepancies: $($s.discrepancies)")
    [void]$sb.AppendLine("- Fingerprint: ``$($Inv.fingerprint)``")
    [void]$sb.AppendLine()
    [void]$sb.AppendLine('## Files')
    [void]$sb.AppendLine()
    [void]$sb.AppendLine('| File | Type | Role | Status | Criteria | Notes |')
    [void]$sb.AppendLine('|---|---|---|---|---|---|')
    foreach ($it in $Inv.items) {
        $note = & $esc $(if ($it.reason) { $it.reason } elseif ($it.textPath -and $it.textPath -ne $it.path) { "Text: $($it.textPath)" } else { '' })
        [void]$sb.AppendLine("| ``$($it.packagePath)`` | $($it.type) | $($it.role) | $($it.status) | $((@($it.criteria) -join ', ')) | $note |")
    }
    [void]$sb.AppendLine()
    [void]$sb.AppendLine('## Discrepancies')
    [void]$sb.AppendLine()
    if (@($Inv.discrepancies).Count -eq 0) { [void]$sb.AppendLine('None found by the deterministic checks. Semantic conflicts still need the agent''s review.') }
    else {
        [void]$sb.AppendLine('| ID | Type | Detail | Required action |')
        [void]$sb.AppendLine('|---|---|---|---|')
        foreach ($d in $Inv.discrepancies) { [void]$sb.AppendLine("| $($d.id) | $($d.type) | $(& $esc $d.detail) | $(& $esc $d.action) |") }
    }
    [void]$sb.AppendLine()
    [void]$sb.AppendLine('## Agent checklist')
    [void]$sb.AppendLine()
    [void]$sb.AppendLine('1. Read every file marked Read or Extracted (extracted text is under `pbi-extracted/` in this folder).')
    [void]$sb.AppendLine('2. Open every RequiresAgentReview file with your own file or image tool. In spec.md "PBI sources and attachments" record it as Reviewed (and what it shows), Unreadable (with the reason) or Not relevant.')
    [void]$sb.AppendLine('3. Cite every supporting file by name in spec.md and say what it contributes, including Unreadable and Unsupported files.')
    [void]$sb.AppendLine('4. Address every discrepancy ID in spec.md: resolved (with its source), or recorded as an open question. Never reconcile conflicting requirements silently.')
    return $sb.ToString()
}

function Get-SDDInventoryProblems {
    # Traceability between the PBI input package and spec.md. Used by the AnalysisComplete gate.
    param([Parameter(Mandatory)]$Inventory, [Parameter(Mandatory)][AllowEmptyString()][string]$SpecAuthored)
    $problems = New-Object System.Collections.Generic.List[string]
    $spec = $SpecAuthored.Replace('\', '/')
    $lines = $spec -split "`n"
    $required = @($Inventory.items | Where-Object { $_.role -notin @('History', 'Metadata') -and $_.status -ne 'Duplicate' })
    $leafCount = @{}
    foreach ($it in $required) { $k = $it.name.ToLowerInvariant(); $leafCount[$k] = 1 + [int]$leafCount[$k] }
    foreach ($it in $required) {
        $tokens = @($it.path, $it.packagePath)
        if ($leafCount[$it.name.ToLowerInvariant()] -eq 1) { $tokens += $it.name }
        $patterns = @($tokens | Select-Object -Unique | ForEach-Object { '(?i)(?<![\w./\\-])' + [regex]::Escape($_) + '(?![\w-])' })
        $hits = @($lines | Where-Object { $line = $_; @($patterns | Where-Object { $line -match $_ }).Count -gt 0 })
        if ($hits.Count -eq 0) { $problems.Add("spec.md does not cite PBI input file '$($it.packagePath)' ($($it.role), $($it.status)). State what it contributes, or why it is not relevant."); continue }
        if ($it.status -in @('RequiresAgentReview', 'Unreadable', 'Unsupported')) {
            if (@($hits | Where-Object { $_ -match '(?i)\b(reviewed|unreadable|unsupported|not\s+relevant)\b' }).Count -eq 0) {
                $problems.Add("spec.md cites '$($it.packagePath)' ($($it.status)) without its review result: Reviewed (what it shows), Unreadable (reason) or Not relevant.")
            }
        }
    }
    foreach ($d in @($Inventory.discrepancies)) {
        if ($spec -notmatch ('(?<![\w-])' + [regex]::Escape($d.id) + '(?![\w-])')) { $problems.Add("spec.md does not address discrepancy $($d.id) ($($d.type)): $($d.detail)") }
    }
    return $problems.ToArray()
}

function Add-SDDLocalExclude {
    # Keeps untracked local-only folders out of Git Changes through the repository-local .git/info/exclude.
    # Never touches .gitignore, never hides tracked files, never hides specs or source code.
    param([Parameter(Mandatory)][string]$Repository, [Parameter(Mandatory)][string[]]$RelativeDirs)
    $repo = Resolve-SDDFullPath $Repository
    $result = [ordered]@{}
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) { foreach ($d in $RelativeDirs) { $result[$d] = 'GitNotAvailable' }; return [pscustomobject]$result }
    $top = ((& git -C $repo rev-parse --show-toplevel 2>$null) | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or -not $top) { foreach ($d in $RelativeDirs) { $result[$d] = 'NotAGitRepository' }; return [pscustomobject]$result }
    $top = [IO.Path]::GetFullPath($top)
    $exclude = ((& git -C $repo rev-parse --path-format=absolute --git-path info/exclude 2>$null) | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or -not $exclude -or -not [IO.Path]::IsPathRooted($exclude)) {
        $gitDir = ((& git -C $repo rev-parse --absolute-git-dir 2>$null) | Out-String).Trim()
        $exclude = Join-Path $gitDir 'info/exclude'
    }
    $existing = @()
    if (Test-Path -LiteralPath $exclude -PathType Leaf) { $existing = @([IO.File]::ReadAllLines($exclude)) }
    $toAdd = New-Object System.Collections.Generic.List[string]
    foreach ($d in $RelativeDirs) {
        $rel = (Get-SDDRelativePath $top (Join-Path $repo $d)).Trim('/')
        $pattern = '/' + $rel + '/'
        $tracked = @(& git -C $top ls-files -- $rel 2>$null)
        if ($tracked.Count -gt 0) { $result[$d] = 'TrackedByTeam'; continue }
        if ($existing -contains $pattern -or $toAdd.Contains($pattern)) { $result[$d] = 'AlreadyExcluded'; continue }
        # Already ignored by any rule (team .gitignore, a broader local exclusion): add nothing.
        & git -C $top check-ignore -q -- ($rel + '/') 2>$null
        if ($LASTEXITCODE -eq 0) { $result[$d] = 'AlreadyIgnored'; continue }
        $toAdd.Add($pattern); $result[$d] = 'Excluded'
    }
    if ($toAdd.Count) {
        $dir = Split-Path -Parent $exclude
        if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Path $dir -Force) }
        $prefix = ''
        if (Test-Path -LiteralPath $exclude -PathType Leaf) { $raw = [IO.File]::ReadAllText($exclude); if ($raw.Length -and -not $raw.EndsWith("`n")) { $prefix = "`n" } }
        $block = @()
        if ($existing -notcontains $script:ExcludeMarker) { $block += $script:ExcludeMarker }
        $block += $toAdd
        [IO.File]::AppendAllText($exclude, $prefix + ($block -join "`n") + "`n", $script:Utf8NoBom)
    }
    return [pscustomobject]$result
}

function Get-SDDGitVisible([string]$Repository, [string]$RelativeDir) {
    # Files under the folder that Git (and so Visual Studio / VS Code Git Changes) would list.
    # Returns $null when Git is not available or the folder is not in a repository, otherwise a string array.
    $repo = Resolve-SDDFullPath $Repository
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) { return $null }
    $out = @(& git -C $repo status --porcelain --untracked-files=all -- $RelativeDir 2>$null)
    if ($LASTEXITCODE -ne 0) { return $null }
    return , ([string[]]@($out | Where-Object { $_ }))
}


# ------------------------------------------------------------------ PBI input import (v2.5)
# One command (or a drag-and-drop) copies a downloaded PBI package into docs/sdd/pbi-input/<PBI-ID>/ and keeps
# it out of Git Changes. Sources are only read; existing input files are never overwritten unless asked.

$script:PackageDocPattern = '(?i)^(refined[-_ ]?pbi[^/]*|pbi|request|original[^/]*|decision[-_ ]?log[^/]*|decisions?|open[-_ ]?questions?[^/]*|evidence[^/]*|handoff|readme)\.(md|markdown|txt)$'

function Test-SDDJunkFile([string]$Name) {
    return ($script:JunkFiles -contains $Name -or $Name -like '~$*' -or $Name -eq '.gitkeep')
}

function Get-SDDPbiIdFromName([string]$Name) {
    # "2026-10-07-305183-complaint-imitation-request.zip" -> 305183. Leading dates are ignored.
    $n = [IO.Path]::GetFileNameWithoutExtension($Name)
    $n = $n -replace '^\d{4}-\d{2}-\d{2}(?:[T_ ]\d{2}[-:.]?\d{2}(?:[-:.]?\d{2})?)?[-_ ]*', ''
    $ids = @([regex]::Matches($n, '(?<!\d)(\d{5,8})(?!\d)') | ForEach-Object { $_.Groups[1].Value } | Select-Object -Unique)
    if ($ids.Count -eq 1) { return $ids[0] }
    return $null
}

function Get-SDDDownloadsFolder {
    if ($env:SDD_DOWNLOADS_DIR) { return $env:SDD_DOWNLOADS_DIR }
    if ($IsWindows -or $env:OS -eq 'Windows_NT') {
        try {
            $key = '{374DE290-123F-4565-9164-39C4925E467B}'
            $v = (Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' -Name $key -ErrorAction Stop).$key
            if ($v) { $v = [Environment]::ExpandEnvironmentVariables($v); if (Test-Path -LiteralPath $v -PathType Container) { return $v } }
        } catch { }
    }
    $profileDir = [Environment]::GetFolderPath('UserProfile')
    if (-not $profileDir) { $profileDir = $HOME }
    return (Join-Path $profileDir 'Downloads')
}

function Find-SDDDownloadCandidates([string]$PbiId) {
    # Read-only: lists ZIPs, Markdown files and folders in the developer's Downloads folder named after the PBI.
    $dir = Get-SDDDownloadsFolder
    if (-not $dir -or -not (Test-Path -LiteralPath $dir -PathType Container)) { return @() }
    $list = New-Object System.Collections.Generic.List[object]
    foreach ($e in @(Get-ChildItem -LiteralPath $dir -Force -ErrorAction SilentlyContinue)) {
        if ($e.Name -notmatch "(?<!\d)$PbiId(?!\d)") { continue }
        if (-not $e.PSIsContainer -and $e.Extension -notin @('.zip', '.md')) { continue }
        $kind = if ($e.PSIsContainer) { 'Folder' } else { $e.Extension.TrimStart('.').ToUpperInvariant() }
        $list.Add([pscustomobject][ordered]@{ path = $e.FullName; name = $e.Name; kind = $kind; modified = $e.LastWriteTime.ToString('yyyy-MM-dd HH:mm') })
    }
    return @($list | Sort-Object modified -Descending)
}

function Expand-SDDZipSafe([string]$ZipPath, [string]$Destination) {
    Add-Type -AssemblyName System.IO.Compression -ErrorAction SilentlyContinue
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    $zip = $null
    try { $zip = [IO.Compression.ZipFile]::OpenRead($ZipPath) } catch { throw "Cannot open ZIP '$ZipPath': $($_.Exception.Message.Split("`n")[0])" }
    try {
        foreach ($e in $zip.Entries) {
            $n = $e.FullName.Replace('\', '/')
            if ($n.StartsWith('/') -or $n -match '(^|/)\.\.(/|$)' -or $n -match '^[A-Za-z]:') { throw "Unsafe path in ZIP (nothing was imported): $n" }
        }
        $destFull = [IO.Path]::GetFullPath($Destination).TrimEnd([char]'/', [char]'\') + [IO.Path]::DirectorySeparatorChar
        foreach ($e in $zip.Entries) {
            $n = $e.FullName.Replace('\', '/')
            if ($n.EndsWith('/') -or -not $e.Name -or $n -match '(^|/)__MACOSX/') { continue }
            $target = [IO.Path]::GetFullPath((Join-Path $Destination $n))
            if (-not $target.StartsWith($destFull, [StringComparison]::OrdinalIgnoreCase)) { throw "Unsafe path in ZIP (nothing was imported): $n" }
            $dir = [IO.Path]::GetDirectoryName($target)
            if (-not [IO.Directory]::Exists($dir)) { [void][IO.Directory]::CreateDirectory($dir) }
            [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $target, $true)
        }
    } finally { $zip.Dispose() }
}

function Get-SDDTreeFiles([string]$Root) {
    # Every file below Root (nothing silently skipped except OS junk, __MACOSX and .git).
    $out = New-Object System.Collections.Generic.List[string]
    $stack = New-Object System.Collections.Generic.Stack[string]
    $stack.Push($Root)
    while ($stack.Count) {
        $d = $stack.Pop()
        foreach ($f in [IO.Directory]::GetFiles($d)) { if (-not (Test-SDDJunkFile ([IO.Path]::GetFileName($f)))) { $out.Add($f) } }
        foreach ($sub in [IO.Directory]::GetDirectories($d)) { if ([IO.Path]::GetFileName($sub) -notin @('__MACOSX', '.git')) { $stack.Push($sub) } }
    }
    return $out.ToArray()
}

function Get-SDDStagedInput([string[]]$Source, [string]$StageRoot) {
    # Returns one entry per input file: where it is read from and its path inside the PBI package.
    $entries = New-Object System.Collections.Generic.List[object]
    $n = 0
    foreach ($src in $Source) {
        $n++
        $full = Resolve-SDDFullPath $src
        if (-not (Test-Path -LiteralPath $full)) { throw "Source not found: $src" }
        $root = $null
        if (Test-Path -LiteralPath $full -PathType Container) { $root = $full }
        elseif ([IO.Path]::GetExtension($full) -ieq '.zip') {
            $root = Join-Path $StageRoot ("zip$n")
            Expand-SDDZipSafe $full $root
        } else {
            $name = [IO.Path]::GetFileName($full)
            if (Test-SDDJunkFile $name) { continue }
            $rel = if ($name -match $script:PackageDocPattern) { $name } else { 'attachments/' + $name }
            $entries.Add([pscustomobject]@{ Source = $full; Full = $full; Rel = $rel }); continue
        }
        # A single wrapper folder (ZIP of "2026-10-07-305183-.../") is unwrapped.
        while ($true) {
            $files = @([IO.Directory]::GetFiles($root) | Where-Object { -not (Test-SDDJunkFile ([IO.Path]::GetFileName($_))) })
            $dirs = @([IO.Directory]::GetDirectories($root) | Where-Object { [IO.Path]::GetFileName($_) -notin @('__MACOSX', '.git') })
            if ($files.Count -eq 0 -and $dirs.Count -eq 1 -and [IO.Path]::GetFileName($dirs[0]) -notmatch '(?i)^attachments?$') { $root = $dirs[0] } else { break }
        }
        $all = @(Get-SDDTreeFiles $root)
        # A PBI package keeps its layout; a plain bundle of attachments goes under attachments/.
        $isPackage = @($all | Where-Object { (Split-Path -Parent $_) -eq $root -and ([IO.Path]::GetFileName($_) -match $script:PackageDocPattern) }).Count -gt 0
        foreach ($f in $all) {
            $rel = Get-SDDRelativePath $root $f
            if (-not $isPackage -and $rel -notmatch '(?i)^attachments?/') { $rel = 'attachments/' + $rel }
            $entries.Add([pscustomobject]@{ Source = $full; Full = $f; Rel = $rel })
        }
    }
    return $entries.ToArray()
}

function Import-SDDPbiInput {
    # Copies PBI documents and attachments into docs/sdd/pbi-input/<PBI-ID>/ for ONE PBI.
    # Status: Imported | NothingNew | InputConflict | PbiMismatch | PbiIdRequired
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Repository,
        [Parameter(Mandatory)][string[]]$Source,
        [string]$PbiId,
        # Replace input files whose content changed; the previous version is kept under .previous/<timestamp>/.
        [switch]$UpdateChanged
    )
    $repo = Resolve-SDDFullPath $Repository
    $stage = Join-Path ([IO.Path]::GetTempPath()) ('sdd-pbi-import-' + [guid]::NewGuid().ToString('N').Substring(0, 12))
    [void][IO.Directory]::CreateDirectory($stage)
    $result = [ordered]@{ status = ''; pbiId = $PbiId; inputFolder = $null; sources = @($Source | ForEach-Object { Resolve-SDDFullPath $_ }); files = @(); counts = $null; warnings = @(); message = ''; git = $null }
    $warnings = New-Object System.Collections.Generic.List[string]
    try {
        $entries = @(Get-SDDStagedInput -Source $Source -StageRoot $stage)
        if ($entries.Count -eq 0) { $result.status = 'NothingNew'; $result.message = 'The source contains no files.'; return [pscustomobject]$result }

        # ------------------------------------------------ PBI identity: document header > explicit ID > file name
        $declaredByRefined = New-Object System.Collections.Generic.List[string]
        $headerIds = @{}
        foreach ($e in $entries) {
            if ([IO.Path]::GetExtension($e.Full).ToLowerInvariant() -notin @('.md', '.markdown', '.txt')) { continue }
            $ids = @(Get-SDDDeclaredPbiIds (Read-SDDText $e.Full))
            $headerIds[$e.Rel] = $ids
            if ($e.Rel -match '(?i)^refined[-_ ]?pbi[^/]*\.(md|markdown)$') { foreach ($i in $ids) { if (-not $declaredByRefined.Contains($i)) { $declaredByRefined.Add($i) } } }
        }
        $nameIds = @($Source | ForEach-Object { Get-SDDPbiIdFromName ([IO.Path]::GetFileName((Resolve-SDDFullPath $_).TrimEnd([char]'/', [char]'\'))) } | Where-Object { $_ } | Select-Object -Unique)
        if ($PbiId -and $PbiId -notmatch '^\d{4,8}$') { throw "PBI ID must be numeric (4-8 digits): $PbiId" }
        if (-not $PbiId) {
            if ($declaredByRefined.Count -eq 1) { $PbiId = $declaredByRefined[0] }
            elseif ($declaredByRefined.Count -eq 0 -and $nameIds.Count -eq 1) { $PbiId = $nameIds[0] }
            else {
                $result.status = 'PbiIdRequired'
                $result.message = 'The PBI ID cannot be determined from the files' + $(if ($declaredByRefined.Count -gt 1) { " (the refined PBI declares $($declaredByRefined -join ', '))" } else { '' }) + '. Pass -PbiId.'
                return [pscustomobject]$result
            }
        }
        $result.pbiId = $PbiId
        if ($declaredByRefined.Count -and $declaredByRefined -notcontains $PbiId) {
            $result.status = 'PbiMismatch'
            $result.message = "The refined PBI in the source declares PBI $($declaredByRefined -join ', '), not $PbiId. Nothing was imported."
            return [pscustomobject]$result
        }
        foreach ($i in $nameIds) { if ($i -ne $PbiId) { $warnings.Add("Source name suggests PBI $i; importing as PBI $PbiId as requested.") } }

        # ------------------------------------------------ plan every file before touching anything
        $idDir = Join-Path $repo "docs/sdd/pbi-input/$PbiId"
        $existingHashes = @{}
        if (Test-Path -LiteralPath $idDir -PathType Container) {
            foreach ($f in (Get-SDDTreeFiles $idDir)) {
                $r = Get-SDDRelativePath $idDir $f
                if ($r -match '(?i)^\.previous/') { continue }
                $h = Get-SDDFileSha256 $f
                if (-not $existingHashes.ContainsKey($h)) { $existingHashes[$h] = $r }
            }
        }
        $plan = New-Object System.Collections.Generic.List[object]
        $seenRel = @{}
        foreach ($e in $entries) {
            $hash = Get-SDDFileSha256 $e.Full
            $target = Join-Path $idDir $e.Rel
            $item = [ordered]@{ packagePath = $e.Rel; source = $e.Source; status = ''; detail = ''; sha256 = $hash; full = $e.Full; target = $target }
            $ids = $headerIds[$e.Rel]
            if ($seenRel.ContainsKey($e.Rel.ToLowerInvariant())) { $item.status = 'SkippedSameName'; $item.detail = "Another source file already maps to $($e.Rel)." }
            elseif ($ids -and @($ids).Count -gt 0 -and @($ids) -notcontains $PbiId) { $item.status = 'SkippedOtherPbi'; $item.detail = "Declares PBI $(@($ids) -join ', '); not imported into $PbiId (no cross-PBI contamination)." }
            elseif (Test-Path -LiteralPath $target -PathType Leaf) {
                if ((Get-SDDFileSha256 $target) -eq $hash) { $item.status = 'AlreadyPresent'; $item.detail = 'Identical file already in the input folder.' }
                elseif ($UpdateChanged) { $item.status = 'Update'; $item.detail = 'Content changed; previous version kept under .previous/.' }
                else { $item.status = 'Conflict'; $item.detail = 'A different file with this name already exists; it was not overwritten.' }
            }
            elseif ($existingHashes.ContainsKey($hash)) { $item.status = 'DuplicateSkipped'; $item.detail = "Same content already present as $($existingHashes[$hash])." }
            else { $item.status = 'Copy' }
            $seenRel[$e.Rel.ToLowerInvariant()] = $true
            $plan.Add([pscustomobject]$item)
        }
        $conflicts = @($plan | Where-Object { $_.status -eq 'Conflict' })
        $result.inputFolder = Get-SDDRelativePath $repo $idDir
        if ($conflicts.Count) {
            $result.status = 'InputConflict'
            $result.message = "$($conflicts.Count) file(s) differ from the files already in $($result.inputFolder): $(($conflicts | ForEach-Object { $_.packagePath }) -join ', '). Nothing was imported. If the PBI was re-refined, re-run with -UpdateChanged (old versions are kept under .previous/)."
        } else {
            # ------------------------------------------------ copy (never overwrite without -UpdateChanged)
            $stamp = [DateTime]::Now.ToString('yyyyMMdd-HHmmss')
            foreach ($it in $plan) {
                if ($it.status -notin @('Copy', 'Update')) { continue }
                $dir = Split-Path -Parent $it.target
                if (-not [IO.Directory]::Exists($dir)) { [void][IO.Directory]::CreateDirectory($dir) }
                if ($it.status -eq 'Update') {
                    $null = Set-SDDReadOnly $it.target $false
                    $keep = Join-Path $idDir (".previous/$stamp/" + $it.packagePath)
                    [void][IO.Directory]::CreateDirectory((Split-Path -Parent $keep))
                    Move-Item -LiteralPath $it.target -Destination $keep
                }
                Copy-Item -LiteralPath $it.full -Destination $it.target
                if ((Get-SDDFileSha256 $it.target) -ne $it.sha256) { throw "Copy verification failed for $($it.packagePath)." }
                $null = Set-SDDReadOnly $it.target $true
                $it.status = if ($it.status -eq 'Update') { 'Updated' } else { 'Copied' }
            }
            $copied = @($plan | Where-Object { $_.status -in @('Copied', 'Updated') }).Count
            $result.status = if ($copied) { 'Imported' } else { 'NothingNew' }
            $result.message = "$copied file(s) copied into $($result.inputFolder)."
            # ------------------------------------------------ keep the inputs local-only and record provenance
            if (Test-Path -LiteralPath $idDir -PathType Container) {
                $ex = Add-SDDLocalExclude -Repository $repo -RelativeDirs @("docs/sdd/pbi-input/$PbiId", '.sdd-builder/pbi-imports')
                $visible = Get-SDDGitVisible $repo "docs/sdd/pbi-input/$PbiId"
                $git = [ordered]@{ exclusion = $ex."docs/sdd/pbi-input/$PbiId"; gitAvailable = ($null -ne $visible); visibleInGitChanges = -1; visibleFiles = [string[]]@() }
                if ($null -ne $visible) { $git.visibleInGitChanges = $visible.Count; $git.visibleFiles = [string[]]$visible }
                $result.git = [pscustomobject]$git
                if ($ex."docs/sdd/pbi-input/$PbiId" -eq 'TrackedByTeam') { $warnings.Add("docs/sdd/pbi-input/$PbiId contains Git-tracked files; the team tracks this folder, so it was not hidden. Review Git Changes before committing.") }
                $logPath = Join-Path $repo ".sdd-builder/pbi-imports/$PbiId.json"
                $log = @()
                if (Test-Path -LiteralPath $logPath -PathType Leaf) { try { $log = @(Read-SDDText $logPath | ConvertFrom-Json) } catch { $log = @() } }
                $srcInfo = @($result.sources | ForEach-Object { [pscustomobject][ordered]@{ path = $_; sha256 = $(if (Test-Path -LiteralPath $_ -PathType Leaf) { Get-SDDFileSha256 $_ } else { $null }) } })
                $log += [pscustomobject][ordered]@{ importedAtUtc = [DateTime]::UtcNow.ToString('o'); sources = $srcInfo; copied = @($plan | Where-Object { $_.status -in @('Copied', 'Updated') } | ForEach-Object { $_.packagePath }); files = @($plan | Where-Object { $_.status -in @('Copied', 'Updated', 'AlreadyPresent') } | ForEach-Object { [pscustomobject][ordered]@{ packagePath = $_.packagePath; sha256 = $_.sha256 } }) }
                Write-SDDText $logPath ((ConvertTo-Json -InputObject @($log) -Depth 6) + "`n")
                # Baseline: what was imported is the evidence; later edits are detected by the gates.
                $explicit = @{}
                foreach ($it in @($plan | Where-Object { $_.status -in @('Copied', 'Updated', 'AlreadyPresent') })) { $explicit[$it.packagePath] = $it.sha256 }
                $null = Update-SDDInputBaseline -Repository $repo -PbiId $PbiId -Explicit $explicit
                Set-SDDActivePbi -Repository $repo -PbiId $PbiId -Active $true
            }
        }
        $result.files = @($plan | ForEach-Object { [pscustomobject][ordered]@{ packagePath = $_.packagePath; status = $_.status; detail = $_.detail; sha256 = $_.sha256 } })
        $result.counts = [pscustomobject][ordered]@{
            total = $plan.Count; copied = @($plan | Where-Object { $_.status -eq 'Copied' }).Count; updated = @($plan | Where-Object { $_.status -eq 'Updated' }).Count
            alreadyPresent = @($plan | Where-Object { $_.status -eq 'AlreadyPresent' }).Count; duplicates = @($plan | Where-Object { $_.status -eq 'DuplicateSkipped' }).Count
            otherPbi = @($plan | Where-Object { $_.status -eq 'SkippedOtherPbi' }).Count; conflicts = $conflicts.Count
        }
        $result.warnings = $warnings.ToArray()
        return [pscustomobject]$result
    } finally {
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
    }
}


# ------------------------------------------------------------------ v2.5.2: input protection, placement checks, prefill

$script:AppSourceExt = @('.cs', '.csproj', '.sln', '.slnx', '.ts', '.tsx', '.js', '.html', '.scss', '.css', '.graphql', '.gql', '.json', '.xml', '.config', '.resx', '.sql', '.ps1', '.psm1', '.cshtml', '.razor', '.yml', '.yaml', '.props', '.targets')

function Get-SDDBaselinePath([string]$Repository, [string]$PbiId) {
    return (Join-Path (Resolve-SDDFullPath $Repository) ".sdd-builder/pbi-imports/$PbiId.baseline.json")
}

function Read-SDDInputBaseline([string]$Repository, [string]$PbiId) {
    # packagePath -> SHA-256 recorded when the file entered the PBI input folder. $null when none was recorded.
    $p = Get-SDDBaselinePath $Repository $PbiId
    if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { return $null }
    try { $o = Read-SDDText $p | ConvertFrom-Json } catch { return $null }
    $h = @{}
    if ($o.files) { foreach ($prop in $o.files.PSObject.Properties) { $h[$prop.Name] = [string]$prop.Value } }
    return $h
}

function Save-SDDInputBaseline([string]$Repository, [string]$PbiId, [hashtable]$Files) {
    $ordered = [ordered]@{}
    foreach ($k in ($Files.Keys | Sort-Object)) { $ordered[$k] = $Files[$k] }
    $doc = [ordered]@{
        pbiId = $PbiId; updatedAtUtc = [DateTime]::UtcNow.ToString('o')
        note = 'SHA-256 of every PBI input file as it entered docs/sdd/pbi-input. Inputs are evidence: never edit them; replace them with tools/Add-SDDPbiInput.ps1 -UpdateChanged.'
        files = [pscustomobject]$ordered
    }
    Write-SDDText (Get-SDDBaselinePath $Repository $PbiId) (($doc | ConvertTo-Json -Depth 4) + "`n")
    $null = Add-SDDLocalExclude -Repository $Repository -RelativeDirs @('.sdd-builder/pbi-imports')
}

function Set-SDDReadOnly([string]$Path, [bool]$ReadOnly) {
    try {
        $item = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
        if ($item.IsReadOnly -ne $ReadOnly) { $item.IsReadOnly = $ReadOnly }
        return $true
    } catch { return $false }
}

function Update-SDDInputBaseline {
    # Records files of the PBI input folder that have no baseline yet ("first seen") and marks every recorded
    # file read-only, so an editor or agent cannot silently change the evidence. Existing entries never change here.
    param([Parameter(Mandatory)][string]$Repository, [Parameter(Mandatory)][string]$PbiId, [hashtable]$Explicit)
    $repo = Resolve-SDDFullPath $Repository
    $idDir = Join-Path $repo "docs/sdd/pbi-input/$PbiId"
    if (-not (Test-Path -LiteralPath $idDir -PathType Container)) { return $null }
    $base = Read-SDDInputBaseline $repo $PbiId
    $created = ($null -eq $base)
    if ($created) { $base = @{} }
    $added = New-Object System.Collections.Generic.List[string]
    if ($Explicit) { foreach ($k in $Explicit.Keys) { $base[$k] = $Explicit[$k] } }
    foreach ($f in (Get-SDDTreeFiles $idDir)) {
        $rel = Get-SDDRelativePath $idDir $f
        if ($rel -match '(?i)^\.previous/') { continue }
        if (-not $base.ContainsKey($rel)) { $base[$rel] = Get-SDDFileSha256 $f; $added.Add($rel) }
        if ((Get-SDDFileSha256 $f) -eq $base[$rel]) { $null = Set-SDDReadOnly $f $true }
    }
    Save-SDDInputBaseline $repo $PbiId $base
    return [pscustomobject]@{ Created = $created; Added = $added.ToArray(); Count = $base.Count }
}

function Get-SDDAcceptanceBlock([string]$Text) {
    # The body of the refined PBI's "Acceptance criteria" section, copied verbatim (tables, lists, sub-headings).
    $lines = $Text -split "`r?`n"
    $start = -1; $level = 0
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match '^\s{0,3}(#{1,6})\s+acceptance\s+criteria\b') { $start = $i; $level = $Matches[1].Length; break }
    }
    if ($start -lt 0) { return $null }
    $body = New-Object System.Collections.Generic.List[string]
    for ($j = $start + 1; $j -lt $lines.Count; $j++) {
        if ($lines[$j] -match '^\s{0,3}(#{1,6})\s+' -and $Matches[1].Length -le $level) { break }
        $body.Add($lines[$j])
    }
    $block = ($body -join "`n").Trim()
    if (-not $block -or @(Get-SDDAcceptanceIds $block).Count -eq 0) { return $null }
    return $block
}

function Get-SDDCompanionSummary([string]$Role, [string]$Text) {
    # Deterministic one-line summary of a PBI Builder companion file for the spec's sources table.
    $fmt = { param($prefix, $nums) (@($nums | Sort-Object | ForEach-Object { '{0}-{1:D2}' -f $prefix, $_ })) -join ', ' }
    if ($Role -eq 'DecisionLog') {
        $approved = New-Object System.Collections.Generic.List[int]; $other = New-Object System.Collections.Generic.List[string]
        foreach ($row in (Get-SDDTableRows $Text 'D-?')) {
            $st = @($row.Cells | Where-Object { $_ -match '(?i)^(approved|accepted|proposed|pending|draft|open|tentative|under\s+review|rejected|superseded)$' }) | Select-Object -First 1
            if (-not $st) { continue }
            if ($st -match '(?i)^(approved|accepted)$') { $approved.Add($row.Number) } else { $other.Add(('D-{0:D2} ({1})' -f $row.Number, $st)) }
        }
        if ($approved.Count -eq 0 -and $other.Count -eq 0) { return $null }
        return "Read by Start-SDD: approved $(if ($approved.Count) { & $fmt 'D' $approved } else { 'none' }); not approved $(if ($other.Count) { $other -join ', ' } else { 'none' })."
    }
    if ($Role -eq 'OpenQuestions') {
        $resolved = New-Object System.Collections.Generic.List[int]; $open = New-Object System.Collections.Generic.List[int]
        foreach ($row in (Get-SDDTableRows $Text 'Q-?')) {
            $last = @($row.Cells | Where-Object { $_ }) | Select-Object -Last 1
            if ($last -match '(?i)^(resolved|closed|answered|decided|not\s+relevant)') { $resolved.Add($row.Number) }
            elseif ($last -match '(?i)^(open|pending|blocking|unresolved)') { $open.Add($row.Number) }
        }
        if ($resolved.Count -eq 0 -and $open.Count -eq 0) { return $null }
        return "Read by Start-SDD: resolved $(if ($resolved.Count) { & $fmt 'Q' $resolved } else { 'none' }); open $(if ($open.Count) { & $fmt 'Q' $open } else { 'none' })."
    }
    return $null
}

function Test-SDDGitTracked([string]$Repository, [string]$RelativePath) {
    # $true when Git tracks the file or any file under the folder. Tracked content is team content: never moved.
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) { return $false }
    $out = @(& git -C (Resolve-SDDFullPath $Repository) ls-files -- $RelativePath 2>$null)
    return ($LASTEXITCODE -eq 0 -and @($out | Where-Object { $_ }).Count -gt 0)
}

function Find-SDDStrayInputs([string]$Repository, [string]$PbiId) {
    # Copies of this PBI's package outside docs/sdd/pbi-input (for example a ZIP extracted into tools/).
    # They show up in Git Changes and can be mistaken for the real input.
    # kind Folder: a folder named after the PBI that holds only package files (moved as a whole).
    # kind Files:  package files lying in a folder with other content (only the package files are listed).
    $repo = Resolve-SDDFullPath $Repository
    $found = New-Object System.Collections.Generic.List[object]
    $seen = @{}
    $codeExt = @('.cs', '.csproj', '.sln', '.slnx', '.ts', '.tsx', '.js', '.ps1', '.psm1', '.cmd', '.bat', '.sh', '.graphql', '.razor', '.cshtml')
    foreach ($f in (Get-SDDFiles -Root $repo -Include @('*.md') -MaxDepth 8)) {
        if ([IO.Path]::GetFileName($f) -notmatch '(?i)^refined[-_ ]?pbi\.md$') { continue }
        $rel = Get-SDDRelativePath $repo $f
        if ($rel -match '(?i)^docs/sdd/(pbi-input|changes|pbi-sources)/') { continue }
        $dir = Split-Path -Parent $f
        $ids = @(Get-SDDDeclaredPbiIds (Read-SDDText $f))
        $dirName = [IO.Path]::GetFileName($dir)
        if ($ids -notcontains $PbiId -and $dirName -notmatch "(?<!\d)$PbiId(?!\d)") { continue }
        $isRoot = ((Resolve-SDDFullPath $dir).TrimEnd([char]'/', [char]'\') -eq $repo.TrimEnd([char]'/', [char]'\'))
        $dirRel = if ($isRoot) { '' } else { Get-SDDRelativePath $repo $dir }
        if ($seen.ContainsKey($dirRel)) { continue }
        $seen[$dirRel] = $true
        $kind = 'Files'
        if (-not $isRoot -and $dirName -match "(?<!\d)$PbiId(?!\d)") {
            $hasCode = @(Get-SDDFiles -Root $dir -MaxDepth 4 | Where-Object { $codeExt -contains [IO.Path]::GetExtension($_).ToLowerInvariant() }).Count -gt 0
            if (-not $hasCode) { $kind = 'Folder' }
        }
        if ($kind -eq 'Folder') { $files = @(Get-SDDFiles -Root $dir -MaxDepth 8 | ForEach-Object { Get-SDDRelativePath $repo $_ }) }
        else {
            # Only the refined PBI and companions that name this PBI; a README or other content of a shared folder stays.
            $files = @([IO.Directory]::GetFiles($dir) | Where-Object {
                    $n = [IO.Path]::GetFileName($_)
                    ($_ -eq $f) -or ($n -match '(?i)^(original[-_ ]?pbi|decision[-_ ]?log|open[-_ ]?questions?|evidence)[^/]*\.(md|markdown|txt)$' -and (Read-SDDText $_) -match "(?<!\d)$PbiId(?!\d)")
                } | ForEach-Object { Get-SDDRelativePath $repo $_ })
        }
        $tracked = @($files | Where-Object { Test-SDDGitTracked $repo $_ }).Count -gt 0
        $found.Add([pscustomobject][ordered]@{ path = $(if ($kind -eq 'Folder') { $dirRel } else { $rel }); folder = $dirRel; kind = $kind; files = $files; tracked = $tracked })
    }
    return $found.ToArray()
}

function Find-SDDMisplacedDocs([string]$Repository, [string]$PbiId, [string]$Feature, [switch]$IncludeUserFolders) {
    # spec.md / plan.md / completion.md for this PBI that are not where the gates read them, and loose files
    # directly in the spec root. With -IncludeUserFolders also looks (read-only) in the Desktop and Documents.
    $repo = Resolve-SDDFullPath $Repository
    $specRoot = Resolve-SDDFullPath (Get-SDDSpecRoot $repo)
    $expected = @()
    if ($Feature) { $expected = @((Join-Path $specRoot "$Feature/spec.md"), (Join-Path $specRoot "$Feature/plan.md")) | ForEach-Object { Resolve-SDDFullPath $_ } }
    $list = New-Object System.Collections.Generic.List[object]
    if (Test-Path -LiteralPath $specRoot -PathType Container) {
        foreach ($f in [IO.Directory]::GetFiles($specRoot)) {
            $rel = Get-SDDRelativePath $repo $f
            if (Test-SDDGitTracked $repo $rel) { continue }   # team content, not an agent leftover
            $list.Add([pscustomobject][ordered]@{ path = $rel; location = 'Repository'; tracked = $false; reason = 'Loose file directly in the spec root; specs live in a feature folder.' })
        }
    }
    foreach ($f in (Get-SDDFiles -Root $repo -Include @('spec.md', 'plan.md', 'completion.md') -MaxDepth 8)) {
        $full = Resolve-SDDFullPath $f
        if ($expected -contains $full) { continue }
        $rel = Get-SDDRelativePath $repo $full
        if ($rel -match '(?i)^docs/sdd/(changes|pbi-input|pbi-sources|specs)/') { continue }
        if ((Split-Path -Parent $full) -eq $specRoot) { continue }   # already reported as a loose file
        if (@(Get-SDDDeclaredPbiIds (Read-SDDText $full)) -notcontains $PbiId) { continue }
        $list.Add([pscustomobject][ordered]@{ path = $rel; location = 'Repository'; tracked = (Test-SDDGitTracked $repo $rel); reason = "Declares PBI $PbiId but is not at $(if ($Feature) { Get-SDDRelativePath $repo (Join-Path $specRoot $Feature) } else { 'the feature folder' })." })
    }
    if ($IncludeUserFolders) {
        $roots = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('MyDocuments')) | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Container) } | Select-Object -Unique
        if ($env:SDD_USER_FOLDERS) { $roots = @($env:SDD_USER_FOLDERS -split ';' | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Container) }) }
        $budget = 3000
        foreach ($root in $roots) {
            $queue = New-Object System.Collections.Generic.Queue[object]
            $queue.Enqueue(@($root, 0))
            while ($queue.Count -and $budget -gt 0) {
                $item = $queue.Dequeue(); $dir = $item[0]; $depth = $item[1]; $budget--
                if ($dir.StartsWith($repo, [StringComparison]::OrdinalIgnoreCase)) { continue }
                if ([IO.Path]::GetFileName($dir) -match "(?<!\d)$PbiId(?!\d)") {
                    foreach ($f in (Get-SDDFiles -Root $dir -Include @('*.md') -MaxDepth 2)) {
                        $name = [IO.Path]::GetFileName($f)
                        if ($name -match '(?i)^(spec|plan|completion)\.md$' -or (@(Get-SDDDeclaredPbiIds (Read-SDDText $f)) -contains $PbiId -and $name -notmatch '(?i)^refined[-_ ]?pbi')) {
                            $list.Add([pscustomobject][ordered]@{ path = $f; location = 'OutsideRepository'; tracked = $false; reason = 'SDD document outside the repository; Git and the gates never see it.' })
                        }
                    }
                    continue
                }
                if ($depth -ge 3) { continue }
                try { foreach ($sub in [IO.Directory]::GetDirectories($dir)) { if ([IO.Path]::GetFileName($sub) -notmatch '^(\.|node_modules$|AppData$)') { $queue.Enqueue(@($sub, $depth + 1)) } } } catch { continue }
            }
        }
    }
    return $list.ToArray()
}

function Test-SDDApplicationPath([string]$RelativePath) {
    # Application source that needs an approved and verified SDD feature before it is committed.
    $p = $RelativePath.Replace('\', '/')
    if ($p -match '(?i)^(docs/|tools/|\.github/|\.sdd-builder/|\.sdd-installer-backups/|src/\.github/)') { return $false }
    return ($script:AppSourceExt -contains [IO.Path]::GetExtension($p).ToLowerInvariant())
}

function Get-SDDActivePbis([string]$Repository) {
    $p = Join-Path (Resolve-SDDFullPath $Repository) '.sdd-builder/pbi-imports/active-pbis.json'
    if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { return @() }
    try { return @((Read-SDDText $p | ConvertFrom-Json).active | Where-Object { $_ } | ForEach-Object { [string]$_ }) } catch { return @() }
}

function Set-SDDActivePbi([string]$Repository, [string]$PbiId, [bool]$Active) {
    $repo = Resolve-SDDFullPath $Repository
    $list = New-Object System.Collections.Generic.List[string]
    foreach ($i in (Get-SDDActivePbis $repo)) { if (-not $list.Contains($i)) { $list.Add($i) } }
    if ($Active -and -not $list.Contains($PbiId)) { $list.Add($PbiId) }
    if (-not $Active) { $null = $list.Remove($PbiId) }
    $doc = [ordered]@{ note = 'PBIs in progress. While one is listed, the local commit gate requires its ImplementationVerified gate before application source is committed. Removed automatically when the PRReady gate passes.'; active = $list.ToArray() }
    Write-SDDText (Join-Path $repo '.sdd-builder/pbi-imports/active-pbis.json') (($doc | ConvertTo-Json -Depth 3) + "`n")
    $null = Add-SDDLocalExclude -Repository $repo -RelativeDirs @('.sdd-builder/pbi-imports')
}

. (Join-Path $PSScriptRoot 'SDD.Execution.ps1')
. (Join-Path $PSScriptRoot 'SDD.Automation.ps1')
Export-ModuleMember -Function *-SDD*
