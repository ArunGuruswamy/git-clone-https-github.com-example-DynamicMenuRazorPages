﻿[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$Repository,
    [Parameter(Mandatory=$true)][string]$Feature,
    [Parameter(Mandatory=$true)][int]$PbiId,
    [Parameter(Mandatory=$true)][string]$PbiTitle,
    [ValidateSet('CDMS','DAB','UI')][string]$SelectedRole
)
# Akzo SDD Builder v2.5.3 - kept for backward compatibility (v2.2 command line).
# Delegates to Start-SDD.ps1 so there is one template and one discovery path. -SelectedRole is ignored:
# the role is taken from repository evidence (record an override in .sdd-builder/settings.json if needed).
$ErrorActionPreference = 'Stop'
if ($SelectedRole) { Write-Warning "-SelectedRole is ignored; role comes from repository evidence." }
& (Join-Path $PSScriptRoot 'Start-SDD.ps1') -Repository $Repository -PbiId ([string]$PbiId) -Title $PbiTitle -Feature $Feature
exit $LASTEXITCODE
