﻿[CmdletBinding()]
param(
    [string]$Repository = (Get-Location).Path,
    [string]$PbiId,
    [string]$Feature,
    # Repair what can be repaired safely: nothing is deleted, every moved or replaced file is kept.
    [switch]$Fix,
    [switch]$Json
)
# Akzo SDD Builder v2.5.3 - one command that shows where a PBI stands and what is wrong, and with -Fix puts
# files where they belong:
# - stray copies of the PBI package (for example a ZIP extracted into tools/) -> merged into the input folder,
#   the copy kept hidden under docs/sdd/pbi-input/<id>/.previous/
# - PBI input files edited after import -> originals restored (edited versions kept under .previous/)
# - spec/plan/completion files in the wrong place, also on the Desktop or in Documents -> moved or copied to
#   docs/sdd/changes/<id>-<Feature>/agent-draft/ (local-only) for the agent to merge
# - missing local-only exclusions and read-only protection of the inputs
# It never touches application source code, never runs git write commands and never deletes a file.
# Exit codes: 0 no blocking problem, 1 blocking problems remain.
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
$repo = Resolve-SDDRepositoryRoot $Repository
if (-not (Test-Path -LiteralPath $repo -PathType Container)) { throw "Repository not found: $Repository" }
$stamp = [DateTime]::Now.ToString('yyyyMMdd-HHmmss')
$fixes = New-Object System.Collections.Generic.List[string]

function New-Report {
    $r = [ordered]@{ tool = "Get-SDDStatus.ps1 v$(Get-SDDVersion)"; repository = $repo; pbiId = $script:PbiId; feature = $script:Feature; stage = $null; checks = (New-Object System.Collections.Generic.List[object]); next = '' }
    return $r
}
function Add-Check($report, [string]$Area, [string]$Status, [string]$Detail, [string]$Action) {
    $report.checks.Add([pscustomobject][ordered]@{ area = $Area; status = $Status; detail = $Detail; action = $Action })
}

function Resolve-Context {
    # PBI ID and feature from the arguments, the active list, the input folders or the SDD state.
    if (-not $script:PbiId) {
        $ids = New-Object System.Collections.Generic.List[string]
        foreach ($i in (Get-SDDActivePbis $repo)) { if (-not $ids.Contains($i)) { $ids.Add($i) } }
        if ($ids.Count -eq 0) {
            $inputRoot = Join-Path $repo 'docs/sdd/pbi-input'
            if (Test-Path -LiteralPath $inputRoot) { foreach ($d in [IO.Directory]::GetDirectories($inputRoot)) { $n = [IO.Path]::GetFileName($d); if ($n -match '^\d{4,8}$' -and -not $ids.Contains($n)) { $ids.Add($n) } } }
        }
        if ($ids.Count -eq 1) { $script:PbiId = $ids[0] }
        elseif ($ids.Count -gt 1) { return "Several PBIs found ($($ids -join ', ')). Run again with -PbiId <id>." }
        else { return 'No PBI found. Import the PBI Builder package first: drag the ZIP onto tools\Add-PbiInput.cmd.' }
    }
    if (-not $script:Feature) {
        $changes = Join-Path $repo 'docs/sdd/changes'
        $dirs = @()
        if (Test-Path -LiteralPath $changes) { $dirs = @([IO.Directory]::GetDirectories($changes, "$script:PbiId-*") | Where-Object { Test-Path -LiteralPath (Join-Path $_ 'sdd-state.json') }) }
        if ($dirs.Count -eq 1) { $script:Feature = ([IO.Path]::GetFileName($dirs[0])).Substring($script:PbiId.Length + 1) }
        elseif ($dirs.Count -eq 0) { $script:Feature = Find-SDDFeatureFolder -Repository $repo -PbiId $script:PbiId }
    }
    return $null
}

function Get-Status {
    $report = New-Report
    $report['installation'] = Get-SDDInstallationHealth $repo
    $problem = Resolve-Context
    $report.pbiId = $script:PbiId; $report.feature = $script:Feature
    # ---------------------------------------------------- builder version
    $agents = @(Get-ChildItem -LiteralPath (Join-Path $repo '.github/agents') -Filter 'akzo-sdd-*.agent.md' -File -ErrorAction SilentlyContinue)
    $old = @($agents | Where-Object { (Get-Content -LiteralPath $_.FullName -Raw) -notmatch ('sdd-builder-version:\s*' + [regex]::Escape((Get-SDDVersion))) })
    if ($agents.Count -eq 0) { Add-Check $report 'Builder' 'WARN' 'No Akzo SDD agents in .github/agents.' 'Run Install-DevelopmentBuilder.cmd for this repository.' }
    elseif ($old.Count) { Add-Check $report 'Builder' 'WARN' "Agent file(s) older than the tools (v$(Get-SDDVersion)): $(($old | ForEach-Object Name) -join ', ')." 'Re-run Install-DevelopmentBuilder.cmd; a team-tracked agent is upgraded through a PR.' }
    else { Add-Check $report 'Builder' 'OK' "Tools and agents are v$(Get-SDDVersion)." '' }
    if ($problem) { Add-Check $report 'PBI' 'FAIL' $problem ''; $report.next = $problem; return $report }

    $id = $script:PbiId
    $idDir = Join-Path $repo "docs/sdd/pbi-input/$id"
    # ---------------------------------------------------- input folder
    $primary = $null
    if (-not (Test-Path -LiteralPath $idDir -PathType Container)) {
        Add-Check $report 'PBI input' 'FAIL' "docs/sdd/pbi-input/$id does not exist." 'Drag the PBI Builder ZIP onto tools\Add-PbiInput.cmd.'
    } else {
        $found = Find-SDDPbiSource -Repository $repo -PbiId $id
        $primary = $found.Selected
        $baseline = Read-SDDInputBaseline $repo $id
        $files = @(Get-SDDTreeFiles $idDir | Where-Object { (Get-SDDRelativePath $idDir $_) -notmatch '(?i)^\.previous/' })
        if (-not $primary) { Add-Check $report 'PBI input' 'FAIL' "No refined PBI in docs/sdd/pbi-input/$id ($($found.Status))." 'Import the PBI Builder package (REFINED-PBI.md is required).' }
        else {
            $inv = New-SDDPbiInventory -Repository $repo -PbiId $id -Selected $primary
            $edited = @($inv.items | Where-Object { $_.editedAfterImport })
            if ($edited.Count) { foreach ($e in $edited) { Add-Check $report 'PBI input' 'FAIL' "$($e.path) was changed after import. Inputs are evidence and must not be edited." 'Get-SDDStatus.ps1 -Fix restores the original and keeps the edited copy under .previous/.' } }
            else { Add-Check $report 'PBI input' 'OK' "$primary and $($files.Count - 1) other input file(s); none changed since import." '' }
            if ($inv.primaryApproval.approved) { Add-Check $report 'PBI approval' 'OK' 'The refined PBI is business-approved.' '' }
            else { Add-Check $report 'PBI approval' 'WARN' "Not business-approved: $($inv.primaryApproval.summary)." 'Ask the PO to approve it in the PBI Builder, or approve implementation explicitly despite it (Approve-SDD.ps1 -AcknowledgeUnapprovedPbi).' }
        }
        if (-not $baseline) { Add-Check $report 'Protection' 'WARN' 'No import record of the input files yet, so edits cannot be detected.' 'Get-SDDStatus.ps1 -Fix records them and makes them read-only.' }
        else {
            $writable = @($files | Where-Object { $rel = Get-SDDRelativePath $idDir $_; $baseline.ContainsKey($rel) -and -not (Get-Item -LiteralPath $_ -Force).IsReadOnly -and (Get-SDDFileSha256 $_) -eq $baseline[$rel] })
            $unrecorded = @($files | Where-Object { -not $baseline.ContainsKey((Get-SDDRelativePath $idDir $_)) })
            if ($writable.Count -or $unrecorded.Count) { Add-Check $report 'Protection' 'WARN' "$($writable.Count) input file(s) not read-only, $($unrecorded.Count) not recorded." 'Get-SDDStatus.ps1 -Fix records them and makes them read-only.' }
            else { Add-Check $report 'Protection' 'OK' 'Input files are recorded and read-only.' '' }
        }
        $visible = Get-SDDGitVisible $repo "docs/sdd/pbi-input/$id"
        if ($null -ne $visible -and $visible.Count) {
            $tracked = @(& git -C $repo ls-files -- "docs/sdd/pbi-input/$id" 2>$null)
            if ($tracked.Count) { Add-Check $report 'Git' 'INFO' "docs/sdd/pbi-input/$id is tracked by the team; it stays visible by design." '' }
            else { Add-Check $report 'Git' 'WARN' "$($visible.Count) PBI input file(s) visible in Git Changes." 'Get-SDDStatus.ps1 -Fix adds the local exclusion.' }
        }
    }
    # ---------------------------------------------------- stray copies and misplaced documents
    foreach ($s in (Find-SDDStrayInputs -Repository $repo -PbiId $id)) {
        $what = if ($s.kind -eq 'Folder') { "$($s.path)/" } else { $s.files -join ', ' }
        if ($s.tracked) { Add-Check $report 'Stray copy' 'WARN' "${what}: a copy of the PBI package that Git tracks." 'Tracked files are team content: remove the copy through a pull request (the builder does not move tracked files).' }
        else { Add-Check $report 'Stray copy' 'WARN' "${what}: a copy of the PBI package outside docs/sdd/pbi-input (shows in Git Changes)." 'Get-SDDStatus.ps1 -Fix merges missing files into the input folder and moves the copy under .previous/.' }
    }
    foreach ($m in (Find-SDDMisplacedDocs -Repository $repo -PbiId $id -Feature $script:Feature -IncludeUserFolders)) {
        if ($m.tracked) { Add-Check $report 'Misplaced' 'WARN' "$($m.path): $($m.reason) Git tracks it." 'Tracked files are team content: move it through a pull request if it is wrong.'; continue }
        if ($m.location -eq 'OutsideRepository' -and $script:Feature) {
            $draftDir = Join-Path (Get-SDDWorkFolder $repo $id $script:Feature) 'agent-draft'
            $h = Get-SDDFileSha256 $m.path
            if ((Test-Path -LiteralPath $draftDir) -and @(Get-SDDTreeFiles $draftDir | Where-Object { (Get-SDDFileSha256 $_) -eq $h }).Count) {
                Add-Check $report 'Misplaced' 'INFO' "$($m.path) is outside the repository; a copy is already in $(Get-SDDRelativePath $repo $draftDir)." ''
                continue
            }
        }
        $verb = if ($m.location -eq 'Repository') { 'moves' } else { 'copies' }
        Add-Check $report 'Misplaced' 'WARN' "$($m.path): $($m.reason)" "Get-SDDStatus.ps1 -Fix $verb it to the work folder's agent-draft/ for the agent to merge."
    }
    # ---------------------------------------------------- feature documents and gates
    $stage = 'None'
    if (-not $script:Feature) {
        Add-Check $report 'Spec/plan' 'FAIL' 'Start Development has not run for this PBI (no spec.md / plan.md, no SDD state).' ''
    } else {
        $report['artifacts'] = Get-SDDArtifactReceipt -Repository $repo -Feature $script:Feature -PbiId $id
        $folder = Join-Path (Get-SDDSpecRoot $repo) $script:Feature
        $missing = @(@('spec.md', 'plan.md') | Where-Object { -not (Test-Path -LiteralPath (Join-Path $folder $_) -PathType Leaf) })
        if ($missing.Count) { Add-Check $report 'Spec/plan' 'FAIL' "Missing in $(Get-SDDRelativePath $repo $folder): $($missing -join ', ')." '' }
        else { Add-Check $report 'Spec/plan' 'OK' "$(Get-SDDRelativePath $repo $folder)/spec.md and plan.md" '' }
        $statePath = @(Find-SDDStateFile -Repository $repo -Feature $script:Feature -PbiId $id) | Select-Object -First 1
        if ($statePath) { $stage = [string](Read-SDDState $statePath)['stage'] }
        $report.stage = $stage
        if (-not $missing.Count) {
            $order = @('Initialized', 'AnalysisComplete', 'ImplementationApproved', 'ImplementationVerified', 'PRReady')
            $next = if ($stage -in $order -and $stage -ne 'PRReady') { $order[[array]::IndexOf($order, $stage) + 1] } elseif ($stage -eq 'PRReady') { 'PRReady' } else { 'AnalysisComplete' }
            $raw = & (Join-Path $PSScriptRoot 'Assert-SDDArtifacts.ps1') -Repository $repo -Feature $script:Feature -PbiId $id -Stage $next -Json -NoStateUpdate | Out-String
            $gate = $null
            try { $gate = $raw.Substring($raw.IndexOf('{')) | ConvertFrom-Json } catch { $gate = $null }
            if ($gate -and $gate.result -eq 'PASS') { Add-Check $report 'Gate' 'OK' "$next gate passes." '' }
            elseif ($gate) {
                $first = @($gate.problems) | Select-Object -First 3
                Add-Check $report 'Gate' 'FAIL' "$next gate: $(@($gate.problems).Count) problem(s). $($first -join ' | ')" "The agent completes the documents, then runs tools/Assert-SDDArtifacts.ps1 -Repository . -Feature $script:Feature -Stage $next."
            }
        }
    }
    $planForGuard = if ($script:Feature) { Join-Path (Join-Path (Get-SDDSpecRoot $repo) $script:Feature) 'plan.md' } else { '' }
    $approvedBase = ''
    if ($script:Feature) {
        $approvalPath = Join-Path (Get-SDDWorkFolder $repo $id $script:Feature) 'approval.json'
        if (Test-Path -LiteralPath $approvalPath) { $approvedBase = [string](Read-SDDText $approvalPath | ConvertFrom-Json).gitHead }
    }
    foreach ($c in (Get-SDDSolutionChanges -Repository $repo -PlanPath $planForGuard -BaseRef $approvedBase)) { Add-Check $report 'Solution' 'FAIL' "$($c.path): $($c.reason)" "Review this command; never run automatically: $($c.restoreCommand)" }
    # ---------------------------------------------------- application source changed before approval
    $porcelain = @(& git -C $repo status --porcelain --untracked-files=all 2>$null)
    if ($LASTEXITCODE -eq 0) {
        $app = @($porcelain | Where-Object { $_ -and $_.Length -gt 3 -and (Test-SDDApplicationPath (($_.Substring(3) -split ' -> ')[-1].Trim('"'))) })
        $staged = @($app | Where-Object { $_[0] -ne ' ' -and $_[0] -ne '?' })
        $approved = $stage -in @('ImplementationApproved', 'ImplementationVerified', 'PRReady')
        if ($app.Count -and -not $approved) {
            Add-Check $report 'Source' 'FAIL' "$($app.Count) application file(s) changed before implementation approval ($($staged.Count) staged)." 'Keep them aside until the plan is approved: git stash push -u -m "<PBI> unapproved changes" (your decision; the builder never runs git write commands).'
        } elseif ($app.Count) { Add-Check $report 'Source' 'INFO' "$($app.Count) application file(s) changed ($($staged.Count) staged); implementation is approved." '' }
    }
    $blocking = @($report.checks | Where-Object { $_.status -eq 'FAIL' })
    $report.next = if ($blocking.Count) { $(if ($blocking[0].action) { $blocking[0].action } else { 'In Copilot Chat select Akzo SDD Developer and say: Start Development ' + $id + ' <Feature Name>' }) }
                   elseif (@($report.checks | Where-Object { $_.status -eq 'WARN' -and $_.action -like 'Get-SDDStatus.ps1 -Fix*' }).Count) { 'Run tools/Get-SDDStatus.ps1 -Fix' }
                   else { "Continue: next stage after $stage." }
    return $report
}

function Invoke-Fixes {
    $id = $script:PbiId
    if (-not $id) { return }
    $idDir = Join-Path $repo "docs/sdd/pbi-input/$id"
    $prevRoot = Join-Path $idDir '.previous'
    # 1. stray package copies -> hidden under .previous (kept, never deleted)
    $moved = New-Object System.Collections.Generic.List[string]
    foreach ($s in (Find-SDDStrayInputs -Repository $repo -PbiId $id)) {
        if ($s.tracked) { continue }
        $label = if ($s.folder) { $s.folder } else { 'repository-root' }
        $name = (($label -replace '[\\/:*?"<>|]', '_') -replace '^_+', '')
        $dst = Join-Path $prevRoot "stray-$stamp-$name"
        [void][IO.Directory]::CreateDirectory($dst)
        if ($s.kind -eq 'Folder') {
            $src = Join-Path $repo $s.path
            foreach ($child in @(Get-ChildItem -LiteralPath $src -Force)) { Move-Item -LiteralPath $child.FullName -Destination (Join-Path $dst $child.Name) }
            if (@(Get-ChildItem -LiteralPath $src -Force).Count -eq 0) { Remove-Item -LiteralPath $src -Force }   # the folder is empty now; its content is kept under .previous
            $fixes.Add("Moved stray copy $($s.path)/ to $(Get-SDDRelativePath $repo $dst)")
        } else {
            foreach ($rel in $s.files) { Move-Item -LiteralPath (Join-Path $repo $rel) -Destination (Join-Path $dst ([IO.Path]::GetFileName($rel))) }
            $fixes.Add("Moved stray file(s) $($s.files -join ', ') to $(Get-SDDRelativePath $repo $dst)")
        }
        $moved.Add($dst)
    }
    if (Test-Path -LiteralPath $idDir -PathType Container) {
        # 2. edited inputs -> restore the original from a pristine copy, else from the recorded download
        $baseline = Read-SDDInputBaseline $repo $id
        if ($baseline) {
            $pristine = @{}
            if (Test-Path -LiteralPath $prevRoot) { foreach ($f in (Get-SDDTreeFiles $prevRoot)) { $h = Get-SDDFileSha256 $f; if (-not $pristine.ContainsKey($h)) { $pristine[$h] = $f } } }
            $stillEdited = New-Object System.Collections.Generic.List[string]
            foreach ($rel in @($baseline.Keys)) {
                $target = Join-Path $idDir $rel
                if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { continue }
                if ((Get-SDDFileSha256 $target) -eq $baseline[$rel]) { continue }
                if ($pristine.ContainsKey($baseline[$rel])) {
                    $keep = Join-Path $prevRoot "edited-$stamp/$rel"
                    [void][IO.Directory]::CreateDirectory((Split-Path -Parent $keep))
                    $null = Set-SDDReadOnly $target $false
                    Move-Item -LiteralPath $target -Destination $keep
                    Copy-Item -LiteralPath $pristine[$baseline[$rel]] -Destination $target
                    $null = Set-SDDReadOnly $target $true
                    $fixes.Add("Restored $rel from a pristine copy; edited version kept as $(Get-SDDRelativePath $repo $keep)")
                } else { $stillEdited.Add($rel) }
            }
            if ($stillEdited.Count) {
                $logPath = Join-Path $repo ".sdd-builder/pbi-imports/$id.json"
                $sources = @()
                if (Test-Path -LiteralPath $logPath) { try { $sources = @((Read-SDDText $logPath | ConvertFrom-Json) | ForEach-Object { $_.sources } | ForEach-Object { $_.path } | Where-Object { $_ -and (Test-Path -LiteralPath $_) }) } catch { $sources = @() } }
                $src = @($sources) | Select-Object -Last 1
                if ($src) {
                    $r = Import-SDDPbiInput -Repository $repo -Source @($src) -PbiId $id -UpdateChanged
                    $fixes.Add("Re-imported $src to restore $($stillEdited -join ', ') ($($r.status)); edited versions kept under .previous/")
                } else { $fixes.Add("NOT restored: $($stillEdited -join ', ') - no pristine copy and no recorded download. Download the PBI Builder package again and run tools/Add-SDDPbiInput.ps1 <zip> -PbiId $id -UpdateChanged.") }
            }
        }
        # 3. files only present in the stray copies -> added to the input folder (never overwriting)
        foreach ($dst in $moved) {
            $r = Import-SDDPbiInput -Repository $repo -Source @($dst) -PbiId $id
            if ($r.status -eq 'Imported') { $fixes.Add("Added $($r.counts.copied) file(s) from the stray copy to the input folder") }
            elseif ($r.status -eq 'InputConflict') { $fixes.Add("Stray copy differs from the input folder in: $(@($r.files | Where-Object status -eq 'Conflict' | ForEach-Object packagePath) -join ', '). Kept as is; the input folder wins.") }
        }
        # 4. record and protect the inputs, hide them from Git Changes
        $null = Update-SDDInputBaseline -Repository $repo -PbiId $id
        $ex = Add-SDDLocalExclude -Repository $repo -RelativeDirs @("docs/sdd/pbi-input/$id")
        if ($ex."docs/sdd/pbi-input/$id" -eq 'Excluded') { $fixes.Add("Added docs/sdd/pbi-input/$id to .git/info/exclude") }
        $fixes.Add('Input files recorded and set read-only')
    }
    # 5. misplaced documents -> work folder agent-draft/ (local-only), outside files copied, repository files moved
    $work = if ($script:Feature) { Get-SDDWorkFolder $repo $id $script:Feature } else { Join-Path $repo "docs/sdd/changes/$id-drafts" }
    $draft = Join-Path $work 'agent-draft'
    foreach ($m in @(Find-SDDMisplacedDocs -Repository $repo -PbiId $id -Feature $script:Feature -IncludeUserFolders | Where-Object { -not $_.tracked })) {
        $src = if ($m.location -eq 'Repository') { Join-Path $repo $m.path } else { $m.path }
        $sub = if ($m.location -eq 'Repository') { ($m.path -replace '[\\/:*?"<>|]', '_') } else { 'outside_' + (([IO.Path]::GetFileName((Split-Path -Parent $src))) -replace '[\\/:*?"<>|]', '_') + '_' + [IO.Path]::GetFileName($src) }
        $dst = Join-Path $draft $sub
        if (Test-Path -LiteralPath $dst) { $dst = Join-Path $draft "$stamp-$sub" }
        [void][IO.Directory]::CreateDirectory($draft)
        if ($m.location -eq 'Repository') { Move-Item -LiteralPath $src -Destination $dst; $fixes.Add("Moved $($m.path) to $(Get-SDDRelativePath $repo $dst)") }
        else { Copy-Item -LiteralPath $src -Destination $dst; $fixes.Add("Copied $src to $(Get-SDDRelativePath $repo $dst) (original left in place)") }
    }
    if (Test-Path -LiteralPath $draft) { $null = Add-SDDLocalExclude -Repository $repo -RelativeDirs @((Get-SDDRelativePath $repo $work)) }
}

if ($Fix) {
    $null = Resolve-Context
    Invoke-Fixes
}
$report = Get-Status
$report['fixesApplied'] = $fixes.ToArray()
$blocking = @($report.checks | Where-Object { $_.status -eq 'FAIL' }).Count
if ($Json) { $report | ConvertTo-Json -Depth 6 | Write-Output; exit $(if ($blocking) { 1 } else { 0 }) }

Write-Host ("Akzo SDD status  v{0}  PBI {1}  feature {2}  stage {3}" -f (Get-SDDVersion), $report.pbiId, $(if ($report.feature) { $report.feature } else { '-' }), $(if ($report.stage) { $report.stage } else { '-' })) -ForegroundColor Cyan
foreach ($f in $fixes) { Write-Host "  FIXED  $f" -ForegroundColor Green }
foreach ($c in $report.checks) {
    $color = switch ($c.status) { 'OK' { 'Green' } 'WARN' { 'Yellow' } 'FAIL' { 'Red' } default { 'Gray' } }
    Write-Host ("  {0,-5} {1,-12} {2}" -f $c.status, $c.area, $c.detail) -ForegroundColor $color
    if ($c.action -and $c.status -ne 'OK') { Write-Host ("        {0,-12} -> {1}" -f '', $c.action) -ForegroundColor DarkGray }
}
Write-Host "NEXT: $($report.next)" -ForegroundColor Cyan
exit $(if ($blocking) { 1 } else { 0 })
