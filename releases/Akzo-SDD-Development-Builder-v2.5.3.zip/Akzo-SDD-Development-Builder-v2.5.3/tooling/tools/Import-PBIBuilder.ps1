﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Repository,
    # PBI Builder output: ZIP, folder or single Markdown file.
    [Parameter(Mandatory = $true)][string]$PbiSource,
    # Kept for compatibility with v2.4 scripts; the feature folder is chosen by Start Development.
    [string]$Feature,
    [string]$PbiId
)
# Akzo SDD Builder v2.5.3 - compatibility wrapper. PBI Builder output now goes to the single PBI input folder
# docs/sdd/pbi-input/<PBI-ID>/ (see Add-SDDPbiInput.ps1); the upstream package is never modified.
$ErrorActionPreference = 'Stop'
if ($Feature -and $Feature -notmatch '^[A-Z][A-Za-z]*$') { throw 'Feature must use short PascalCase letters only; exclude the PBI number.' }
$params = @{ Repository = $Repository; Source = @($PbiSource) }
if ($PbiId) { $params['PbiId'] = $PbiId }
& (Join-Path $PSScriptRoot 'Add-SDDPbiInput.ps1') @params
exit $LASTEXITCODE
