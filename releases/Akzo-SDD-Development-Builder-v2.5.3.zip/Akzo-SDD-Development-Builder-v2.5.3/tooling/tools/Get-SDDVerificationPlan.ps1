﻿[CmdletBinding()]
param([string]$Repository = (Get-Location).Path, [string[]]$ChangedFiles, [ValidateSet('Targeted','Final')][string]$Scope = 'Targeted')
Import-Module (Join-Path $PSScriptRoot 'SDD.Common.psm1') -Force
Get-SDDVerificationPlan -Repository $Repository -ChangedFiles $ChangedFiles -Scope $Scope | ConvertTo-Json -Depth 10
