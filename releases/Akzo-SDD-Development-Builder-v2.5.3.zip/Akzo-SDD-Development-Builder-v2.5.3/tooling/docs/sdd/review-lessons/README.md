# PR Review Feedback — Prevention Loop

Put exported historical PR comments in `inbox/` as `.md` or `.csv`, including PR ID, date, changed file, reviewer comment, and disposition. Do not paste secrets or private URLs/tokens in comments.

1. Classify each comment (correctness, domain, testing, integration, security, Sonar, maintainability).
2. Deduplicate by **root cause**, not exact wording.
3. Keep a reference to its originating PR and evidence of the confirmed fix.
4. Promote a rule to `approved-rules.md` **only after review**. The starter items in `candidate-rules.md` are hypotheses from known project patterns, NOT analyzed historical PR comments.
5. At each PBI start, select relevant approved rules and record evidence in `docs/sdd/changes/<...>/pr-review-audit.md`.
6. Before a PR, rerun quality checks, review affected files and mark each applicable rule Pass, Fail or an approved Waiver.

Automatic checks cannot guarantee all review feedback is addressed. Human review of architecture and business semantics remains mandatory.
