# Approved PR Review Rules

<!-- Do not promote candidates without evidence of the actual PR comment and developer review. -->

No historical PR review rules have been approved in this distribution. Import and review the real export first.
