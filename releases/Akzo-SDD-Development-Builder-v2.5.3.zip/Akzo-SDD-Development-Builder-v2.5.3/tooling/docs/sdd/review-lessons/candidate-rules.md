# Candidate Project Checks — NOT Verified PR Comments

The following are preventive checks informed by previous development issues, not claims about the content of an unprovided PR export. Review and confirm before approval.

| Candidate | Topic | Suggested check |
|---|---|---|
| C-001 | CQRS | Keep function/controller slim, domain validation in handlers/validators, register dependencies |
| C-002 | Validation response | Preserve agreed success/data/errors envelope; test both positive and negative branches |
| C-003 | Versioning | Cover 1.1, 2.1/2.2, sibling alternatives, lowercase `c` suffix, highest version resolution |
| C-004 | PaintSystem status | Test Actual↔Non-Actual transitions and edit permissions after changing status |
| C-005 | Product families | Explicitly test primary/secondary derived product parent lookup and eligibility |
| C-006 | Imitation request | Preserve agreed duplicate key; test active IR restrictions and technical/improved/complaint variants separately |
| C-007 | GraphQL | Confirm exact operation, nullable fields, generated client, DAB/CDMS parity |
| C-008 | Measurement | Test component and measurement completeness; exceptions for adaptation where approved |
| C-009 | Tests | Add focused positive/negative tests and run targeted tests plus required suite |
| C-010 | Sonar | Avoid dead paths, overly long handlers, untested branches and repeated code; measure actual gates |
| C-011 | Angular | Verify request/response DTO mapping, feature flag behavior and nonblank error notifications |
| C-012 | Scope and security | Do not commit unrelated code, tokens, or credentials; verify tests and DI configuration |
