---
agent: Akzo SDD Developer
description: "Verify: build, tests, coverage, Sonar self-review, merge safety, AC traceability, PR text."
---

Follow `.github/sdd/workflow.md`, the sole phase and execution-mode authority.


Run PHASE 10 (VERIFY). Run `tools/Invoke-SDDVerification.ps1 -Repository . -Feature <ShortFeatureName>` (real exit codes and logs; NOT EXECUTED when a tool is missing), the merge-safety diffs against the integration branch, and a Sonar self-review of the diff. Then `tools/Assert-SDDArtifacts.ps1 -Stage ImplementationVerified`.
Produce `completion.md` with evidence for every claim, AC traceability, commit message, PR title and PR description, then run `-Stage PRReady`. Do not commit or push.
