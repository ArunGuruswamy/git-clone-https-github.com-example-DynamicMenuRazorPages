---
agent: Akzo SDD Developer
description: "Write the delta spec, implementation plan and test plan for the current PBI (backend + UI, contract parity)."
---

Follow `.github/sdd/workflow.md`, the sole phase and execution-mode authority.


Run PHASE 4 (SPECIFY) and PHASE 5 (PLAN): write the published `src/.github/specs/<ShortFeatureName>/spec.md` and `plan.md` with every protocol P2 section, plus the working `06-test-plan.md`. Write the files yourself, read them back, run `tools/Assert-SDDArtifacts.ps1 -Stage AnalysisComplete` and fix until PASS. Do not edit source code and never ask me to create folders or save files.
