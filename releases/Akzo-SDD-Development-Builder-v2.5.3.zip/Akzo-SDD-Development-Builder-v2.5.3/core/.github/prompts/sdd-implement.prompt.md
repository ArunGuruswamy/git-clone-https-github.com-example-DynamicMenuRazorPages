---
agent: Akzo SDD Developer
description: Complete approved task groups using the authoritative SDD workflow.
---
Read `.github/sdd/workflow.md`. Record the user's explicit implementation approval with `Approve-SDD.ps1` and require ImplementationApproved PASS. Resume the remaining approved tasks in FAST mode unless the user explicitly selected another mode. Group related edits, update progress and verify meaningful checkpoints. Continue automatically, fix in-scope failures, and run final consolidated regression. Preserve user changes and report missing capabilities as NOT EXECUTED.
