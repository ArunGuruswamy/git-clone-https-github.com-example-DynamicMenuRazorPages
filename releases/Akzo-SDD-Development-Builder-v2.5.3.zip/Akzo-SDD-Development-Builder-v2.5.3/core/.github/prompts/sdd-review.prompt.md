---
agent: Akzo SDD Reviewer
description: "Independent pre-PR code review of the current PBI against all project standards and learned reviewer rules; writes review.md."
---

Follow `.github/sdd/workflow.md`, the sole phase and execution-mode authority.


Review the current PBI change (change folder under `docs/sdd/changes/`, diff against the integration branch from `.github/sdd/config.md`, plus uncommitted changes).
Apply the `pre-pr-review` skill completely: automated evidence first, then every checklist section (N/A where it does not apply), then every rule in `.github/sdd/review-learnings.md`.
Write `review.md` from the template. Do not edit any source file. End with the verdict and counts per severity.
