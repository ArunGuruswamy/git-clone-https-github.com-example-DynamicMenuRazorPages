---
agent: Akzo SDD Developer
description: "Inventory what the application already implements for a PBI (backend + UI), with an EXISTS/PARTIAL/MISSING/CONFLICT matrix per acceptance criterion."
---

Follow `.github/sdd/workflow.md`, the sole phase and execution-mode authority.


Run only PHASE 2 (INVENTORY) using the `feature-inventory` skill for the current PBI. Select the project from repository evidence; ask once only if ambiguous.
Include route ownership (DAB local vs forwarded to CDMS), the backend flow trace, the UI flow trace and the AC matrix with file evidence.
Write or update `01-feature-inventory.md`. Do not edit source code.
