---
agent: Akzo SDD Developer
description: "Consistency gate: AC → requirement → task → test coverage and constitution check before approval."
---

Follow `.github/sdd/workflow.md`, the sole phase and execution-mode authority.


Run PHASE 7 (ANALYZE). Produce `08-analysis.md`, then run `tools/Assert-SDDArtifacts.ps1 -Repository . -Feature <ShortFeatureName> -Stage AnalysisComplete`. On any FAIL, fix the artifacts and re-run. Then show the Approval Summary and STOP.
