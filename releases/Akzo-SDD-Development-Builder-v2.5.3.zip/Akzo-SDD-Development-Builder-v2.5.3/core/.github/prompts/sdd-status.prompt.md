---
agent: Akzo SDD Developer
description: "Show SDD status for the active PBI: stage, open questions, tasks done/remaining, evidence."
---

Follow `.github/sdd/workflow.md`, the sole phase and execution-mode authority.


Read `docs/sdd/changes/<PBI-ID>-<Feature>/sdd-state.json` (stage and history), `07-tasks.md`, `02-clarifications.md` and `verification.json`. Report in five lines maximum: PBI, role, stage (Initialized / AnalysisComplete / ImplementationApproved / ImplementationVerified / PRReady), blocking questions, tasks done/remaining, last recorded build/test result (or NOT EXECUTED).
