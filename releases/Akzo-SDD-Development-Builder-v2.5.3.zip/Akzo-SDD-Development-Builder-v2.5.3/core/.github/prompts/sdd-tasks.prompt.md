---
agent: Akzo SDD Developer
description: "Break the approved plan into coherent approved task groups."
---

Follow `.github/sdd/workflow.md`, the sole phase and execution-mode authority.


Run PHASE 6 (TASKS). Produce `07-tasks.md` in the working folder. Each task: tag, file, change, AC/Gap ref, verify command. Order: constants/contracts → failing test → implementation → DI → UI interfaces → service → store → component → UI tests. Do not tick tasks in plan.md (that would invalidate the approved plan hash).
