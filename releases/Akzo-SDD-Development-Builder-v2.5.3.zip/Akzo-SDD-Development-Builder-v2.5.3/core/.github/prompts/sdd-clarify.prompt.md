---
agent: Akzo SDD Developer
description: "Classify PBI requirements as CONFIRMED / ASSUMPTION / OPEN QUESTION and list PBI-vs-code gaps."
---

Follow `.github/sdd/workflow.md`, the sole phase and execution-mode authority.


Run PHASE 3 (CLARIFY) for the current PBI. Check `docs/architecture/OPEN-QUESTIONS.md` first.
Resolve technical questions automatically from approved inputs, project files, schema and integration-branch evidence. Ask only remaining business/scope decisions, in one batch with the affected AC and options. There is no question quota: zero questions is normal. Persist spec.md, plan.md and `02-clarifications.md` before reporting a blocker; continue independent work.
