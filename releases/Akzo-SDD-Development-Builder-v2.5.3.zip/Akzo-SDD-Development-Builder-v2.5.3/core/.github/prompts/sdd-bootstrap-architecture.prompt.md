---
agent: Akzo SDD Developer
description: "Generate evidence-based architecture docs (docs/architecture/*) for a repository that lacks them, mirroring the DAB document set."
---

Follow `.github/sdd/workflow.md`, the sole phase and execution-mode authority.


Generate `docs/architecture/` for THIS repository from code evidence only, mirroring the DAB set:
ARCHITECTURE-SUMMARY, SYSTEM-ARCHITECTURE (projects, layers, DI, middleware, error model), CQRS-FLOW (with 3 real end-to-end traces), DATA-ACCESS (XRM/Dataverse for CDMS: entities, queries, option-set cache), domain flow docs (IMITATION-REQUEST-FLOW, PAINT-SYSTEM-FLOW, MEASUREMENT-FLOW as applicable), STATUS-AND-VERSIONING, TESTING-ARCHITECTURE, ARCHITECTURE-DECISION-MAP, MERGE-SAFETY-CHECKLIST, ANTI-HALLUCINATION-RULES, OPEN-QUESTIONS.
Rules: cite file › class › method for every fact; anything not provable goes to OPEN-QUESTIONS.md; no source code edits.
Also confirm the build/test commands and update `.github/sdd/config.md`.
Write related documents continuously and report a concise summary.
