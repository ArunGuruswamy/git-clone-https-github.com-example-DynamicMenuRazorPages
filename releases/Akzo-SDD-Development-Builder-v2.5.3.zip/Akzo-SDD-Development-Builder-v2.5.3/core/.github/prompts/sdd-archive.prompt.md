---
agent: Akzo SDD Developer
description: "Archive a finished PBI: merge the delta into the living domain spec and move the change folder to archive."
---

Follow `.github/sdd/workflow.md`, the sole phase and execution-mode authority.


Run PHASE 11 (ARCHIVE). Merge the `spec.md` delta into `docs/sdd/specs/<domain>/spec.md` (ADDED append, MODIFIED replace, REMOVED delete; tag with the PBI id). Move the change folder to `docs/sdd/changes/archive/<yyyy-mm-dd>-<PBI-ID>/`. Move answered open questions into the architecture docs with evidence. Show the file list changed.
