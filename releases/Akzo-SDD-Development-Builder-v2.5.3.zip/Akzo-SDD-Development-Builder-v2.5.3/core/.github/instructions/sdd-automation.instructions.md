---
applyTo: "**"
---
# Akzo SDD startup contract
For a Start Development request or ongoing SDD PBI, use `.github/sdd/workflow.md` as the sole authority. First run `tools/Start-SDD.ps1` from the primary Git root (or equivalent edit operations when terminal execution is unavailable), read back the returned spec.md and plan.md, and report their absolute paths. Keep drafts saved during unresolved decisions. On implementation approval, ensure both canonical files are complete, record hash-bound approval and continue FAST. No application edits before that check.

Do technical searches and ordinary authorized operations directly; do not ask permission to search history/schema or create files. A legacy reference repository never becomes the implementation/artifact root. Preserve user edits and approved scope. Zero tests, compile errors and a previous successful build cannot demonstrate verification. This instruction file does not intercept IDE tool calls; the agent must execute the actual gates.
