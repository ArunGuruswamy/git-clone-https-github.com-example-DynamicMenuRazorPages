---
name: dab-development
description: Implement a PBI, user story, bug fix or change request in DAB (AN.ColorAppsAzure.BL Formula service, repository-verified .NET isolated Azure Functions, IDispatcher CQRS, FluentValidation, GraphQL/DAB via StrawberryShake). Covers imitation requests, paint systems, versioning, product derivation, status, GraphQL/CDMS routing, regression and merge safety.
---

> v2 note: this skill is the team's `implement-pbi` skill, unchanged in substance. It is wired into the SDD phases: Steps 0–5 = INVENTORY + CLARIFY, Step 6 = SPEC/PLAN/TASKS, Steps 7–8 = IMPLEMENT, Steps 9–12 = VERIFY. The additions marked **[v2]** come last.


Workflow authority: `.github/sdd/workflow.md`. Technical patterns below require evidence in actual project files; verify SDK, framework, dispatcher, DI and dependency versions before use. These sections do not add phases or developer pauses.

# Implement a PBI in the Formula Service

This skill enforces an evidence-first workflow. Do not skip to coding.

Full architecture evidence lives in `docs/architecture/`. Load only what the PBI needs.

---

## Step 0 — Orient

Read `docs/architecture/ARCHITECTURE-SUMMARY.md`.

Then load only the relevant deep docs:

| PBI touches | Load |
|---|---|
| new endpoint / handler | `CQRS-FLOW.md` |
| imitation request rules | `IMITATION-REQUEST-FLOW.md` |
| paint system create/update | `PAINT-SYSTEM-FLOW.md` |
| version numbers | `STATUS-AND-VERSIONING.md` (Part A) |
| status transitions | `STATUS-AND-VERSIONING.md` (Part B) |
| product / parent / derived | `PRODUCT-DERIVATION-RULES.md` |
| GraphQL / cache / CDMS | `DATA-ACCESS-GRAPHQL.md` |
| "where does rule X live" | `ARCHITECTURE-DECISION-MAP.md` |
| tests | `TESTING-ARCHITECTURE.md` |

Always keep `ANTI-HALLUCINATION-RULES.md` in mind.

---

## Step 1 — Classify the requirements

Produce a table before anything else:

| # | Requirement | CONFIRMED / ASSUMPTION / OPEN QUESTION | Evidence or missing info |
|---|---|---|---|

An ASSUMPTION never becomes a requirement without user confirmation.
If an OPEN QUESTION blocks a business rule, stop and ask.

Check `docs/architecture/OPEN-QUESTIONS.md` first — it may already be listed.

---

## Step 2 — Sync with develop

```powershell
git fetch origin
git status
git log --oneline origin/develop -15
git diff origin/develop --stat
```

Current behavior = `origin/develop`. Old feature branches are not truth.

---

## Step 3 — Find the existing implementation

Search before creating. Suggested order:

1. `ARCHITECTURE-DECISION-MAP.md` — locate the owning class.
2. `grep_search` for the business term, request type, constant name.
3. `find_symbol` (Find All References) on the owning method.
4. `Data/Graphql/GraphqlAssets/**/*.graphql` — 57 operations already exist.
5. `Common/Utility/Constants.cs` — the constant probably already exists.
6. Existing tests — they encode the current rules.

Assume it exists until proven otherwise.

---

## Step 4 — Trace the flow

Write out the real chain with file and method names:

```
Function endpoint
  -> Command/Query
  -> IDispatcher
  -> Handler
  -> Validator
  -> Helper / Resolver
  -> I*QueryService | I*CommandService
  -> .graphql operation
  -> response mapper
```

Record the current behavior. That is your regression baseline.

---

## Step 5 — Impact analysis

Answer each. "Not applicable" is a valid answer; silence is not.

- [ ] Which layers change?
- [ ] Which **shared** files are touched? (see `MERGE-SAFETY-CHECKLIST.md`)
- [ ] Which imitation request types are affected?
- [ ] Does a `.graphql` operation change? → generated client + test mocks change too.
- [ ] Product derivation: which of the four rules is in scope?
- [ ] Versioning: which type group (default / minor / major / complaint)?
- [ ] Status: does this service even own the transition?
- [ ] Local vs Global impact?
- [ ] Duplicate vs cross-over validation impact?
- [ ] Cache dependency? (missing cache degrades to `Guid.Empty` silently)
- [ ] Is the endpoint forwarded to CDMS by `RoutingMiddleware`?

---

## Step 6 — Plan (output before coding)

```
Requirement
Current behavior  (file / class / method)
Gap
Files to change
Approach
Test plan
Regression risks
Open questions
```

Present this. Get agreement if anything is ambiguous.

---

## Step 7 — Implement minimally

Follow existing patterns exactly:

- Command/Query: `ICommand<T>` / `IQuery<T>` in
  `Application/<Feature>/Commands|Queries/<Operation>/`.
- Handler: `ICommandHandler<,>` / `IQueryHandler<,>`, `ArgumentNullException.ThrowIfNull` at entry,
  validator invoked inside the handler. Auto-registered.
- Validator: FluentValidation, auto-registered by assembly scan.
- Complex logic: `HandlerHelper/` static helper or `<Feature>/Shared/` service — keeps Sonar
  cognitive complexity down.
- Data: new `.graphql` + `I<X>Service` method + implementation; **register new service interfaces
  in `Program.cs` manually**.
- Function: add the method to the existing `<Feature>Functions.<Verb>.cs` partial, with
  `[Function]`, `[RequiresRole]`, `[OpenApiOperation]`; return
  `req.CreateSuccessResponse(result, SuccessMessages.X)`; never catch generically.
- Constants: add to `Common/Utility/Constants.cs`. No magic strings.

Rules:
- Minimum change. No unrelated refactoring. No new libraries or abstractions.
- Obey `.github/instructions/sonar-rules.instructions.md`. No suppressions.

---

## Step 8 — Tests

MSTest + NSubstitute, mirroring the production folder layout, using `TestParams`.

Minimum per handler: success, validation failure, service exception.

Add where relevant:
- derived product: `IsPrimaryDerivedProduct` = `true`, `false`, **`null`**
- `ParentProductId` present and absent
- version: one per type group + "no siblings" + "highest sibling wins"
- status: cache hit and cache miss (`Guid.Empty` path)
- Local and Global variants
- GraphQL error response → `GraphQlException`
- assert the exact filter arguments passed to `ExecuteAsync`

---

## Step 9 — Build and verify

```powershell
dotnet build AN.ColorAppsAzure.BL.sln
```

Then targeted tests → affected test projects → full solution:

```powershell
dotnet test AN.ColorAppsAzure.BL.sln --settings coverlet.runsettings --collect:"XPlat Code Coverage"
```

If a `.graphql` file changed:

```powershell
git diff --stat -- "*Generated*"
```

The generated diff must correspond exactly to your operation edit.

---

## Step 10 — Regression

Re-test neighbouring flows that share the code you touched:

| Touched | Must retest |
|---|---|
| `ImitationRequestValidator.cs` | IR create **and** update, all request types |
| `CreateImitationRequestValidator.cs` | New Sample, Improved Formula, Technical minimum |
| `VersioningHelper.cs` / `CreatePaintSystemVersionResolver.cs` | every version type group |
| `ConversionEligibilityValidationHelper.cs` | create-side conversion; check update side unchanged |
| `PaintSystemQueryService.cs` | every caller of the changed method |
| `Program.cs` | app starts; DI resolves |
| `Constants.cs` | nothing renamed or removed |

---

## Step 11 — Merge safety

Run `docs/architecture/MERGE-SAFETY-CHECKLIST.md`.

```powershell
git diff origin/develop --name-only
git diff origin/develop --diff-filter=D --name-only
```

- [ ] Every changed file explained by the PBI
- [ ] Zero unexpected deletions
- [ ] No develop functionality removed
- [ ] No `Program.cs` registration lost
- [ ] No test removed or `[Ignore]`d
- [ ] Generated client diff reviewed

---

## Step 12 — Report

Traceability, one line per requirement:

```
Requirement -> File -> Class -> Method -> Test
```

Then the PR summary: what changed, why, which flows were regression-tested, what was deliberately
left alone, and any remaining open questions.

Never report "implemented" without traceability plus a green build and tests.

---

## Stop conditions

First resolve these conditions using the workflow question policy and authorized technical searches; only an unresolved required decision/dependency can block its affected task:

- a business rule, status transition or version rule cannot be proven from the repository
- a required GraphQL field is still unavailable after checking the actual Formula operations, schema/generated types and discovered DAB configuration; record the dependency without inventing a mutation
- the PBI requires changing shared validation and the affected request types are unclear
- approved sources leave a business choice ambiguous after comparing current code; an explicitly requested change from legacy behavior is a gap to implement, not a reason to ask again
- an entry in `docs/architecture/OPEN-QUESTIONS.md` blocks the work

Format:

```
NOT CONFIRMED
Evidence found: ...
Missing: ...
Question: ...
```

---

## [v2] Contract parity and CDMS routing (do this in INVENTORY)
- The UI calls DAB only (`colorAppsBaseUrl`). For every route in scope, decide: **local handler** or **forwarded to CDMS** (`RoutingMiddleware` + exclusion list + `FeatureFlags_Cdms` per environment, see `deployments/vars*.yaml`).
- If the route is forwarded in any environment, the CDMS implementation must match. Add a Gap and a CDMS task (in the CDMS repo), or record why not.
- Response envelope: `req.CreateSuccessResponse(result, SuccessMessages.X)` → UI `ApiResponse<T> { success, message, data, error }`. Errors through `ExceptionHandlingMiddleware` (400 validation, 401, 500, 502 GraphQL). Do not change the shape without a UI task.

## [v2] UI linkage
- Find the UI consumer in `docs/sdd/ui/UI-API-MAP.md` (copy in every repo). If a request or response field is added, renamed or removed, plan the matching changes to the UI `interfaces/*.ts`, service, store and spec.
- Backend PR merges first. The UI PR references it.

## Execution
Use `.github/sdd/workflow.md` for task grouping and checks. Regenerate GraphQL clients through the repository build, inspect generated types, and update affected callers and mocks in one coherent group.
