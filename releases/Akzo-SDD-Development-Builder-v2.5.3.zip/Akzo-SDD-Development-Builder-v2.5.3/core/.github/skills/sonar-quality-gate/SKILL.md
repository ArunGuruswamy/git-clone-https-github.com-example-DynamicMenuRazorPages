---
name: sonar-quality-gate
description: Sonar-clean coding and verification for CDMS and DAB C# (and UI TypeScript). Use when writing or reviewing code, fixing Sonar issues (complexity, coupling, unused code, coverage), or before commit/PR.
---

# Sonar Quality Gate

Rules: `.github/instructions/sonar-rules.instructions.md` (C#) and the TypeScript section below.
Proven patterns with code: `docs/sdd/quality-reference/` (CDMS repo). Look up the scenario in this table:

| Scenario | Reference |
|---|---|
| Complexity > limit | `SDD-BEFORE-AFTER-PATTERNS.md` Pattern 1 · `SDD-IMPLEMENTATION-CHECKLIST.md` "Extract Helper Methods" |
| HTTP/IO not testable | Pattern 7 · protected virtual seam + `Test<Class>` subclass |
| Coverage gaps | Pattern 6 · `SDD-IMPLEMENTATION-CHECKLIST.md` "Test Implementation Checklist" |
| Unused variable | Pattern 2 · `out _` |
| Broad catch | Pattern 4 · fatal-exception filter |
| String search | Pattern 8 · `OrdinalIgnoreCase` |

## Self-review before every step is declared done
1. Count decision points in each touched method. If > 10, extract before moving on.
2. Check for new magic strings, unused symbols and missing `using` blocks.
3. CDMS: `ConfigureAwait(false)` on every await.
4. DAB: no GraphQL client call in Application; no data access in Function.
5. Tests: each new branch has a test. Assert specific values, not just `IsNotNull`.

## Verify phase commands
- DAB: `dotnet test AN.ColorAppsAzure.BL.sln --settings coverlet.runsettings --collect:"XPlat Code Coverage"`
- CDMS: the test command from `.github/sdd/config.md` (confirmed on first run)
- UI: `npx jest --coverage <paths>`; `npm run lint`; `npm run format:check`
- Report changed-lines coverage when a coverage report is available. Otherwise say "coverage not measured".

## TypeScript (UI) Sonar essentials
- No `any`. Use `unknown` and narrow it. No `as unknown as` in tests (repo rule).
- Cognitive complexity ≤ 15 per function. Move logic out of templates into `computed()`.
- No unused imports or variables. No empty functions without a comment. No nested ternaries.
- Subscriptions: prefer signals, `rxMethod`, `takeUntilDestroyed`. No leaks.
- No `console.log`.
