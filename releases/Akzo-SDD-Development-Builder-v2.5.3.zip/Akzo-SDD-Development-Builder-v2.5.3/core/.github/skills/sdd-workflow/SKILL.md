---
name: sdd-workflow
description: Akzo spec-driven development lifecycle (route, intake, inventory, clarify, specify, plan, tasks, analyze, implement, verify, archive). Use when starting or continuing development of any PBI, user story, bug or change request on CDMS, DAB or AN.ColorAppsAzure.UI.
---

# SDD Workflow (OpenSpec core, Spec Kit gates)

## Folder layout (per repository)
```
.github/sdd/constitution.md          non-negotiables (always loaded)
.github/sdd/config.md                repos, branches and confirmed commands
.github/sdd/templates/*.md           artifact templates
docs/sdd/specs/<domain>/spec.md      LIVING spec: current truth per domain
src/.github/specs/<ShortFeatureName>/   PUBLISHED, checked in with the PR (no PBI number in folder)
    spec.md            (the only spec: verbatim PBI, AC, evidence, ADDED / MODIFIED / REMOVED, scenarios)
    plan.md            (the only plan: inventory, traceability, files, tests, risks, sequence)
docs/sdd/changes/<PBI-ID>-<Feature>/  ACTIVE working folder (local-only)
    sdd-state.json     stage + history (Initialized -> AnalysisComplete -> ImplementationApproved -> ImplementationVerified -> PRReady)
    00-intake.md
    01-feature-inventory.md
    02-clarifications.md
    06-test-plan.md
    07-tasks.md        (tick tasks here, never in plan.md)
    08-analysis.md
    approval.json / approval.md   (written by tools/Approve-SDD.ps1)
    verification.json + verification-logs/   (written by tools/Invoke-SDDVerification.ps1)
    pr-review-audit.md, review.md, completion.md
docs/sdd/changes/archive/<yyyy-mm-dd>-<PBI-ID>/   finished changes
```
Domains: `imitation-request`, `paint-system`, `formula`, `measurement`, `market-color`, `technical-remarks`, `derived-paint-system`, `lookups-optionsets`, `view-list`, `products-info`.

Cross-repo PBI (backend + UI): the change folder lives in the **backend** repo. The UI repo gets `docs/sdd/changes/<PBI-ID>-<slug>/ui-plan.md`, which links back to it, plus its own tasks.

Older artifact names map as: `developer-refined-pbi.md`, `04-spec.md` → published `spec.md` · `technical-analysis.md` → `01-feature-inventory.md` + `plan.md` · `implementation-spec.md`, `05-plan.md` → published `plan.md` · `development-tasks.md`, `tasks.md` → `07-tasks.md` · `analysis.md` → `08-analysis.md` · `test-plan.md` → `06-test-plan.md`. Existing files are read, never deleted.

## Workflow authority
Read `.github/sdd/workflow.md` for phases, gates, modes, capability handling, resume and verification. This skill is a layout reference. Load only the current phase templates and selected project skill.
