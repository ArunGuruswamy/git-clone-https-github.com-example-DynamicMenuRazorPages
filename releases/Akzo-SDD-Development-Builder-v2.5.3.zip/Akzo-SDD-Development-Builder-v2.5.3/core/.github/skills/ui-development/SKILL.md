---
name: ui-development
description: Plan and implement the AN.ColorAppsAzure.UI (Angular 21, NgRx Signal Store, Material + Akzo design system, Jest) part of a CDMS or DAB PBI, keeping UI/UX identical for both backends. Use for UI impact analysis, new or changed screens, forms, stores, services, interfaces, translations and Jest tests.
---

Workflow authority: `.github/sdd/workflow.md`. Technical patterns below require evidence in actual project files; verify SDK, framework, dispatcher, DI and dependency versions before use. These sections do not add phases or developer pauses.

# UI Development (shared by CDMS and DAB)

Reference: `docs/sdd/ui/UI-ARCHITECTURE.md`, `UI-API-MAP.md`, `UI-FEATURE-INVENTORY.md` (copies in every repo; the UI repo code is the truth).
Repo rules: the UI repo's `.github/copilot-instructions.md` (mandatory) and its `angular-testing-with-jest` skill.
The UI repo's own agents (`create-component`, `api-service`, `form-validation`, `generate-jest-tests`, …) may be used for single tasks. This skill owns the plan.

## Core rule: one UI, two backends
The UI does not know whether DAB or CDMS answers. Therefore:
- A UI change is needed **only** when the contract or the UX changes (new field, new endpoint, new validation message, new screen).
- The UX must stay identical for both backends. Never branch UI behaviour on the backend.
- Interfaces in `**/shared/interfaces/*.ts` are the contract. Change them in the same task as the service.

## Step 1 — UI impact analysis (during INVENTORY)
| Question | Where to look |
|---|---|
| Which screen / step shows this? | `dashboard/src/app/app.routes.ts`, `formulas/src/app/app.routes.ts`, stepper (`formula-app-stepper.html`: IR → Formula & Measurement → Paint System) |
| Which component, store, service? | `shared-external-libs/src/lib/components/<feature>/**` |
| Which request/response interface? | `<feature>/shared/interfaces/*.ts` |
| Which validation lives in the UI? | reactive form validators in base components (`base-paint-system`, `base-imitation-request`) |
| Permissions? | `shared-libs/src/lib/enums/*-permissions.enum.ts` |
| Texts? | `assets/translations/<lang>/<Feature>-<lang>.json` |
| Existing tests? | sibling `*.spec.ts` |
Write the result into the inventory's "UI flow trace" section, plus UI rows in the AC matrix.

## Step 2 — Choose the smallest UI pattern
1. Field only → interface + form control + template + translation + spec.
2. New simple master-data form → **JSON form config** + `GenericFormBuilder` (no new component).
3. New list → `view-list` registration + backend `shared/viewlist` + `{Entity}/GetAll`.
4. New dialog / sub-feature → copy the `technical-remarks` structure (component + `shared/{interfaces,services,store}`).
5. New stepper behaviour → the matching `formula-app-stepper/services/*` service; never put logic in the template.

## Step 3 — Task dependency order
interfaces → enum/constants → service (+ `HttpTestingController` spec) → Signal Store (+ spec) → component TS → template → SCSS → translations → component spec → route/permission wiring.
Verify related component/service changes at meaningful checkpoints under `.github/sdd/workflow.md`.

## Coding checklist (enforced on each edit)
- [ ] `ChangeDetectionStrategy.OnPush`, `input()/output()`, `inject()`, no `standalone: true`
- [ ] Signals + `computed()`; store uses `patchState`; no `mutate`
- [ ] `@if/@for/@switch`, `@let`; no method calls in template; no `ngClass/ngStyle`
- [ ] Typed: no `any`; tests use typed fixtures
- [ ] HTTP errors handled: `catchError` → store error state → snackbar/dialog (existing services)
- [ ] Permissions guarded with the existing enum + `roleGuard`/`hasRole`
- [ ] Texts via ngx-translate keys (no hard-coded user text when the area is translated)
- [ ] Material + Akzo design-system components only; no new visual patterns; no `::ng-deep`, no `!important`
- [ ] Jest: success, error, empty, permission-denied paths; ≥ 80 % (repo prompt) and 100 % of new branches (constitution target)
- [ ] File is inside Jest `testMatch`. If not, add a task to extend `jest.config.js` (agree first).

## Verify
```
npx jest <changed specs> --coverage
npx ng build <project>
npm run lint
npm run format:check
```
