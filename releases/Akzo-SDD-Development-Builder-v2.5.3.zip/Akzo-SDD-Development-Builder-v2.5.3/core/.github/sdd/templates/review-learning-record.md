# PR Review Learning

- PR ID / URL: <reference>
- Project: <CDMS|DAB|UI>
- Category: <correctness|tests|security|Sonar|architecture|naming|maintainability>
- Evidence: <exact code finding and affected path>
- Generalized rule: <testable rule>
- Automated check: <name or Not automatable>
- Reviewer/developer approval: <explicit approval>
- Regression example: <test or minimal example>

Do not treat extracted reviewer comments as binding rules until a human approves them.
