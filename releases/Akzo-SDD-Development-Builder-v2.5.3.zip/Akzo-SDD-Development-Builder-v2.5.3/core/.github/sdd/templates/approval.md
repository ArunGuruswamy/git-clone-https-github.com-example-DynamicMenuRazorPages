# Approval — <PBI-ID> <PBI Title>

- Feature folder: `<ShortFeatureName>` (no PBI number in folder)
- Selected project role / repository: <CDMS|DAB|UI / path>
- Approved spec: `src/.github/specs/<ShortFeatureName>/spec.md`
- Spec revision / SHA256: <SHA256>
- Plan revision / SHA256: <SHA256>
- Approved scope and excluded scope: <description>
- Approved by: <name or explicit chat confirmation>
- Approval date (UTC): <date>
- Approval evidence (PR / chat / link): <reference>
- Reapproval needed when spec changes: Yes
