# <PBI-ID> — <Title> · Intake

| Field | Value |
|---|---|
| Target backend | CDMS / DAB |
| UI in scope | Yes / No / To be decided by inventory |
| PBI source | <path or link to approved PBI package> |
| Branch | <current branch> (integration: `origin/develop` @ <short sha>) |
| Change folder | `docs/sdd/changes/<PBI-ID>-<slug>/` |
| Convention | v2 SDD / existing repo `spec.md`+`plan.md` (state which and why) |

## Business intent (verbatim from approved PBI — do not edit)
> ...

## Acceptance Criteria (verbatim, numbered)
| AC | Text |
|---|---|
| AC-1 | ... |

## Upstream decisions / technical remarks reused
- <decision> — source: <file>

## Explicitly ignored sections
- e.g. "Description ignored — SCS-dependent (PO decision <date>)"
