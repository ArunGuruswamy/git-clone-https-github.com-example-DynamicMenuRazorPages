# <PBI-ID> · Existing Feature Inventory

Snapshot of what the system does **today** on `origin/develop` @ <sha>. This is the regression baseline.

## 1. Route ownership (contract parity)
| UI call (service › method) | HTTP | Route | Served by today | Evidence |
|---|---|---|---|---|
| `CreateUpdatePaintSystemService.create` | POST | `PaintSystem/Create` | DAB local handler / forwarded to CDMS | `RoutingMiddleware` exclusion list, `Constants.Cdms*` |

## 2. Backend flow trace
```
Function <File>.<Method> [route]
  -> Command/Query <Type>
  -> Handler <Type>.Handle
  -> Validator <Type> (rules: ...)
  -> Helper/Resolver <Type>
  -> Service <IType>.<Method>
  -> .graphql <Operation> | XRM QueryExpression/FetchXml <entity>
  -> response mapper / ApiResponse<T>
```

## 3. UI flow trace (if UI touched)
```
Route <path> -> Component <Type> -> Store <Type>.<method> -> Service <Type>.<method> -> HTTP <verb> <route>
Form controls: ... | Validators: ... | Dialogs: ... | Translations: ...
```

## 4. AC coverage by current code
| AC | Status | Evidence (file › class › method) | Note |
|---|---|---|---|
| AC-1 | EXISTS | | reuse as is |
| AC-2 | PARTIAL | | missing: ... |
| AC-3 | MISSING | | |
| AC-4 | CONFLICT | | current code does X, PBI says Y → Gap G-1 |

## 5. Existing tests that encode current behaviour
| Test class › method | Rule it protects |
|---|---|

## 6. Shared / high-risk files in the blast radius
| File | Other callers / request types | Regression tests needed |
|---|---|---|
