# <ShortFeatureName> - Specification

- PBI ID: <PBI-ID>
- PBI title: <Full PBI title>
- Feature folder: <ShortFeatureName>
- Primary project role: <DAB | CDMS | UI> (skill: <dab-development | cdms-development | ui-development>)
- Refined PBI source: <docs/sdd/pbi-input/<PBI-ID>/REFINED-PBI.md>
- Refined PBI approval: <Approved | NOT business-approved (status fields)>
- PBI input package: <docs/sdd/pbi-input/<PBI-ID>/ (n files)>
- SDD builder: v2.5.2

## Refined PBI (verbatim source)

<!-- sdd:pbi-source:begin -->
<Paste the refined PBI file unchanged. Never edit inside these markers.>
<!-- sdd:pbi-source:end -->

## Acceptance criteria

<Every acceptance criterion copied verbatim, one per line, with its AC ID.>

## PBI sources and attachments

The refined PBI is the source of truth. Attachments are supporting evidence and add no scope by themselves.

| File | Type | Role | Status | AC referenced | Contribution / review result |
|---|---|---|---|---|---|
| `REFINED-PBI.md` | md | Primary | Read | <AC-1, ...> | Primary requirements source (verbatim above). |
| <`attachments/<file>`> | <pdf> | <Attachment> | <Read / Extracted / RequiresAgentReview / Unreadable / Unsupported> | <AC-n> | <What it contributes, or Reviewed / Unreadable / Unsupported / Not relevant with the reason> |

## Discrepancies and source conflicts

| ID | Type | Sources | Detail | Resolution or open question |
|---|---|---|---|---|
| <PX-... / SX-01> | <type> | <files> | <what differs> | <resolved with source, or open question with impact> |

## Existing implementation and repository evidence

<Current behaviour per AC with real file paths, Class.Method and existing tests. Status per AC: EXISTS / PARTIAL / MISSING / CONFLICT.>

## Delta requirements (ADDED / MODIFIED / REMOVED)

### ADDED
<R-n (AC-n) The system SHALL ...>

### MODIFIED
<R-n (AC-n) Previously: <current behaviour with evidence>. Now: The system SHALL ...>

### REMOVED
<R-n ... Reason and migration, or "None - <reason>".>

## Business rules and state transitions

<Statuses (Actual/Non-Actual), versioning and alternatives (case-sensitive suffixes), derived-product family, Local/Global, IR types.>

## Status and versioning rules

<Status transitions, version numbering and suffixes, naming, derived-product and Local/Global rules that apply, or "N/A - <reason>".>

## API and GraphQL contracts

<Route, verb, request, response, GraphQL operation, nullability, generated client impact, UI contract.>

## Validation rules and response envelope

<Validator rules, error codes and exact messages (constants), response envelope.>

## Testable scenarios

<Scenario AC-n: GIVEN ... WHEN ... THEN ... (positive and negative).>

## Open questions, assumptions, decisions and dependencies

<Confirmed decisions with their source file; open questions (BLOCKING / NON-BLOCKING) with implementation impact; assumptions; dependencies.>
