# <PBI-ID> · Test Plan

## AC → Test mapping
| AC | Scenario | Layer | Test class › method | Type (new/updated/existing) |
|---|---|---|---|---|

## Mandatory scenario checklist
- [ ] Handler: success · validation failure · service/GraphQL/XRM failure
- [ ] Null / empty / whitespace inputs
- [ ] Derived product: `IsPrimaryDerivedProduct` true · false · **null**; `ParentProductId` present · absent
- [ ] Versioning: one per type group + no siblings + highest sibling wins
- [ ] Status: cache hit · cache miss (`Guid.Empty`)
- [ ] Local · Global
- [ ] Duplicate hit · cross-over hit · clean path
- [ ] HTTP: 2xx valid · 2xx invalid body · error with body · error without body (CDMS HTTP calls)
- [ ] UI: store success/error, service HttpTestingController, component render + interaction, form validators
- [ ] Neighbouring flows regression: <list>

## Commands
| Scope | Command |
|---|---|
| Targeted | |
| Project | |
| Solution / workspace | |
