# <PBI-ID> · Development Completion

| Item | Result (with evidence) |
|---|---|
| Target | CDMS / DAB (+ UI) |
| Branch | |
| Build | command + result |
| Tests | command + passed/failed counts |
| Coverage (new code) | |
| Sonar / lint | |
| Merge safety (`git diff origin/develop --diff-filter=D`) | |
| Pre-PR review | READY FOR PR · rounds: <n> · findings fixed: <n> · waived: <n> |

## Traceability
| AC | Requirement | File › Class › Method | Test |
|---|---|---|---|

## Deliberately left alone

## Remaining risks / manual verification

## Suggested commit message
```
<type>(<scope>): <summary> [<PBI-ID>]
```

## PR title
## PR description
