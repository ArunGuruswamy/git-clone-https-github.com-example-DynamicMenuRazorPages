# <PBI-ID> · Tasks

Follow `.github/sdd/workflow.md`: coherent task groups, FAST by default after approval. Each task records AC, affected files, evidence and a checkpoint; no per-file builds or pauses.
Tags: [BE] backend · [UI] frontend · [T] test · [CFG] DI/config · [DOC] docs · [P] can run in parallel with previous

| # | Tag | File | Change | AC / Gap | Verify with | Status |
|---|---|---|---|---|---|---|
| T1 | [BE] | `Common/Utility/Constants.cs` | add `ErrorMessages.X` | AC-2 | `dotnet build ...` | ☐ |
| T2 | [T]  | `...Tests/...HandlerTests.cs` | add failing test for AC-2 | AC-2 | `dotnet test --filter ...` | ☐ |
| T3 | [BE] | `...Handler.cs` | implement rule | AC-2 | `dotnet test --filter ...` | ☐ |
