# Contract Matrix — <PBI-ID> <PBI Title>

| API route + method | Primary owner | Runtime route/feature flag | Request DTO + nullability | Response success and errors | GraphQL/schema | UI caller/contract | Evidence | Verification/test |
|---|---|---|---|---|---|---|---|---|
| <route> | <CDMS/DAB/UI> | <source location> | <fields> | <shapes> | <operation or N/A> | <Angular path or N/A> | <real paths> | <test> |

Fail readiness on unresolved breaking request, response, error, routing or UI parity. Use N/A with evidence where appropriate.
