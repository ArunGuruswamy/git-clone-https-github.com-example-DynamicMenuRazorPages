# <PBI-ID> · Clarifications & Decisions

## Requirement classification
| # | Requirement / statement | CONFIRMED / ASSUMPTION / OPEN QUESTION | Evidence or missing info |
|---|---|---|---|

## PBI vs Code Gaps
| Gap | PBI says | Code does (evidence) | Business-impacting? | Resolution |
|---|---|---|---|---|
| G-1 | | | Yes → ask / No → technical choice | |

## Questions for PO / BA / Tech lead
```
NOT CONFIRMED
Evidence found: ...
Missing: ...
Question: ...
```

## Decision log
| Date | Decision | By | Source |
|---|---|---|---|
