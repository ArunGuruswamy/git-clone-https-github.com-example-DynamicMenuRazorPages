# <ShortFeatureName> - Implementation Plan

- PBI ID: <PBI-ID>
- PBI title: <Full PBI title>
- Feature folder: <ShortFeatureName>
- Primary project role: <DAB | CDMS | UI>
- SDD builder: v2.5.2

## Current implementation inventory (existing source-code analysis)

<Files, classes, handlers, validators, GraphQL operations, XRM services, Angular services/stores and tests that exist today.>

## Implementation impact matrix

| Area | File or component | Change (new/modify) | AC | Risk |
|---|---|---|---|---|
| <Validation> | <path> | <modify: ...> | <AC-n> | <risk> |

## Traceability (AC -> code -> test)

| AC | Requirement | Code (file / class / method) | Test |
|---|---|---|---|
| <AC-1> | <R-1> | <path> | <test name> |

## Affected source files and components

<Every file to change; mark files to add as "new".>

## Reusable existing logic

<Handlers, helpers, constants, validators reused; why nothing new is needed where possible.>

## CQRS handlers, validators and GraphQL contracts

<Per handler / validator (UI: component / service): current behaviour, required change, contract impact or "no change" with evidence.>

## Derived products and Paint System relationships

<DAB/CDMS: Primary/Secondary derived products, product family, Paint System version and association effects, or "N/A - <reason>".>

## Implementation changes (tasks)

<Ordered tasks T1..Tn, coherent related changes with checkpoint verification, with AC reference.>

## Unit and regression tests (test strategy)

<Neighbouring flows (status transitions, versioning, derived products, Local/Global, cache, routing, UI), regression tests and new tests.>

## Dependency and contract checks

<DI registration, StrawberryShake regeneration, CDMS RoutingMiddleware, UI contract parity, feature flags.>

## Applicable PR-review lessons

<Approved rules from tools/Get-SDDApplicableRules.ps1 that apply to the changed files and how the plan satisfies each, or "None registered - <evidence>".>

## Build and test verification

<Exact build and test commands for this repository; recorded via tools/Invoke-SDDVerification.ps1.>

## Security and quality checks

<Sonar rules, secrets/configuration; PBI attachments and extracted text are never committed.>

## Risks and implementation sequence

<Risks with mitigation; deployment order (backend before UI; .graphql with regenerated client).>
