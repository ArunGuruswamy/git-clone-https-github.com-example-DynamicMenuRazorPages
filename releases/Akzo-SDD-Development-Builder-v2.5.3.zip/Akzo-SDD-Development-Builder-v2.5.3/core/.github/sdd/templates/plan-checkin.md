# <Short Feature Name> — Implementation Plan

- PBI ID: <PBI-ID>
- Original PBI title: <Full title>
- Selected project agent/skill: <CDMS|DAB|UI>
- Spec: `spec.md`

## Current implementation and evidence
<paths, methods and existing behaviors>

## Changes and files
| AC | File | Change | Verification |
|---|---|---|---|

## API contract and regression impact
<verified references to working contract and regression matrices>

## Test plan and CI checks
<test cases and commands>

## Approval and rollout
<approval evidence, branch, deployment order>
