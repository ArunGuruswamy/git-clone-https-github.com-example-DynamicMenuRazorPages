# Regression Impact — <PBI-ID> <PBI Title>

| Area | Impact / N/A reason | Source evidence | Required test |
|---|---|---|---|
| Paint System status/status reason transitions | | | |
| Formula components / measurement / developed-predicted validation | | | |
| Primary/secondary derived family and parent product | | | |
| Local/Global and Geo | | | |
| IR type / duplicate keys | | | |
| Versioning and alternatives | | | |
| Cache fallback and reference data | | | |
| GraphQL/StrawberryShake generated client | | | |
| CDMS/DAB routing, feature flags, and API parity | | | |
| Angular UI state, enable/disable and error messages | | | |
| Deployment/configuration/permissions | | | |

Risk rating: <Low|Medium|High>. Mandatory targeted tests: <paths>. No test claimed as passed without run evidence.
