# <PBI-ID> · Consistency Analysis (pre-approval gate)

| Check | Result | Detail |
|---|---|---|
| Every AC has ≥1 requirement in spec.md | PASS/FAIL | |
| Every requirement has ≥1 scenario | | |
| Every requirement has ≥1 task | | |
| Every AC has ≥1 test in test-plan.md | | |
| No task without an AC/Gap reference | | |
| No ASSUMPTION used as a requirement | | |
| No blocking OPEN QUESTION | | |
| Constitution articles 1–11 respected | | |
| Contract parity stated | | |
| Shared-file regression tests listed | | |
| Sonar risk: methods likely > complexity limit identified | | |

## Verdict
READY FOR APPROVAL / BLOCKED (reasons)
