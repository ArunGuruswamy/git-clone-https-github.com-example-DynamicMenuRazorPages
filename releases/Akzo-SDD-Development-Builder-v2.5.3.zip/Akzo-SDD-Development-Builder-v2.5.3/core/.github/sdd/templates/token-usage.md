# Token / Context Usage — <PBI-ID> <PBI Title>

Provider token usage is **not** observable from agent prose alone. Record actuals from provider or IDE usage logs only; otherwise enter `Unknown`. Do not estimate actual consumption from character counts.

| Phase | Files read / source scope | Input tokens (actual / Unknown) | Output tokens (actual / Unknown) | Tool/cache use | Optimization |
|---|---|---|---|---|---|
| Route/Intake | | Unknown | Unknown | | |
| Inventory | | Unknown | Unknown | | |
| Clarify/Spec/Plan | | Unknown | Unknown | | |
| Tasks/Analyze | | Unknown | Unknown | | |
| Implement | | Unknown | Unknown | | |
| Review/Verify/Archive | | Unknown | Unknown | | |

## Context budget plan
- Load repository signature and one selected project skill first; other project skill only if impacts justify it.
- Reuse inventories and file lists; prefer source-path references over repeating files in chat.
- Inspect changed files, referenced dependencies and affected tests; widen only with evidence.
- Preserve complete acceptance criteria, safety and verification content; optimize redundant chatter, not correctness.
- Compare baseline and pilot on identical PBIs and same model/provider where possible.
- Savings claim: Not established until measurements collected.
