# <Domain> — Living Specification

Current, merged truth for this domain. Updated only by the archive step.
Each requirement cites the PBI that introduced or last modified it.

## Requirements

### Requirement: <name>
Source: <PBI-ID> (archived <date>) · Code: `<file › class › method>`
The system SHALL ...
#### Scenario: ...
- GIVEN ... WHEN ... THEN ...
