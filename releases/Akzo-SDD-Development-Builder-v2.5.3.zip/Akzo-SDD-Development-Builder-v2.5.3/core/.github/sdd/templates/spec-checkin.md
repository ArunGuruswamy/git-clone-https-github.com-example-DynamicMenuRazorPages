# <Short Feature Name> — Specification

- PBI ID: <PBI-ID>
- Original PBI title: <Full title>
- Target project and selected role: <CDMS|DAB|UI>
- Source and approval reference: <approved package / approval.md>

## Business intent and acceptance criteria
<verbatim>

## ADDED / MODIFIED / REMOVED requirements
<requirements + GIVEN/WHEN/THEN scenarios with AC IDs>

## Constraints and API/UI contract
<verified constraints, links to contract matrix>

## Out of scope
<scope>
