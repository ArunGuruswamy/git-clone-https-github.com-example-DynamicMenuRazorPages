# <PBI-ID> · Pre-PR Review

| Item | Value |
|---|---|
| Round | 1 / 2 / 3 |
| Reviewed range | `<INTEGRATION_BRANCH>...HEAD` + uncommitted · <n> files · +<a> / -<d> lines |
| Verdict | READY FOR PR / CHANGES REQUIRED |
| Open findings | BLOCKER <n> · MAJOR <n> · MINOR <n> · NIT <n> |

## Automated evidence
| Check | Command | Result |
|---|---|---|
| Build | | |
| Tests | | passed/failed/skipped |
| Coverage (new code) | | |
| Format / lint | | |
| Merge safety (deletions) | | |
| Generated client diff (DAB) | | |

## Findings
| ID | Sev | File:line | Rule (source) | Problem | Fix | Status |
|---|---|---|---|---|---|---|
| F1 | MAJOR | `Application/.../XHandler.cs:42` | S3776 complexity ≤ 15 (sonar-rules) | Handle() complexity 18 | Extract `ResolveX()` helper | Open → Fixed (R1) |

## Checklist result
| Section | Result |
|---|---|
| 1 Scope & merge safety | PASS / FAIL (F-ids) / N/A |
| 2 Spec conformance | |
| 3 Architecture & patterns | |
| 4 Sonar | |
| 5 Naming & readability | |
| 6 Tests | |
| 7 Error handling, logging, security | |
| 8 PR hygiene | |
| 9 Learned rules (L-ids) | |

## Waived (developer decision only)
| ID | Reason | Waived by |
|---|---|---|
