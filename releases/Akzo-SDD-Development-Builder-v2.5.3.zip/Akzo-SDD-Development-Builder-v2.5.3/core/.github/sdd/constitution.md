# Akzo Color Apps — SDD Constitution

Non-negotiable rules for every SDD session on CDMS, DAB and UI.
The `analyze` gate checks the plan against every article. A violation blocks approval.

---

## Article 1 — Business intent is owned upstream
1. The approved PBI, its Acceptance Criteria (AC) and the PO/BA decision log define **WHAT**.
2. Repository evidence may refine **HOW**. It never silently changes WHAT.
3. Record a difference between approved requirements and current code as a **PBI vs Code Gap**. An explicitly approved behavior change is work to implement. Ask only when the approved sources leave a required business choice unresolved; do not request approval again merely because the requested behavior differs from legacy code.

## Article 2 — Evidence before claims
1. Every statement about current behaviour cites `file › class › method` (line when useful).
2. Every requirement is classified **CONFIRMED / ASSUMPTION / OPEN QUESTION**. An assumption never becomes a requirement without confirmation.
3. Never claim build, test, coverage, Sonar, deployment or PR success without command output.
4. Follow the question policy in `.github/sdd/workflow.md`: resolve repository facts with authorized searches first, persist draft spec/plan, and continue independent work. Use `NOT CONFIRMED` only for a remaining required decision or unavailable dependency, with the evidence and affected task. Pause only that dependent work:
   ```
   NOT CONFIRMED
   Evidence found: <file / class / method / behaviour>
   Missing:        <what cannot be proven from the repository>
   Question:       <exact question for PO / BA / tech lead>
   ```

## Article 3 — Search before create
1. Assume the feature, helper, constant, query, `.graphql` operation, component, service or store already exists until search proves otherwise.
2. Reuse existing patterns. No new library, abstraction or parallel pattern without explicit approval.

## Article 4 — Current truth is the integration branch
1. Current behaviour = `origin/develop` (or the branch configured in `.github/sdd/config.md`).
2. Old feature branches are not truth. Never copy a whole file from an old branch.

## Article 5 — Contract parity (one UI, two backends)
1. `AN.ColorAppsAzure.UI` calls **one** base URL (`colorAppsBaseUrl`). DAB's `RoutingMiddleware` forwards some routes to the CDMS Function App when `FeatureFlags_Cdms` is on.
2. Therefore any endpoint added or changed in CDMS **or** DAB must keep the route, HTTP verb, query/body shape and response envelope that the UI consumes (`ApiResponse<T> { success, message, data, error }` or the endpoint's existing typed shape).
3. Every plan states: which backend serves the route today (local DAB handler vs forwarded to CDMS), and whether the UI needs a change.

## Article 6 — Minimal, scoped change
1. Implement only approved scope. No unrelated refactoring, reformatting or "while I'm here" fixes.
2. A PBI branch must not remove functionality present in the integration branch.
3. Never delete, `[Ignore]` or `skip` a failing test to go green.

## Article 7 — Quality gate is the same for every C# project
1. Sonar rules in `.github/instructions/sonar-rules.instructions.md` apply to CDMS and DAB alike.
2. New code: 0 new Sonar issues, cognitive complexity ≤ 15, cyclomatic ≤ 10 per method, coverage target 100 % of new lines/branches (pipeline gate is the floor, not the target).
3. No new `// NOSONAR` / `#pragma warning disable` / `[SuppressMessage]` without written reviewer agreement in the PR.

## Article 8 — Tests are part of the change
1. Tests are written with the code, not after.
2. Every AC maps to at least one test. Every handler: success, validation failure, service failure.

## Article 9 — Approval gate and repository safety
1. Read-only inspection is allowed before approval. **No production source edit before explicit approval** ("approve", "go", "start implementation").
2. Never automatically: switch branch, reset, revert, discard, stash-pop, delete files, commit, push, force-push, create/complete a PR. Only when the developer explicitly asks.
3. Preserve unrelated working-tree changes.

## Article 10 — Continuous execution
Follow `.github/sdd/workflow.md`, the sole execution-mode and phase authority. FAST is the default after approval. STANDARD adds checks; STEP pauses per task only on explicit request. Ordinary approved edits need no further permission. Verify coherent groups and perform final regression; preserve every other constitution safeguard.

## Article 11 — Independent review before PR
1. After the last task is green, the change is reviewed by the **Akzo SDD Reviewer** agent (`pre-pr-review` skill + `review-learnings.md`). A model does not approve its own work.
2. A PR is raised only with verdict `READY FOR PR`: 0 open findings, or only NITs the developer explicitly waived.
3. Every real PR comment is fed back with `/sdd-learn-review`, so the same comment does not come back.

## Article 12 — Knowledge is kept
1. When the PBI is done, the delta spec is merged into the living spec (`docs/sdd/specs/<domain>/spec.md`) and the change folder moves to `docs/sdd/changes/archive/`.
2. Newly proven rules move from `OPEN-QUESTIONS.md` into the architecture docs with an evidence citation.
