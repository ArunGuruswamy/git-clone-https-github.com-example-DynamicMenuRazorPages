# Review Learnings

Rules learned from real PR review comments. The reviewer agent checks **every** rule on every review.
Add rules with `/sdd-learn-review` (paste the reviewer's comments). Keep one rule per line of behaviour. Never delete a rule; mark it `retired` with a reason.

| ID | Applies to | Rule | Example comment (source PR) | Added |
|---|---|---|---|---|
| L-001 | All | Identifiers, routes, messages and JSON keys contain no spelling mistakes | (seed) `PaintSytem` route spelling in UI | 2026-10-07 |
| L-002 | C# | No new `// NOSONAR` / pragma suppressions without written reviewer agreement | (seed) team Sonar policy | 2026-10-07 |
| L-003 | All | Do not reformat or reorder untouched code in a PBI diff | (seed) DAB merge-safety checklist | 2026-10-07 |
| L-004 | Tests | Assert exact arguments of side effects (`Received(1).X(Arg.Is<...>(...))`), not only return values | (seed) DAB testing architecture | 2026-10-07 |
