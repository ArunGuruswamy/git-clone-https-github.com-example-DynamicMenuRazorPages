﻿<#
.SYNOPSIS
Removes only hash-owned builder assets, or rolls back the latest install. User edits are retained.
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param([Parameter(Mandatory = $true)][string]$Destination, [switch]$RollbackLastUpgrade)
$ErrorActionPreference = 'Stop'
$Destination = [IO.Path]::GetFullPath($Destination).TrimEnd([char]92,[char]47)
$manifestPath = Join-Path $Destination '.sdd-builder/manifest.json'
if (-not (Test-Path -LiteralPath $manifestPath)) { throw "No builder manifest: $manifestPath. Nothing removed." }
$doc = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
$installs = @($doc.installs)
if (-not $installs.Count) { throw 'Manifest contains no install records.' }
$records = if ($RollbackLastUpgrade) { @($installs[-1]) } else { $installs }
function Resolve-OwnedPath([string]$relative, [switch]$Backup) {
    if (-not $relative -or [IO.Path]::IsPathRooted($relative) -or $relative -match '(^|[\\/])\.\.([\\/]|$)') { throw "Unsafe manifest path: $relative" }
    $relative = $relative.Replace('\','/')
    if ($Backup) { if ($relative -notmatch '^\.sdd-installer-backups/') { throw "Backup outside owned folder: $relative" } }
    elseif ($relative -notmatch '^(\.github/(agents|skills|prompts|instructions|sdd)/|tools/|docs/(architecture/|sdd/(quality-reference/|review-lessons/|ui/)))') { throw "Not a builder asset path: $relative" }
    if ($relative -match '(^|/)specs/|^docs/sdd/(pbi-input|changes|pbi-sources)/') { throw "Protected document path: $relative" }
    $full = [IO.Path]::GetFullPath((Join-Path $Destination $relative))
    $current = $Destination
    foreach ($part in $relative.Split('/')) {
        $current = Join-Path $current $part
        if ((Test-Path -LiteralPath $current) -and ((Get-Item -LiteralPath $current -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Linked path cannot be removed/restored: $relative" }
    }
    return $full
}
$first = [ordered]@{}; $last = @{}
foreach ($r in $records) {
    foreach ($f in @($r.files)) {
        if ($f.action -notin @('installed','updated')) { continue }
        $null = Resolve-OwnedPath $f.path
        if ($f.backup) { $null = Resolve-OwnedPath $f.backup -Backup }
        if (-not $first.Contains([string]$f.path)) { $first[[string]$f.path] = $f }
        $last[[string]$f.path] = $f
    }
}
$removed = 0; $restored = 0; $kept = 0
$tracked = @(& git -C $Destination -c core.quotepath=false ls-files --cached 2>$null)
foreach ($path in $first.Keys) {
    $origin = $first[$path]; $latest = $last[$path]; $full = Resolve-OwnedPath $path
    if (-not $latest.sha256) { Write-Warning "Kept without ownership hash: $path"; $kept++; continue }
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { Write-Warning "Kept user deletion: $path"; continue }
    if ((Get-FileHash -LiteralPath $full -Algorithm SHA256).Hash.ToLowerInvariant() -ne $latest.sha256) { Write-Warning "Kept (edited after install): $path"; $kept++; continue }
    if ($origin.action -eq 'updated') {
        $bak = if ($origin.backup) { Resolve-OwnedPath $origin.backup -Backup } else { '' }
        if (-not $bak -or -not (Test-Path -LiteralPath $bak) -or -not $origin.PSObject.Properties['backupSha256'] -or -not $origin.backupSha256 -or (Get-FileHash -LiteralPath $bak -Algorithm SHA256).Hash.ToLowerInvariant() -ne $origin.backupSha256) { Write-Warning "Kept: backup missing or ownership hash unavailable/mismatched: $path"; $kept++; continue }
        if ($PSCmdlet.ShouldProcess($path,'Restore verified pre-install version')) { Copy-Item -LiteralPath $bak -Destination $full -Force; $restored++ }
    } else {
        if ($tracked -contains $path) { Write-Warning "Kept (now Git-tracked): $path"; $kept++; continue }
        if ($PSCmdlet.ShouldProcess($path,'Remove unchanged builder asset')) { Remove-Item -LiteralPath $full -Force; $removed++ }
    }
}
# A marker alone does not prove hook ownership. Rollback removes only a hook created by that install.
$hookRecord = @($records | Where-Object { $_.PSObject.Properties['hook'] -and $_.hook -and $_.hook.created }) | Select-Object -First 1
$hooksConfig = (& git -C $Destination config --get core.hooksPath 2>$null | Out-String).Trim()
if ($hookRecord -and -not $hooksConfig) {
    $hookDir = (& git -C $Destination rev-parse --path-format=absolute --git-path hooks 2>$null | Out-String).Trim()
    if ($hookDir) {
        $hook = Join-Path $hookDir 'pre-commit'
        if (Test-Path -LiteralPath $hook) {
            if ((Get-Item -LiteralPath $hook).Attributes -band [IO.FileAttributes]::ReparsePoint) { Write-Warning 'Kept linked hook'; $kept++ }
            elseif ((Get-FileHash -LiteralPath $hook -Algorithm SHA256).Hash.ToLowerInvariant() -eq $hookRecord.hook.sha256) {
                if ($PSCmdlet.ShouldProcess($hook,'Remove hash-owned builder hook')) { Remove-Item -LiteralPath $hook }
            } else { Write-Warning 'Kept modified hook'; $kept++ }
        }
    }
}
if (-not $RollbackLastUpgrade) {
    $exclude = (& git -C $Destination rev-parse --path-format=absolute --git-path info/exclude 2>$null | Out-String).Trim()
    if ($exclude -and (Test-Path -LiteralPath $exclude)) {
        $ours = @($first.Keys | ForEach-Object { '/' + $_ })
        $lines = @(Get-Content -LiteralPath $exclude)
        $retained = @($lines | Where-Object { $ours -notcontains $_.Trim() -or (Test-Path -LiteralPath (Join-Path $Destination $_.Trim().TrimStart('/'))) })
        # Keep input, work, cache and backup exclusions, and all non-builder entries.
        if ($PSCmdlet.ShouldProcess($exclude,'Remove exclusions only for removed builder files')) { Set-Content -LiteralPath $exclude -Value $retained -Encoding UTF8 }
    }
}
if ($kept -gt 0) { Write-Warning "$kept modified/unverified assets retained. Manifest retained for review and recovery." }
elseif ($RollbackLastUpgrade) {
    $doc.installs = @($installs | Select-Object -First ($installs.Count - 1))
    $doc.currentVersion = if ($doc.installs.Count) { $doc.installs[-1].version } else { $null }
    if ($PSCmdlet.ShouldProcess($manifestPath,'Drop completed rollback record')) { $doc | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $manifestPath -Encoding UTF8 }
} elseif ($PSCmdlet.ShouldProcess($manifestPath,'Remove completed uninstall manifest')) { Remove-Item -LiteralPath $manifestPath }
Write-Host "Removed $removed, restored $restored, retained $kept modified/unverified assets. Specifications, inputs, settings and backups preserved."
