@echo off
setlocal EnableExtensions
rem Explicit reviewed update of tracked builder assets; application source is never selected.
rem Uses the same policy-preserving launcher. Edited owned files remain protected.
set "SDD_TEAM_UPDATE=1"
call "%~dp0Install-DevelopmentBuilder.cmd" %*
exit /b %ERRORLEVEL%
