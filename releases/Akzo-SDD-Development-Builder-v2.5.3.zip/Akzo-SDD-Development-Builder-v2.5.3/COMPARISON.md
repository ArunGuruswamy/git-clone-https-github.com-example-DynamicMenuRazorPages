# Akzo SDD Developer v2: market comparison and design decisions

This document compares the v1 Akzo SDD Developer agent with the main market SDD frameworks. It explains what v2 takes from each one and why.

---

## 1. The three candidates you shortlisted

| | **GitHub Spec Kit** | **OpenSpec** (Fission-AI) | **spec-compare** (cameronsjo) |
|---|---|---|---|
| What it is | SDD toolkit: `specify` CLI plus slash commands/skills | Lightweight, repo-native SDD with change proposals and delta specs | A research repo that compares about 20 SDD tools. It is not a tool you install. |
| Core flow | constitution → specify → clarify → plan → tasks → analyze → implement | explore → propose → apply → archive (plus new / ff / verify / sync) | n/a |
| Artifacts | `.specify/memory/constitution.md`, `specs/NNN-feature/{spec,plan,research,data-model,quickstart,tasks}.md`, `contracts/` | `openspec/specs/<domain>/spec.md` (living truth), `openspec/changes/<id>/{proposal,design,tasks}.md` + `specs/` deltas | n/a |
| Change model | One folder per feature. A second iteration on the same feature is awkward. | **Delta specs**: `ADDED / MODIFIED / REMOVED Requirements`, each with GIVEN/WHEN/THEN scenarios. Archive merges them into the living spec. | Names "the modification problem" as the main weakness of most SDD tools |
| Gates | Stops for review at every stage (heavier) | One gate before apply (faster) | Names "the enforcement gap": writing specs is easy, but proving the code follows them is hard |
| Best for | Greenfield, governance, approval trails | Brownfield, frequent incremental changes | Choosing a tool |
| Weak spot for Akzo | Heavy ceremony per PBI. No "what does the system do *now*" view. | Thin on constitution, quality gates and test traceability | n/a |

Others worth knowing: **BMAD** (role-based PO→Architect→Dev handoffs, adaptive sizing), **Kiro** (IDE-native requirements/design/tasks), **Spec Kitty** (git-worktree isolation per feature), **Superpowers** (low ceremony, design docs only for architecture).

### Ratings for the Akzo CDMS/DAB/UI estate

| Tool | Fit | Why |
|---|---|---|
| OpenSpec | ★★★★★ | Your work is 100% brownfield. Almost every PBI changes existing IR/Paint System behaviour, so delta specs fit exactly. |
| Spec Kit | ★★★★☆ | Its clarify and analyze gates and its constitution are the strongest quality controls. Its greenfield folder model is a poor fit. |
| BMAD | ★★★☆☆ | You already have a separate PO/BA PBI Builder upstream, so BMAD's PO/Architect roles duplicate it |
| spec-compare | Reference only | Use it to justify the choice, not to run development |

---

## 2. Gaps in v1 (the `Akzo-SDD-Development-Builder-v1.0` you have today)

| # | v1 gap | Impact |
|---|---|---|
| 1 | Agent `tools:` lists only `read`, `search`, `terminal`. **No `edit` tool.** | The agent cannot edit files after approval in VS Code. It falls back to pasting code. |
| 2 | No skills. CDMS and DAB rules are a few bullet lines in the agent. | DAB's rich `implement-pbi` skill and architecture docs are never loaded |
| 3 | No CDMS knowledge base. The 7 CDMS SDD `.md` files (Sonar, testability, null-safety…) are not referenced. | CDMS code repeats Sonar issues that are already solved |
| 4 | No UI awareness. `AN.ColorAppsAzure.UI` is ignored. | Backend changes ship without the matching Angular change or contract check |
| 5 | No "current truth" spec. Each PBI starts from zero. | The existing feature is re-discovered every time. There is no delta view. |
| 6 | No consistency gate between spec ↔ tasks ↔ tests (Spec Kit `analyze`) | ACs silently drop out of the implementation |
| 7 | No CONFIRMED / ASSUMPTION / OPEN QUESTION discipline (DAB has it, v1 doesn't) | Invented business rules |
| 8 | No contract-parity rule, although the UI reaches CDMS **through** DAB's `RoutingMiddleware` | A route or response-shape drift breaks the UI only when the CDMS flag is toggled |
| 9 | Implementation is a single block | Large diffs and late build failures without coherent task groups and targeted verification checkpoints. |
| 10 | No archive step | Knowledge from a finished PBI is lost |

---

## 3. v2 approach: "OpenSpec core, Spec Kit gates, Akzo evidence rules"

The authoritative lifecycle and execution modes are defined in [`core/.github/sdd/workflow.md`](core/.github/sdd/workflow.md). Repository evidence selects the role; explicit PBI identity is reconciled with the branch and persisted state. After analysis and hash-bound implementation approval, FAST completes coherent task groups continuously, then independent review and final regression. STEP is available only on explicit request.


| Phase | Borrowed from | Akzo-specific addition |
|---|---|---|
| Constitution | Spec Kit | `.github/sdd/constitution.md`, the non-negotiables from DAB anti-hallucination rules + CDMS SDD skills |
| Inventory | OpenSpec "living spec" + DAB playbook "search before create" | Backend **and** UI inventory, every AC marked EXISTS / PARTIAL / MISSING / CONFLICT with file evidence |
| Clarify | Spec Kit `/clarify` + DAB CONFIRMED/ASSUMPTION/OPEN | Checks `OPEN-QUESTIONS.md` first. `NOT CONFIRMED` stop format. |
| Specify | OpenSpec delta specs | GIVEN/WHEN/THEN scenarios, linked to AC ids |
| Plan | Spec Kit `/plan` | Impact dimensions (status, version, derivation, Local/Global, routing), **contract parity** CDMS↔DAB↔UI |
| Tasks | Spec Kit `/tasks` | Coherent task groups with AC traceability and targeted verification checkpoints |
| Analyze | Spec Kit `/analyze` | AC → task → test coverage matrix. Constitution violations block approval. |
| Implement | Spec Kit `/implement`, OpenSpec `/apply` | FAST by default, applicable Sonar rules, implementation gated by approval |
| Independent review | Existing Akzo reviewer | Review current scope and evidence; resolve findings before final readiness |
| Verify | OpenSpec `/verify`, Traycer-style verify (spec-compare's "enforcement gap") | Build + tests + coverage + merge-safety diff + traceability, with evidence |
| Archive | OpenSpec `/archive` | Merges the delta into `docs/sdd/specs/<domain>/spec.md` and writes the PR description |

What v2 deliberately leaves out:
- Spec Kit's `research.md` / `quickstart.md` / `data-model.md` as mandatory files. They are optional and created only when the PBI needs them.
- Separate CLI installs (`specify`, `openspec`). Everything is plain Copilot agent, prompt, skill and instruction files, so nothing extra is needed on locked-down CGI/Akzo machines.
- Git worktrees (Spec Kitty). Use the existing checkout unless explicitly requested; the installer leaves branches alone.

---

## 4. Sources

- GitHub Spec Kit: https://github.com/github/spec-kit · Microsoft Learn module: https://learn.microsoft.com/en-us/training/modules/spec-driven-development-github-spec-kit-enterprise-developers/3-examine-github-spec-kit
- OpenSpec: https://openspec.dev/docs/getting-started
- spec-compare: https://github.com/cameronsjo/spec-compare
- Framework comparison (Spec Kit vs OpenSpec vs BMAD vs Superpowers): https://developertoolkit.ai/en/ecosystem/frameworks/spec-driven-frameworks/
