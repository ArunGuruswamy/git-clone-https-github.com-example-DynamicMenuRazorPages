# TESTING-ARCHITECTURE

---

## 1. Projects

| Test project | Covers |
|---|---|
| `src/AN.ColorAppsAzure.Formula.Tests/AN.ColorAppsAzure.Formula.Application.Tests` | handlers, validators, helpers (the bulk of business-rule coverage) |
| `src/AN.ColorAppsAzure.Formula.Tests/AN.ColorAppsAzure.Formula.Data.Tests` | query/command services against mocked generated GraphQL interfaces |
| `src/AN.ColorAppsAzure.Formula.Tests/AN.ColorAppsAzure.Formula.Function.Tests` | function endpoints, middleware (`RoutingMiddlewareTests`) |
| `src/AN.ColorAppsAzure.Formula.Tests/AN.ColorAppsAzure.Formula.Common.Tests` | `EnvConfigTests`, constants, extensions |

Test folder layout mirrors the production folder layout.

## 2. Conventions

- **Framework:** MSTest — `[TestClass]`, `[TestMethod]`.
- **Mocking:** NSubstitute — `Substitute.For<IService>()`.
- **Setup:** constructor-based with `readonly` fields. `[TestInitialize]` is not used when all
  fields are `readonly`.
- **Signatures:** `public async Task` for async tests, `public void` for sync.
- **Shared constants:** `Application.Tests/Utility/TestParams.cs`. Use it instead of magic strings.
- **Assertions:** `Assert.AreEqual(expected, actual)` ordering; no `[ExpectedException]` —
  use `Assert.ThrowsExceptionAsync<T>()` (Sonar rule).
- **Coverage settings:** `coverlet.runsettings` at repository root; SonarCloud pipeline in
  `deployments/sonarcloud.yaml`.

## 3. Mocking strategy

Tests mock **two** things:

1. Hand-written Data interfaces — `IPaintSystemQueryService`, `IImitationRequestQueryService`,
   `IMarketColorQueryService`, `IProductQueryService`, `I*CommandService`, `IMemoryCacheManager`.
   This is the normal case for Application tests.
2. **Generated StrawberryShake client interfaces** — e.g. `Substitute.For<IFormulaGraphQL>()`,
   plus substitutes for generated result interfaces such as
   `IProducts_GetParentProductId_Products_Items`. This is used in Data tests and in some
   validator tests.

> Because generated result interfaces are mocked directly, **a `.graphql` change breaks tests at
> compile time**. That is intentional and useful. Fix the mocks; do not cast around them.

The repo instruction "Do NOT mock GraphQL clients" applies to *Application* tests. Data tests must
mock the client — that is what they exist for.

## 4. Representative test classes

| Production code | Test class |
|---|---|
| `CreateImitationRequestValidator` | `Application.Tests/ImitationRequest/Validator/CreateImitationRequestValidatorTests.cs` |
| `CreatePaintSystemHandler` | `Application.Tests/PaintSystem/CreatePaintSystemHandlerTests.cs` |
| `VersioningHelper` | `Application.Tests/PaintSystem/Shared/VersioningHelperTests.cs` |
| `ConversionEligibilityValidationHelper` | `Application.Tests/PaintSystem/Shared/ConversionEligibilityValidationHelperTests.cs` |
| `LinkDerivedProductsAsyncHandler` | `Application.Tests/PaintSystem/LinkDerivedProductsAsyncHandlerTests.cs` |
| `PaintSystemQueryService` | `Data.Tests/Graphql/PaintSystem/Queries/PaintSystemQueryServiceTests.cs` |
| `PaintSystemCommandService` | `Data.Tests/Graphql/PaintSystem/Commands/PaintSystemCommandServiceTests.cs` |
| `RoutingMiddleware` | `Function.Tests/Middleware/Routing/RoutingMiddlewareTests.cs` |
| `EnvConfig` | `Common.Tests/Utility/EnvConfigTests.cs` |

## 5. Required coverage per change type

Minimum three scenarios for every handler: **success, validation failure, service exception.**

| Change | Additional required tests |
|---|---|
| IR validation rule | one test per affected request type; at minimum New Sample + Improved Formula + Technical |
| Duplicate / cross-over rule | exact-MCI duplicate hit, colour cross-over hit, and the clean path |
| Paint system existence rule | `count == 0` and `count > 0`, plus primary-derived (parent lookup) and non-derived |
| Product / derivation logic | `IsPrimaryDerivedProduct` = `true`, `false`, **`null`**; `ParentProductId` present and absent |
| Versioning | one test per IR type group (default / minor / major / complaint) + "no siblings" + "highest sibling wins" |
| Status | status present in cache, and status **missing** from cache (`Guid.Empty` path) |
| Local/Global | Local and Global variants, since only the Improved-Formula query filters `LocalGlobalId` |
| GraphQL operation | service test asserting the exact filter arguments passed to `ExecuteAsync`, plus an error-response test (`GraphQlException`) |
| Cache usage | cache miss returning `null` must not throw |

## 6. Existing examples to copy

| Scenario | Example |
|---|---|
| derived product resolves to parent | `CreateImitationRequestValidatorTests.Validate_ResolvesParentProductId_WhenProductIsPrimaryDerivedAndPaintSystemExistsOnParent` |
| non-derived uses own product | `CreateImitationRequestValidatorTests.Validate_UsesOriginalProductId_WhenProductIsNotPrimaryDerived` |
| business rule blocks even when derived | `ConversionEligibilityValidationHelperTests` (RelestProtect) |
| null/empty collection arguments | `PaintSystemCommandServiceTests` (LinkDerivedProducts null/empty product ids) |
| generated interface substitution | `PaintSystemQueryServiceTests` (mocking `IProducts_GetParentProductId_Products_Items`) |

## 7. Commands

```powershell
# full solution
dotnet build AN.ColorAppsAzure.BL.sln
dotnet test AN.ColorAppsAzure.BL.sln --settings coverlet.runsettings --collect:"XPlat Code Coverage"

# single project
dotnet test src/AN.ColorAppsAzure.Formula.Tests/AN.ColorAppsAzure.Formula.Application.Tests/AN.ColorAppsAzure.Formula.Application.Tests.csproj
```

In Visual Studio, use the `get_tests` / `run_tests` tooling with `TypeName` or
`FullyQualifiedName` filters. Repository skill: `.github/skills/run-tests/SKILL.md`.

## 8. Do not

- Do not add `[Ignore]` without a linked reason.
- Do not assert on booleans with `Assert.IsTrue(x == true)`.
- Do not introduce a second mocking library.
- Do not delete a failing test to make a build green — the test encodes an existing business rule
  that another PBI may depend on.
