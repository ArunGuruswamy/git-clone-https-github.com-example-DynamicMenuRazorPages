# MERGE-SAFETY-CHECKLIST

Base branch: **`origin/develop`** (`origin/HEAD -> origin/develop`).

Multiple PBIs routinely touch the same small set of files. A careless rebase or a file copied from
an old branch silently removes another PBI's behaviour.

---

## 1. High-risk shared files

| File | Why shared | PBIs that touch it | Failure mode |
|---|---|---|---|
| `Application/ImitationRequest/Shared/ImitationRequestValidator.cs` | base validator for **create and update**, all request types | any IR validation PBI | a rule added for one request type rejects all others |
| `Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestValidator.cs` | duplicate, cross-over, paint-system existence, Improved-Formula eligibility all in one class | most IR PBIs | one branch's `DependentRules` chain overwrites another's |
| `Application/PaintSystem/Commands/CreatePaintSystem/CreatePaintSystemHandler.cs` | orchestrates versioning, status, linked records, conversion, IR status update | most Paint System PBIs | a whole-file copy from an old branch loses linked-record or conversion logic |
| `Application/PaintSystem/Commands/CreatePaintSystem/HandlerHelper/CreatePaintSystemVersionResolver.cs` | sibling filter shared by every IR type | versioning PBIs | narrowing the filter changes versions for all types |
| `Application/PaintSystem/Shared/VersioningHelper.cs` | all version arithmetic and naming | versioning PBIs | a new type mapping silently reclassifies an existing type |
| `Application/PaintSystem/Shared/ConversionEligibilityValidationHelper.cs` | product-number rules | conversion PBIs | reordering the branches changes RelestProtect precedence |
| `Application/PaintSystem/Commands/UpdatePaintSystem/UpdatePaintSystemHandler.cs` | level + conversion on update | Paint System PBIs | divergence with create-side rule widens |
| `Data/Graphql/PaintSystem/Queries/PaintSystemQueryService.cs` | 11 methods used by validators, versioning and queries | many | changing a shared method's filters affects unrelated callers |
| `Data/Graphql/.../Generated/FormulaGraphQL.Client.cs` (and the other three) | generated, committed, huge | any `.graphql` PBI | textual merge conflicts resolved wrongly; regenerate instead |
| `Data/Graphql/GraphqlAssets/Formula/schema.graphql` | schema snapshot | any schema PBI | stale snapshot breaks another branch's generation |
| `Function/Program.cs` | single composition root | any PBI adding a service | lost `AddScoped` registration → runtime DI failure, not a compile error |
| `Common/Utility/Constants.cs` | every constant, id name, message | almost every PBI | duplicated or renamed constants |
| `Function/Middleware/Routing/RoutingMiddleware.cs` | CDMS exclusion list | routing/CDMS PBIs | an endpoint silently starts/stops being forwarded |
| `Application.Tests/Utility/TestParams.cs` | shared test constants | every PBI with tests | value changed for one test breaks others |

## 2. Before you start a PBI

```powershell
git fetch origin
git rebase origin/develop        # or merge, per team policy
dotnet build AN.ColorAppsAzure.BL.sln
dotnet test AN.ColorAppsAzure.BL.sln --settings coverlet.runsettings
```

If the build/tests are red **before** your change, stop and report it. Do not build on a broken base.

## 3. Before every PR

### 3.1 Diff review

```powershell
git diff origin/develop --stat
git diff origin/develop --name-only
git diff origin/develop --diff-filter=D --name-only     # anything DELETED vs develop
git diff origin/develop -- "*Generated*" --stat          # generated client churn
```

Check:

- [ ] Every file in the diff is explainable by the PBI.
- [ ] Zero unexpected deletions.
- [ ] No `Program.cs` registration removed.
- [ ] No constant removed from `Constants.cs`.
- [ ] No test removed or `[Ignore]`d.
- [ ] Generated client diff matches exactly the `.graphql` operations you edited.
- [ ] `schema.graphql` changed only if you intended to refresh the snapshot.

### 3.2 Shared-file review

For each high-risk file in §1 that appears in your diff:

- [ ] Open the develop version side by side: `git diff origin/develop -- <file>`
- [ ] Confirm every removed line was removed on purpose.
- [ ] List which request types / flows the change affects.
- [ ] Confirm a regression test exists for each of those flows.

### 3.3 Old-branch contamination

If any code came from an older feature branch:

- [ ] It was re-applied as a targeted edit, **not** a whole-file copy.
- [ ] Its behaviour was re-validated against current develop, not against the old branch.
- [ ] Nothing that develop gained since that branch was written has been reverted.

## 4. Deployment-order risks

When two PBIs both touch `VersioningHelper`, `CreateImitationRequestValidator` or a shared
`.graphql` operation:

- Whoever merges second must **rebase and re-run the first PBI's tests**, not just their own.
- A `.graphql` change must be merged together with its regenerated client and its updated test
  mocks. Splitting them across PRs produces a broken develop.
- A new `Program.cs` service registration must merge before or with the code that resolves it.

## 5. Red flags — stop and investigate

- A diff larger than the PBI scope.
- `*.Client.cs` changing when you edited no `.graphql` file.
- A test failing in a feature you did not touch.
- `Constants.cs` showing modifications you did not make.
- `git diff origin/develop --diff-filter=D` returning anything.
