# ARCHITECTURE-DECISION-MAP

Business rule → owning file / class / method. Use this to find the right place before writing code.

---

## Imitation Request

| Rule | Owner |
|---|---|
| Required fields (MCI, type, product, local/global, urgency, team) | `Application/ImitationRequest/Shared/ImitationRequestValidator.cs` (rule chain in ctor) |
| Due date not in the past | `ImitationRequestValidator.IsDueDateValid` / `RetrieveLocalTimeFromUtcTime` |
| Formula region not allowed for Global | `ImitationRequestValidator.IsFormulaRegionValid` |
| MCI must resolve a ColorId | `ImitationRequestValidator.HasValidColorId` |
| Active MCI must exist | `ImitationRequestValidator.HasActiveMarketColorInstance` |
| MCI must have a role | `CreateImitationRequestValidator.HasAssignedRole` |
| No duplicate active IR (MCI + product + local/global) | `CreateImitationRequestValidator.NoActiveImitationRequestExists` → `IImitationRequestQueryService.GetActiveImitationRequest` → `Formula_CheckActiveImitationRequest` |
| No cross-over active IR (colour + product + local/global) | same method → `GetActiveImitationRequestByColor` → `Formula_CheckActiveImitationRequestByColor` |
| New Sample only when no paint system exists | `CreateImitationRequestValidator.GetPaintSystemValidationError` |
| All other types require a paint system | same method |
| Which product id the paint system check uses | `CreateImitationRequestValidator.ResolvePaintSystemProductIdAsync` |
| Improved Formula derived-product eligibility (Coil owner) | `CreateImitationRequestValidator.IsProductEligibleForImprovedFormula` |
| Per-product fan-out of one payload | `CreateImitationRequestMapper.Map` |
| Audit stamping (`RecordModifiedBy`) | `CreateImitationRequestHandler.CreateImitationRequest` via `IUserContextAccessor` |
| Partial success envelope (`total/succeeded/failed`) | `CreateImitationRequestHandler.Handle` + `Function/Functions/ImitationRequestFunctions.Post.cs` |
| View name whitelist for list query | `Application/ImitationRequest/Queries/GetImitationRequestList/ViewValidator.cs` |

## Paint System

| Rule | Owner |
|---|---|
| Create orchestration | `Application/PaintSystem/Commands/CreatePaintSystem/CreatePaintSystemHandler.Handle` |
| Request field validation | `CreatePaintSystemValidator` |
| "Imitation request not found" | `CreatePaintSystemHandler.Handle` (null `ctx` → `AppValidationException(ErrorMessages.ImitationRequestNotFound)`) |
| Initial status = Incomplete | `CreatePaintSystemHandler.ResolveInitialPaintSystemStatusId` |
| Linked Color/ColorImitation creation | `CreatePaintSystemHandler.RequiresLinkedRecords` + `CreateLinkedColorAsync` + `CreatePaintSystemInputFactory.BuildColorImitations` |
| Mutation input shape | `CreatePaintSystemInputFactory.Build(CreatePaintSystemInputParams)` |
| Conversion-to-all-products (create) | `CreatePaintSystemHandler.ResolveConversionEligibilityAsync` + `Application/PaintSystem/Shared/ConversionEligibilityValidationHelper.IsConversionAllowed` |
| Conversion-to-all-products (update) | `UpdatePaintSystemHandler.DetermineConversionEligibility` |
| Paint system level (Adapted / Industrialized) | `UpdatePaintSystemHandler.GetPaintSystemLevelId` |
| Paint system type resolution | `IPaintSystemTypeResolver.ResolvePaintSystemTypeAsync` |
| Response detail assembly | `CreatePaintSystemDetailsFactory.BuildDetailsAsync`, `CreatePaintSystemDetailsMapper` |
| IR → InDevelopment after create | `CreatePaintSystemImitationRequestStatusUpdater.UpdateAsync` |

## Versioning

| Rule | Owner |
|---|---|
| Orchestration | `PaintSystemVersioningService.ResolveVersioningAsync` |
| Context (type, names, IsPrimaryDerived, ColorId) | `CreatePaintSystemVersioningContextResolver.Resolve` → `CreatePaintSystemVersioningContext` |
| Base version from siblings | `CreatePaintSystemVersionResolver.ResolveBaseVersionAsync` |
| Which siblings count (product OR parent) | `CreatePaintSystemVersionResolver.FilterCandidateSiblings` |
| Version parsing / ordering | `VersioningHelper.ParseVersion`, `VersioningHelper.CompareVersionsDesc` |
| Next version per IR type | `VersioningHelper.ComputeNextVersion` → `ComputeVersionByType` |
| `1.1` default types | `VersioningHelper.IsDefaultVersionType` |
| Minor increment types | `VersioningHelper.IsMinorIncrementType` / `ComputeMinorIncrement` |
| Major increment types | `VersioningHelper.IsMajorIncrementType` / `ComputeMajorIncrement` |
| Complaint `C` suffix | `VersioningHelper.ComputeComplaintVersion` |
| Paint system name | `VersioningHelper.BuildPaintSystemName` |
| Default version constant `"1.1"` | `Common/Utility/Constants.cs` → `Versioning.DefaultVersion` |

## Product

| Rule | Owner |
|---|---|
| Parent substitution for paint system lookup | `CreateImitationRequestValidator.ResolvePaintSystemProductIdAsync` |
| Product + parent union for versioning | `CreatePaintSystemVersionResolver.FilterCandidateSiblings` |
| RelestProtect blocks conversion | `ConversionEligibilityValidationHelper.IsConversionAllowed` |
| Salcomix allows conversion | same |
| Product number lookup | `IPaintSystemQueryService.GetProductNumberByProductIdAsync`, `IProductQueryService.GetProductById` |
| Parent product id lookup | `Products_GetParentProductId.graphql` |

## Cross-cutting

| Concern | Owner |
|---|---|
| Command/query dispatch | `Application/Shared/Abstractions/Dispatching/Dispatcher.cs` |
| Handler + validator registration | `Function/Program.cs` (assembly scans) |
| Data service registration | `Function/Program.cs` (explicit `AddScoped`) |
| Exception → HTTP mapping | `Function/Middleware/ExceptionHandler/ExceptionHandlingMiddleware.cs` |
| Error codes | `Common/Errors/ErrorCode.cs` |
| Success/error envelope | `Common/Models/ApiResponse.cs`, `Common/Extensions/HttpRequestDataResponseExtension.cs` |
| Role checks | `Function/Middleware/Authorization/{AuthorizationMiddleware, RequiresRoleAttribute}.cs` |
| Skip JWT for system endpoints | `SkipUserJWTAuthenticationAttribute` |
| CDMS forwarding + exclusions | `Function/Middleware/Routing/RoutingMiddleware.cs` |
| Correlation id propagation | `RequestTracing/Correlation/*` |
| Reference-data cache | `Data/Shared/{MemoryCacheManager, CacheWarmupWithData}.cs` |
| GraphQL error guard | `Data/Shared/Exceptions/Helper/GraphQlExceptionHelper.cs` |
| All magic strings / ids | `Common/Utility/Constants.cs` |
| Environment configuration | `Common/Utility/EnvConfig.cs` |

## "I need to change X" → go here first

| You want to... | Start at |
|---|---|
| add a request type rule | `CreateImitationRequestValidator` (check the matrix in IMITATION-REQUEST-FLOW §5) |
| change how a version number is produced | `VersioningHelper` + `CreatePaintSystemVersionResolver` |
| change which paint systems "count as existing" | the `.graphql` file, not the C# |
| change a status | confirm ownership first — see STATUS-AND-VERSIONING §B3 |
| add a new endpoint | `.github/skills/add-feature/SKILL.md` |
| add a lookup value | cache warmup + `CacheKeys` |
