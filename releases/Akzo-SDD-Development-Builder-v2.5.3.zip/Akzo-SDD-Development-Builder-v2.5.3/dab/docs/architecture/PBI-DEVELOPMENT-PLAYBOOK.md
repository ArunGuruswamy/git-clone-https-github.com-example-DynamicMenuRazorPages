# PBI-DEVELOPMENT-PLAYBOOK

Repeatable process for implementing a PBI in this repository.

Do not skip to step 18.

---

## Phase 1 — Understand (no code)

1. Read the PBI. Extract every explicit statement.
2. Classify each statement:
   - **CONFIRMED** — stated in the PBI or provable from the repository.
   - **ASSUMPTION** — you inferred it.
   - **OPEN QUESTION** — needed but unknown.
   An assumption never becomes a requirement without confirmation.
3. Identify the domain: Imitation Request / Paint System / Formula / Measurement / Product /
   Market Color / Toner / reference data.
4. Open only the relevant architecture document
   ([index](./ARCHITECTURE-SUMMARY.md#document-index)).

## Phase 2 — Search before creating

5. Search the repository for the requirement's terminology, the request type, relevant constants,
   handler names, validator names, query services, `.graphql` operations and existing tests.
6. Assume an implementation already exists until proven otherwise. 57 GraphQL operations and a
   large helper set are already present.
7. Compare against `origin/develop`, not against an old feature branch:
   ```powershell
   git fetch origin
   git log --oneline origin/develop -20
   git diff origin/develop --stat
   ```

## Phase 3 — Trace

8. Trace the existing flow end to end with real file and method names:
   ```
   Function endpoint -> Command/Query -> Dispatcher -> Handler -> Validator
	 -> Helper/Resolver -> I*QueryService / I*CommandService -> .graphql -> response mapper
   ```
9. Record the exact current behaviour. This is your regression baseline.

## Phase 4 — Impact analysis

10. List: files to change, **shared** files touched, affected request types, GraphQL regeneration
	impact, tests to add/update.
11. Explicitly check each of these dimensions and say "not applicable" where it is:
	- status (who owns the transition — see STATUS-AND-VERSIONING §B3)
	- version (per-type rules — §A3)
	- product derivation (four different rules — PRODUCT-DERIVATION-RULES)
	- Local/Global (only some queries filter it)
	- duplicate vs cross-over validation (two distinct keys)
	- cache dependency (silent `Guid.Empty` degradation)
	- CDMS routing (your handler may be bypassed by `RoutingMiddleware`)

## Phase 5 — Plan (output before coding)

12. Produce, in this order:
	```
	Requirement
	Current behaviour (with file/method evidence)
	Gap
	Files to change
	Implementation approach
	Test plan
	Regression risks
	Open questions
	```
13. If any open question affects a business rule, **stop and ask**. Do not implement past it.

## Phase 6 — Implement

14. Minimum change. Reuse existing services, helpers, constants, validators, GraphQL operations
	and response patterns.
15. No speculative abstractions. No unrelated cleanup. No reformatting of untouched code.
16. Follow `.github/instructions/sonar-rules.instructions.md` (no suppressions).
17. Write or update tests alongside the change, not after.

## Phase 7 — Verify

18. ```powershell
	dotnet build AN.ColorAppsAzure.BL.sln
	```
19. Run targeted tests, then the affected test projects, then the solution.
20. If a `.graphql` file changed, inspect the generated client diff:
	```powershell
	git diff --stat -- "*Generated*"
	```
	Confirm the change is consistent with your operation edit and nothing else moved.

## Phase 8 — Regression

21. Test neighbouring flows that share the code you touched:
	- `ImitationRequestValidator<T>` → create **and** update, all request types.
	- `CreateImitationRequestValidator` → New Sample, Improved Formula, Technical at minimum.
	- `VersioningHelper` / `CreatePaintSystemVersionResolver` → every IR type group.
	- `PaintSystemQueryService` → every caller of the changed method.
22. Run the full [MERGE-SAFETY-CHECKLIST](./MERGE-SAFETY-CHECKLIST.md).

## Phase 9 — Evidence

23. For each requirement produce a traceability line:
	```
	Requirement -> File -> Class -> Method -> Test
	```
	Never report "implemented" without this.

## Phase 10 — PR readiness

24. Confirm all of:
	- [ ] build passes
	- [ ] tests pass
	- [ ] no unrelated files in the diff
	- [ ] no accidental deletions (`git diff origin/develop --diff-filter=D`)
	- [ ] develop functionality preserved
	- [ ] generated GraphQL diff reviewed and expected
	- [ ] every business rule covered by a test
	- [ ] open questions resolved or explicitly listed in the PR description
	- [ ] Sonar rules respected
25. Write the PR summary: what changed, why, which flows were regression-tested, what was
	deliberately left alone.

---

## Quick command reference

```powershell
git fetch origin
git status
git diff origin/develop --stat
git diff origin/develop --diff-filter=D --name-only    # deletions vs develop
dotnet build AN.ColorAppsAzure.BL.sln
dotnet test AN.ColorAppsAzure.BL.sln --settings coverlet.runsettings --collect:"XPlat Code Coverage"
```
