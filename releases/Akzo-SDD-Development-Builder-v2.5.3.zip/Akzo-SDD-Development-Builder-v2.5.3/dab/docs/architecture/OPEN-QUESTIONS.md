# OPEN-QUESTIONS

Everything below is **NOT CONFIRMED** from the repository. Each needs PO / BA / technical
confirmation before any PBI relies on it.

Format: Question — what the code shows — who should answer.

---

## Status ownership

1. **Who moves a Paint System from `Incomplete` to `Actual`?**
   Code shows: `CreatePaintSystemHandler.ResolveInitialPaintSystemStatusId` always sets
   `Incomplete`. No transition to `Actual` exists anywhere in this solution.
   Candidate owners: SCS, CDMS, a downstream process. — *Tech lead / integration owner.*

2. **Who sets `Historic`?**
   Code shows: `PaintSystemStatuses.Historic` exists as a constant and appears in the OR-set of
   qualifying-paint-system GraphQL filters, but nothing in this repository writes it. — *Tech lead.*

3. **Who closes an Imitation Request?**
   Code shows: only `InDevelopment` is written by this service
   (`CreatePaintSystemImitationRequestStatusUpdater`). `Closed` is never written here. — *PO / tech lead.*

4. **Is the caller-supplied `ImitationRequestStatusId` on create intentional?**
   Code shows: `CreateImitationRequestHandler` passes it straight through with no server-side
   default. A wrong client value is accepted. — *PO.*

## SCS integration

5. **Where does SCS integration live?**
   Code shows: no `Scs` type, constant, client, URL or feature flag exists in this repository.
   Triggering conditions, `KindOfFormulation` requirements and `OriginalProductId` conditions
   could not be located. — *Integration owner.*

6. **Is `OriginalProductId` written anywhere on create?**
   Code shows: it appears as a PaintSystem field/input, but no assignment was located in
   `CreatePaintSystemInputFactory`. — *Tech lead.*

## Versioning

7. **Should Improved Formula with no existing sibling paint system produce `2.1` or `1.1`?**
   Code shows: base resolves to `Versioning.DefaultVersion` (`1.1`) and
   `ComputeMajorIncrement` then yields `2.1`. — *PO.*

8. **Is `Complaint` reachable?**
   Code shows: `ImitationRequestTypeCdmsKeys.Complaint = 1` and a dedicated
   `ComputeComplaintVersion` with a `C` suffix, but no validator branch for Complaint. — *PO.*

9. **Is the `C` suffix version ever used as a base version?**
   Code shows: `ParseVersion` returns a `hasC` flag, but `ComputeVersionByType` does not appear to
   consume it outside the Complaint path. — *Tech lead.*

10. **Should the parent-product sibling union apply to all IR types?**
	Code shows: `FilterCandidateSiblings` unions product and parent for **every** type, while its
	comment mentions Technical IR only. — *PO / tech lead.* (High regression risk.)

## Product / conversion

11. **Why do create and update use different conversion-eligibility rules?**
	Code shows: `ConversionEligibilityValidationHelper.IsConversionAllowed` (RelestProtect block,
	Salcomix allowance) vs `UpdatePaintSystemHandler.DetermineConversionEligibility`
	(parent + primary-derived only). — *PO / tech lead.*

12. **What is the intended meaning of `IsPrimaryDerivedProduct == null`?**
	Code shows: rejected for Improved Formula; treated as not-derived elsewhere. — *PO.*

13. **Are secondary-derived products defined anywhere?**
	Code shows: "secondary derived" is only implied by `IsPrimaryDerivedProduct == false` in
	`IsProductEligibleForImprovedFormula`. No explicit field. — *PO.*

## Validation

14. **Should `Formula_GetQualifyingImprovedFormulaPaintSystems` filter `RecordIsActive`?**
	Code shows: it filters only `RecordIsDeleted`, unlike
	`Formula_GetQualifyingPaintSystems`. This is the query used by the generic
	"paint system must exist" rule. — *PO / tech lead.* (Possible false positives.)

15. **Is the partial-success response of IR create intentional?**
	Code shows: HTTP 200 with `{ total, succeeded, failed }` even when every product failed
	validation, while Paint System create throws and returns 400. — *PO / API consumer.*

16. **Is Pacific Standard Time correct for due-date validation?**
	Code shows: `ImitationRequestValidator.RetrieveLocalTimeFromUtcTime()` converts UTC to PST for
	the "not in the past" check, in an otherwise EU-centric domain. — *PO.*

## GraphQL / build

17. **How are schema snapshots refreshed?**
	Code shows: the schema-download MSBuild targets in
	`AN.ColorAppsAzure.Formula.Data.csproj` are **commented out**. The documented workflow in
	`.github/copilot-instructions.md` says schemas are downloaded at build time. These disagree.
	— *Tech lead.*

18. **Is the `Formula_` / `Product_` operation prefix enforced by the backend?**
	Code shows: consistent convention, no enforcement found. — *Backend owner.*

19. **Which backend serves the GraphQL endpoint (DAB over Dataverse, or something else)?**
	Code shows: a single configured URL plus subscription key in `EnvConfig`. No XRM/Dataverse SDK
	usage. — *Platform owner.*

## Routing / CDMS

20. **What is the authoritative CDMS exclusion list, and is it expected to grow?**
	Code shows: a hard-coded exclusion list in `RoutingMiddleware`. With the flag enabled, some
	Application handlers are unreachable. — *Tech lead.*

21. **Is `FeatureFlags_Cdms` on per environment?**
	Code shows: parsed from an environment variable in `Program.cs`; per-environment values live in
	`deployments/vars*.yaml`, not verified here. — *DevOps.*

## Process

22. **Handler registration:** `.github/copilot-instructions.md` instructs registering every handler
	in `Program.cs`, but `Program.cs` auto-registers handlers by assembly scan. Which is
	authoritative going forward? — *Tech lead.* (Documented in SYSTEM-ARCHITECTURE §4 as "code wins".)

---

## How to use this file

- Before implementing anything that depends on an item above, get it answered and then move the
  answer into the relevant architecture document with an evidence citation.
- If you discover new unprovable behaviour, add it here rather than guessing.
