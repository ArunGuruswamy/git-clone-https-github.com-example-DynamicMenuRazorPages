# ANTI-HALLUCINATION-RULES

Reusable checklist for every Copilot/agent session on this repository.

---

## Search before you create

- [ ] Searched for an existing method/class before proposing a new one.
- [ ] Searched `Data/Graphql/GraphqlAssets/**/*.graphql` before writing a new operation
	  (57 already exist).
- [ ] Searched `Common/Utility/Constants.cs` before adding a constant.
- [ ] Searched `<Feature>/Shared/` and `<Operation>/HandlerHelper/` before adding a helper.
- [ ] Checked `Program.cs` before assuming a service is or is not registered.

## Never assume

- [ ] Never assume `PaintSystem.ProductId == selected ProductId`.
	  Check `IsPrimaryDerivedProduct`, `ParentProductId`, `OriginalProductId`.
- [ ] Never assume `LocalGlobalId` is a PaintSystem field — it is on ImitationRequest.
- [ ] Never assume `IsPrimaryDerivedProduct` is a `bool`. It is nullable and `null` is a distinct case.
- [ ] Never assume a status transition belongs to this service. Only two are implemented here
	  (PaintSystem → Incomplete on create; IR → InDevelopment after PaintSystem create).
- [ ] Never assume "Technical becomes Actual automatically" — no such code exists.
- [ ] Never assume versioning rules are shared across request types. They are grouped
	  (default / minor / major / complaint).
- [ ] Never assume "no previous paint system" means version `1.1` for every type — the base
	  resolves to `1.1` and the type rule is then still applied.
- [ ] Never assume `RecordIsActive` is filtered. `Formula_GetQualifyingImprovedFormulaPaintSystems`
	  filters only `RecordIsDeleted`.
- [ ] Never assume which PaintSystem statuses qualify — open the `.graphql` file.
- [ ] Never assume creating an Imitation Request creates a Paint System. It does not.
- [ ] Never assume your handler is reachable — `RoutingMiddleware` may forward the request to CDMS.
- [ ] Never assume a cache lookup succeeded; failures degrade to `Guid.Empty` silently.

## GraphQL

- [ ] Never invent a schema field. Verify it in the relevant `schema.graphql` snapshot.
- [ ] Never hand-edit a `*GraphQL.Client.cs` file.
- [ ] Never trust a remembered `ExecuteAsync` signature — read the generated interface.
- [ ] After changing an operation, update production callers **and** every NSubstitute mock.
- [ ] Keep the domain prefix (`Formula_`, `MarketColor_`, `Product_`, `ComplexUpdate_`).
- [ ] Build the solution after any `.graphql` change.

## Shared code

- [ ] Never change `ImitationRequestValidator<T>` without checking create *and* update.
- [ ] Never change `CreateImitationRequestValidator` without checking New Sample, Improved Formula
	  and Technical at minimum.
- [ ] Never change `VersioningHelper` without a test per version-type group.
- [ ] Never merge the create-side and update-side conversion-eligibility rules — they legitimately
	  differ today.
- [ ] Never extract a "shared product resolver" — four intentionally different rules exist.

## Branch hygiene

- [ ] Never copy a whole file from an old feature branch.
- [ ] Never treat old-branch behaviour as current truth without diffing `origin/develop`.
- [ ] Never remove functionality that exists in develop.
- [ ] Never delete or `[Ignore]` a failing test to go green.

## Scope

- [ ] Never refactor unrelated code during a PBI.
- [ ] Never introduce a new library, pattern or abstraction not already used here.
- [ ] Never silently change the behaviour of another request type.
- [ ] Never implement before tracing the existing flow.

## When uncertain

Stop. Output:

```
NOT CONFIRMED

Evidence found:   <file / class / method / behaviour>
Missing:          <what cannot be proven from the repository>
Question:         <the exact question needing PO/BA/tech confirmation>
```

Then wait. Do not guess a business rule.
