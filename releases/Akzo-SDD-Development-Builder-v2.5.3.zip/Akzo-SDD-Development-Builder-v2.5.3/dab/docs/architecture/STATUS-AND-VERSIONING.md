# STATUS-AND-VERSIONING

Two separate concerns that are frequently confused. Both are evidence-based below.

---

# PART A — VERSIONING

## A1. Components

| Class | File | Role |
|---|---|---|
| `PaintSystemVersioningService` | `Application/PaintSystem/Commands/CreatePaintSystem/HandlerHelper/PaintSystemVersioningService.cs` | orchestrator, injected into `CreatePaintSystemHandler` |
| `CreatePaintSystemVersioningContextResolver` | same folder | builds the context record |
| `CreatePaintSystemVersioningContext` | same folder | `ImitationRequestType`, `ProductName`, `MciName`, `IsPrimaryDerived`, `ColorId` |
| `CreatePaintSystemVersionResolver` | same folder | finds the **base** version from sibling paint systems |
| `VersioningHelper` | `Application/PaintSystem/Shared/VersioningHelper.cs` | parsing, comparison, next-version computation, name building |
| `Versioning.DefaultVersion` | `Common/Utility/Constants.cs` | `"1.1"` |

Orchestration (`ResolveVersioningAsync`):

```
context   = CreatePaintSystemVersioningContextResolver.Resolve(ctx)
baseVer   = CreatePaintSystemVersionResolver.ResolveBaseVersionAsync(queryService, context.ColorId, ctx)
nextVer   = VersioningHelper.ComputeNextVersion(baseVer, context.ImitationRequestType, context.IsPrimaryDerived)
finalName = VersioningHelper.BuildPaintSystemName(context.ProductName, context.MciName, nextVer, context.ImitationRequestType)
return (context, nextVer, finalName)
```

## A2. Base version selection — `CreatePaintSystemVersionResolver.ResolveBaseVersionAsync`

```csharp
if (colorId == Guid.Empty) return Versioning.DefaultVersion;          // "1.1"

siblings = FetchPastPaintSystemsForColorAsync(colorId)               // Formula_GetColorImitationsWithPaintSystems
			 .Items.Select(i => i.PaintSystem).Where(ps => ps != null)

candidates = siblings.Where(s =>
		s.ProductId == product.ProductId ||
		(product.ParentProductId.HasValue && s.ProductId == product.ParentProductId));

if (candidates.Count == 0) return Versioning.DefaultVersion;          // "1.1"

candidates.Sort(VersioningHelper.CompareVersionsDesc);
return candidates[0].Version ?? Versioning.DefaultVersion;
```

Key points:
- Siblings are found **by ColorId**, not by MarketColorInstanceId.
- The candidate filter accepts paint systems on the **selected product OR its parent product**.
  Source comment: *"Technical IR versioning must consider paint systems stored on the selected
  product as well as on its parent product."*
- `product` comes from `ctx?.Product` on `Formula_GetImitationRequestForVersioning`. If it is
  `null`, the candidate list is empty and the version falls back to `"1.1"`.
- The **highest** version wins (`CompareVersionsDesc`), not the newest by date.

## A3. Next version — `VersioningHelper.ComputeNextVersion(baseVersion, irType, isPrimaryDerivedProduct)`

```
(major, minor, patch, hasC) = ParseVersion(baseVersion)
return ComputeVersionByType(major, minor, irType, isPrimaryDerivedProduct)
```

| Group | CDMS keys | Method | Rule |
|---|---|---|---|
| Default | `NewSample (3)`, `DigitalVariant (800000002)` | `IsDefaultVersionType` | always `"1.1"` |
| Minor increment | `Technical (5)`, `ProductModification (4)`, `MasterCandidate (6)` | `ComputeMinorIncrement` | `$"{major}.{Math.Max(1, minor) + 1}"` |
| Major increment | `ImprovedFormula (2)`, `Industrialization (800000000)`, `Adaption (800000001)` | `ComputeMajorIncrement` | `$"{Math.Max(1, major) + 1}.1"` |
| Complaint | `Complaint (1)` | `ComputeComplaintVersion` | primary-derived → `$"{Math.Max(1, major)+1}.1"`; otherwise → `$"{major}.{effectiveMinor}C"` |

### Worked examples

| Base | Request type | Primary derived | Result |
|---|---|---|---|
| any | New Sample | any | `1.1` |
| any | Digital Variant | any | `1.1` |
| `1.1` | Technical | any | `1.2` |
| `1.2` | Technical | any | `1.3` |
| `2.1` | Technical | any | `2.2` |
| `5.10` | Product Modification | any | `5.11` |
| `1.1` | Improved Formula | any | `2.1` |
| `2.3` | Improved Formula | any | `3.1` |
| `1.1` | Industrialization | any | `2.1` |
| `1.1` | Adaption | any | `2.1` |
| `1.1` | Complaint | `true` | `2.1` |
| `1.1` | Complaint | `false` | `1.1C` |
| no sibling paint system | any | any | base `1.1` then the rule above is still applied |

> Note the last row: "no previous paint system" resolves the **base** to `1.1`, it does not
> short-circuit the type rule. E.g. Improved Formula with no siblings yields `2.1`.
> If a PBI expects `1.1` in that case, that is a behaviour change — raise it as an open question.

## A4. Name generation — `VersioningHelper.BuildPaintSystemName`

```csharp
irType == ImitationRequestTypeCdmsKeys.DigitalVariant
	? $"{productName}_{version}"
	: $"{mciName}_{productName}_{version}"
```

## A5. Where NOT to put version logic

Never compute versions inside a handler or validator. `VersioningHelper` +
`CreatePaintSystemVersionResolver` own this. Adding arithmetic elsewhere creates a second source
of truth and breaks `VersioningHelperTests`.

---

# PART B — STATUS

## B1. Constants (`Common/Utility/Constants.cs`)

- `PaintSystemStatuses`: `Historic`, `Actual`, `Incomplete`
- `ImitationRequestStatuses`: includes `InDevelopment`, `AwaitingDevelopment` (used in the
  active-IR GraphQL filters)
- `PaintSystemLevels`: `Adapted`, `Industrialized`

Status ids are never hard-coded; they are resolved from cache by **name**:
`cache.Get(CacheKeys.PaintSystemStatusKey, PaintSystemStatuses.Incomplete)?.Id`.

## B2. Transitions performed by THIS service

| Trigger | Entity | From | To | Code |
|---|---|---|---|---|
| Paint System create | PaintSystem | – | `Incomplete` | `CreatePaintSystemHandler.ResolveInitialPaintSystemStatusId` |
| Paint System create (with `ImitationRequestId`) | ImitationRequest | any | `InDevelopment` | `CreatePaintSystemImitationRequestStatusUpdater.UpdateAsync` |
| Explicit endpoint | ImitationRequest | any | caller-supplied | `UpdateImitationRequestStatusHandler` |
| IR create | ImitationRequest | – | caller-supplied `ImitationRequestStatusId` | `CreateImitationRequestHandler` |

## B3. Transitions NOT performed here

- `Incomplete → Actual` for Paint Systems: **not found** in this repository.
- `Actual → Historic`: **not found**.
- IR → `Closed`: **not found**.

Do **not** assume "Technical becomes Actual automatically". There is no such code.
If a PBI requires it, that is new behaviour and needs explicit confirmation of ownership
(this service vs SCS vs CDMS) before implementation. See [OPEN-QUESTIONS.md](./OPEN-QUESTIONS.md).

## B4. Status used as a query filter

Status participates in existence checks as an **OR set**:

| Query | Paint System statuses accepted |
|---|---|
| `Formula_GetQualifyingPaintSystems` | Actual OR Incomplete OR Historic |
| `Formula_GetQualifyingImprovedFormulaPaintSystems` | OR set of status ids |
| `Formula_Local_GetPaintSystemByProductAndColor` | OR set of status ids |
| `Formula_Global_GetPaintSystemByProductAndColor` | OR set of status ids |

| Query | IR statuses accepted |
|---|---|
| `Formula_CheckActiveImitationRequest` | InDevelopment OR AwaitingDevelopment |
| `Formula_CheckActiveImitationRequestByColor` | InDevelopment OR AwaitingDevelopment |

Changing which statuses qualify changes duplicate/existence validation for **all** request types.

## B5. Paint System level (not a status)

`UpdatePaintSystemHandler.GetPaintSystemLevelId`:
`Adaption → Adapted`, `Industrialization → Industrialized`, everything else `null`.
Level and status are separate fields. Do not conflate them.
