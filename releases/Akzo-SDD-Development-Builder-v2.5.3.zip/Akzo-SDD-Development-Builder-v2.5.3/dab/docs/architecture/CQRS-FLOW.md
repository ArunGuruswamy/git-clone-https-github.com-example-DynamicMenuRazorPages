# CQRS-FLOW

How CQRS is actually implemented here. Not the textbook version.

---

## 1. The abstractions

All in `Application/Shared/Abstractions/`:

| File | Contract |
|---|---|
| `ICommand.cs` | `ICommand<out TResult>` — marker only |
| `IQuery.cs` | `IQuery<out TResult>` — marker only |
| `ICommandHandler.cs` | `ICommandHandler<TCommand, TResult> where TCommand : ICommand<TResult>` with `Task<TResult> Handle(TCommand, CancellationToken)` |
| `IQueryHandler.cs` | `IQueryHandler<TQuery, TResult> where TQuery : IQuery<TResult>` with `Task<TResult> Handle(TQuery, CancellationToken)` |
| `Dispatching/IDispatcher.cs` | `Task<TResult> Send<TResult>(ICommand<TResult>, CancellationToken)` and `Task<TResult> Query<TResult>(IQuery<TResult>, CancellationToken)` |
| `Dispatching/Dispatcher.cs` | Builds the closed generic handler type, `GetRequiredService`, invokes via `(dynamic)` |

No MediatR. No pipeline behaviours. No pre/post processors.

---

## 2. Answers to the ten questions

1. **What is a Command?** A record/class implementing `ICommand<TResult>` that changes state
   (create/update/delete/publish). Example: `CreatePaintSystemCommand`.
2. **What is a Query?** A record/class implementing `IQuery<TResult>` that only reads.
   Example: `GetPaintSystemByIdQuery`.
3. **Command dispatch:** `await _dispatcher.Send(new XCommand(request))` from the Function.
4. **Query dispatch:** `await _dispatcher.Query(new XQuery(id))` from the Function.
5. **Where does validation run?** Inside the handler, explicitly. There is no validation pipeline.
   Two variants exist — see §4.
6. **Where is business logic?** In the handler and in its `HandlerHelper/` or `<Feature>/Shared/`
   helper classes (`VersioningHelper`, `ConversionEligibilityValidationHelper`,
   `CreatePaintSystemVersionResolver`, `CreatePaintSystemInputFactory`).
7. **Where are data calls?** Only in `Data` layer `I*QueryService` / `I*CommandService`
   implementations. Handlers call the interfaces.
8. **How are failures represented?**
   - Thrown `AppValidationException` → middleware → HTTP 400 with field errors.
   - Or returned inside a response object with `Success=false` + `Errors[]`
	 (`CreatePaintSystemResponse`, `CreateImitationRequestResponse`).
9. **HTTP mapping:** `req.CreateSuccessResponse(result, SuccessMessages.X)` producing
   `ApiResponse<T>` `{ success, message, data, error }`. Errors are produced by
   `ExceptionHandlingMiddleware` via `CreateErrorResponse`.
10. **Handler vs service:** handler = orchestration + business rules; service = one GraphQL
	operation, no business rules.

---

## 3. Function endpoint template (existing convention)

```csharp
[Function("PaintSystemCreate")]
[RequiresRole(PaintSystemPermissions.Create)]
[OpenApiOperation(operationId: "PaintSystemCreate")]
public async Task<HttpResponseData> CreateAsync(
	[HttpTrigger(AuthorizationLevel.Function, HttpVerbs.Post, Route = "PaintSystem/Create")] HttpRequestData req)
{
	var request = await req.ReadFromJsonAsync<CreatePaintSystemRequest>();
	if (request is null) throw new AppValidationException(ErrorMessages.InvalidRequestBody);

	var result = await _dispatcher.Send(new CreatePaintSystemCommand(request));
	return req.CreateSuccessResponse(result, SuccessMessages.RequestCompleted);
}
```

Rules enforced by the existing code:
- Never `try/catch` generically in a function — let `ExceptionHandlingMiddleware` map it.
- Functions hold no data access and no business rules.
- One partial class per feature, one file per HTTP verb.

---

## 4. Two validation styles — both are current, do not unify

### Style A — throw (Paint System)

`Application/PaintSystem/Commands/CreatePaintSystem/CreatePaintSystemHandler.cs`

```csharp
ArgumentNullException.ThrowIfNull(request.PaintSystemRequest);
await _validator.ValidateAndThrowAsync(request.PaintSystemRequest, cancellationToken);
```

Result: `ValidationException` / `AppValidationException` → HTTP 400.

### Style B — collect (Imitation Request, multi-product)

`Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestHandler.cs`

```csharp
var perProduct = CreateImitationRequestMapper.Map(request);      // one request per ProductId
foreach (...) {
	var validationResult = await _createValidator.ValidateAsync(mapped, cancellationToken);
	if (!validationResult.IsValid)
		// build failure CreateImitationRequestResponse from e.PropertyName / e.ErrorMessage
	else
		await CreateImitationRequest(mapped, userEmail);
}
```

The endpoint returns HTTP 200 with `{ total, succeeded, failed, response[] }`.
A single invalid product does **not** fail the whole call.

---

## 5. Three real end-to-end traces

### 5.1 CreateImitationRequest

```
POST ImitationRequest/Create
  Function/Functions/ImitationRequestFunctions.Post.cs :: CreateAsync
	[Function("ImitationRequestCreate")] [RequiresRole(ImitationRequestPermissions.Create)]
  -> IDispatcher.Send(new CreateImitationRequestCommand(body))
  -> Application/.../CreateImitationRequest/CreateImitationRequestHandler.Handle
	   CreateImitationRequestMapper.Map            (fan-out per ProductId)
	   IValidator<CreateImitationRequest>
		 -> CreateImitationRequestValidator  (: ImitationRequestValidator<CreateImitationRequest>)
			  IMemoryCacheManager              (LocalGlobals, ImitationRequestTypes)
			  IMarketColorQueryService         (MarketColorInstance, Owners)
			  IImitationRequestQueryService    (GetActiveImitationRequest[, ByColor])
			  IPaintSystemQueryService         (GetPaintSystemCount)
			  IProductQueryService             (product / parent product)
	   IImitationRequestCommandService.CreateImitationRequest(CreateImitationRequestsInput)
		 -> FormulaGraphQL :: Formula_CreateImitationRequest
  -> req.CreateSuccessResponse({ total, succeeded, failed, response })
```

### 5.2 CreatePaintSystem

```
POST PaintSystem/Create
  Function/Functions/PaintSystemFunctions.Post.cs
  -> IDispatcher.Send(new CreatePaintSystemCommand(request))
  -> Application/PaintSystem/Commands/CreatePaintSystem/CreatePaintSystemHandler.Handle
	   IValidator<CreatePaintSystemRequest>.ValidateAndThrowAsync
	   IPaintSystemQueryService.FetchPaintSystemVersioningContextAsync(imitationRequestId)
			-> Formula_GetImitationRequestForVersioning
			null => throw AppValidationException(ErrorMessages.ImitationRequestNotFound)
	   PaintSystemVersioningService.ResolveVersioningAsync(ctx)
			CreatePaintSystemVersioningContextResolver.Resolve
			CreatePaintSystemVersionResolver.ResolveBaseVersionAsync
				 -> Formula_GetColorImitationsWithPaintSystems
			VersioningHelper.ComputeNextVersion
			VersioningHelper.BuildPaintSystemName
	   IPaintSystemTypeResolver.ResolvePaintSystemTypeAsync(ctx)
	   ResolveInitialPaintSystemStatusId()          -> cache: PaintSystemStatuses.Incomplete
	   ResolveConversionEligibilityAsync(irId)      -> IConversionEligibilityValidationHelper
	   RequiresLinkedRecords(developmentToolId)     -> ColorApps | OwnColor
	   IPaintSystemCommandService.CreatePaintSystem(CreatePaintSystemInputFactory.Build(...))
			-> Formula_CreatePaintSystem
	   [if linked]  CreateLinkedColorAsync -> IPaintSystemCommandService.CreateColor
	   [if irId]    CreatePaintSystemImitationRequestStatusUpdater.UpdateAsync
					   -> IImitationRequestCommandService.UpdateImitationRequest (InDevelopment)
	   CreatePaintSystemDetailsFactory.BuildDetailsAsync
  -> CreatePaintSystemResponse { Success, Data, Errors }
```

### 5.3 UpdatePaintSystem

```
PUT PaintSystem/Update
  Function/Functions/PaintSystemFunctions.Put.cs
  -> IDispatcher.Send(new UpdatePaintSystemCommand(request))
  -> Application/PaintSystem/Commands/UpdatePaintSystem/UpdatePaintSystemHandler.Handle
	   IValidator<UpdatePaintSystemRequest> (UpdatePaintSystemValidator)
	   GetPaintSystemLevelId(irType)
			Adaption (800000001)        -> PaintSystemLevels.Adapted
			Industrialization (800000000) -> PaintSystemLevels.Industrialized
			otherwise                    -> null
	   DetermineConversionEligibility(product)
			true only when ParentProductId != null && IsPrimaryDerivedProduct == true
	   IPaintSystemCommandService.UpdatePaintSystem -> Formula_UpdatePaintSystem
  -> req.CreateSuccessResponse(...)
```

> Note the asymmetry: `UpdatePaintSystemHandler.DetermineConversionEligibility` is **not** the same
> rule as `ConversionEligibilityValidationHelper.IsConversionAllowed` used on create.
> See [PRODUCT-DERIVATION-RULES.md](./PRODUCT-DERIVATION-RULES.md) §4 — this divergence is real and
> must not be "fixed" without a PBI.

---

## 6. Adding a new operation — checklist

1. `Application/<Feature>/Commands|Queries/<Op>/<Op>Command|Query.cs` implementing `ICommand<R>`/`IQuery<R>`.
2. `<Op>Handler.cs` implementing `ICommandHandler<,>`/`IQueryHandler<,>` — auto-registered.
3. `<Op>Request.cs` / `<Op>Response.cs` if the shape is new.
4. `<Op>Validator.cs` (FluentValidation) — auto-registered by assembly scan.
5. Data layer: add the `.graphql` operation, extend `I<X>QueryService`/`I<X>CommandService`,
   implement it, and **register the service in `Program.cs` if the interface is new**.
6. Function: add the method to the existing `<Feature>Functions.<Verb>.cs` partial.
7. Tests in the matching `*.Tests` project: success, validation failure, service exception.

The repository also ships a scaffold skill: `.github/skills/add-feature/SKILL.md`.
