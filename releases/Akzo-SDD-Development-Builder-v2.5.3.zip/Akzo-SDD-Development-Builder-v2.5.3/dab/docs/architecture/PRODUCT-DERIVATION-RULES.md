# PRODUCT-DERIVATION-RULES

Product identity is the single most error-prone area in this repository.

> **Never assume the UI-selected `ProductId` equals `PaintSystem.ProductId`.**

---

## 1. The fields

| Field | Lives on | Meaning (per usage in code) |
|---|---|---|
| `ProductId` | ImitationRequest, PaintSystem, Product | the product the record points at |
| `ParentProductId` | Product | parent of a derived product; nullable |
| `IsPrimaryDerivedProduct` | Product | `true` / `false` / **`null`** — three states, `null` is meaningful |
| `OriginalProductId` | PaintSystem input | preserved original product reference |
| `ProductNr` | Product | product number string, compared against `ProductNumbers.*` constants |

`IsPrimaryDerivedProduct` is nullable and `null` is treated as "unknown / not eligible" in
`IsProductEligibleForImprovedFormula`. Do not collapse `null` into `false`.

---

## 2. Rule 1 — Paint System lookup product (IR validation)

`Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestValidator.cs`
→ `ResolvePaintSystemProductIdAsync()`

```
if (product.IsPrimaryDerivedProduct == true && product.ParentProductId is not null)
	return product.ParentProductId.Value;     // paint systems are stored on the parent
return productId;                             // selected product
```

Covered by tests:
- `Validate_ResolvesParentProductId_WhenProductIsPrimaryDerivedAndPaintSystemExistsOnParent`
- `Validate_UsesOriginalProductId_WhenProductIsNotPrimaryDerived`

Consumer: `IPaintSystemQueryService.GetPaintSystemCount(paintSystemProductId, mciId, localGlobalId)`.

## 3. Rule 2 — Versioning sibling product set

`Application/PaintSystem/Commands/CreatePaintSystem/HandlerHelper/CreatePaintSystemVersionResolver.FilterCandidateSiblings`

```csharp
siblings.Where(s =>
	s.ProductId == product.ProductId ||
	(product.ParentProductId.HasValue && s.ProductId == product.ParentProductId));
```

This is an **OR** (both product and parent), unlike Rule 1 which is an **either/or** substitution.
They are deliberately different. Do not replace one with the other.

## 4. Rule 3 — Conversion eligibility (two different rules!)

### On create — `Application/PaintSystem/Shared/ConversionEligibilityValidationHelper.IsConversionAllowed`

```
if productNumber == ProductNumbers.RelestProtect                        -> false
else if isPrimaryDerivedProduct == true                                 -> true
else if productNumber == Salcomix || parentProductNumber == Salcomix    -> true
else                                                                    -> false
```

Tests: `PaintSystem/Shared/ConversionEligibilityValidationHelperTests.cs`
(RelestProtect blocks even when primary-derived; primary-derived allows; Salcomix family allows).

### On update — `UpdatePaintSystemHandler.DetermineConversionEligibility`

```
true only when product.ParentProductId != null && product.IsPrimaryDerivedProduct == true
```

**These two rules do not agree.** Confirmed divergence in current code. When a PBI touches
conversion eligibility, state explicitly which path is in scope.

## 5. Rule 4 — Improved Formula eligibility by derivation

`CreateImitationRequestValidator.IsProductEligibleForImprovedFormula`

| `IsPrimaryDerivedProduct` | Outcome |
|---|---|
| `true` | allowed |
| `null` | rejected |
| `false` (secondary derived) | allowed only if the MarketColor owner type name is `Coil` (`OwnerTypes.Coil`, `OrdinalIgnoreCase`), resolved via `IMarketColorQueryService.GetOwners()` |

## 6. Rule 5 — Complaint versioning by derivation

`VersioningHelper.ComputeComplaintVersion(major, minor, isPrimaryDerivedProduct)`

| Primary derived | Result |
|---|---|
| `true` | major increment: `{major+1}.1` |
| `false` | complaint suffix: `{major}.{minor}C` |

## 7. Where product data comes from

| Source | Operation | Client |
|---|---|---|
| `IProductQueryService.GetProductById(productId)` | `Products_GetById` | Product |
| parent product id | `Products_GetParentProductId($productId: UUID!)` | Formula (generated interface `IProducts_GetParentProductId_Products_Items` exposes `ParentProductId`, `ProductNr`) |
| `IPaintSystemQueryService.GetProductNumberByProductIdAsync(productId)` | `Products_GetById` | Product |
| product embedded in versioning context | `Formula_GetImitationRequestForVersioning` → `ctx.Product` | Formula |

> There are **two** operations named around products in two different schemas
> (`Products_GetById` in Formula assets and in Product assets). Confirm which client a service uses
> before assuming the shape of the result.

## 8. Derived-product features

| Feature | Location |
|---|---|
| Derived paint system endpoints | `Function/Functions/DerivedPaintSystemFunctions.{cs,Get.cs}` |
| Link derived products to a technical remark | `Application/PaintSystem/Commands/LinkDerivedProductsAsync/LinkDerivedProductsAsyncHandler.cs` → `IPaintSystemCommandService.LinkDerivedProductsAsync(Guid technicalRemarkId, IEnumerable<Guid> productIds)` (`PaintSystemCommandService.cs`) |
| Technical remark allowed for derived products | `Formula_CreateTechnicalRemarksForDerivedProductAllowed.graphql` |
| Market colour original-type product | `MarketColor_GetMarketColorOrginalTypeProduct.graphql` (note the repository spelling `Orginal`) |

## 9. Duplicated resolution — known hotspots

The "primary derived → use parent" idea appears in at least four places with four *different*
shapes:

1. `CreateImitationRequestValidator.ResolvePaintSystemProductIdAsync` — substitution
2. `CreatePaintSystemVersionResolver.FilterCandidateSiblings` — union
3. `CreatePaintSystemHandler.ResolveConversionEligibilityAsync` + `ConversionEligibilityValidationHelper` — product-number based
4. `UpdatePaintSystemHandler.DetermineConversionEligibility` — presence based

**Do not extract a shared helper** unless a PBI explicitly asks for it and all four call sites are
regression-tested. The repository has not chosen a single abstraction here, and consolidating them
would silently change at least two flows.

## 10. Checklist before touching product logic

- [ ] Which of the four rules above is in scope?
- [ ] Is `IsPrimaryDerivedProduct == null` handled?
- [ ] Is `ParentProductId` nullable-checked?
- [ ] Does the GraphQL operation actually select `ParentProductId` / `IsPrimaryDerivedProduct` / `ProductNr`?
- [ ] Are the existing tests in `CreateImitationRequestValidatorTests` (lines ~828-925) and
	  `ConversionEligibilityValidationHelperTests` still green?
