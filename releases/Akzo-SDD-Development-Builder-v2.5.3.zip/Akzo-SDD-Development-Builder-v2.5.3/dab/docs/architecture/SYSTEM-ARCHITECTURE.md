# SYSTEM-ARCHITECTURE

Evidence-based map of the solution. Every statement below cites a file.

---

## 1. Solution structure

Solution: `AN.ColorAppsAzure.BL.sln` (7 projects).

```
AN.ColorAppsAzure.BL.sln
├── src/AN.ColorAppsAzure.Formula/
│   ├── AN.ColorAppsAzure.Formula.Function       <- Azure Functions host (entry points)
│   ├── AN.ColorAppsAzure.Formula.Application    <- CQRS: commands, queries, handlers, validators
│   ├── AN.ColorAppsAzure.Formula.Data           <- GraphQL services + generated clients + cache
│   └── AN.ColorAppsAzure.Formula.Common         <- Constants, EnvConfig, ApiResponse, ErrorCode
└── src/AN.ColorAppsAzure.Formula.Tests/
	├── AN.ColorAppsAzure.Formula.Function.Tests
	├── AN.ColorAppsAzure.Formula.Application.Tests
	├── AN.ColorAppsAzure.Formula.Data.Tests
	└── AN.ColorAppsAzure.Formula.Common.Tests
```

There is **no separate GraphQL project**. Generated clients live inside the Data project under
`Data/Graphql/GraphqlAssets/<Schema>/Generated/`.

There is **no separate Domain project**. Business rules live in Application handlers, validators
and helper classes.

---

## 2. Project responsibilities

### 2.1 Function — `AN.ColorAppsAzure.Formula.Function`

Responsibility: HTTP surface, cross-cutting middleware, composition root.

Allowed dependencies: Application, Data, Common.

Key contents:

| Area | Files |
|---|---|
| Composition root | `Program.cs` |
| Endpoints | `Functions/ImitationRequestFunctions.{cs,Get,Post,Put,Delete}.cs`, `Functions/PaintSystemFunctions.{cs,Get,Post,Put,Delete}.cs`, `Functions/DerivedPaintSystemFunctions.{cs,Get}.cs`, `Functions/LookupFunctions.cs`, `Functions/MeasurementFunctions.cs`, `Functions/OptionSetFunctions.cs`, `Functions/ProductInfoFunctions.cs`, `Functions/SharedFunctions.cs`, `Functions/StandardTechnicalRemarksFunctions.*.cs` |
| Authorization | `Middleware/Authorization/{AuthorizationMiddleware, ConditionalTokenValidationMiddleware, RequiresRoleAttribute, SkipUserJWTAuthenticationAttribute, PermissionValueAttribute, PermissionExtensions, UserRoles}.cs` |
| Errors | `Middleware/ExceptionHandler/ExceptionHandlingMiddleware.cs` |
| CDMS routing | `Middleware/Routing/RoutingMiddleware.cs` |
| Tracing | `RequestTracing/Correlation/{CorrelationIdMiddleware, CorrelationIdAccessor, CorrelationIdDelegatingHandler}.cs` |

Convention: one `partial class <Feature>Functions` split into verb files. The base file holds only
the constructor (`IDispatcher` + `ILogger<T>`).

### 2.2 Application — `AN.ColorAppsAzure.Formula.Application`

Responsibility: CQRS handlers, FluentValidation validators, business helpers, response models.

Allowed dependencies: Data, Common. **Must not** reference Function.

Folder convention:
`<Feature>/Commands/<Operation>/` and `<Feature>/Queries/<Operation>/`, plus `<Feature>/Shared/`
for cross-operation helpers and `<Operation>/HandlerHelper/` for operation-scoped helpers.

Features present: `ImitationRequest`, `PaintSystem`, `Lookup`, `ProductInfo`, `OptionSets`,
`Measurement`, `TonerInProducts`, `Shared`.

### 2.3 Data — `AN.ColorAppsAzure.Formula.Data`

Responsibility: all outbound data access. Exposes hand-written interfaces so Application never
touches a GraphQL client directly.

Structure:
- `Graphql/<Domain>/Queries/I<X>QueryService.cs` + implementation
- `Graphql/<Domain>/Commands/I<X>CommandService.cs` + implementation
- `Graphql/GraphqlAssets/<Schema>/**/*.graphql` — hand-written operations
- `Graphql/GraphqlAssets/<Schema>/schema.graphql` — schema snapshot
- `Graphql/GraphqlAssets/<Schema>/.graphqlrc.json` — StrawberryShake client name + namespace
- `Graphql/GraphqlAssets/<Schema>/Generated/<Schema>GraphQL.Client.cs` — **generated, committed**
- `Shared/MemoryCacheManager.cs`, `Shared/CacheWarmupWithData.cs`
- `Shared/Exceptions/{CacheException, GraphQlException}.cs`, `Shared/Exceptions/Helper/GraphQlExceptionHelper.cs`

### 2.4 Common — `AN.ColorAppsAzure.Formula.Common`

Responsibility: constants and primitives shared by all layers. No business logic.

| File | Contents |
|---|---|
| `Utility/Constants.cs` | Nested static classes: `ImitatationRequestTypes`, `ImitationRequestTypeCdmsKeys`, `PaintSystemStatuses`, `ImitationRequestStatuses`, `PaintSystemLevels`, `LocalGlobal`, `OwnerTypes`, `ProductNumbers`, `Versioning`, `CacheKeys`, `ErrorMessages`, `SuccessMessages`, route/CDMS endpoint constants |
| `Utility/EnvConfig.cs` | `CdmsFunctionAppUrl`, `CdmsFunctionKey`, `FeatureFlagsCdms`, GraphQL URL/keys |
| `Errors/ErrorCode.cs` | enum (see §5) |
| `Errors/AppBaseException.cs` | abstract base carrying `ErrorCode` |
| `Models/ApiResponse.cs` | `ApiResponse<T>` + `ApiError` |
| `Extensions/HttpRequestDataResponseExtension.cs` | `CreateJsonResponse`, `CreateSuccessResponse<T>`, `CreateErrorResponse` |

---

## 3. Middleware pipeline

`Program.cs` (worker defaults) registers, in order:

1. `CorrelationIdMiddleware`
2. `ConditionalTokenValidationMiddleware`
3. `ExceptionHandlingMiddleware`
4. `AuthorizationMiddleware`
5. `RoutingMiddleware`

Consequence: exceptions thrown by `AuthorizationMiddleware`, `RoutingMiddleware` and by the
function/handler chain are all caught by `ExceptionHandlingMiddleware`.

`RoutingMiddleware` can short-circuit an invocation and forward the raw HTTP request to the
**CDMS Function App** when the `Cdms` feature flag is on and the route is not on the exclusion list.
See [DATA-ACCESS-GRAPHQL.md](./DATA-ACCESS-GRAPHQL.md) §5.

---

## 4. Dependency injection (`Program.cs`)

Registration groups, in the order they appear:

| Group | What is registered |
|---|---|
| CORS | localhost + dev Azure origins |
| Token validation | JWT configuration for `ConditionalTokenValidationMiddleware` |
| Memory cache | `IMemoryCache`, `IMemoryCacheManager` → `MemoryCacheManager` |
| Environment | `EnvConfig` singleton (GraphQL URL, subscription key, CDMS URL/key) |
| HTTP clients | `GraphQL`, `StrawberryClient`, `CdmsClient` — each with `CorrelationIdDelegatingHandler` |
| Scoped data services | ~20 `I*QueryService` / `I*CommandService` → concrete implementations |
| Application helpers | `IConversionEligibilityValidationHelper`, `IMetallicPearlValidationService`, `IDuplicateTonerValidationService`, `IPaintSystemTypeResolver` |
| Validators | `services.AddValidatorsFromAssemblyContaining<UpdateImitationRequestValidator>()` — assembly scan, so **new validators need no manual registration** |
| GraphQL clients | `AddFormulaGraphQL()`, `AddComplexUpdateGraphQL()`, `AddMarketColorGraphQL()`, `AddProductGraphQL()` — all `ConfigureHttpClient` with the same base URL + API key header |
| Feature flags | `FeatureFlags_Cdms` environment variable |
| Cache warmup | `CacheWarmupWithData` as singleton **and** as `IHostedService` |
| Dispatcher | `services.AddScoped<IDispatcher, Dispatcher>()` |
| Handlers | Assembly scan of the Application assembly: every type ending in `Handler` implementing `ICommandHandler<,>` or `IQueryHandler<,>` registered scoped |

> Practical rule: **new handlers and new validators are auto-registered**. New *data services* and
> new *helper interfaces* must be added manually to `Program.cs`.
> (The repo-level `.github/copilot-instructions.md` says "register every new handler" — the scan makes
> that unnecessary for handlers; it is still required for services. Prefer the code as evidence.)

---

## 5. Error model

`Common/Errors/ErrorCode.cs`:

```csharp
GraphQlResponseError = 100,
GraphQlDataNotFound,          // 101
CacheWarmupFailed = 200,
CacheWarmupSchedulingFailed,  // 201
CacheDependencyMissing,       // 202
CacheDataFetchFailed,         // 203
ValidationFailed = 300,
UnexpectedError,              // 301
AuthTokenMissing,             // 302
```

Exception types:

| Type | Location | ErrorCode |
|---|---|---|
| `AppBaseException` (abstract) | `Common/Errors/AppBaseException.cs` | carries any |
| `AppValidationException` | `Application/Shared/Exceptions/AppValidationException.cs` | `ValidationFailed`, carries `IReadOnlyList<FieldError>` |
| `GraphQlException` | `Data/Shared/Exceptions/GraphQlException.cs` | `GraphQlResponseError` / `GraphQlDataNotFound` |
| `CacheException` | `Data/Shared/Exceptions/CacheException.cs` | `CacheDataFetchFailed` |

Mapping in `ExceptionHandlingMiddleware`:

| Error / exception | HTTP |
|---|---|
| `ValidationFailed` | 400 |
| `JsonException` | 400 |
| `AuthTokenMissing`, `UnauthorizedAccessException` | 401 |
| `CacheWarmupFailed`, `CacheDependencyMissing` | 500 |
| `GraphQlResponseError` | 502 |
| anything else | 500 |

---

## 6. Known architecture exceptions / things that are not textbook

- `Dispatcher` uses reflection + `dynamic` rather than MediatR. There is no pipeline behaviour,
  therefore **validation is not a pipeline concern** — each handler invokes its validator itself.
- Two validation styles coexist:
  - `CreatePaintSystemHandler` uses `ValidateAndThrowAsync` → `AppValidationException` → HTTP 400.
  - `CreateImitationRequestHandler` uses `ValidateAsync` and returns a **per-product result list**
	with `total/succeeded/failed`, i.e. HTTP 200 with failures inside the payload.
  Do not "harmonise" these without a PBI that asks for it.
- Some operation-scoped logic lives in `static` helper classes inside `HandlerHelper/` folders
  (e.g. `CreatePaintSystemVersionResolver`, `CreatePaintSystemInputFactory`). This is the existing
  pattern for keeping handler cognitive complexity within Sonar limits.
- `CreatePaintSystemHandlerDependencies` is a dependency-bundle object used to keep the handler
  constructor under the Sonar parameter limit.
- `Application/ImitationRequest/Queries/GetImitationRequestList/GetImiatationListCommand.cs` is a
  **query** despite the `Command` suffix (dispatched with `IDispatcher.Query`). Naming inconsistency,
  not a behavioural one.

NOT CONFIRMED: whether any non-HTTP trigger (timer/queue/event) exists. Only HTTP-triggered
functions plus the `CacheWarmupWithData` `IHostedService` were found.
