# DATA-ACCESS-GRAPHQL

GraphQL / DAB / CDMS / cache architecture.

---

## 1. Four GraphQL clients

Configured by `.graphqlrc.json` under `Data/Graphql/GraphqlAssets/<Schema>/`:

| Folder | Client name | Generated namespace | Used for |
|---|---|---|---|
| `Formula/` | `FormulaGraphQL` | `Formula.GraphQL.Client` | main domain: imitation requests, paint systems, formulas, measurements, toners, lookups, cache data |
| `MarketColor/` | `MarketColorGraphQL` | `MarketColor.GraphQL.Client` | market colour owners, original-type products, primer market colour |
| `ComplexUpdate/` | `ComplexUpdateGraphQL` | `Formula.GraphQL.ComplexUpdate` | `ComplexUpdate_UpdateFormulaWithComponents` |
| `Product/` | `ProductGraphQL` | `Product.GraphQL.Client` | `Product_GetTonerTypes` |

All four are registered in `Program.cs`:

```csharp
services.AddFormulaGraphQL().ConfigureHttpClient(...);
services.AddComplexUpdateGraphQL().ConfigureHttpClient(...);
services.AddMarketColorGraphQL().ConfigureHttpClient(...);
services.AddProductGraphQL().ConfigureHttpClient(...);
```

They share the same base URL + subscription-key header from `EnvConfig`, with a 5-minute timeout.

---

## 2. Pipeline

```
Data/Graphql/GraphqlAssets/<Schema>/<Area>/<Operation>.graphql      (hand written)
		+ <Schema>/schema.graphql                                   (schema snapshot)
		+ <Schema>/.graphqlrc.json                                  (client name + namespace)
   --[ StrawberryShake generator ]-->
Data/Graphql/GraphqlAssets/<Schema>/Generated/<Schema>GraphQL.Client.cs   (COMMITTED to git)
   -->  I<Schema>GraphQL  +  I<Operation>_<Path>_<Type> result interfaces
   -->  Data/Graphql/<Domain>/Queries|Commands/<X>Service.cs        (hand written wrapper)
   -->  Application handlers (via the I<X>Service interface only)
```

### 2.1 Generated code is committed
`FormulaGraphQL.Client.cs` is in source control (200k+ lines). `.gitignore` excludes
`Generated\ Files/` and `Generated_Code/` but **not** these folders.

Consequences:
- Any `.graphql` change produces a large diff in `*.Client.cs`. That diff is expected — review it,
  do not revert it.
- Never hand-edit `*.Client.cs`.
- A schema/variable change alters `ExecuteAsync(...)` signatures. That breaks:
  - the calling `I<X>Service` implementation,
  - every NSubstitute mock in `*.Tests` that stubs that `ExecuteAsync` overload.
  Fix production code **and** test mocks together, then build the whole solution.

### 2.2 Operation naming
Operations are prefixed with their domain: `Formula_`, `MarketColor_`, `Product_`,
`Products_`, `ComplexUpdate_`. Keep the prefix — the generator derives the client interface member
name from it.

NOT CONFIRMED: whether the backend enforces the prefix or it is only a repository convention.

### 2.3 Regeneration
`Data/AN.ColorAppsAzure.Formula.Data.csproj` contains MSBuild targets for downloading the
Formula / MarketColor / ComplexUpdate schemas — **currently commented out**. Packages in use:
`GraphQL.Client` 6.1.0, `StrawberryShake.Transport.Http` 15.1.12.

So today: schema snapshots are checked in and generation happens during build from the local
`schema.graphql` files. If a new backend field is needed, the `schema.graphql` snapshot must be
refreshed first — otherwise generation fails with an unknown-field error.

---

## 3. Paint System / Imitation Request query filters (exact)

These are the queries that decide "does a paint system exist" and "is there an active IR".
Using the wrong one produces false "Paint system does not exist" errors.

| Operation | Filters |
|---|---|
| `Formula_GetQualifyingPaintSystems` | `ProductId.eq`, `imitationRequest.MarketColorInstanceId.eq`, `RecordIsActive.eq`, `RecordIsDeleted.eq`, `PaintSystemStatusId.eq` OR-set (Actual / Incomplete / Historic) |
| `Formula_GetQualifyingImprovedFormulaPaintSystems` | `ProductId.eq`, `imitationRequest.MarketColorInstanceId.eq`, **`imitationRequest.LocalGlobalId.eq`**, `RecordIsDeleted.eq`, `PaintSystemStatusId.eq` OR-set |
| `Formula_Local_GetPaintSystemByProductAndColor` | `ProductId.eq` (OR parent), `RecordIsDeleted.eq`, `RecordIsActive.eq`, **`GeoId.isNull = false`**, `MultiLayerLink.isNull = true`, `PaintSystemStatusId.eq` OR-set, `colorImitations.filter.ColorId.eq` |
| `Formula_Global_GetPaintSystemByProductAndColor` | identical to Local except **`GeoId.isNull = true`** |
| `Formula_GetPaintSystemsByColor` | `colorImitations`: `ColorId.eq`, `RecordIsDeleted.eq`, `RecordIsActive.eq` |
| `Formula_GetColorImitationsWithPaintSystems` | by `ColorId`; returns `Items[].PaintSystem` — used for versioning siblings |
| `Formula_GetImitationRequestForVersioning` | `ImitationRequestId.eq` only |
| `Formula_CheckActiveImitationRequest` | `MarketColorInstanceId.eq`, `ProductId.eq`, `LocalGlobalId.eq`, `RecordIsDeleted.eq`, `RecordIsActive.eq`, `ImitationRequestStatusId.eq` OR-set (InDevelopment / AwaitingDevelopment) |
| `Formula_CheckActiveImitationRequestByColor` | `marketColorInstance.ColorId.eq`, `ProductId.eq`, `LocalGlobalId.eq`, `RecordIsDeleted.eq`, `RecordIsActive.eq`, `ImitationRequestStatusId.eq` OR-set |

### Differences that bite

- `GetQualifyingPaintSystems` filters on `RecordIsActive`; `GetQualifyingImprovedFormulaPaintSystems`
  **does not** — it only filters `RecordIsDeleted`.
- Only the Improved-Formula variant filters on `LocalGlobalId`.
- Local vs Global differ **only** by `GeoId.isNull`.
- `Formula_GetImitationRequestForVersioning` has **no** active/deleted filter.

Verify the actual `.graphql` file before claiming a filter exists.

---

## 4. Relationship navigation (DAB shape)

Fields reachable only through a relationship — this is the #1 source of schema errors:

| Field you want | Where it actually lives | GraphQL path from PaintSystem |
|---|---|---|
| `MarketColorInstanceId` | ImitationRequest | `imitationRequest.MarketColorInstanceId` |
| `LocalGlobalId` | ImitationRequest | `imitationRequest.LocalGlobalId` |
| `ColorId` | MarketColorInstance / ColorImitation | `colorImitations.ColorId` or `imitationRequest.marketColorInstance.ColorId` |
| `Product` details | Product | `Product.{ProductId, ParentProductId, IsPrimaryDerivedProduct, ProductNr}` |
| `DevelopmentTool` | ImitationRequest | `imitationRequest.DevelopmentTool.Id` |

Direct PaintSystem fields seen in queries: `PaintSystemId`, `ProductId`, `Version`,
`PaintSystemStatusId`, `GeoId`, `MultiLayerLink`, `RecordIsActive`, `RecordIsDeleted`,
`IsConversionToAllProductsAllowed`, `OriginalProductId`.

**`LocalGlobalId` is NOT a PaintSystem field.** Filtering it directly on `paintSystems` is a
schema error.

---

## 5. CDMS routing (not GraphQL)

`Function/Middleware/Routing/RoutingMiddleware.cs`

- Reads `EnvConfig.CdmsFunctionAppUrl` / `CdmsFunctionKey`; enabled by the `FeatureFlags_Cdms`
  environment variable parsed in `Program.cs`.
- `Invoke` checks `_featureFlags.Cdms` and `IsValidRequestUrl`; if routed, `RouteTosCdms`
  forwards the raw HTTP request (with correlation headers) to the CDMS Function App and returns
  its response. The local handler never executes.
- `BuildCdmsRequest` composes the CDMS URL from path + query string.
- An **exclusion list** keeps certain routes local.

CDMS endpoint constants (`Common/Utility/Constants.cs`):

```
CdmsImitationCreate              = "imitationrequest/createimitation"
CdmsImitationUpdate              = "imitationrequest/update"
CdmsImitationDeleteBase          = "imitationrequest/delete"
CdmsExecuteWorkflowNotFeasible   = "imitationrequest/Execute_Workflow_NotFeasibleImitationRequest"
```

**Implication:** with the CDMS flag on, IR create/update/delete may never reach
`CreateImitationRequestHandler`. Always check `RoutingMiddleware`'s exclusion list before assuming
your handler change is reachable.

`Formula_GetDataForCdms.graphql` exists in the Formula assets — a query that supplies data for the
CDMS side.

## 5.1 SCS

No `Scs` class, service, client or constant was found in this repository.
Status transitions attributed to SCS (`Incomplete → Actual`) are **not implemented here**.
See [OPEN-QUESTIONS.md](./OPEN-QUESTIONS.md).

## 5.2 XRM / Dataverse

No direct XRM/Dataverse SDK usage found. All persistence is through GraphQL endpoints or CDMS
forwarding. NOT CONFIRMED whether the GraphQL backend itself is Dataverse-backed.

---

## 6. Cache

`Data/Shared/MemoryCacheManager.cs` (`IMemoryCacheManager`) and
`Data/Shared/CacheWarmupWithData.cs` (`ICacheWarmupWithData`, registered as singleton **and**
`IHostedService`).

- Warmup runs one GraphQL query: `Formula_GetCacheData`.
- Entries use an 8-hour absolute expiration; a post-eviction callback re-triggers warmup.
- `MemoryCacheManager` tracks all keys in a `ConcurrentDictionary` with per-category semaphores and
  supports clearing via `CancellationTokenSource` expiration tokens.
- Warmup failure is **logged, not thrown** — the host still starts. Lookups then return `null` and
  callers that use `?.Id ?? Guid.Empty` silently degrade.

### Cache reference table

| Cache key constant | Value | Contents | Used by | Failure behaviour |
|---|---|---|---|---|
| `CacheKeys.LocalGlobals` | `localGlobals` | LocalGlobal | `ImitationRequestValidator.IsFormulaRegionValid` | rule cannot detect Global → skipped |
| `CacheKeys.ImitationRequestTypes` | `imitationRequestTypes` | ImitationRequestType | IR validators, versioning context | type comparisons fail |
| `CacheKeys.DevelopmentTools` | `developmentTools` | DevelopmentTool | `RequiresLinkedRecords` | linked records not created |
| `CacheKeys.ImitationRequestStatusKey` | `imitationRequestStatuses` | ImitationRequestStatus | `CreatePaintSystemImitationRequestStatusUpdater`, active-IR queries | `Guid.Empty` → updater **silently no-ops** |
| `CacheKeys.ApplicationMethods` | `applicationMethods` | ApplicationMethod | lookups | empty lookup |
| `CacheKeys.Urgencies` | `urgencies` | Urgency | lookups | empty lookup |
| `CacheKeys.SubstrateMetadatas` | `substrateMetadatas` | SubstrateMetadata | lookups | empty lookup |
| `CacheKeys.FormulaComponentTypeKey` | `formulaComponentTypes` | FormulaComponentType | formula components | empty lookup |
| `CacheKeys.PaintSystemStatusKey` | `paintSystemStatuses` | PaintSystemStatus | `ResolveInitialPaintSystemStatusId`, `GetPaintSystemStatusId` | `Guid.Empty` status written |
| `CacheKeys.PaintSystemLevelKey` | `paintSystemLevels` | PaintSystemLevel | `UpdatePaintSystemHandler.GetPaintSystemLevelId` | null level |
| `CacheKeys.PaintSystemTypeKey` | `paintSystemTypes` | PaintSystemType | `IPaintSystemTypeResolver` | null type |

`CacheException` (`ErrorCode.CacheDataFetchFailed`) exists for explicit failures;
`ErrorCode.CacheDependencyMissing` and `CacheWarmupFailed` map to HTTP 500.

---

## 7. GraphQL error handling

`Data/Shared/Exceptions/Helper/GraphQlExceptionHelper.cs`

| Method | Throws |
|---|---|
| `ThrowIfGraphQlResponseHasErrors(result)` | `GraphQlException` with `ErrorCode.GraphQlResponseError` → HTTP 502 |
| `ThrowIfGraphQlDataNull<T>(data)` | `GraphQlException` with `ErrorCode.GraphQlDataNotFound` |

Every data service should call these after `ExecuteAsync`. Follow the existing service as a
template rather than inventing new error handling.

---

## 8. Checklist for a GraphQL change

- [ ] Search existing `.graphql` files first — 57 operations already exist.
- [ ] Confirm the field exists in the relevant `schema.graphql` snapshot.
- [ ] Keep the domain prefix in the operation name.
- [ ] Build; inspect the `*.Client.cs` diff.
- [ ] Update the `I<X>Service` wrapper and its implementation.
- [ ] Update every NSubstitute mock of the changed `ExecuteAsync` overload.
- [ ] `dotnet build` the full solution, then run the Data and Application test projects.
