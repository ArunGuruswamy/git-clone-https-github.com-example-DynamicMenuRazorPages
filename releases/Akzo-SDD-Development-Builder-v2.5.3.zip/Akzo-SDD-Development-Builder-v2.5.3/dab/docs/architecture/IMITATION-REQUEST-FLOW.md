# IMITATION-REQUEST-FLOW

Complete analysis of Imitation Request (IR) creation and validation.

Primary files:
- `Application/ImitationRequest/Shared/ImitationRequestValidator.cs` (generic base, `ImitationRequestValidator<T>`)
- `Application/ImitationRequest/Shared/Requests/BaseImitationRequest.cs`
- `Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestValidator.cs`
- `Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestHandler.cs`
- `Application/ImitationRequest/Commands/CreateImitationRequest/CreateImitationRequestMapper.cs`
- `Application/ImitationRequest/Commands/UpdateImitationRequest/UpdateImitationRequestValidator.cs`
- `Function/Functions/ImitationRequestFunctions.Post.cs`

---

## 1. End-to-end

```
POST ImitationRequest/Create            [Function("ImitationRequestCreate")]
										[RequiresRole(ImitationRequestPermissions.Create)]
  body: CreateImitationRequest (one payload, N ProductIds)
  -> CreateImitationRequestCommand
  -> CreateImitationRequestHandler.Handle
	   CreateImitationRequestMapper.Map  => one BaseImitationRequest per product
	   per product:
		 CreateImitationRequestValidator.ValidateAsync
		 if invalid  -> failure entry (PropertyName / ErrorMessage), continue
		 if valid    -> CreateImitationRequest(...) -> IImitationRequestCommandService
  <- 200 { total, succeeded, failed, response[] }
```

The handler stamps audit fields:
`RecordIsActive = true`, `RecordIsDeleted = false`,
`RecordModifiedBy = _userContextAccessor.GetUserContext()?.Email`.

**Creating an IR does not create a Paint System.** Confirmed: `CreateImitationRequestHandler`
contains no call into any paint system command service. Paint System creation is a separate,
explicit endpoint (see [PAINT-SYSTEM-FLOW.md](./PAINT-SYSTEM-FLOW.md)).

---

## 2. Request types

Defined in `Common/Utility/Constants.cs`.

`ImitatationRequestTypes` (display names, note the typo in the class name — keep it):
`NewSample = "New sample"`, `Improved = "Improved formula"`, `Technical = "Technical"`.

`ImitationRequestTypeCdmsKeys` (integer keys — these drive versioning):

| Key | Type |
|---|---|
| 1 | Complaint |
| 2 | ImprovedFormula |
| 3 | NewSample |
| 4 | ProductModification |
| 5 | Technical |
| 6 | MasterCandidate |
| 800000000 | Industrialization |
| 800000001 | Adaption |
| 800000002 | DigitalVariant |

> "Adaptation" appears in code as **`Adaption`**. Use the repository spelling.

---

## 3. Validation — layer 1: `ImitationRequestValidator<T>` (create AND update)

| Rule | Field | Message |
|---|---|---|
| NotEmpty | `MarketColorInstanceId` | "MarketColorInstanceId is required." |
| NotEmpty | `ImitationRequestTypeId` | "ImitationRequestType is required." |
| NotEmpty | `ProductId` | "ProductId is required." |
| NotEmpty | `LocalGlobalId` | "Local/Global must be specified." |
| NotEmpty | `UrgencyId` | "UrgencyID must be specified." |
| NotEmpty | `TeamId` | "TeamID must be specified." |
| `IsDueDateValid` | `DueDate` | must not be in the past; compared against local time derived from UTC via `RetrieveLocalTimeFromUtcTime()` (Pacific Standard Time) |
| `IsFormulaRegionValid` | `FormulaRegionId` | "Formula region is not supported for the Global." — only evaluated when `FormulaRegionId.HasValue && != Guid.Empty`; rejects when the cached `LocalGlobals` name for `LocalGlobalId` is `Global` |
| `HasValidColorId` | `MarketColorInstanceId` | "Color Id not exist for the Market color instance" — `marketColorInstance.ColorId != Guid.Empty` |
| `HasActiveMarketColorInstance` | `MarketColorInstanceId` | "No Active market color instances found while ImitationRequestValidation." |

These apply to **every request type**. No type-specific branching in this layer.

---

## 4. Validation — layer 2: `CreateImitationRequestValidator` (create only)

### 4.1 Role assigned
`HasAssignedRole()` — `marketColorInstance?.RoleId` must be non-null and non-empty.
Error key `MarketColorInstanceRoleRequired`.

### 4.2 Duplicate / cross-over — `NoActiveImitationRequestExists()`

Two distinct checks, both producing `ActiveImitationRequestAlreadyExists`:

**(a) Exact duplicate**
`IImitationRequestQueryService.GetActiveImitationRequest(marketColorInstanceId, productId, localGlobalId)`
→ `Formula_CheckActiveImitationRequest`
Filters: `MarketColorInstanceId`, `ProductId`, `LocalGlobalId`, `RecordIsDeleted`, `RecordIsActive`,
`ImitationRequestStatusId ∈ { InDevelopment, AwaitingDevelopment }`.

**(b) Cross-over by colour**
Resolve `ColorId` from the MarketColorInstance, then
`IImitationRequestQueryService.GetActiveImitationRequestByColor(colorId, productId, localGlobalId)`
→ `Formula_CheckActiveImitationRequestByColor`
Filters: `marketColorInstance.ColorId`, `ProductId`, `LocalGlobalId`, `RecordIsDeleted`,
`RecordIsActive`, `ImitationRequestStatusId ∈ { InDevelopment, AwaitingDevelopment }`.

Difference to remember:
- (a) keys on **MarketColorInstanceId + Product + Local/Global**.
- (b) keys on **ColorId + Product + Local/Global** — catches different MCIs that share one colour.

Both run for **all** request types.

### 4.3 Paint System existence — `GetPaintSystemValidationError()` (DependentRules, only if 4.2 passed)

1. `ResolvePaintSystemProductIdAsync()` — if `IsPrimaryDerivedProduct == true` and a
   `ParentProductId` exists, the **parent product id** is used for the lookup; otherwise the
   selected `ProductId`.
2. `IPaintSystemQueryService.GetPaintSystemCount(paintSystemProductId, marketColorInstanceId, localGlobalId)`
   → `Formula_GetQualifyingImprovedFormulaPaintSystems`.
3. Rules:

| Condition | Result |
|---|---|
| `count == 0` and type != `NewSample` | "Paint system does not exist for this Market Color Instance and Product, only New Sample is allowed." |
| `count > 0` and type == `NewSample` | "New Sample is not allowed, Paint system exist for this Market Color Instance and Product." |

So: **New Sample requires that no Paint System exists; every other type requires that one exists.**

### 4.4 Improved Formula eligibility — `IsProductEligibleForImprovedFormula()`

Runs only when `request.ImitationRequestTypeId == _improvedFormulaTypeId`.

| `product.IsPrimaryDerivedProduct` | Outcome |
|---|---|
| `true` | allowed |
| `null` | rejected |
| `false` (secondary derived) | allowed **only** when the MarketColor's `OwnerTypeId` resolves (via `IMarketColorQueryService.GetOwners()`) to an owner named `Coil` (`OwnerTypes.Coil`, `OrdinalIgnoreCase`). Otherwise: "Improved Formula is not allowed for the selected Secondary Derived Product." |

---

## 5. Per-request-type rule matrix (create)

| Rule | New Sample | Improved Formula | Technical | Adaption | Industrialization | Product Modification | Master Candidate | Complaint | Digital Variant |
|---|---|---|---|---|---|---|---|---|---|
| Layer-1 required fields | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ |
| Due date not past | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ |
| FormulaRegion not allowed for Global | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ |
| MCI role assigned | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ |
| No duplicate active IR (MCI key) | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ |
| No cross-over active IR (Color key) | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ |
| Paint System must **not** exist | ✔ | – | – | – | – | – | – | – | – |
| Paint System must exist | – | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ |
| Improved-Formula derived-product rule | – | ✔ | – | – | – | – | – | – | – |

The last three rows are derived from type comparisons in `GetPaintSystemValidationError` /
`IsProductEligibleForImprovedFormula`. They are **not** written per type; they are
"NewSample vs everything else" and "ImprovedFormula only".

---

## 6. Initial status

`ImitationRequestStatusId` is **supplied by the caller** and passed straight through by
`CreateImitationRequestHandler` into `CreateImitationRequestsInput`.
There is no server-side default-status resolution on IR create.

The only server-driven IR status transition found is:
**Paint System created → IR set to `InDevelopment`**
(`CreatePaintSystemImitationRequestStatusUpdater.UpdateAsync`, reading
`CacheKeys.ImitationRequestStatusKey` / `ImitationRequestStatuses.InDevelopment`;
it silently no-ops if the status id resolves to `Guid.Empty`).

NOT CONFIRMED: who sets `Closed` / `AwaitingDevelopment`. Not found in this repository.

---

## 7. Other IR operations

| Operation | Handler |
|---|---|
| Update | `UpdateImitationRequest/UpdateImitationRequestHandler.cs` + `UpdateImitationRequestValidator` (extends the same `ImitationRequestValidator<T>` base, **without** the create-only rules in §4) |
| Update status only | `UpdateImitationRequestStatus/UpdateImitationRequestStatusHandler.cs` |
| Deactivate | `DeactivateImitationRequest/DeactivateImitationRequestHandler.cs` |
| Delete | `DeleteImitationRequest/DeleteImitationRequestHandler.cs` |
| Not-feasible workflow | `Workflow/NotFeasibleWorkflow/NotFeasibleWorkflowHandler.cs` |
| Get by id | `Queries/GetImitationRequestById/` → `Formula_GetImitationRequestById` |
| List (by view) | `Queries/GetImitationRequestList/` + `ViewValidator.cs` → `Formula_GetImitationRequestByIsActive` / `Formula_GetImitationRequestByStatusName` |
| Paint systems of an IR | `Queries/GetPaintSystemByImitationRequestId/` → `Formula_GetPaintSystemByImitationRequestId` |

**Regression rule:** `ImitationRequestValidator<T>` is shared by create *and* update. Any change
there affects both flows and all request types.
