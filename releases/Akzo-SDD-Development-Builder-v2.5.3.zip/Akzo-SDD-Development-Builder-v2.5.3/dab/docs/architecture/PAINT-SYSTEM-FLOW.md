# PAINT-SYSTEM-FLOW

Paint System create / update / publish architecture.

---

## 1. Files

```
Application/PaintSystem/
├── Commands/
│   ├── CreatePaintSystem/
│   │   ├── CreatePaintSystemCommand.cs
│   │   ├── CreatePaintSystemRequest.cs
│   │   ├── CreatePaintSystemResponse.cs
│   │   ├── CreatePaintSystemValidator.cs
│   │   ├── CreatePaintSystemHandler.cs
│   │   ├── CreatePaintSystemDetailsMapper.cs
│   │   └── HandlerHelper/
│   │       ├── CreatePaintSystemHandlerDependencies.cs
│   │       ├── CreatePaintSystemVersioningContext.cs
│   │       ├── CreatePaintSystemVersioningContextResolver.cs
│   │       ├── CreatePaintSystemVersionResolver.cs
│   │       ├── PaintSystemVersioningService.cs
│   │       ├── CreatePaintSystemInputFactory.cs
│   │       ├── CreatePaintSystemDetailsFactory.cs
│   │       ├── CreatePaintSystemImitationRequestStatusUpdater.cs
│   │       ├── PaintSystemDetails.cs
│   │       └── PaintSystemType.cs
│   ├── CreateNotFeasiblePaintSystem/
│   ├── CreateTechnicalRemarkRequest/
│   ├── LinkDerivedProductsAsync/
│   ├── PublishPaintSystem/
│   ├── UpdateFormulaWithComponents/
│   └── UpdatePaintSystem/
├── Queries/  (GetPaintSystemById, GetPaintSystemList, GetFormulaComponentsOfPaintSystem, GetMeasurementsByPaintSystemId)
└── Shared/   (VersioningHelper.cs, ConversionEligibilityValidationHelper.cs, ...)
```

Dependency bundle: `CreatePaintSystemHandlerDependencies` exposes
`QueryService`, `TypeResolver`, `Cache`, `ImitationRequestCommandService`,
`ConversionEligibilityValidationHelper`. It exists to keep the handler constructor small
(Sonar parameter-count rule).

---

## 2. `CreatePaintSystemHandler.Handle` — exact sequence

```
1  ArgumentNullException.ThrowIfNull(request.PaintSystemRequest)
2  _validator.ValidateAndThrowAsync(request.PaintSystemRequest, ct)        // CreatePaintSystemValidator
3  ctx = QueryService.FetchPaintSystemVersioningContextAsync(ImitationRequestId)
	   -> Formula_GetImitationRequestForVersioning  (filter: ImitationRequestId.eq)
	   if ctx == null -> throw AppValidationException(ErrorMessages.ImitationRequestNotFound)
4  (versioningContext, nextVersion, finalName) = _versioningService.ResolveVersioningAsync(ctx)
5  paintSystemType     = TypeResolver.ResolvePaintSystemTypeAsync(ctx)
6  paintSystemStatusId = ResolveInitialPaintSystemStatusId()               // always "Incomplete"
7  (imitationRequest, isConversionToAllProductsAllowed) = ResolveConversionEligibilityAsync(irId)
8  createLinkedRecords = RequiresLinkedRecords(
		request.DevelopmentToolId ?? imitationRequest?.DevelopmentTool?.Id)  // ColorApps | OwnColor
9  id = _commandService.CreatePaintSystem(CreatePaintSystemInputFactory.Build(CreatePaintSystemInputParams{...}))
	   -> Formula_CreatePaintSystem
	   (nested CreateColorImitationsInput is built by BuildColorImitations when ColorId != Guid.Empty)
10 if createLinkedRecords -> CreateLinkedColorAsync(request, id, finalName)
	   -> _commandService.CreateColor(paintSystemId, colorName, recordModifiedBy) -> Formula_CreateColor
11 if ImitationRequestId.HasValue -> CreatePaintSystemImitationRequestStatusUpdater.UpdateAsync(...)
	   -> IR status := InDevelopment
12 return CreatePaintSystemResponse {
	   Success = true,
	   Data    = CreatePaintSystemDetailsFactory.BuildDetailsAsync(QueryService, id, finalName, nextVersion, paintSystemType),
	   Errors  = []
   }
```

### Ordering facts that matter
- **Paint System row is created first (step 9).** The nested `colorImitations` input is created in
  the same mutation. The extra `CreateColor` call (step 10) happens *after*, and only for
  ColorApps / OwnColor development tools.
- **There is no transaction.** If step 10 or 11 fails, the Paint System from step 9 already exists.
  Any compensation logic would be new behaviour — do not assume it exists.
- **IR status update is last-but-one** and is best-effort: if
  `ImitationRequestStatuses.InDevelopment` is missing from cache the updater returns without
  updating and without throwing.

---

## 3. Initial status

```csharp
private Guid ResolveInitialPaintSystemStatusId() =>
	_dependencies.Cache?.Get(CacheKeys.PaintSystemStatusKey, PaintSystemStatuses.Incomplete)?.Id
	?? Guid.Empty;
```

**Every** Paint System — regardless of imitation request type — is created `Incomplete`.
There is no branch for Technical, Improved Formula, etc.
Transition to `Actual` / `Historic` is not performed by this repository on create.
See [STATUS-AND-VERSIONING.md](./STATUS-AND-VERSIONING.md).

---

## 4. Linked record creation

`RequiresLinkedRecords(Guid? developmentToolId)` returns `true` only for the **ColorApps** and
**OwnColor** development tools; `false` for `null`/`Guid.Empty` and everything else.

When `true`:
- `CreatePaintSystemInputFactory.BuildColorImitations` produces a nested
  `CreateColorImitationsInput { ColorImitationId = Guid.NewGuid(), ColorId, RecordIsActive = true, RecordIsDeleted = false }`.
  Returns `null` when `ColorId == Guid.Empty`.
- `CreateLinkedColorAsync` additionally calls `IPaintSystemCommandService.CreateColor`.

The `CreateLinkedRecords` flag is also passed into `CreatePaintSystemInputParams`.

---

## 5. Conversion eligibility (create)

`CreatePaintSystemHandler.ResolveConversionEligibilityAsync(Guid? imitationRequestId)`:

1. `QueryService.GetImitationRequestByIdAsync(imitationRequestId)`
2. resolve the parent product number when the product is primary-derived
3. `IConversionEligibilityValidationHelper.IsConversionAllowed(isPrimaryDerivedProduct, productNr, parentProductNumber)`

`Application/PaintSystem/Shared/ConversionEligibilityValidationHelper.cs`:

```
if productNumber == ProductNumbers.RelestProtect            -> false   // hard block, wins over everything
else if isPrimaryDerivedProduct == true                     -> true
else if productNumber == Salcomix || parentProductNumber == Salcomix -> true
else                                                        -> false
```

Result is written to `CreatePaintSystemsInput.IsConversionToAllProductsAllowed`.

---

## 6. UpdatePaintSystem

`Application/PaintSystem/Commands/UpdatePaintSystem/UpdatePaintSystemHandler.cs`

| Concern | Method | Rule |
|---|---|---|
| Paint System level | `GetPaintSystemLevelId(irType)` | `Adaption (800000001)` → `PaintSystemLevels.Adapted`; `Industrialization (800000000)` → `PaintSystemLevels.Industrialized`; otherwise `null` |
| Conversion eligibility | `DetermineConversionEligibility(product)` | `true` only when `product.ParentProductId != null && product.IsPrimaryDerivedProduct == true` |

Mutation: `Formula_UpdatePaintSystem`.

> **Divergence (confirmed, intentional or not — treat as real):** update uses a *different and
> simpler* conversion rule than create (`ConversionEligibilityValidationHelper`). It has no
> `RelestProtect` block and no `Salcomix` allowance. Do not unify without a PBI.

---

## 7. Other paint system operations

| Operation | Handler | GraphQL |
|---|---|---|
| Not feasible | `CreateNotFeasiblePaintSystemHandler` — pure pass-through to `_service.CreateNotFeasiblePaintSystem(request.Request)` | `Formula_CreateNotFeasiblePaintSystem` |
| Publish | `PublishPaintSystem/PublishPaintSystemHandler.cs` (+ `PaintSystemPublishData`, `FormulaComponents`) | see handler |
| Update formula + components | `UpdateFormulaWithComponents/UpdateFormulaWithComponentsHandler.cs` | `ComplexUpdate_UpdateFormulaWithComponents` (ComplexUpdate client) |
| Create formula + components | — | `Formula_CreateFormulaWithComponents` |
| Technical remarks | `CreateTechnicalRemarkRequest/CreateTechnicalRemarkHandler.cs` | `Formula_CreateTechnicalRemarks`, `Formula_CreateTechnicalRemarksForDerivedProductAllowed`, `Formula_CheckTechnicalRemarkExist`, `Formula_CheckNonStandardTechnicalRemarkExist` |
| Link derived products | `LinkDerivedProductsAsyncHandler` → `IPaintSystemCommandService.LinkDerivedProductsAsync(technicalRemarkId, productIds)` | mutation in `PaintSystemCommandService` |
| Get by id | `Queries/GetPaintSystemById/` (+ `GetPaintSystemByIdMapper`) | `Formula_GetPaintSystemById` |
| List | `Queries/GetPaintSystemList/` | `Formula_GetPaintSystemByIsActive` |
| Measurements | `Queries/GetMeasurementsByPaintSystemId/` | `Formula_GetMeasurementByPSId` |

---

## 8. Formula and ColorImitation creation — when?

| Record | Created where | Condition |
|---|---|---|
| PaintSystem | `Formula_CreatePaintSystem` (step 9) | always |
| ColorImitation | nested in the same mutation via `BuildColorImitations` | `ColorId != Guid.Empty` (and `CreateLinkedRecords` flows into the input) |
| Color | `IPaintSystemCommandService.CreateColor` (step 10) | `RequiresLinkedRecords == true` |
| Formula + components | **separate endpoint** `Formula_CreateFormulaWithComponents` / `ComplexUpdate_UpdateFormulaWithComponents` | not part of `CreatePaintSystemHandler` |

NOT CONFIRMED: whether an initial empty Formula record is expected to be created as part of
Paint System creation. No such call exists in `CreatePaintSystemHandler`.
