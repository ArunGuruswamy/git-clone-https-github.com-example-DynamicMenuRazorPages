# ARCHITECTURE-SUMMARY

Concise onboarding summary for a developer or Copilot agent working on `AN.ColorAppsAzure.BL`.

Read this first. Then open only the detailed document relevant to the PBI.

---

## What this repository is

An Azure Functions (isolated worker, .NET 10) backend named **Formula Service**.
It exposes HTTP endpoints for the Color Apps DAB/Formula domain and reads/writes data
through **GraphQL** (Data API Builder style endpoints) using **StrawberryShake** generated clients.

Solution file: `AN.ColorAppsAzure.BL.sln`
Default integration branch: `origin/develop` (`origin/HEAD -> origin/develop`).

---

## Projects (evidence: `get_projects_in_solution`)

| Project | Path | Responsibility |
|---|---|---|
| Function | `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Function` | HTTP endpoints, middleware, DI host (`Program.cs`) |
| Application | `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Application` | Commands, queries, handlers, validators, helpers |
| Data | `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Data` | GraphQL query/command services, generated clients, cache |
| Common | `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Common` | `Constants`, `EnvConfig`, `ApiResponse<T>`, `ErrorCode`, extensions |
| Tests | `src/AN.ColorAppsAzure.Formula.Tests/*` | 4 MSTest projects, one per production project |

Dependency direction: **Function → Application → Data → Common**. Never upward.

---

## Core pattern (10 second version)

```
HTTP (Azure Function)
  -> IDispatcher.Send(command) / IDispatcher.Query(query)
	-> ICommandHandler<T,R> / IQueryHandler<T,R>      (Application)
	  -> IValidator<T> (FluentValidation, inside handler)
	  -> I*QueryService / I*CommandService            (Data)
		-> StrawberryShake generated GraphQL client
  -> req.CreateSuccessResponse(result, message)  => ApiResponse<T>
```

`Dispatcher` (`Application/Shared/Abstractions/Dispatching/Dispatcher.cs`) resolves handlers
from `IServiceProvider` by constructing the closed generic handler type at runtime.
Handlers are auto-registered in `Program.cs` by assembly scan of types ending in `Handler`.

---

## Facts you must not get wrong

1. **Paint systems are always created with status `Incomplete`.**
   `CreatePaintSystemHandler.ResolveInitialPaintSystemStatusId()` reads
   `CacheKeys.PaintSystemStatusKey` / `PaintSystemStatuses.Incomplete`. No request type overrides it.
2. **Creating a Paint System sets the linked Imitation Request to `InDevelopment`.**
   `CreatePaintSystemImitationRequestStatusUpdater.UpdateAsync`.
3. **Creating an Imitation Request does NOT create a Paint System.**
   `CreateImitationRequestHandler` only validates and calls `_service.CreateImitationRequest`.
4. **Selected `ProductId` is not always the Paint System `ProductId`.**
   `CreateImitationRequestValidator.ResolvePaintSystemProductIdAsync` uses `ParentProductId`
   when `IsPrimaryDerivedProduct == true`.
5. **`LocalGlobalId` lives on ImitationRequest, not PaintSystem.** GraphQL filters reach it via
   `imitationRequest.LocalGlobalId`.
6. **Versioning is per imitation request type.** See `VersioningHelper.ComputeNextVersion`.
   There is no single universal rule.
7. **Generated StrawberryShake clients are committed to git.** Changing a `.graphql` file changes
   `*.Client.cs` and can break `ExecuteAsync` signatures in production code *and* test mocks.

---

## Document index

Open only what you need.

| Document | Use when |
|---|---|
| [SYSTEM-ARCHITECTURE.md](./SYSTEM-ARCHITECTURE.md) | Project/layer map, DI, middleware, startup |
| [CQRS-FLOW.md](./CQRS-FLOW.md) | Adding an endpoint, command, query or handler |
| [IMITATION-REQUEST-FLOW.md](./IMITATION-REQUEST-FLOW.md) | IR creation/update, request types, validation |
| [PAINT-SYSTEM-FLOW.md](./PAINT-SYSTEM-FLOW.md) | Paint System create/update/publish |
| [DATA-ACCESS-GRAPHQL.md](./DATA-ACCESS-GRAPHQL.md) | GraphQL/DAB/CDMS/cache, schema changes |
| [PRODUCT-DERIVATION-RULES.md](./PRODUCT-DERIVATION-RULES.md) | Anything touching ProductId/parent/derived |
| [STATUS-AND-VERSIONING.md](./STATUS-AND-VERSIONING.md) | Version numbers or status transitions |
| [TESTING-ARCHITECTURE.md](./TESTING-ARCHITECTURE.md) | Writing or fixing tests |
| [ARCHITECTURE-DECISION-MAP.md](./ARCHITECTURE-DECISION-MAP.md) | "Where does rule X live?" |
| [PBI-DEVELOPMENT-PLAYBOOK.md](./PBI-DEVELOPMENT-PLAYBOOK.md) | Starting any PBI |
| [MERGE-SAFETY-CHECKLIST.md](./MERGE-SAFETY-CHECKLIST.md) | Before PR / after rebase |
| [OPEN-QUESTIONS.md](./OPEN-QUESTIONS.md) | Something is not provable from code |
| [ANTI-HALLUCINATION-RULES.md](./ANTI-HALLUCINATION-RULES.md) | Always |

---

## Build & test

```powershell
dotnet build AN.ColorAppsAzure.BL.sln
dotnet test AN.ColorAppsAzure.BL.sln --settings coverlet.runsettings --collect:"XPlat Code Coverage"
```

`coverlet.runsettings` exists at repository root. SonarCloud pipeline: `deployments/sonarcloud.yaml`.
All C# must satisfy `.github/instructions/sonar-rules.instructions.md`.
