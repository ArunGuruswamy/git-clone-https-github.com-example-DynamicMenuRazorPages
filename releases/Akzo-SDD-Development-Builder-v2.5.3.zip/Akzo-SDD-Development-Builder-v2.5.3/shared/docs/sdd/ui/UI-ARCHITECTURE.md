# UI Architecture: `AN.ColorAppsAzure.UI`

Evidence: repository snapshot of 2026-10-07 (`package.json`, `angular.json`, `jest.config.js`, `.github/*`, `projects/**`). Re-verify versions on the integration branch before relying on them.

## 1. Stack
| Concern | Choice |
|---|---|
| Framework | Angular **21.2** (CLI 21), standalone components, OnPush, zoneless-ready |
| State | `@ngrx/signals` Signal Store (21), plus local `signal()` / `computed()`; classic `@ngrx/store` is present but not the pattern for new code |
| UI kit | Angular Material 21 + `@akzonobel-design/an.designsystems.ui` (`Banner`, `Table`, …) |
| Grid / charts | `ag-grid-angular` 35, `chart.js` 4 + `ng2-charts` |
| Auth | `@azure/msal-angular` 5 (`MsalGuard` on dashboard children, `roleGuard` with `route.data.roles`) |
| i18n | `@ngx-translate` 17, feature files `assets/translations/<lang>/<Feature>-<lang>.json` (`ImitationRequest`, `PaintSystem`) + instrument SDK i18n |
| Instruments | `@akzonobel/instrumenthub-sdk` 4.6 + `-extensions` |
| Tests | Jest 30 + `jest-preset-angular` 16, jsdom; coverage collected for `shared-external-libs/src/lib/components/**` and `formulas/src/components/**` only |
| Lint / format | ESLint 10 + angular-eslint, Prettier 3, Stylelint (SCSS) |
| CI | `buildUI.yaml` (Azure DevOps): build → deploy Dev/Test/Acc/Prod to Azure Web App |
| Runtime config | `globalThis.env` (`environmentName`, `clientId`, `authority`, `redirectUri`, `apiScope`, `azureFunctionKey`, `colorAppsBaseUrl`, `codBaseApiUri`) |
| Copilot | `.github/copilot-instructions.md`, 8 agents (create-component, create-feature, api-service, form-validation, generate-jest-tests, refactor-signals, migrate-zoneless, optimize-performance), skill `angular-testing-with-jest`, Angular CLI MCP (`.vscode/mcp.json`, read-only) |

## 2. Workspace projects (`angular.json`)
| Project | Type | Role |
|---|---|---|
| `dashboard` | app | Shell: MSAL, header menu, home, search, settings, `view-list`; lazy-loads every other area |
| `formulas` | app/area | `FormulaAppStepper`: 3 steps (**Imitation Request → Formula and Measurement → Paint System**), `color-imitation`, `post-paint-system-actions`, generic `:formName` forms |
| `shared-external-libs` | lib | Feature components shared across apps: IR create/update, Paint System create/update, derived paint systems, formula components & toners, measurements (take, coordinates, reflection curve, texture…), primers, technical remarks, view-list, common dialogs |
| `shared-libs` | lib | Cross-cutting: environment, auth/guards, interceptors, generic form builder, inputs (select, autocomplete with pagination, date picker, radio), footer, banner, enums (permissions, lookup keys, view params), `ApiResponse<T>` |
| `market-color`, `products-info`, `documentation` | area | Screens lazy-loaded by `dashboard`; currently **no backend calls** |

## 3. Patterns to copy (do not invent new ones)
| Need | Copy from |
|---|---|
| Feature with create + update + shared base | `shared-external-libs/.../create-update-paint-system/{base-paint-system,create-paint-system,update-paint-system,shared/{services,store,interfaces}}` |
| Signal Store with load/submit status | `technical-remarks/shared/store/technical-remarks-dialog.store.ts`, `derived-paint-systems/shared/store/derived-paint-system.store.ts` |
| Dialog feature | `technical-remarks/technical-remarks-dialog` (spec + plan in `docs/technical-remarks/`) |
| Simple master-data create form | **JSON config** in `shared-external-libs/src/lib/assets/public/<Form>.json` + `GenericFormBuilder` (`:formName` route); no new component |
| List with delete / deactivate | `view-list` + backend `shared/viewlist` + `{Entity}/GetAll|Delete|Deactivate` |
| Lookups / option sets | `*-lookup.service.ts`, `*-option-sets.service.ts`, `LookupApiKey`, `LookupItemKey` |
| Stepper behaviour | `formulas/.../formula-app-stepper/services/*` (navigation, button state, banner, loading, overlay) |
| Permissions | `shared-libs/src/lib/enums/*-permissions.enum.ts` (e.g. `ColorApps.PaintSystem.Create`) + `roleGuard` / `AuthService.hasRole` |
| Notifications | `shared-libs/src/lib/services/snackbar-notification.service.ts`, `common/dialog-{confirmation,error,info,logs}` |

## 4. Coding rules (from `.github/copilot-instructions.md`)
- Standalone components (do not write `standalone: true`), `ChangeDetectionStrategy.OnPush`, `input()`/`output()`, `inject()`, signals and `computed()`, native control flow `@if/@for/@switch`, `@let`.
- No `@HostBinding`/`@HostListener` (use `host`), no `ngClass`/`ngStyle`, no `mutate`, no method calls in templates.
- Reactive forms. Typed models; no `any`; no `as unknown as` in tests.
- Signal Store: typed state interface, `patchState`, computed for derived data.
- Styles: no `::ng-deep`, no `!important`.

## 5. Existing SDD-style docs in the repo
`docs/technical-remarks/{create,read,update}-technical-remarks-{spec,plan}.md`: the team already writes spec + plan pairs (FR-nn, scenarios, data models, API contracts, AC, tasks).
**v2 rule:** for a UI-only PBI, keep this convention (`docs/<feature>/<op>-<feature>-{spec,plan}.md`). For a cross-repo PBI, the master change folder lives in the backend repo and the UI gets `ui-plan.md` under `docs/sdd/changes/<PBI>/`.

## 6. Known risks / findings
1. `PaintSytem/Create` vs `PaintSystem/Create` route spelling (see `UI-API-MAP.md`).
2. Jest `testMatch` / coverage include only `shared-external-libs` components and `formulas` components. Tests written elsewhere are **not run** unless `jest.config.js` is extended: 41 spec files in the snapshot (`shared-libs` 11, `products-info` 10, `documentation` 8, `market-color` 5, `dashboard` 5, others 2). `ng test` uses the same config. Plan for this when a PBI touches those projects.
3. README is the CLI default (mentions Angular 20 and `ng e2e`). It does not describe the real setup.
4. `DEFAULT_OWNER_ID` constant is marked "remove after OUAM integration". Do not build new features on it.
