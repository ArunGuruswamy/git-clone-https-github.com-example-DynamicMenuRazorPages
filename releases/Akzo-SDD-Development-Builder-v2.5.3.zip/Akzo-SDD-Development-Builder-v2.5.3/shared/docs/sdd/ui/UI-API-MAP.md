# UI → Backend API Map (`AN.ColorAppsAzure.UI`)

Generated from the repository snapshot supplied on 2026-10-07. The agent re-verifies it during INVENTORY. Treat it as an index, not as truth.

## How the UI reaches the backends

```
Browser (Angular 21, MSAL)
   │  Authorization: Bearer <token for apiScope>   (MSAL interceptor)
   ▼
colorAppsBaseUrl  ── globalThis.env.colorAppsBaseUrl (runtime env, not compiled)
   │
   ▼
DAB Formula Function App  (AN.ColorAppsAzure.BL)
   ├─ local route  → Function → IDispatcher → Handler → GraphQL (DAB)
   └─ RoutingMiddleware (FeatureFlags_Cdms = on, route not excluded)
          → forwards raw request → CDMS Function App (AN.ColorAppsAzure.BL.ColorDMS) → XRM/Dataverse
```

**Consequence:** the UI and UX are identical whichever backend serves a route. Any CDMS or DAB route change must keep the contract below (constitution Art. 5).

Base URL helpers: `projects/shared-libs/src/lib/environment/environment.service.ts`

| Helper | Value |
|---|---|
| `colorAppsBaseUrl` | `${env.colorAppsBaseUrl}` |
| `imitationRequestUrl` | `${colorAppsBaseUrl}/ImitationRequest/` |
| `paintSystemUrl` | `${colorAppsBaseUrl}/PaintSystem/` |
| `lookUpUrl` | `${colorAppsBaseUrl}/lookup/` |
| `measurementUrl` | `${colorAppsBaseUrl}/Measurement/` |
| `optionSetUrl` | `${colorAppsBaseUrl}/optionset/getall` |

Common envelope (where typed): `shared-libs/src/lib/interfaces/api-response.interface.ts` → `ApiResponse<T> { success: boolean; message: string; data: T; error: string | null }`.

## Endpoint inventory

Paths are relative to `projects/shared-external-libs/src/lib/components/` unless noted.

### Imitation Request
| Verb | Route | Service › method | Response type |
|---|---|---|---|
| POST | `ImitationRequest/Create` | `create-update-imitation-request/shared/services/create-update-imitation-request-service.ts` › `createImitationRequest` | `ImitationRequestResponse` |
| PUT | `ImitationRequest/Update` | same › `updateImitationRequest` | `ImitationRequestResponse` |
| GET | `ImitationRequest/GetById?id=` | same › `getById` | `ImitationRequestDataById` |
| PUT | `ImitationRequest/Deactivate` | same › `deActivate` | `ImitationRequestDeleteDeactivateResponse` |
| DELETE | `ImitationRequest/Delete` | same › `delete` | `ImitationRequestDeleteDeactivateResponse` |
| GET | `ImitationRequest/SearchImitationRequest` | `create-update-paint-system/shared/services/paint-system-lookup.service.ts` | — |
| POST | `lookup/GetTSREnabled` | `.../imitation-request-lookup.service.ts` › `getTsrEnabled` | `TsrCheckResponse[]` |
| GET | `lookup/{GetFormulaRegions, GetColorNames, GetTeams, GetSubstrates, SearchMarketColors, GetProducts, GetReferenceColor}` | `.../imitation-request-lookup.service.ts`, `imitation-request-products.service.ts` | `ImitationOptionSetResponse` |
| POST | `optionset/getall` | `.../imitation-request-option-sets.service.ts` › `fetchOptionSets` | `OptionSetResponse` |

### Paint System
| Verb | Route | Service › method | Response type |
|---|---|---|---|
| POST | **`PaintSytem/Create`** ⚠ | `create-update-paint-system/shared/services/create-update-paint-system-service.ts` › `createPaintSystem` | `PaintSystemResponse` |
| GET | `PaintSystem/GetById?id=` | same › `getPaintSystemById` | `PaintSystemData` |
| PUT | `PaintSystem/Update` | same › `updatePaintSystem` | `PaintSystemResponse` |
| PUT | `PaintSystem/Deactivate` | same › `deactivatePaintSystem` | `string` |
| DELETE | `PaintSystem/Delete` | same › `deletePaintSystem` | `string` |
| GET | `PaintSystem/GetImitationRequestForPaintSystem?id=` | same › `getImitationRequestForPaintSystem` | `IrForPaintSystemResponse` |
| GET | `PaintSystem/GetPaintSystemPrimers` | `paint-system-primers/shared/services/paint-system-primers.service.ts` | `GetPaintSystemPrimersResponse[]` |
| GET | `lookup/GetPrimerMarketColor`, `lookup/SearchPrimerMarketColors` | `create-update-paint-system/shared/services/paint-system-lookup.service.ts` | — |
| POST | `optionset/getall` | `.../paint-system-option-sets.service.ts` | `OptionSetResponse` |

> ⚠ **Contract finding to verify:** the UI posts to `PaintSytem/Create` (missing "s"; the spec file asserts the same URL). DAB `CQRS-FLOW.md` documents `Route = "PaintSystem/Create"`. Either CDMS exposes the misspelt route and DAB forwards it, or Create Paint System returns 404 in some environments. Confirm against both backends before any Paint System Create PBI. Fix it in the UI and its spec only with PO/tech-lead agreement.

### Derived Paint Systems
| Verb | Route | Service | Response type |
|---|---|---|---|
| GET | `PaintSystem/DerivedPaintSystem/GetAll` | `derived-paint-systems/shared/services/derived-paint-system.service.ts` | `DerivedPaintSystemApiResponse` |
| GET | `PaintSystem/DerivedPaintSystem/GetById` | same | — |

### Formula & Components
| Verb | Route | Service › method | Response type |
|---|---|---|---|
| POST | `PaintSystem/CreateFormulaWithComponents` | `formula-components/formula-components-service.ts` › `createFormulaComponents` | `FormulaComponentsResponse` |
| GET | `PaintSystem/FormulaComponents/GetAll` | same › `getFormulaComponents` | `GetFormulasResponse` |
| POST | `ProductsInfo/SearchTonerInProducts` | same › `getProductToners` | `TonerInProduct[]` |

### Measurement
| Verb | Route | Service › method | Response type |
|---|---|---|---|
| POST | `Measurement/CreateMeasurement` | `measurements/shared/services/measurement.service.ts` › `createMeasurement` | `CreateMeasurementResult` |
| GET | `Measurement/GetMeasurementsByPaintSystemId?paintSystemId=` | same › `getMeasurementsByPaintSystemId` | `GetMeasurementResponse[]` |
| — | instrument access | `@akzonobel/instrumenthub-sdk` (+ extensions) | — |

### Technical Remarks
| Verb | Route | Service › method | Response type |
|---|---|---|---|
| GET | `StandardTechnicalRemarks` | `technical-remarks/shared/services/technical-remarks.service.ts` › `getStandardRemarks` | `OptionItem[]` |
| GET | `PaintSystem/TechnicalRemarks` | same › `getTechnicalRemarks` | `GetTechnicalRemarksResponse[]` |
| POST | `PaintSystem/TechnicalRemarks` | same › `saveTechnicalRemarks` | `ApiResponse` |
| PUT | `PaintSystem/TechnicalRemarks/Update` | same › `updateTechnicalRemarks` | `ApiResponse` |

### Shared view list & generic forms
| Verb | Route | Service › method | Notes |
|---|---|---|---|
| GET | `shared/viewlist` | `view-list/services/view-list-service.ts` › `fetchViewLists` | list of views per entity type |
| GET | `{viewParam}/GetAll` | same | `viewParam` ∈ `ViewQueryParams` (`ImitationRequest`, `PaintSystem`, `StandardTechnicalRemarks`) |
| PUT | `{viewParam}/Deactivate` | same › `deactivate` | |
| DELETE | `{viewParam}/Delete` | same › `delete` | |
| POST | `{formKey}/Create` | `shared-libs/.../generic-form-builder/services/generic-form-builder.service.ts` › `submitForm` | JSON-driven form (`assets/shared/<form>.json`) |
| GET | `{formKey}/GetById` | same | |

## UI areas with no backend integration yet
`market-color`, `products-info` and `documentation` contain screens (lazy-loaded from `dashboard`) that make **no HTTP calls**: static/design-system tables and forms. A PBI that "connects" one of them needs a new service, interfaces and a store, plus a backend endpoint in the selected backend.
