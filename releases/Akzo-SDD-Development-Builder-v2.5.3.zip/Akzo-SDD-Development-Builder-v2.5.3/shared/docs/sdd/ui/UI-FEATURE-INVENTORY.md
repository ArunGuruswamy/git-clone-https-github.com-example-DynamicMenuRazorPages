# UI Feature Inventory (baseline for PBI comparison)

This is what the UI already does, grouped by domain. The INVENTORY phase starts here and then verifies the details in code.
Status legend: **Live** = wired to backend · **UI-only** = screen without backend calls · **Partial** = some operations wired.

| Domain | Capability | Status | Where |
|---|---|---|---|
| Imitation Request | Create, update, get by id, deactivate, delete | Live | `create-update-imitation-request/{base,create,update}-imitation-request`, store `shared/store/{create,update}-imitation-request-store` |
| | Lookups: formula regions, colour names, teams, substrates, market colours, products, reference colour, TSR-enabled check | Live | `imitation-request-lookup.service.ts`, `imitation-request-products.service.ts` |
| | Option sets | Live | `imitation-request-option-sets.service.ts` |
| | IR step in stepper; IR state | Live | `formulas/src/components/imitation-request` (`imitation-request-state.service.ts`) |
| Paint System | Create, update, get by id, deactivate, delete; IR for paint system | Live (⚠ create route spelling) | `create-update-paint-system/{base,create,update}-paint-system`, store `shared/store/update-paint-system-store` |
| | Primers list + detail dialog; primer market colour search | Live | `paint-system-primers`, `paint-system-lookup.service.ts` |
| | Post-create actions | Live | `formulas/src/components/post-paint-system-actions` |
| Derived Paint Systems | List + detail, layers | Live (GET only) | `derived-paint-systems` (+ `paint-system-layers`), `DerivedPaintSystemStore` |
| Formula | Create formula with components, list components, toners in products search, add/update/display toners | Live | `formula-components`, `add-update-formula-toners/{base,display}-formula-toner` |
| Measurement | Take measurement (instrument SDK), create measurement, list by paint system, coordinates, reflection curve, texture, reference details, result card, details dialog | Live | `measurements/**`, `formula-measurement` |
| Technical Remarks | Standard remarks list; create/read/update remarks per paint system; copy to derived products | Live | `technical-remarks/**` (spec+plan in `docs/technical-remarks/`) |
| Standard Technical Remarks (master data) | Create via generic form; list via view-list | Live | `assets/public/StandardTechnicalRemarks.json`, `view-list` |
| View list | Views per entity; GetAll; delete; deactivate | Live | `view-list/**` (`ViewQueryParams`: IR, PaintSystem, StandardTechnicalRemarks) |
| Generic forms | JSON-driven create / get-by-id | Live | `shared-libs/.../generic-form-builder` (`ImitationRequestMetaWeave`, `PaintSystemMetaWeave`, `InstructionMetaWeave`, `RadarTransperancyMetaWeave`, `StandardTechnicalRemarks`) |
| Colour imitation | Create colour imitation screen | Verify | `formulas/src/components/color-imitation` |
| Market Color | Create / list screens | UI-only | `market-color/src/components/*` |
| Products Info | Products, conversion factors, toners in product (create/list/view) | UI-only | `products-info/src/components/*` |
| Documentation | Documents, paint brands (create/list) | UI-only | `documentation/src/components/*` |
| Shell | MSAL login, unauthorized, home, search, settings, contact-us, header menu | Live (auth) | `dashboard/**` |

## How to use it in a PBI
1. Find the PBI's domain row.
2. **Live** → the PBI is probably a MODIFIED delta. Inventory the store, service and interfaces before planning.
3. **UI-only** → the PBI is probably an ADDED delta: new service, interfaces and store, plus a backend endpoint in the selected backend.
4. Not listed → search the code first (constitution Art. 3). Then mark MISSING with the searches listed.
