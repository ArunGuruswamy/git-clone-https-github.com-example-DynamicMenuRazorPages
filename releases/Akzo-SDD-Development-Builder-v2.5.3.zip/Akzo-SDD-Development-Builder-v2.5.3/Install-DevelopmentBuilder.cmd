@echo off
setlocal EnableExtensions
rem One-command installer/updater for the trusted Akzo SDD Builder v2.5.3.
rem Removes the need for manual Unblock-File steps under RemoteSigned.
rem Never bypasses AllSigned or Restricted policy or requests administrator privileges.
rem Usage: Install-DevelopmentBuilder.cmd DAB "C:\path\to\DAB" Both
set "SDD_BUILDER_ROOT=%~dp0"
set "SDD_TARGET=%~1"
set "SDD_DESTINATION=%~2"
set "SDD_MODE=%~3"
set "SDD_CDMS_REPO=%~4"
set "SDD_DAB_REPO=%~5"
set "SDD_UI_REPO=%~6"
rem Optional: set SDD_TOOL_PROFILE=Unrestricted before running, for Visual Studio 2026 agents without edit/terminal tools.
if "%SDD_TARGET%"=="" goto usage
if "%SDD_DESTINATION%"=="" goto usage

echo.
echo Akzo SDD Builder v2.5.3 - safe automatic installation / upgrade
powershell.exe -NoLogo -NoProfile -Command "$ErrorActionPreference='Stop'; try { $effective=Get-ExecutionPolicy; if ($effective -in @('AllSigned','Restricted')) { throw ('PowerShell policy is ' + $effective + '. Request an IT-signed package. No policy bypass attempted.') }; $root=$env:SDD_BUILDER_ROOT; $installer=Join-Path $root 'Install-DevelopmentBuilder.ps1'; if (!(Test-Path -LiteralPath $installer -PathType Leaf)) { throw ('Installer missing: '+$installer) }; if ($effective -eq 'RemoteSigned') { Get-ChildItem -LiteralPath $root -Recurse -File | Where-Object { $_.Extension -in @('.ps1','.psm1','.cmd') } | Unblock-File -ErrorAction Stop }; $params=@{Target=$env:SDD_TARGET;Destination=$env:SDD_DESTINATION;Mode=$(if ($env:SDD_MODE) {$env:SDD_MODE} else {'Both'});UpdateExisting=$true;TrackInstalledFiles=$false;PruneLegacy=$true;LocalOnlyMode=$true}; if ($env:SDD_TEAM_UPDATE -eq '1') {$params.LocalOnlyMode=$false;$params.TrackInstalledFiles=$true}; if ($env:SDD_TOOL_PROFILE) {$params.ToolProfile=$env:SDD_TOOL_PROFILE}; if ($env:SDD_CDMS_REPO) {$params.CdmsRepo=$env:SDD_CDMS_REPO}; if ($env:SDD_DAB_REPO) {$params.DabRepo=$env:SDD_DAB_REPO}; if ($env:SDD_UI_REPO) {$params.UiRepo=$env:SDD_UI_REPO}; & $installer @params; if (-not $?) {exit 1}; $tools=Join-Path $env:SDD_DESTINATION 'tools'; if ($effective -eq 'RemoteSigned' -and (Test-Path -LiteralPath $tools)) { Get-ChildItem -LiteralPath $tools -File | Where-Object { $_.Extension -in @('.ps1','.psm1','.cmd') } | Unblock-File }; Write-Host 'SDD upgrade completed. Review Git status before committing.' -ForegroundColor Green } catch { Write-Host $_ -ForegroundColor Red; exit 1 }"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo Installer failed with exit code %RC%.
  exit /b %RC%
)
exit /b 0

:usage
echo Usage:
echo   Install-DevelopmentBuilder.cmd DAB "C:\path\to\AN.ColorAppsAzure.BL" Both
echo   Install-DevelopmentBuilder.cmd CDMS "C:\path\to\ColorDMS" Both
echo   Install-DevelopmentBuilder.cmd UI "C:\path\to\UI" Both "C:\path\to\CDMS" "C:\path\to\DAB" "C:\path\to\UI"
exit /b 2
