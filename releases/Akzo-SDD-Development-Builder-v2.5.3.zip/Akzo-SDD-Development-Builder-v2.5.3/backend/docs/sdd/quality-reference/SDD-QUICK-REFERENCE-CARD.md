# SDD Development Agent - Quick Reference Card

**Print this. Keep this at your desk. Reference daily.**

---

## THE 10 CORE SKILLS (Ranked by Frequency)

### ⭐⭐⭐ MOST USED (Apply to 80% of code)

**#7: Null-Safety (`.`? `??`)**
```csharp
responseBody?.Trim().Trim('"')              // Null-conditional
entity.cdms_MeasurementData ?? string.Empty // Null-coalesce
```
**When**: Object might be null
**How**: Use `?.` and `??` operators
**Sonar**: Prevents NullReferenceException

**#6: Async ConfigureAwait**
```csharp
await HttpClient.PostAsync(...).ConfigureAwait(false)
```
**When**: Every `await` in library code
**How**: Add `.ConfigureAwait(false)`
**Sonar**: Prevents deadlock in .NET Framework

**#2: Unused Variables (Discard)**
```csharp
if (!TryGetService(out _, out var error))  // Use _ not unused var
```
**When**: Variable declared but not used
**How**: Replace `out var X` with `out _`
**Sonar**: Removes code smell, clarifies intent

---

### ⭐⭐ OFTEN USED (Apply to 40% of code)

**#1: Complexity Reduction (Extract Methods)**
```csharp
// Main method: Orchestration only
public async Task<Result> MainAsync()
{
	var data = await HelperAsync();  // Just calls helpers
	return Process(data);             // Orchestration logic
}

// Extracted method: One concern only
protected virtual async Task<string> HelperAsync() { ... }

// Extracted: Business logic
private bool IsErrorType(string msg, string term) { ... }
```
**When**: Sonar says Complexity > 10
**How**: Extract to 3-4 separate methods
**Target**: < 10 branches per method

**#9: String Comparison (OrdinalIgnoreCase)**
```csharp
message?.IndexOf("Duplicate", StringComparison.OrdinalIgnoreCase) >= 0
```
**When**: Case-insensitive search
**How**: Use `OrdinalIgnoreCase` + `>= 0` check
**Why**: Culture-invariant, consistent across systems

**#8: Exception Filtering (Fatal Exceptions)**
```csharp
catch (Exception ex) when (!(
	ex is OutOfMemoryException 
	|| ex is StackOverflowException 
	|| ex is ThreadAbortException
))
{
	return ErrorResponse(ex.Message);  // Only handle safe exceptions
}
```
**When**: Catching broad Exception
**How**: Add `when` clause to filter fatal ones
**Why**: Fatal exceptions must propagate to restart process

---

### ⭐ SOMETIMES USED (Apply to 20% of code)

**#5: Virtual Methods for Testing**
```csharp
// Production class with virtual method
protected virtual async Task<string> PostAsync(string endpoint, string data)
{
	// Real implementation
}

// Test class overrides for mocking
internal class TestService : Service
{
	private Func<string, string, Task<string>> _mock;

	protected override async Task<string> PostAsync(string e, string d)
	{
		return await _mock(e, d);  // Use mock, not real HTTP
	}
}
```
**When**: Need to mock HTTP, Database, external service
**How**: Create `protected virtual` method
**Benefit**: Zero production code changes for testability

**#10: Using Statements (Resource Disposal)**
```csharp
using (var content = new StringContent(data))
using (var response = await HttpClient.PostAsync(...).ConfigureAwait(false))
{
	// ...
}
// Resources guaranteed disposed here
```
**When**: HttpClient, streams, database connections
**How**: Wrap in `using` statement
**Why**: Prevents resource leaks, enables connection pooling

**#3: Test Coverage (100% Branches)**
```csharp
// Before: 37.5% coverage
[TestMethod] public async Task Method_Success() { ... }

// After: 100% coverage - 7 new tests
[TestMethod] public async Task Method_HttpErrorNoBody() { ... }
[TestMethod] public async Task Method_HttpErrorWithBody() { ... }
[TestMethod] public async Task Method_HttpSuccessValidGuid() { ... }
[TestMethod] public async Task Method_HttpSuccessInvalidGuid() { ... }
[TestMethod] public async Task Method_HttpSuccessNullResponse() { ... }
[TestMethod] public async Task Method_DuplicateException() { ... }
[TestMethod] public async Task Method_GenericException() { ... }
```
**When**: Sonar shows uncovered branches (8 lines, 7 conditions)
**How**: Identify each branch, add test case
**Target**: 100% coverage on new code

**#4: Null Validation (Upfront)**
```csharp
// Validate early
if (entity == null)
	return FailureResponse("Entity cannot be null");

if (string.IsNullOrWhiteSpace(error))
	error = Constants.ErrorMessages.DefaultError;
```
**When**: Receiving parameters or parsing input
**How**: Check early, return early
**Why**: Prevents cascading null errors

---

## 🎯 BY SCENARIO - "What do I do when...?"

| Scenario | Skill | Fix |
|----------|-------|-----|
| Sonar: Complexity > 10 | #1 | Extract methods |
| Sonar: Coverage < 100% | #3 | Add test cases |
| Sonar: Unused variable | #2 | Use `out _` |
| Code: Object might be null | #7 | Use `?.` or `??` |
| Code: Calling async | #6 | Add `.ConfigureAwait(false)` |
| Code: Catching Exception | #8 | Add `when (!(OutOfMemory...))` filter |
| Code: String search | #9 | Use `OrdinalIgnoreCase` |
| Code: HTTP/Database call | #5 | Create `protected virtual` method |
| Code: Opening HttpResponse | #10 | Wrap in `using` statement |
| Code: Parameter check | #4 | Validate upfront |

---

## ✅ PRE-COMMIT CHECKLIST (60 SECONDS)

Before running `git commit`:

```
☐ Method complexity < 10 (check: max nesting = 2-3 levels)
☐ All lines covered (check: Sonar coverage = 100%)
☐ No unused variables (check: all `out var X` used or changed to `out _`)
☐ Null-safe access (check: no `obj.Method()` without `?.`)
☐ ConfigureAwait(false) (check: all `await` have it)
☐ Fatal exceptions filtered (check: catch has `when (!(...)`) filter
☐ Tests for all paths (check: success, error, null, empty cases)
☐ Using statements present (check: HttpClient, streams, connections)
☐ No magic strings (check: use Constants class)
☐ Build successful (run: dotnet build)
```

---

## 🚨 3 COMMON MISTAKES

❌ **Mistake 1**: Forgetting ConfigureAwait(false)
```csharp
// WRONG: Can deadlock in .NET Framework
var x = await HttpClient.PostAsync(...);

// CORRECT:
var x = await HttpClient.PostAsync(...).ConfigureAwait(false);
```

❌ **Mistake 2**: Catching without filtering fatal exceptions
```csharp
// WRONG: Swallows OutOfMemoryException
catch (Exception ex) { ... }

// CORRECT:
catch (Exception ex) when (!(ex is OutOfMemoryException 
	|| ex is StackOverflowException 
	|| ex is ThreadAbortException))
{ ... }
```

❌ **Mistake 3**: Adding test code to production
```csharp
// WRONG: Production bloated with test checks
public class Service
{
	internal HttpClient TestClient { get; set; }  // ← BAD

	public async Task Work()
	{
		var client = TestClient ?? _httpClient;   // ← BAD
	}
}

// CORRECT: Override virtual method in test
public class Service
{
	protected virtual async Task<string> PostAsync(...) { ... }
}

internal class TestService : Service
{
	protected override async Task<string> PostAsync(...) 
	{ 
		return await mockFunc(...);  // Clean, no production code changes
	}
}
```

---

## 📊 SONAR RULES (What Each Flag Means)

| Flag | Severity | Fix Time | Solution |
|------|----------|----------|----------|
| Complexity > 10 | 🔴 Major | 30 min | Extract methods (#1) |
| Coverage < 100% | 🔴 Major | 45 min | Add tests (#3) |
| Unused variable | 🟡 Minor | 2 min | Use `out _` (#2) |
| Null pointer risk | 🟠 Medium | 5 min | Use `?.` (#4, #7) |
| Missing await | 🔴 Major | 5 min | Fix typo in method name |
| Broad exception | 🟡 Minor | 5 min | Add `when` filter (#8) |
| No ConfigureAwait | 🟠 Medium | 2 min | Add `.ConfigureAwait(false)` (#6) |
| Case-sensitive search | 🟡 Minor | 5 min | Use `OrdinalIgnoreCase` (#9) |

---

## 🔧 COPY-PASTE CODE TEMPLATES

### Template 1: Method with Test Override
```csharp
// Production class
public class ServiceClass
{
	protected virtual async Task<string> PostAsync(string endpoint, string data)
	{
		using (var content = new StringContent(data, Encoding.UTF8, "application/json"))
		using (var response = await HttpClient.PostAsync(new Uri(endpoint), content).ConfigureAwait(false))
		{
			var body = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
			if (!response.IsSuccessStatusCode)
				throw new HttpRequestException(string.IsNullOrWhiteSpace(body) 
					? $"{(int)response.StatusCode}" 
					: body);
			return body;
		}
	}
}

// Test class
internal sealed class TestServiceClass : ServiceClass
{
	private readonly Func<string, string, Task<string>> _postFunc;

	public TestServiceClass(Func<string, string, Task<string>> postFunc = null)
	{
		_postFunc = postFunc;
	}

	protected override Task<string> PostAsync(string endpoint, string data)
	{
		if (_postFunc != null)
			return _postFunc(endpoint, data);
		return base.PostAsync(endpoint, data);
	}
}
```

### Template 2: Exception Filtering
```csharp
try
{
	// Code that might throw
}
catch (Exception ex) when (!(
	ex is OutOfMemoryException
	|| ex is StackOverflowException
	|| ex is ThreadAbortException
))
{
	return ErrorResponse(ex.Message);
}
```

### Template 3: Safe String Search
```csharp
private static bool IsErrorMessage(string message, string searchTerm)
{
	return message?.IndexOf(searchTerm, StringComparison.OrdinalIgnoreCase) >= 0;
}

// Usage:
if (IsErrorMessage(ex.Message, "Duplicate Record"))
{
	// Handle duplicate
}
```

### Template 4: Null-Safe HTTP Call
```csharp
using (var content = new StringContent(data ?? string.Empty, Encoding.UTF8, "application/json"))
using (var response = await HttpClient.PostAsync(new Uri(endpoint), content).ConfigureAwait(false))
{
	var responseBody = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
	var result = responseBody?.Trim().Trim('"');  // Null-safe trim
	Guid.TryParse(result, out var createdId);     // Safe parse
}
```

---

## 📚 QUICK LINKS

| Topic | Document |
|-------|----------|
| **Overview of all 10 skills** | SDD-SKILLS-MASTER-LIST.md |
| **Understanding the "why"** | SDD-AGENT-SKILLS.md |
| **Before/after code patterns** | SDD-BEFORE-AFTER-PATTERNS.md |
| **Step-by-step guides** | SDD-IMPLEMENTATION-CHECKLIST.md |
| **Full documentation index** | SDD-DOCUMENTATION-INDEX.md |

---

## ⏱️ TIME ESTIMATES

| Task | Beginner | Senior | With Automation |
|------|----------|--------|-----------------|
| Fix complexity > 10 | 45 min | 20 min | 10 min |
| Achieve 100% coverage | 60 min | 30 min | 15 min |
| Review 500 lines for standards | 60 min | 15 min | 5 min |
| Setup test infrastructure | 90 min | 30 min | 15 min |

---

## 🎓 LEARNING PROGRESSION

**Week 1**: Master #2, #4, #7, #9, #10 (The Easy Ones)  
**Week 2**: Master #6, #8 (The Important Ones)  
**Week 3**: Master #1, #5, #3 (The Advanced Ones)  
**Week 4**: Apply all to real code + Review PRs

---

**Print this card. Reference daily. Master in one month. Change your code quality forever.**

Version: 1.0  |  Updated: Current Session  |  Status: ✅ Ready

