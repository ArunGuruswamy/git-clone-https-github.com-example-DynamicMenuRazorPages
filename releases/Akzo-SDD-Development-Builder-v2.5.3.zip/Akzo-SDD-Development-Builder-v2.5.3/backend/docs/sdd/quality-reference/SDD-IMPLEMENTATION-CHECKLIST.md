# SDD Development Agent - Implementation Checklist

## Quick Reference: Apply These Standards to New Code

### BEFORE YOU CODE - Quality Checklist

- [ ] Does the method have > 10 cyclomatic complexity? → Extract helpers
- [ ] Are there unused `out var` parameters? → Replace with `out _`
- [ ] Will HTTP calls be needed? → Make POST virtual for testing
- [ ] Does code access objects that might be null? → Use `?.` operator
- [ ] Are there hardcoded exception messages? → Move to Constants
- [ ] Do you catch broad Exception? → Filter fatal exceptions
- [ ] Is this async code? → Add `.ConfigureAwait(false)`
- [ ] Are you using HttpClient? → Use static readonly instance
- [ ] Do tests need to mock this method? → Make it protected virtual
- [ ] Is string comparison involved? → Use `StringComparison.OrdinalIgnoreCase`

---

## CODE REVIEW CHECKLIST - Apply to Pull Requests

### Sonar Compliance
- [ ] Complexity per method < 10
- [ ] All branches covered by tests
- [ ] No unused variables (`out _` instead of `out var X`)
- [ ] All critical exceptions handled
- [ ] No magic strings in error messages

### Null Safety
- [ ] Null parameters validated upfront
- [ ] Null-conditional `?.` used for chaining
- [ ] Null-coalesce `??` used for defaults
- [ ] Collection checks before iteration
- [ ] Exception messages safely accessed

### Async Patterns
- [ ] ConfigureAwait(false) on all awaits
- [ ] No sync-over-async (no .Result or .Wait())
- [ ] Exceptions properly propagated (not swallowed)
- [ ] CancellationToken passed when available
- [ ] Timeout configured for Http operations

### Resource Management
- [ ] All disposables in `using` statements
- [ ] HttpClient reused (static or injected)
- [ ] Streams disposed properly
- [ ] Database connections returned to pool
- [ ] Event handlers unsubscribed

### Exception Handling
- [ ] Fatal exceptions filtered out (`OutOfMemoryException`, `StackOverflowException`, `ThreadAbortException`)
- [ ] Inner exceptions preserved
- [ ] Stack traces not lost
- [ ] Specific exceptions caught when possible
- [ ] Error messages include context

### Testability
- [ ] External dependencies virtual or injectable
- [ ] Test harness can override behavior
- [ ] No static state blocking tests
- [ ] Mock functions support async patterns
- [ ] Constructor allows test customization

### Documentation
- [ ] XML docs on all public members
- [ ] Method parameters documented
- [ ] Return values explained
- [ ] Exceptions listed in docs
- [ ] Examples in tests show usage

---

## Test Implementation Checklist

### Coverage Paths to Test

**For HTTP Operations:**
- [ ] Success with valid response
- [ ] Success with invalid response data
- [ ] Success with null/empty response
- [ ] Error with response body (error message)
- [ ] Error without response body (status code)
- [ ] Connection timeout
- [ ] DNS resolution failure

**For Exception Handling:**
- [ ] Specific exception type (duplicate record)
- [ ] Generic exception type
- [ ] Fatal exception (OutOfMemoryException) - verify propagation
- [ ] Exception with null message
- [ ] Exception with empty message

**For Input Validation:**
- [ ] Null entity
- [ ] Invalid entity state
- [ ] Missing required fields
- [ ] Invalid GUID format
- [ ] Invalid URL format

**For CRM Operations:**
- [ ] Connection success
- [ ] Connection failure with error message
- [ ] Connection failure without error message
- [ ] Service request timeout
- [ ] Service authentication failure

### Test Code Quality
- [ ] Arrange-Act-Assert pattern used
- [ ] Each test tests one scenario
- [ ] Mock setup is clear and intentional
- [ ] Assertions are specific (not just IsNotNull)
- [ ] Test names describe expected outcome
- [ ] Tests are independent (no shared state)

---

## Refactoring Pattern: Extract Helper Methods

### When to Extract
1. **Method > 20 lines** → Extract
2. **Cyclomatic complexity > 10** → Extract
3. **Multiple concerns in one method** → Extract each
4. **Code that needs mocking for tests** → Extract as virtual

### How to Extract (Step by Step)

```csharp
// STEP 1: Identify responsibility
public async Task<XrmServiceResponse> CreateMeasurementAsync(cdms_measurement entity)
{
	// Responsibility 1: Validate input
	if (entity == null) { ... }

	// Responsibility 2: Check CRM connectivity
	if (!TryGetService(...)) { ... }

	// Responsibility 3: Call HTTP endpoint ← EXTRACT THIS
	var createdId = await ... HttpClient.PostAsync ...;

	// Responsibility 4: Parse response ← EXTRACT THIS
	Guid.TryParse(...);

	// Responsibility 5: Handle exceptions ← EXTRACT THIS
	catch (Exception ex) { ... IsErrorMessage(...) ... }
}

// STEP 2: Extract HTTP/external dependency as virtual
protected virtual async Task<string> PostMeasurementAsync(string endpoint, string data)
{
	using (var content = new StringContent(data, Encoding.UTF8, "application/json"))
	using (var response = await HttpClient.PostAsync(new Uri(endpoint), content).ConfigureAwait(false))
	{
		var responseBody = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
		if (!response.IsSuccessStatusCode)
		{
			throw new HttpRequestException(string.IsNullOrWhiteSpace(responseBody)
				? $"{(int)response.StatusCode} {response.ReasonPhrase}"
				: responseBody);
		}
		return responseBody;
	}
}

// STEP 3: Extract exception handling logic
private string HandleCreateException(Exception ex)
{
	if (IsErrorMessage(ex.Message, "Duplicate Record Found"))
	{
		return "A measurement already exists for this instrument type. Do you want to overwrite it?";
	}
	return ex.Message;
}

// STEP 4: Extract business logic helper
private static bool IsErrorMessage(string message, string searchTerm)
{
	return message?.IndexOf(searchTerm, StringComparison.OrdinalIgnoreCase) >= 0;
}

// STEP 5: Simplify main method to orchestration
public async Task<XrmServiceResponse> CreateMeasurementAsync(cdms_measurement entity)
{
	if (entity == null) return FailureResponse(Constants.ErrorMessages.EntityCannotBeNull);

	if (!TryGetService(out _, out var serviceError))
		return FailureResponse(serviceError);

	try
	{
		var createdId = await SendMeasurementToServiceAsync(entity);
		return createdId == Guid.Empty 
			? FailureResponse(Constants.ErrorMessages.MeasurementCreationFailed)
			: SuccessResponse(createdId);
	}
	catch (Exception ex)
	{
		return FailureResponse(HandleCreateException(ex), IsErrorMessage(ex.Message, "Duplicate Record Found"));
	}
}

private async Task<Guid> SendMeasurementToServiceAsync(cdms_measurement entity)
{
	var endpoint = $"{_config.ColorMeasurementService.TrimEnd('/')}/api/v2/measurement/SaveColorMeasurement/{entity.cdms_ColorId.Id}";
	var responseBody = await PostMeasurementAsync(endpoint, entity.cdms_MeasurementData ?? string.Empty);
	Guid createdId = Guid.Empty;
	Guid.TryParse(responseBody?.Trim().Trim('"'), out createdId);
	return createdId;
}
```

---

## Sonar Rule Reference

| Sonar Rule ID | Name | Severity | Fix Pattern |
|---|---|---|---|
| S1168 | Empty arrays should be returned instead of null | Minor | Return `new T[0]` not `null` |
| S1541 | Cyclomatic Complexity | Major | Extract methods, reduce nesting |
| S1858 | Deprecated API | Critical | Use recommended replacement |
| S2068 | Credentials should not be hardcoded | Critical | Use configuration/SecureString |
| S2275 | Printf-style format strings | Major | Use string.Format or interpolation |
| S3358 | Ternary operators not required | Minor | Simplify boolean logic |
| S3776 | Cognitive Complexity | Major | Extract methods, reduce nesting |
| S4214 | "P/Invoke" DLL name should not be hard-coded | Critical | Use constants |
| S6968 | Tests should include an assertion | Critical | Add Assert in each test |
| S9104 | Empty namespace should be removed | Minor | Delete or add contents |

---

## Test Mock Pattern reference

```csharp
// Pattern 1: Func<T, Task<T>> for async mock
Func<string, string, Task<string>> mockPostFunc = async (endpoint, data) =>
{
	// Simulate success
	return "{\"id\": \"" + Guid.NewGuid() + "\"}";

	// OR simulate failure
	throw new HttpRequestException("Service unavailable");
};

// Pattern 2: Substitute (NSubstitute) for interface mock
var mockOrg = Substitute.For<IOrganizationService>();
mockOrg.Create(Arg.Any<Entity>()).Returns(Guid.NewGuid());

// Pattern 3: Constructor injection in test class
internal class TestMeasurementCommandService : MeasurementCommandService
{
	private readonly Func<string, string, Task<string>> _postFunc;

	public TestMeasurementCommandService(EnvConfig cfg, ICrmConfigurationService crmCfg, 
		Func<(bool, IOrganizationService, string)> getServiceFunc,
		Func<string, string, Task<string>> postFunc = null)
		: base(cfg, crmCfg) { _postFunc = postFunc; }

	protected override Task<string> PostMeasurementAsync(string endpoint, string data)
		=> _postFunc?.Invoke(endpoint, data) ?? base.PostMeasurementAsync(endpoint, data);
}

// Usage in test:
var service = new TestMeasurementCommandService(config, crmConfig, getServiceFunc, mockPostFunc);
var result = await service.CreateMeasurementAsync(entity);
```

---

## Common Anti-Patterns to Avoid

❌ **Anti-Pattern 1**: Catching broad Exception without filtering fatal ones
```csharp
// WRONG
catch (Exception ex)
{
	// Swallows OutOfMemoryException, StackOverflowException
	return FailureResponse(ex.Message);
}

// CORRECT
catch (Exception ex) when (!(ex is OutOfMemoryException || ex is StackOverflowException || ex is ThreadAbortException))
{
	return FailureResponse(ex.Message);
}
```

❌ **Anti-Pattern 2**: Unused variables
```csharp
// WRONG - 'service' declared but never used
if (!TryGetService(out var service, out var error)) { ... }

// CORRECT - discard operator shows intent
if (!TryGetService(out _, out var error)) { ... }
```

❌ **Anti-Pattern 3**: Forgetting ConfigureAwait in library code
```csharp
// WRONG - Can deadlock in sync calling code
var response = await HttpClient.PostAsync(...);

// CORRECT - Safe for all contexts
var response = await HttpClient.PostAsync(...).ConfigureAwait(false);
```

❌ **Anti-Pattern 4**: Not testing all branches
```csharp
// WRONG - Only tests success path
[TestMethod]
public async Task Create_ValidInput_ReturnsSuccess()
{
	// No tests for: null input, connection failure, invalid response, etc.
}

// CORRECT - Full branch coverage
[TestMethod] public async Task Create_NullInput_ReturnsFailure() { }
[TestMethod] public async Task Create_ConnectionFails_ReturnsFailure() { }
[TestMethod] public async Task Create_InvalidResponse_ReturnsFailure() { }
[TestMethod] public async Task Create_ValidInput_ReturnsSuccess() { }
```

❌ **Anti-Pattern 5**: Modifying production code for tests
```csharp
// WRONG - Production code bloated with test hooks
public class MeasurementCommandService
{
	internal HttpClient TestHttpClient { get; set; } // Added for testing!

	public async Task<XrmServiceResponse> CreateMeasurementAsync(...)
	{
		var client = TestHttpClient ?? HttpClient; // Test check in production!
	}
}

// CORRECT - Virtual method, no production changes
public class MeasurementCommandService
{
	protected virtual async Task<string> PostMeasurementAsync(string endpoint, string data)
	{
		// Production uses actual HTTP
	}
}

internal class TestMeasurementCommandService : MeasurementCommandService
{
	protected override async Task<string> PostMeasurementAsync(string endpoint, string data)
	{
		// Test uses mock
		return await _mockPostFunc(endpoint, data);
	}
}
```

---

## Pre-Commit Checklist

Before committing changes:

- [ ] No Sonar issues (run Sonar locally or in PR)
- [ ] All tests pass locally
- [ ] Code coverage >= 80% (100% for new code)
- [ ] No compiler warnings
- [ ] No unused imports or variables
- [ ] Commit message is clear and descriptive
- [ ] No hardcoded secrets, passwords, or credentials
- [ ] No debug code left in place
- [ ] Documentation updated
- [ ] Code follows team naming conventions
- [ ] No merge conflicts
- [ ] Branch is up to date with main

---

## Resources & Documents

- **Sonar Documentation**: https://docs.sonarqube.org/latest/
- **C# Async Best Practices**: https://docs.microsoft.com/en-us/archive/msdn-magazine/2013/march/async-await-best-practices-in-asynchronous-programming
- **.NET Framework Exception Handling**: https://docs.microsoft.com/en-us/dotnet/standard/exceptions/
- **NSubstitute Documentation**: https://nsubstitute.github.io/
- **Microsoft Secure Coding Guidelines**: https://docs.microsoft.com/en-us/dotnet/standard/security/secure-coding-guidelines

---

**Version**: 1.0  
**Last Updated**: Current Session  
**Applicable To**: All C# projects in ColorDMS solution  
**Compliance Required**: Mandatory for code in feature branches

