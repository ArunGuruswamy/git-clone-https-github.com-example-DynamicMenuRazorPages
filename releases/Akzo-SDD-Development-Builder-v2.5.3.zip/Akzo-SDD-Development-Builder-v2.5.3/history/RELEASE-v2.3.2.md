# v2.3.2 — One-command installer and safe upgrade

Run from extracted package folder:

```powershell
.\Install-DevelopmentBuilder.cmd DAB "C:\Users\RGA\source\repos\AN.ColorAppsAzure.BL" Both
```

The launcher performs approved unblocking under `RemoteSigned`, installs/updates builder files with per-file backups, keeps newly installed SDD assets visible to Git, and backs up only a strict allowlist of obsolete *untracked* launchers. It leaves PBI inputs, specs, plans, changed application code, and tracked legacy files untouched. The installation does not request elevated permissions, change execution policy, or bypass enforced signing policies.

Inspect `git status --short`, then check `tools/Start-SDD.ps1` and `src/.github/specs/`. Before implementation, confirm generated feature `spec.md` and `plan.md` contain completed analysis rather than placeholders.

**Validation boundary:** ZIP integrity and package checks completed in this environment; real Windows execution remains to be verified on the company workstation.
