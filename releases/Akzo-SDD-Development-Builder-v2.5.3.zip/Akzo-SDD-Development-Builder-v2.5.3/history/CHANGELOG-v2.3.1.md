# v2.3.1 — PR Review Prevention + Validator consistency

- Fix validator requiring `analysis.md` while start creates `08-analysis.md`.
- Add PR feedback review register and candidate project checks, explicitly marked unverified without export.
- Add working `pr-review-audit.md`, PR-rule structural validator, and agent requirement before coding.
- Preserve existing SDD phases, approved PBI input, feature-only check-in folders, and approval gate.
- Automated gate tests are structural; not proof of full semantic coverage or PR rule accuracy.
