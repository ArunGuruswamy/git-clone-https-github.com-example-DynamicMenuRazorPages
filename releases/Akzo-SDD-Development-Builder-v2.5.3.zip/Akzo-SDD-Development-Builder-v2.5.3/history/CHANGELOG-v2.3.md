# v2.3.0 — Automated SDD start

- Added `tools/Start-SDD.ps1`: selects one approved refined-PBI Markdown, identifies repository role, persists check-in spec and plan immediately, initializes all working artifacts and state without overwriting existing specs.
- Extended agent and start prompt for zero-manual-import entry; existing phases and approval are preserved.
- Strict validator blocks PENDING published artifacts.
- Installer provisions docs/sdd/pbi-input folder.
- New start/install guide documents RemoteSigned and intended interaction.

**Not validated in Windows runtime:** PowerShell installer and VS Code Copilot agent execution require a real repo pilot. ZIP structure and static checks performed by build step.
