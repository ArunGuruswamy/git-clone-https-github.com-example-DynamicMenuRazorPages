# SDD Builder v2.3.3 — mandatory persisted artifacts

- Added `tools/Assert-SDDArtifacts.ps1` with Draft, AnalysisComplete and Approved stages.
- Both developer agents and start/plan prompts now require actual file writes and a passing artifact gate before claiming analysis complete.
- The gate checks file presence, meaningful content, unresolved placeholders, traceability/plan sections, and reads back SHA256 hashes.
- Approved gate additionally requires an approver and current spec SHA256.
- CMD launcher includes the new tool in RemoteSigned file-unblocking list.
- Stale launcher and sample v2.1.2 paths corrected.
- Existing phase flow, role selection, PBI input, Git layout and explicit approval remain unchanged.

**Scope:** This release does not automate intelligent code analysis itself; the editor-capable Copilot developer agent must execute file edits and commands. The gate prevents premature completion claims when it is followed. The tool cannot force an unrelated/read-only agent to write files.
