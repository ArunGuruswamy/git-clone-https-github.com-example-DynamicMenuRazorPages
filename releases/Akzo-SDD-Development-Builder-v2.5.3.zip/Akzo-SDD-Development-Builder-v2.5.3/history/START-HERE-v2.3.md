# Akzo SDD Builder v2.3.0 — Automated PBI start

## One-time installation (approved package only)

1. Unzip into a new directory, inspect the contents before running any script.
2. On corporate Windows PowerShell with RemoteSigned, use `Install-DevelopmentBuilder.cmd`; its reviewed launcher unblocks only the packaged installer, not the repository and does not weaken your execution policy. If company policy requires AllSigned, obtain a signed installer from IT. Do not use Bypass or Unrestricted.
3. Open PowerShell at extracted folder and run:

```powershell
.\Install-DevelopmentBuilder.cmd DAB "C:\Users\RGA\source\repos\AN.ColorAppsAzure.BL" Both
```

For **existing installation**, the CMD launcher is conservative: it preserves existing customizations by default. To deploy changed prompts/agents, after reviewing diffs in a dedicated branch use:

```powershell
# Only if the script is approved and unblocked under RemoteSigned:
.\Install-DevelopmentBuilder.ps1 -Target DAB -Destination "C:\Users\RGA\source\repos\AN.ColorAppsAzure.BL" -Mode Both -UpdateExisting -TrackInstalledFiles
```

If direct PS1 is blocked under RemoteSigned, inspect and use `Unblock-File .\Install-DevelopmentBuilder.ps1` only after approval; under AllSigned obtain signed scripts instead. This is a one-time administrative step, not part of each SDD run.

**Note:** `-TrackInstalledFiles` prevents newly installed instructions/tools being hidden in `.git/info/exclude`; review any older local exclusions separately before checking in.

## Every new PBI

1. Save approved PBI Builder Markdown in the appropriate checked-out repository:
   `docs/sdd/pbi-input/305183/REFINED-PBI.md`.
2. Open that repository in VS Code, select **Akzo SDD Developer**.
3. Say: **`Start Development 305183 Complaint Imitation Request`**. With exactly one PBI in input, **`Start Development`** is enough.
4. Agent automatically runs `tools/Start-SDD.ps1`, selects primary project role, writes check-in `src/.github/specs/ComplaintImitationRequest/spec.md` and `plan.md`, and completes phases 0-7 with evidence. PBI number belongs *inside* documents, never folder name.
5. Agent stops once for unresolved business decisions or final approval before source edits; this gate is intentional. Then development, tests, review, verify and archive follow existing workflow.

The script bootstraps initial source-backed drafts. The agent must replace every PENDING item with verified source/contract/test details. `Validate-SDD.ps1 -Strict` must pass before code changes. The check-in files must exist on disk; a chat summary never counts.

## Developer-facing troubleshooting

- If the installer says 'file is not digitally signed', check `Get-ExecutionPolicy -List`; under `RemoteSigned` check/download mark and approved `Unblock-File`; no policy bypass.
- If Git-tracked files differ, review installer backups, `git diff`, and your `.git/info/exclude` settings. Do not reset unrelated changes.
- If refined PBI is not found, verify the Markdown is under `docs/sdd/pbi-input/<ID>/` and not only a chat attachment.
- If multiple files match the same ID, keep one canonical `REFINED-PBI.md` per PBI folder, or resolve ambiguity once.
- If spec/plan has PENDING lines, the workflow is unfinished; require continued analysis and strict validation. Do not approve coding.

## Boundaries

The package does not install Copilot, cannot bypass corporate policies, and cannot guarantee autonomous execution when VS Code tool permissions disallow terminal/edit access. Review all AI-generated implementation and test evidence. No source edits without explicit code-approval gate.

## PR review prevention

Before development, the agent reads `docs/sdd/review-lessons/approved-rules.md` and creates a `pr-review-audit.md` with applicable rules, inspected files, test evidence, and status. PR comment exports go to `docs/sdd/review-lessons/inbox/`; no supplied export has been imported into this distribution. The provided `candidate-rules.md` are provisional project checks and need manual verification before promotion.

`tools/Test-SDDReviewRules.ps1 -Repository . -ChangeFolder docs/sdd/changes/<ID>-<Feature> -Strict` checks audit completeness. Strict SDD validation also requires the audit. Build/tests still required.
