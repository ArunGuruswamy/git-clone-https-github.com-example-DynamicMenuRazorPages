# SDD Builder v2.2.0 — controlled pilot

Version 2.2.0 extends v2.1.2 without changing its original phase order or approval gate.

## Improvements
- Auto-route through repository evidence and announce a primary CDMS/DAB/UI project skill before edits. Ask a single question if genuinely ambiguous.
- Keep internal `docs/sdd/changes/<PBI-ID>-<slug>/` workflow unchanged.
- Require check-in-ready `src/.github/specs/<ShortFeatureName>/{spec.md,plan.md}` (or `.github/specs` only without `src`). IDs appear **inside** files, not folder names.
- Add approval, contract matrix, regression impact, token usage, and PR learning templates.
- Add two conservative PowerShell utilities: `tools/New-SDDFeature.ps1` creates drafts without overwrite, `tools/Validate-SDD.ps1` checks structure and traceability presence (not semantic correctness).
- Correct verify/archive prompt phase numbers.

## Pilot run (Windows PowerShell)
1. Extract ZIP outside repository, for example Desktop.
2. Back up working tree; confirm `git status` and choose the existing DAB/CDMS/UI target during installation. This is an **installer** decision; development agent will auto-route per repository later.
3. Example: `./Install-DevelopmentBuilder.ps1 -Destination 'C:\Users\RGA\source\repos\AN.ColorAppsAzure.BL' -Target DAB -Mode Full` (confirm parameter names using `Get-Help` first).
4. Start agent via `.github/prompts/start-akzo-sdd-development.prompt.md`. Require role/skill announcement and stop at approval.
5. Example draft: `./tools/New-SDDFeature.ps1 -Repository . -Feature PaintSystemStatusUpdate -PbiId 309559 -PbiTitle 'Actual Paint System record cannot be updated after Status Reason change' -SelectedRole DAB` (only after route evidence validates DAB).
6. Populate spec/plan from verified inventory. Populate all required working artifacts and approval.
7. Run `./tools/Validate-SDD.ps1 -Repository . -Feature PaintSystemStatusUpdate -ChangeFolder './docs/sdd/changes/<PBI-ID>-<slug>'`; later use `-Strict` only after pilot calibration.
8. Execute actual build and tests; collect independent reviewer findings. Never claim validator alone confirms successful build or AC correctness.
9. Examine `git status`, `git check-ignore -v src/.github/specs/PaintSystemStatusUpdate/spec.md`, and review diff before commit.

## Rollout gates
- First: install into a clean disposable test repository and ensure existing files survive update.
- Second: dry-run a completed PBI without source edits; verify all links and generated paths.
- Third: pilot one active PBI and compare review cycles, tests, and available provider token reports with baseline.
- Fourth: only enable strict CI gate after automated fixtures and team sign-off.

## Limitations
- Actual token usage requires provider/IDE usage reports; `Unknown` is correct if unavailable.
- Template checks do not prove API parity or AC implementation. Keep manual and automated integration tests.
- No measured token savings or production rollout readiness are asserted.
