> **v2.3.2 installation:** Use `Install-DevelopmentBuilder.cmd DAB "C:\Users\RGA\source\repos\AN.ColorAppsAzure.BL" Both`. The CMD performs approved RemoteSigned unblocking, safe upgrade, and Git-visible installation automatically. It does not bypass corporate policy.

# Web Setup Wizard — v2.1.2

Open `Akzo-SDD-Development-Builder.html` in Edge or Chrome. The page works offline and lets you select DAB/CDMS/UI, configure repository paths and agent mode, and download a configured PowerShell script plus a CMD launcher.

## Default installation path
1. Extract the complete ZIP package.
2. Open `Akzo-SDD-Development-Builder.html`.
3. Enter the extracted package folder and repository paths; select targets and mode.
Use the bundled `Install-DevelopmentBuilder.cmd` with repository target/path arguments; do not generate or run old launchers.
5. Review the PowerShell script and run the read-only preflight.
6. Double-click the `.cmd` launcher. It removes the downloaded-file mark only from the two scripts it is about to run, then invokes the configured script under the machine's existing effective execution policy.

## Security behavior
The launcher does not use `-ExecutionPolicy Bypass` and does not change persistent execution-policy settings. It stops if the effective policy is `AllSigned` or `Restricted`; request an IT-approved signed copy in that case. Only run it for a package you trust. `Unblock-File` removes the Windows internet-zone mark, not a script signature requirement.

A browser page cannot directly write to repositories or launch PowerShell. The `.cmd` file is the local handoff for the installation.

## Default repository paths
- DAB: `C:\src\AN.ColorAppsAzure.BL`
- CDMS: `C:\src\ColorDMS`
- UI: `C:\src\AN.ColorAppsAzure.UI`

## Git-clean behavior (v2.1.2)

Normal installation no longer overwrites files that already exist. Newly installed, untracked SDD assets and installer backup files are added to each repository clone’s `.git/info/exclude` by default. That local exclude is not committed. Use `-UpdateExisting` only when intentionally refreshing existing assets, and review any resulting Git changes. This behavior does not undo changes left by an older installer run.


## v2.1.2 safety notes
- The setup wizard command preview invokes the generated `.cmd` launcher. Do not paste raw installer execution commands if Windows still marks downloaded scripts.
- The launcher can remove the internet-zone mark from the bundled installer and generated script when policy permits. It never changes PowerShell execution policy. If `AllSigned`/`Restricted` is effective or a company signing policy blocks the script, use an approved signed release from IT.
- The installer avoids overwriting existing files by default and preserves tracked deletions. Existing untracked SDD files that are part of the package are locally excluded from normal Git status through `.git/info/exclude`.
- Local exclusions do not delete files and are not committed. Explicit `git add -f` can still stage an excluded file.
