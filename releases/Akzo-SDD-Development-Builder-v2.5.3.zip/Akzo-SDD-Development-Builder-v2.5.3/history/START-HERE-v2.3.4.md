# Akzo SDD Builder 2.3.4 — local-only installer and automatic artifacts

## Install (DAB example)
From the extracted folder in PowerShell:

```powershell
.\Install-DevelopmentBuilder.cmd DAB "C:\Users\RGA\source\repos\AN.ColorAppsAzure.BL" Both
```

The launcher handles trusted RemoteSigned scripts without changing execution policy. It cannot override company-enforced AllSigned/Restricted policies. Review company script approval before running.

The default installer updates untracked builder-managed local files, backs up replaced files, and adds exact-file patterns to repository-local `.git/info/exclude`. It **does not modify Git-tracked team files** in local-only mode. Git ignore and exclude never hide tracked modifications. For team-wide tracked agent updates, use a separate reviewed PR.

Locally excluded *untracked* working directories: `docs/sdd/changes/`, `docs/sdd/pbi-input/`, `.sdd-installer-backups/`. Published specs stay visible under `src/.github/specs/<Feature>/spec.md` and `plan.md`. Existing tracked files in these directories stay tracked.

## Start development
Place your approved `REFINED-PBI.md` under `docs/sdd/pbi-input/<PBI-ID>/`. Open VS Code on repository, choose `Akzo SDD Developer` (Full or Caveman Concise) in agent mode with file editing enabled, then say:

`Start Development 305183 Complaint Imitation Request`

The agent must select role, initialize and finish artifacts, run `tools/Assert-SDDArtifacts.ps1 -Repository . -Feature ComplaintImitationRequest -Stage AnalysisComplete`, and ask for approval *only before application code edits*. Never manually copy spec or plan.

## Old Git changes
Check `git status --short`. If a previously installed builder modified Git-tracked files, they remain in Changes and cannot be hidden by `.git/info/exclude`. Review individual changes; do not mass-revert or reset a feature branch. For safe cleanup, run `git diff --name-only`, identify only builder files, and restore them only after confirming no intentional edits.

## Security
The installer does not modify PowerShell execution policy, request admin privileges, change Git index/history, or modify/delete tracked application code. It cannot guarantee Copilot complies without agent/editor tool access; read-back and artifact checks provide an enforceable failure signal.
