# Akzo SDD Builder v2.3.3 — install and start

From the **extracted package folder** (not an old v2.1.x folder), in PowerShell:

```powershell
.\Install-DevelopmentBuilder.cmd DAB "C:\Users\RGA\source\repos\AN.ColorAppsAzure.BL" Both
```

The CMD launcher handles download-zone unblocking under `RemoteSigned` for the reviewed package. It does not bypass AllSigned or company policies. Installation refreshes builder-managed assets and backs up replaced files. Inspect the Git diff before committing. Never remove feature specs or project code.

Place the approved refined PBI at `docs/sdd/pbi-input/305183/REFINED-PBI.md` inside DAB repo. Open that repo in VS Code, choose **Akzo SDD Developer** (not Reviewer) with workspace edit/terminal permissions, and say:

`Start Development 305183 Complaint Imitation Request`

The agent starts SDD from disk, completes analysis, and MUST persist and verify:

- `src/.github/specs/ComplaintImitationRequest/spec.md`
- `src/.github/specs/ComplaintImitationRequest/plan.md`

It runs `tools/Assert-SDDArtifacts.ps1 -Repository . -Feature ComplaintImitationRequest -Stage AnalysisComplete` and requests approval only after PASS. The `Approved` stage checks approved spec hash and recorded approver before coding. The new gate tests structure/persistence; separate build and tests still required.

Do not paste old `C:\Tools\...v2.1.2` launcher snippets. In PowerShell, use `./` or `.\` for local commands.
