# Rollout & Implementation Plan: Akzo SDD Developer v2

## A. Analysis summary per project

| | CDMS | DAB | UI |
|---|---|---|---|
| Repo | `AN.ColorAppsAzure.BL.ColorDMS` | `AN.ColorAppsAzure.BL` (Formula service) | `AN.ColorAppsAzure.UI` |
| Runtime | .NET Framework 4.8 Azure Functions | .NET 10 isolated Azure Functions | Angular 21.2, Node, Azure Web App |
| Data | XRM / Dataverse (`IOrganizationService`) | GraphQL / DAB via StrawberryShake (4 clients, 57 ops) | HTTP to `colorAppsBaseUrl` |
| CQRS | Handlers + validators (verify mediator) | Custom `IDispatcher`, reflection, validation inside handler | n/a; NgRx Signal Store |
| Tests | MSTest + NSubstitute | MSTest + NSubstitute, `TestParams`, coverlet | Jest 30, jest-preset-angular |
| Sonar | SonarCloud, same profile as DAB | SonarCloud (`deployments/sonarcloud.yaml`) | ESLint/Prettier/Stylelint (+ SonarCloud TS if enabled) |
| Existing AI docs | 7 SDD quality `.md` (Sonar/testability patterns) | 14 architecture docs + `implement-pbi` skill + instructions (best in estate) | copilot-instructions, 8 agents, Jest skill, 6 spec/plan docs (technical remarks) |
| Biggest gap | **No architecture docs**: agent must trace from scratch each time | Docs reference `sonar-rules.instructions.md`, which is not in the supplied set (v2 provides one) | 41 spec files outside Jest `testMatch`; README is the CLI default |

**How the three connect (drives the whole design):**
UI → DAB Function App → (`RoutingMiddleware`, `FeatureFlags_Cdms`) → either the DAB handler or the CDMS Function App. One UI and one contract, so UI/UX stays the same whichever backend implements the PBI. v2 enforces this as constitution Article 5.

**Contract findings to verify before related PBIs:**
1. UI calls `POST PaintSytem/Create` (typo) while DAB documents `PaintSystem/Create`.
2. The authoritative `RoutingMiddleware` exclusion list (DAB OPEN-QUESTIONS #20) and the per-environment `FeatureFlags_Cdms` values (#21) decide which backend a PBI must change.

## B. Rollout (one developer, about half a day)

| Step | Action | Done when |
|---|---|---|
| 1 | Extract the zip. Run the installer for **DAB**, then **CDMS**, then **UI** (pass all three repo paths on the UI run to get the multi-root workspace). | `Installed/updated` printed for each; `git status` remains clean for installer-managed assets by default; new local assets are ignored via `.git/info/exclude`, existing files are not overwritten |
| 2 | Open `.github/sdd/AkzoColorApps.code-workspace` in VS Code. In Visual Studio, open each solution and keep `config.md` paths correct. | All 3 folders visible in Explorer |
| 3 | Copilot Chat → agent **Akzo SDD Developer** → `/sdd-bootstrap-architecture` in the **CDMS** repo | `docs/architecture/*` for CDMS reviewed and committed (one doc at a time) |
| 4 | Confirm the CDMS build/test commands; the agent writes them into `config.md` | `config.md` has no "verify" placeholders |
| 5 | Dry run on a **finished** PBI (e.g. Standard Technical Remarks Create, CDMS): run `/sdd-inventory` only | Inventory shows EXISTS for all ACs with correct evidence. This is the calibration check. |
| 6 | First live PBI: `Start Development <PBI-ID> <Feature Name>` → approve → FAST task groups → independent review (fix loop) → final verification | `review.md` READY FOR PR; `completion.md` with green build/test evidence; PR raised by you |
| 6b | After the human review, paste every reviewer comment into `/sdd-learn-review` | New L-rules in `.github/sdd/review-learnings.md`; commit them so the whole team's reviews improve |
| 7 | After merge: `/sdd-archive` | `docs/sdd/specs/<domain>/spec.md` created |
| 8 | Commit the installed `.github/` + `docs/sdd/` to each repo through a normal PR (the installer never commits) | Team gets the same agent |

## C. What happens on "Start Development" (end to end)

The shared [workflow](core/.github/sdd/workflow.md) controls every phase and mode. This example illustrates the normal FAST path:

```
You:   Start Development 305183 Complaint Imitation Request
Agent: Discovers and pins PBI 305183, detects DAB from project evidence,
       reads relevant approved inputs and architecture, and inventories current behavior.
       Resolves required business decisions; writes and reads back spec.md and plan.md
       at src/.github/specs/ComplaintImitationRequest/.
       Saves task groups and AC traceability in the change folder, validates analysis,
       then presents the implementation approval summary.
You:   Approve implementation
Agent: Records hash-bound approval and continues in FAST mode.
       Implements coherent groups, runs targeted checks, records verified progress,
       and continues through all approved tasks without ordinary task/file pauses.
       Requests independent review, fixes in-scope findings (maximum 3 review rounds),
       and performs final regression. Reports PRReady only with current passing evidence.
You:   Raise the PR and provide human review comments for /sdd-learn-review.
You:   /sdd-archive after confirmed merge.
```

STANDARD adds checks. STEP pauses after one task only when explicitly requested. Missing tools, unresolved decisions and required permissions are reported accurately; unexecuted checks never count as PASS.


## D. Recommended follow-ups (not done by the installer)
1. Commit `sonar-rules.instructions.md` in DAB, which its docs already reference, after review.
2. Fix or confirm the `PaintSytem/Create` route through a small PBI.
3. Extend `jest.config.js` `testMatch` and coverage for `shared-libs`, `dashboard` and the area apps (separate PBI; 41 specs are not run today).
4. Replace the UI README with a real setup guide (env, MSAL, `start.sh`, test/lint commands).
5. Later options: git worktree per PBI (Spec Kitty style); CI check that every PR touching `src/` links a `docs/sdd/changes/<PBI>` folder.
