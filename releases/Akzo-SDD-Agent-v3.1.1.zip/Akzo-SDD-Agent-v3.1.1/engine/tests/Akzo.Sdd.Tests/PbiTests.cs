using System.IO.Compression;
using Akzo.Sdd.Core;
using Akzo.Sdd.Core.Pbi;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class PbiTests
{
    [TestMethod]
    public void Read_ParsesPbi306400Package()
    {
        var package = PbiPackageReader.Read(TestRepo.FixtureFolder);

        Assert.AreEqual("306400", package.Id);
        StringAssert.StartsWith(package.Title, "[CAA] [DAB API] Creation of");
        Assert.AreEqual("Ready for PO-BA review", package.Status);
        Assert.AreEqual("Pending", package.BusinessApproval);
        Assert.IsFalse(package.IsBusinessApproved);
        Assert.AreEqual("Pending", package.TechnicalReview);
        Assert.AreEqual(11, package.AcceptanceCriteria.Count);
        Assert.AreEqual("AC-01", package.AcceptanceCriteria[0].Id);
        Assert.AreEqual("PS version is `2.1`.", package.AcceptanceCriteria[0].Then);
        Assert.AreEqual(12, package.BusinessRules.Count);
        Assert.AreEqual(10, package.Decisions.Count);
        Assert.AreEqual(1, package.Decisions.Count(d => !d.IsApproved));
        Assert.AreEqual(9, package.OpenQuestions.Count);
        Assert.IsTrue(package.OpenQuestions.All(q => q.IsResolved));
        Assert.AreEqual(5, package.Files.Count);
        Assert.AreEqual(64, package.Files[0].Sha256.Length);
    }

    [TestMethod]
    public void Read_SupportsBulletCriteriaAndMissingCompanions()
    {
        using var repo = new TestRepo();
        var folder = Path.GetDirectoryName(repo.AddFile("p/REFINED-PBI.md", "# 123 - Title\n\n## Acceptance criteria\n- AC-1: First thing\n- **AC-2** - Second thing\n"))!;

        var package = PbiPackageReader.Read(folder);

        Assert.AreEqual(2, package.AcceptanceCriteria.Count);
        Assert.AreEqual("Second thing", package.AcceptanceCriteria[1].Then);
        Assert.AreEqual(0, package.Decisions.Count);
        Assert.AreEqual(0, package.BusinessRules.Count);
    }

    [TestMethod]
    public void Read_WithoutAcceptanceCriteria_ReturnsEmpty()
    {
        using var repo = new TestRepo();
        var folder = Path.GetDirectoryName(repo.AddFile("p/REFINED-PBI.md", "# 123 - Title\n"))!;

        Assert.AreEqual(0, PbiPackageReader.Read(folder).AcceptanceCriteria.Count);
    }

    [TestMethod]
    public void Read_MissingRefined_Throws()
    {
        using var repo = new TestRepo();
        var ex = Assert.ThrowsException<SddException>(() => PbiPackageReader.Read(repo.Root));
        Assert.AreEqual(ErrorCodes.PbiNotFound, ex.Code);
    }

    [TestMethod]
    public void ParseTitle_RejectsHeadingWithoutId()
    {
        Assert.ThrowsException<SddException>(() => PbiPackageReader.ParseTitle("Just a title"));
        Assert.AreEqual(("42", "Name"), PbiPackageReader.ParseTitle("42: Name"));
    }

    [TestMethod]
    public void Decision_And_Question_StatusFlags()
    {
        Assert.IsTrue(new Decision("D", "t", "Approved", "e", "a").IsApproved);
        Assert.IsFalse(new Decision("D", "t", "Proposed", "e", "a").IsApproved);
        Assert.IsTrue(new OpenQuestion("Q", "q", "i", "o", "Closed").IsResolved);
        Assert.IsTrue(new OpenQuestion("Q", "q", "i", "o", "Answered: x").IsResolved);
        Assert.IsFalse(new OpenQuestion("Q", "q", "i", "o", "Open").IsResolved);
    }

    [DataTestMethod]
    [DataRow("Start Development 306400 Creation of Complaint PaintSystem", "306400", "Creation of Complaint PaintSystem", null)]
    [DataRow("start development PBI #305183 Complaint IR (source: C:\\dl\\305183.zip)", "305183", "Complaint IR", "C:\\dl\\305183.zip")]
    [DataRow("306400", "306400", "", null)]
    [DataRow("Start Development Some feature", "", "Some feature", null)]
    [DataRow(null, "", "", null)]
    public void StartRequest_Parses(string? text, string id, string hint, string? source)
    {
        var request = StartRequest.Parse(text);

        Assert.AreEqual(id, request.PbiId);
        Assert.AreEqual(hint, request.FeatureHint);
        Assert.AreEqual(source, request.Source);
    }

    [DataTestMethod]
    [DataRow("[CAA] [DAB API] Creation of \"Complaint\" PaintSystem - (Part1)", "ComplaintPaintSystem")]
    [DataRow("Complaint Imitation Request", "ComplaintImitationRequest")]
    [DataRow("update paint system status for the global product family", "UpdatePaintSystemStatus")]
    [DataRow("[x] (y) 123", "Feature")]
    [DataRow(null, "Feature")]
    public void FeatureName_Build(string? title, string expected)
    {
        Assert.AreEqual(expected, FeatureNameBuilder.Build(title));
    }

    [TestMethod]
    public void FeatureName_Candidates_HintFirstAndDistinct()
    {
        var candidates = FeatureNameBuilder.Candidates("[CAA] Creation of Complaint PaintSystem", "Complaint PS");

        Assert.AreEqual("ComplaintPS", candidates[0]);
        CollectionAssert.Contains(candidates.ToList(), "ComplaintPaintSystem");
        CollectionAssert.Contains(candidates.ToList(), "CreationOfComplaintPaintSystem");
        Assert.AreEqual(candidates.Count, candidates.Distinct().Count());
    }

    [TestMethod]
    public void Import_FromFolder_ThenSkipsExistingFiles()
    {
        using var repo = new TestRepo();

        var first = repo.ImportFixture();
        var second = repo.ImportFixture();

        Assert.AreEqual("306400", first.PbiId);
        Assert.AreEqual(5, first.Copied.Count);
        Assert.AreEqual(0, second.Copied.Count);
        Assert.AreEqual(5, second.Skipped.Count);
    }

    [TestMethod]
    public void Import_FromZipAndFromFile()
    {
        using var repo = new TestRepo();
        var zip = Path.Combine(repo.Root, "pkg.zip");
        ZipFile.CreateFromDirectory(TestRepo.FixtureFolder, zip, CompressionLevel.Fastest, includeBaseDirectory: true);

        var fromZip = PbiImporter.Import(zip, repo.Root);
        Assert.AreEqual(5, fromZip.Copied.Count);

        using var other = new TestRepo();
        var fromFile = PbiImporter.Import(Path.Combine(TestRepo.FixtureFolder, "REFINED-PBI.md"), other.Root);
        Assert.AreEqual(5, fromFile.Copied.Count);
    }

    [TestMethod]
    public void Import_InvalidSources_Throw()
    {
        using var repo = new TestRepo();
        Assert.ThrowsException<SddException>(() => PbiImporter.Import(Path.Combine(repo.Root, "missing"), repo.Root));
        Assert.ThrowsException<SddException>(() => PbiImporter.Import(repo.Root, repo.Root));
        Assert.ThrowsException<ArgumentException>(() => PbiImporter.Import(" ", repo.Root));
    }

    [TestMethod]
    public void Locate_ById_Single_Multiple_AndLegacy()
    {
        using var repo = new TestRepo();
        Assert.IsFalse(PbiLocator.Locate(repo.Root, null).Found);
        Assert.IsFalse(PbiLocator.Locate(repo.Root, "1").Found);

        repo.ImportFixture();
        Assert.IsTrue(PbiLocator.Locate(repo.Root, "306400").Found);
        Assert.IsTrue(PbiLocator.Locate(repo.Root, string.Empty).Found);

        repo.AddFile("docs/sdd/pbi-input/111/REFINED-PBI.md", "# 111 - Other");
        var ambiguous = PbiLocator.Locate(repo.Root, null);
        Assert.IsFalse(ambiguous.Found);
        Assert.AreEqual(2, ambiguous.Candidates.Count);

        repo.AddFile("docs/sdd/pbi-sources/222-Legacy/REFINED-PBI.md", "# 222 - Legacy");
        Assert.IsTrue(PbiLocator.Locate(repo.Root, "222").Found);
    }
}
