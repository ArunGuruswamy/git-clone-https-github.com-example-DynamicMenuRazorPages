using Akzo.Sdd.Core.Execution;
using Akzo.Sdd.Core.Services;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class FrontmatterTests
{
    [TestMethod]
    public void EveryBundledCopilotFileHasValidFrontmatter()
    {
        var agentRoot = Path.Combine(AppContext.BaseDirectory, "agent");
        var files = Directory.EnumerateFiles(agentRoot, "*.md", SearchOption.AllDirectories)
            .Where(f => f.EndsWith(".agent.md", StringComparison.Ordinal) || f.EndsWith(".prompt.md", StringComparison.Ordinal) || f.EndsWith(".instructions.md", StringComparison.Ordinal))
            .ToList();

        Assert.IsTrue(files.Count >= 8);
        var problems = files.SelectMany(f => FrontmatterValidator.Validate(File.ReadAllText(f)).Select(p => Path.GetFileName(f) + " " + p)).ToList();
        Assert.AreEqual(0, problems.Count, string.Join("; ", problems));
    }

    [TestMethod]
    public void Validate_FlagsUnquotedColonsAndBadFences()
    {
        Assert.AreEqual(1, FrontmatterValidator.Validate("---\nname: A\nargument-hint: Start X [(source: <zip>)]\n---\nbody").Count);
        Assert.AreEqual(1, FrontmatterValidator.Validate("---\n  - prompt: do it # now\n---").Count);
        Assert.AreEqual(0, FrontmatterValidator.Validate("---\nname: A\nargument-hint: 'Start X (source: <zip>)'\ntools: ['a: b']\nx: \"q: r\"\n---").Count);
        StringAssert.Contains(FrontmatterValidator.Validate("no header")[0], "must start");
        StringAssert.Contains(FrontmatterValidator.Validate("---\nname: A\n")[0], "not closed");
    }

    [TestMethod]
    public async Task Doctor_ReportsBrokenAgentHeader()
    {
        using var repo = new TestRepo();
        repo.AddFile(".github/agents/bad.agent.md", "---\nname: Bad\nargument-hint: x (source: y)\n---\n");
        var runner = new FakeRunner { Handler = cmd => FakeRunner.Ok(cmd, "8.0.100") };

        var checks = await DoctorService.RunAsync(repo.Root, runner);

        Assert.AreEqual(CheckStatus.Fail, checks.First(c => c.Name == "Header .github/agents/bad.agent.md").Status);
    }
}
