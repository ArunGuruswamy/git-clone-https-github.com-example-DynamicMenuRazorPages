using Akzo.Sdd.Core.Markdown;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class MarkdownTests
{
    [TestMethod]
    public void Parse_ReadsTitleSectionsAndFields()
    {
        var doc = MarkdownDocument.Parse("# 1 - Title\r\n\r\nStatus: Ready\r\n\r\n## First\r\nbody\r\n## Second\r\n- Business approval: Pending\r\n");

        Assert.AreEqual("1 - Title", doc.Title);
        Assert.AreEqual(2, doc.Sections.Count);
        Assert.AreEqual("body", doc.Find("first")!.Body);
        Assert.AreEqual("Ready", doc.GetField("Status"));
        Assert.AreEqual("Pending", doc.GetField("business approval"));
        Assert.AreEqual(string.Empty, doc.GetField("Missing"));
        Assert.IsNull(doc.Find("Nope"));
    }

    [TestMethod]
    public void Parse_IgnoresHeadingsInsideFences()
    {
        var doc = MarkdownDocument.Parse("# T\n## Real\n````markdown\n## Fake\n```\ncode\n```\n````\n## After\n");

        Assert.AreEqual(2, doc.Sections.Count);
        Assert.AreEqual("After", doc.Sections[1].Heading);
        StringAssert.Contains(doc.Sections[0].Body, "## Fake");
    }

    [TestMethod]
    public void TrackFence_OpensAndClosesOnMatchingRun()
    {
        Assert.AreEqual(4, MarkdownDocument.TrackFence("````md", 0));
        Assert.AreEqual(4, MarkdownDocument.TrackFence("```", 4));
        Assert.AreEqual(0, MarkdownDocument.TrackFence("````", 4));
        Assert.AreEqual(0, MarkdownDocument.TrackFence("text", 0));
    }

    [TestMethod]
    public void Table_ParsesRowsByHeaderPrefix()
    {
        var rows = MarkdownTable.Parse("intro\n| ID | Decision text | Status |\n| --- | :---: | --- |\n| D-01 | Do it | Approved |\n| D-02 | Short |\n\nafter");

        Assert.AreEqual(2, rows.Count);
        Assert.AreEqual("Do it", rows[0].Get("Decision"));
        Assert.AreEqual("Approved", rows[0].Get("status"));
        Assert.AreEqual(string.Empty, rows[1].Get("Status"));
        Assert.AreEqual(string.Empty, rows[0].Get("Unknown"));
        Assert.AreEqual(3, rows[0].Cells.Count);
    }

    [TestMethod]
    public void Table_ReturnsEmptyWithoutSeparatorOrTable()
    {
        Assert.AreEqual(0, MarkdownTable.Parse("no table").Count);
        Assert.AreEqual(0, MarkdownTable.Parse("| a | b |\n| x | y |").Count);
    }

    [TestMethod]
    public void SplitRow_HandlesMissingOuterPipes()
    {
        CollectionAssert.AreEqual(new[] { "a", "b" }, MarkdownTable.SplitRow("a | b").ToArray());
    }
}
