using Akzo.Sdd.Core;
using Akzo.Sdd.Core.Automation;
using Akzo.Sdd.Core.Cli;
using Akzo.Sdd.Core.Execution;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class CliTests
{
    private TestRepo _repo = null!;
    private FakeRunner _runner = null!;
    private StringWriter _out = null!;
    private HttpClient _http = null!;

    [TestInitialize]
    public async Task Init()
    {
        _repo = new TestRepo();
        await NativeCommand.GitAsync(_repo.Root, "init");
        await NativeCommand.GitAsync(_repo.Root, "config", "user.name", "SDD Test");
        await NativeCommand.GitAsync(_repo.Root, "config", "user.email", "sdd@example.invalid");
        _repo.AddFile("initial.txt", "fixture");
        await NativeCommand.GitAsync(_repo.Root, "add", "initial.txt");
        await NativeCommand.GitAsync(_repo.Root, "commit", "-m", "fixture");
        // This is an offline CLI integration fixture, not a server-analysis test.
        new SddSettings { RequireServerSonar = false }.Save(_repo.Root);
        _repo.AddDabSignature();
        _runner = new FakeRunner();
        _out = new StringWriter();
        _http = new HttpClient();
    }

    [TestCleanup]
    public void Cleanup()
    {
        _repo.Dispose();
        _out.Dispose();
        _http.Dispose();
    }

    [TestMethod]
    public void Args_ParseOptionsFlagsAndPositionals()
    {
        var a = CommandArgs.Parse(["VERIFY", "x", "--scope", "final", "--json", "--min-coverage", "95.5", "--all-files", "y", "--dangling"]);

        Assert.AreEqual("verify", a.Command);
        Assert.AreEqual("final", a.Option("scope"));
        Assert.IsTrue(a.Flag("json") && a.Flag("all-files") && a.Flag("dangling"));
        Assert.AreEqual(95.5, a.Number("min-coverage", 90));
        Assert.AreEqual(90, a.Number("missing", 90));
        Assert.AreEqual("x y", a.Rest());
        Assert.IsNull(a.Option("nope"));
        Assert.AreEqual("help", CommandArgs.Parse([]).Command);
    }

    [TestMethod]
    public async Task ProgramEntryPoint_RunsVersion()
    {
        var entry = System.Reflection.Assembly.Load("sdd").EntryPoint!;
        var result = entry.Invoke(null, [new[] { "version" }]);

        var code = result is Task<int> task ? await task : (int)result!;

        Assert.AreEqual(0, code);
    }

    [TestMethod]
    public async Task HelpVersionAndUnknown()
    {
        Assert.AreEqual(SddApp.Ok, await Run("help"));
        StringAssert.Contains(Output(), "sdd start");
        Assert.AreEqual(SddApp.Ok, await Run("version"));
        Assert.AreEqual(SddApp.UsageError, await Run("bogus"));
    }

    [TestMethod]
    public async Task CommandsWithoutActivePbi_ReturnNotFound()
    {
        Assert.AreEqual(SddApp.NotFound, await Run("status", "--repo", _repo.Root));
        Assert.AreEqual(SddApp.NotFound, await Run("start", "Start Development 1", "--repo", _repo.Root));
        StringAssert.Contains(Output(), "PbiNotFound");
        Assert.AreEqual(SddApp.NotFound, await Run("start", "Start Development 1", "--repo", _repo.Root, "--json"));
    }

    [TestMethod]
    public async Task FullLifecycle_StartToPr()
    {
        var root = _repo.Root;
        Assert.AreEqual(SddApp.Ok, await Run("start", "Start Development 306400 Creation of Complaint PaintSystem", "--source", TestRepo.FixtureFolder, "--repo", Path.Combine(root, "src")));
        StringAssert.Contains(Output(), "Initialized PBI 306400");
        StringAssert.Contains(Output(), "**Q-BIZ** (required)");

        Assert.AreEqual(SddApp.Ok, await Run("start", "306400", "--repo", root, "--json"));
        StringAssert.Contains(Output(), "\"status\": \"Resumed\"");

        Assert.AreEqual(SddApp.Ok, await Run("questions", "--repo", root));
        Assert.AreEqual(SddApp.Ok, await Run("questions", "--repo", root, "--json"));
        Assert.AreEqual(SddApp.UsageError, await Run("answer", "Q-BIZ", "--repo", root));
        Assert.AreEqual(SddApp.GateFailed, await Run("answer", "Q-BIZ", "7", "--repo", root));
        Assert.AreEqual(SddApp.Ok, await Run("answer", "Q-BIZ", "1", "--repo", root));
        Assert.AreEqual(SddApp.Ok, await Run("answer", "Q-D-01", "accept", "--repo", root, "--note", "PO confirmed"));
        Assert.AreEqual(SddApp.Ok, await Run("answer", "Q-FIT", "here", "--repo", root));

        Assert.AreEqual(SddApp.GateFailed, await Run("check", "--repo", root));
        StringAssert.Contains(Output(), "AnalysisComplete: FAIL");
        Assert.AreEqual(SddApp.GateFailed, await Run("check", "--repo", root, "--json"));
        Assert.AreEqual(SddApp.GateFailed, await Run("task", "T1", "--evidence", "x", "--repo", root));

        var ws = new SddWorkspace(root, new FakeClock());
        var state = ws.Load();
        ArtifactFiller.Complete(ws.Absolute(state.SpecPath), ws.Absolute(state.PlanPath));
        Assert.AreEqual(SddApp.Ok, await Run("check", "--repo", root));
        Assert.AreEqual(SddPhase.AwaitingApproval, ws.Load().Phase);
        Assert.AreEqual(SddApp.Ok, await Run("questions", "--stage", "approval", "--repo", root));
        StringAssert.Contains(Output(), "Q-APPROVE");

        Assert.AreEqual(SddApp.UsageError, await Run("approve", "--repo", root));
        Assert.AreEqual(SddApp.Ok, await Run("approve", "--statement", "Approve implementation", "--by", "Arun", "--repo", root));
        StringAssert.Contains(Output(), "ImplementationApproved: PASS");

        Assert.AreEqual(SddApp.UsageError, await Run("task", "T1", "--repo", root));
        Assert.AreEqual(SddApp.Ok, await Run("task", "t1", "--evidence", "dotnet build ok", "--repo", root));
        StringAssert.Contains(Output(), "Remaining: T2");
        Assert.AreEqual(SddApp.Ok, await Run("task", "T2", "--evidence", "dotnet test 12 passed", "--repo", root));
        StringAssert.Contains(Output(), "Remaining: none - run sdd verify");

        _runner.Handler = Passing;
        Assert.AreEqual(SddApp.Ok, await Run("verify", "--scope", "final", "--repo", root));
        StringAssert.Contains(Output(), "Verification (final): PASS");
        Assert.AreEqual(SddApp.Ok, await Run("verify", "--scope", "final", "--repo", root, "--json", "--all-files"));

        Assert.AreEqual(SddApp.Ok, await Run("tokens", "--phase", "Analysis (agent)", "--input", "12000", "--output", "3000", "--actual", "--repo", root));
        Assert.AreEqual(SddApp.Ok, await Run("tokens", "--phase", "Implementation (agent)", "--input", "800", "--output", "400", "--repo", root));
        Assert.AreEqual(SddApp.UsageError, await Run("tokens", "--repo", root));
        Assert.AreEqual(SddApp.Ok, await Run("phase", "start", "Review", "--repo", root));
        Assert.AreEqual(SddApp.Ok, await Run("phase", "end", "Review", "--repo", root));
        Assert.AreEqual(SddApp.GateFailed, await Run("phase", "end", "Nothing", "--repo", root));
        Assert.AreEqual(SddApp.UsageError, await Run("phase", "start", "--repo", root));
        Assert.AreEqual(SddApp.Ok, await Run("metrics", "--repo", root));
        StringAssert.Contains(Output(), "12,000 / 3,000");

        Assert.AreEqual(SddApp.GateFailed, await Run("pr", "--repo", root));
        StringAssert.Contains(Output(), "Review evidence is missing or stale");
        await File.WriteAllTextAsync(ws.ChangeFile(state, SddConstants.ReviewFile), "| Item | Value |\n|---|---|\n| Verdict | READY FOR PR |\n");
        Assert.AreEqual(SddApp.Ok, await Run("review-seal", "--repo", root));
        Assert.AreEqual(SddApp.Ok, await Run("pr", "--repo", root));
        StringAssert.Contains(Output(), "PRReady: PASS");
        Assert.AreEqual(SddPhase.PrReady, ws.Load().Phase);
        StringAssert.Contains(await File.ReadAllTextAsync(ws.ChangeFile(state, SddConstants.PrFile)), "AB#306400");

        Assert.AreEqual(SddApp.Ok, await Run("status", "--repo", root));
        StringAssert.Contains(Output(), "\"approved\": true");

        await File.AppendAllTextAsync(ws.Absolute(state.PlanPath), "\nlate edit");
        Assert.AreEqual(SddApp.GateFailed, await Run("task", "T3", "--evidence", "x", "--repo", root));
        StringAssert.Contains(Output(), "ApprovalStale");
    }

    [TestMethod]
    public async Task VerifyFailureAndSonarCommands()
    {
        await Run("start", "306400", "--source", TestRepo.FixtureFolder, "--repo", _repo.Root, "--role", "cdms", "--feature", "Complaint");
        StringAssert.Contains(Output(), "Role: Cdms");

        _runner.Handler = cmd => FakeRunner.Fail(cmd, "error CS0103");
        Assert.AreEqual(SddApp.GateFailed, await Run("verify", "--repo", _repo.Root));
        Assert.AreEqual(SddApp.GateFailed, await Run("verify", "--repo", _repo.Root, "--json", "--build", "b", "--test", "t"));

        Assert.AreEqual(SddApp.GateFailed, await Run("sonar", "--repo", _repo.Root));
        StringAssert.Contains(Output(), "Sonar: NOT EXECUTED");
        Assert.AreEqual(SddApp.GateFailed, await Run("sonar", "--repo", _repo.Root, "--url", "http://127.0.0.1:1", "--project", "k"));
    }

    [TestMethod]
    public async Task SonarCommand_ReportsGate()
    {
        await Run("start", "306400", "--source", TestRepo.FixtureFolder, "--repo", _repo.Root);
        using var handler = new JsonHandler("""{"projectStatus":{"status":"OK","conditions":[{"status":"OK","metricKey":"new_coverage","actualValue":"93","errorThreshold":"90"}]}}""");
        using var http = new HttpClient(handler);
        var app = new SddApp(_runner, new FakeClock(), http, _out);

        Assert.AreEqual(SddApp.Ok, await app.RunAsync(["sonar", "--repo", _repo.Root, "--url", "https://sonar.example", "--project", "k", "--pr", "7"]));
        StringAssert.Contains(Output(), "new_coverage: 93 (threshold 90) OK");
        Assert.AreEqual(SddApp.GateFailed, await app.RunAsync(["pr", "--repo", _repo.Root, "--sonar", "--url", "https://sonar.example/", "--project", "k"]));
    }

    private static ProcessResult Passing(string cmd)
    {
        if (cmd.StartsWith("dotnet test", StringComparison.Ordinal))
        {
            var start = cmd.IndexOf("--results-directory \"", StringComparison.Ordinal) + 21;
            var folder = cmd[start..cmd.LastIndexOf('"')];
            File.WriteAllText(Path.Combine(folder, "r.trx"), TestData.Trx);
            File.WriteAllText(Path.Combine(folder, "coverage.cobertura.xml"), TestData.Cobertura("src/A.cs", 19, 20));
        }

        return FakeRunner.Ok(cmd, cmd.StartsWith("git status", StringComparison.Ordinal) ? " M src/A.cs\n" : "ok");
    }

    private Task<int> Run(params string[] args)
    {
        _out.GetStringBuilder().Clear();
        return new SddApp(_runner, new FakeClock(), _http, _out).RunAsync(args);
    }

    private string Output() => _out.ToString();

    private sealed class JsonHandler(string body) : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken) =>
            Task.FromResult(new HttpResponseMessage(System.Net.HttpStatusCode.OK) { Content = new StringContent(body) });
    }
}
