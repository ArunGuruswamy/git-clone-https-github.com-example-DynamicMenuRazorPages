using Akzo.Sdd.Core;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class WorkspaceTests
{
    [TestMethod]
    public void FindRoot_WalksUpFromNestedSolutionFolder()
    {
        using var repo = new TestRepo();
        var nested = Path.Combine(repo.Root, "src", "Formula", "Function");
        Directory.CreateDirectory(nested);

        Assert.AreEqual(Path.GetFullPath(repo.Root), RepositoryLocator.FindRoot(nested));
    }

    [TestMethod]
    public void FindRoot_WithoutGit_ReturnsStart()
    {
        var folder = Path.Combine(Path.GetTempPath(), "sdd-nogit-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(folder);
        try
        {
            var root = RepositoryLocator.FindRoot(folder);
            Assert.IsTrue(root == Path.GetFullPath(folder) || Directory.Exists(Path.Combine(root, ".git")));
        }
        finally
        {
            Directory.Delete(folder);
        }
    }

    [TestMethod]
    public void SpecRoot_UsesSrcWhenPresent()
    {
        using var withSrc = new TestRepo(src: true);
        using var withoutSrc = new TestRepo(src: false);

        StringAssert.EndsWith(RepositoryLocator.SpecRoot(withSrc.Root).Replace('\\', '/'), "src/.github/specs");
        Assert.AreEqual(Path.Combine(withoutSrc.Root, ".github", "specs"), RepositoryLocator.SpecRoot(withoutSrc.Root));
    }

    [TestMethod]
    public void FindExistingFeature_MatchesPbiIdInSpecHeader()
    {
        using var repo = new TestRepo();
        var specRoot = RepositoryLocator.SpecRoot(repo.Root);
        Assert.IsNull(RepositoryLocator.FindExistingFeature(specRoot, "306400"));

        repo.AddFile("src/.github/specs/Other/spec.md", "# Other\n- PBI ID: 1\n");
        repo.AddFile("src/.github/specs/MyFeature/spec.md", "# MyFeature\n- PBI ID: 306400\n");

        Assert.AreEqual("MyFeature", RepositoryLocator.FindExistingFeature(specRoot, "306400"));
    }

    [TestMethod]
    public void RoleDetector_ClassifiesEachProjectType()
    {
        using var dab = new TestRepo();
        dab.AddDabSignature();
        Assert.AreEqual(ProjectRole.Dab, RoleDetector.Detect(dab.Root).Role);

        using var dabProject = new TestRepo();
        dabProject.AddFile("src/Data/Data.csproj", "<Project><ItemGroup><PackageReference Include=\"StrawberryShake.Server\" /></ItemGroup></Project>");
        Assert.AreEqual(ProjectRole.Dab, RoleDetector.Detect(dabProject.Root).Role);

        using var cdms = new TestRepo();
        cdms.AddFile("src/Cdms/Cdms.csproj", "<Project><PropertyGroup><TargetFramework>net48</TargetFramework></PropertyGroup></Project>");
        cdms.AddFile("src/Cdms/bin/ignored.graphql", "query X");
        Assert.AreEqual(ProjectRole.Cdms, RoleDetector.Detect(cdms.Root).Role);

        using var ui = new TestRepo();
        ui.AddFile("angular.json", "{}");
        var detection = RoleDetector.Detect(ui.Root);
        Assert.AreEqual(ProjectRole.Ui, detection.Role);
        Assert.IsTrue(detection.IsDecisive);
        StringAssert.Contains(detection.Evidence[0], "angular.json");
    }

    [TestMethod]
    public void RoleDetector_AmbiguousOrEmpty_IsNotDecisive()
    {
        using var mixed = new TestRepo();
        mixed.AddDabSignature();
        mixed.AddFile("ui/angular.json", "{}");
        var ambiguous = RoleDetector.Detect(mixed.Root);
        Assert.IsFalse(ambiguous.IsDecisive);
        Assert.AreEqual(2, ambiguous.Candidates.Count);

        using var empty = new TestRepo();
        empty.AddFile("src/Plain/Plain.csproj", "<Project />");
        Assert.AreEqual(ProjectRole.Unknown, RoleDetector.Detect(empty.Root).Role);
    }

    [TestMethod]
    public void RoleProfile_DefaultsPerRole()
    {
        Assert.AreEqual("ui-development", RoleProfile.For(ProjectRole.Ui).Skill);
        Assert.AreEqual("cdms-development", RoleProfile.For(ProjectRole.Cdms).Skill);
        Assert.AreEqual("dab-development", RoleProfile.For(ProjectRole.Unknown).Skill);
        StringAssert.Contains(RoleProfile.For(ProjectRole.Dab).TestCommand, SddConstants.ResultsPlaceholder);
    }

    [TestMethod]
    public void Settings_DefaultsSaveAndLoad()
    {
        using var repo = new TestRepo();
        var defaults = SddSettings.Load(repo.Root);
        Assert.AreEqual(90.0, defaults.CoverageThreshold);
        Assert.AreEqual(ProjectRole.Unknown, defaults.ConfiguredRole());

        new SddSettings { Role = "cdms", CoverageThreshold = 95, BuildCommand = "msbuild x.sln" }.Save(repo.Root);
        var loaded = SddSettings.Load(repo.Root);

        Assert.AreEqual(ProjectRole.Cdms, loaded.ConfiguredRole());
        Assert.AreEqual(95.0, loaded.CoverageThreshold);
        Assert.AreEqual("msbuild x.sln", loaded.BuildCommand);
        Assert.AreEqual("origin/develop", loaded.IntegrationBranch);
    }

    [TestMethod]
    public void Workspace_SaveLoadAndActivePointer()
    {
        using var repo = new TestRepo();
        var clock = new FakeClock();
        var ws = new SddWorkspace(repo.Root, clock);
        Assert.IsNull(ws.TryLoad());
        Assert.ThrowsException<SddException>(() => ws.Load("9"));

        var state = new SddState { PbiId = "306400", Feature = "ComplaintPaintSystem", Role = ProjectRole.Dab };
        ws.Save(state);

        Assert.AreEqual("306400", ws.Load().PbiId);
        Assert.AreEqual(ProjectRole.Dab, ws.Load("306400").Role);
        Assert.AreEqual(clock.UtcNow, ws.Load().UpdatedUtc);
        Assert.AreEqual("306400-ComplaintPaintSystem", state.ChangeFolderName);
        Assert.ThrowsException<SddException>(() => SddState.FromJson("null"));
    }

    [TestMethod]
    public void SystemClock_ReturnsCurrentTime()
    {
        var before = DateTimeOffset.UtcNow;
        Assert.IsTrue(new SystemClock().UtcNow >= before);
    }

    [TestMethod]
    public void SddException_Constructors()
    {
        Assert.AreEqual(ErrorCodes.Failed, new SddException().Code);
        Assert.AreEqual("m", new SddException("m").Message);
        var inner = new InvalidOperationException("x");
        var ex = new SddException("outer", inner);
        Assert.AreEqual(inner, ex.InnerException);
        Assert.AreEqual(ErrorCodes.Failed, ex.Code);
    }
}
