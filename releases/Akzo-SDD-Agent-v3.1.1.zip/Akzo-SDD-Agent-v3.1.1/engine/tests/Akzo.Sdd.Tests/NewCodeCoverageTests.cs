using System.Xml.Linq;
using Akzo.Sdd.Core.Execution;
using Akzo.Sdd.Core.Verification;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class NewCodeCoverageTests
{
    private const string Handler = "src/App/Handler.cs";
    private const string Service = "src/Data/Service.cs";

    private const string Diff = """
        diff --git a/src/App/Handler.cs b/src/App/Handler.cs
        --- a/src/App/Handler.cs
        +++ b/src/App/Handler.cs
        @@ -10,0 +11,3 @@ public class Handler
        +line
        @@ -20 +24 @@ public class Handler
        -old
        +new
        @@ -30,2 +35,0 @@
        diff --git a/src/Old.cs b/src/Old.cs
        --- a/src/Old.cs
        +++ /dev/null
        @@ -1,3 +0,0 @@
        """;

    private static string Cobertura => """
        <coverage><packages><package><classes>
          <class filename="C:\repo\src\App\Handler.cs"><lines>
            <line number="5" hits="1" />
            <line number="11" hits="1" branch="True" condition-coverage="50% (1/2)" />
            <line number="12" hits="0" />
            <line number="13" hits="1" />
            <line number="24" hits="1" branch="True" condition-coverage="100% (2/2)" />
          </lines></class>
          <class filename="C:\repo\src\Data\Service.cs"><lines>
            <line number="3" hits="0" />
            <line number="4" hits="0" branch="True" condition-coverage="0% (0/2)" />
          </lines></class>
        </classes></package></packages></coverage>
        """;

    [TestMethod]
    public void ParseUnifiedDiff_ReturnsNewSideLines()
    {
        var lines = GitClient.ParseUnifiedDiff(Diff);

        CollectionAssert.AreEqual(new[] { 11, 12, 13, 24 }, lines[Handler].OrderBy(l => l).ToArray());
        Assert.IsFalse(lines.ContainsKey("src/Old.cs"));
    }

    [TestMethod]
    public async Task ChangedLines_UsesMergeBaseAndMarksUntrackedFilesAsNew()
    {
        var runner = new FakeRunner
        {
            Handler = cmd => cmd switch
            {
                _ when cmd.StartsWith("git merge-base", StringComparison.Ordinal) => FakeRunner.Ok(cmd, "abc123\n"),
                _ when cmd.StartsWith("git diff -U0", StringComparison.Ordinal) => FakeRunner.Ok(cmd, Diff),
                _ => FakeRunner.Ok(cmd, "src\\New\\Collaborator.cs\n"),
            },
        };

        var changed = await new GitClient(runner).ChangedLinesAsync("/repo", "origin/develop");

        StringAssert.Contains(runner.Commands[1], "git diff -U0 --no-color --no-ext-diff abc123");
        Assert.AreEqual(4, changed[Handler]!.Count);
        Assert.IsNull(changed["src/New/Collaborator.cs"]);

        var failing = new FakeRunner { Handler = cmd => FakeRunner.Fail(cmd, "fatal") };
        await Assert.ThrowsExceptionAsync<Akzo.Sdd.Core.SddException>(() => new GitClient(failing).ChangedLinesAsync("/repo", "origin/develop"));
    }

    [TestMethod]
    public void NewCode_CountsChangedLinesAndConditionsLikeSonar()
    {
        var report = CoberturaParser.Merge([XDocument.Parse(Cobertura)]);
        var changed = new Dictionary<string, IReadOnlySet<int>?>
        {
            [Handler] = new HashSet<int> { 11, 12, 13, 24, 99 },
            [Service] = null,
            ["src/App/IHandler.cs"] = new HashSet<int> { 1 },
        };

        var (files, missing) = report.ForChangedLines(changed);

        var handler = files.Single(f => f.Path == Handler);
        Assert.AreEqual(4, handler.LinesToCover);
        Assert.AreEqual(1, handler.UncoveredLines);
        Assert.AreEqual(4, handler.ConditionsToCover);
        Assert.AreEqual(1, handler.UncoveredConditions);
        Assert.AreEqual(75.0, handler.Percent);
        Assert.AreEqual(0.0, files.Single(f => f.Path == Service).Percent);
        CollectionAssert.AreEqual(new[] { "src/App/IHandler.cs" }, missing.ToArray());
        Assert.AreEqual(50.0, CoverageReport.NewCodePercent(files));
        Assert.IsNull(CoverageReport.NewCodePercent([]));
        Assert.IsNull(new NewCodeFile("x", 0, 0, 0, 0).Percent);
    }

    [TestMethod]
    public void OpenCover_BranchPointsBecomeConditions()
    {
        const string xml = """
            <CoverageSession><Modules><Module><Files><File uid="1" fullPath="C:\repo\src\App\Handler.cs" /></Files>
              <Classes><Class><Methods>
                <Method><SequencePoints>
                  <SequencePoint vc="1" sl="11" fileid="1" />
                  <SequencePoint vc="0" sl="12" fileid="1" />
                </SequencePoints><BranchPoints>
                  <BranchPoint vc="1" sl="11" />
                  <BranchPoint vc="0" sl="11" />
                </BranchPoints></Method>
                <Method><SequencePoints /><BranchPoints><BranchPoint vc="1" sl="1" /></BranchPoints></Method>
              </Methods></Class></Classes>
            </Module></Modules></CoverageSession>
            """;

        var report = CoberturaParser.MergeOpenCover([XDocument.Parse(xml)]);
        var (files, _) = report.ForChangedLines(new Dictionary<string, IReadOnlySet<int>?> { [Handler] = null });

        Assert.AreEqual(2, files[0].LinesToCover);
        Assert.AreEqual(2, files[0].ConditionsToCover);
        Assert.AreEqual(1, files[0].UncoveredConditions);
        Assert.AreEqual(50.0, files[0].Percent);
    }

    [TestMethod]
    public void CoverageGate_NewCodeFailsLikeSonarCloud_AndFlagsProjectsWithoutCoverage()
    {
        using var repo = new TestRepo();
        repo.AddFile("src/App/App.csproj", "<Project />");
        repo.AddFile("src/Other/Other.csproj", "<Project />");
        var report = new VerificationReport();
        var coverage = CoberturaParser.Merge([XDocument.Parse(Cobertura)]);
        var options = new VerificationOptions("targeted", "b", "t", 90, ChangedOnly: true, TimeSpan.FromMinutes(1), "origin/develop");
        var changed = new Dictionary<string, IReadOnlySet<int>?>
        {
            [Handler] = new HashSet<int> { 11, 12, 13, 24 },
            [Service] = null,
            ["src/App/IHandler.cs"] = null,
            ["src/Other/Untested.cs"] = null,
            ["tests/App.Tests/HandlerTests.cs"] = null,
        };

        var gate = VerificationService.CoverageGate(coverage, report, options, changed, repo.Root);

        Assert.AreEqual(GateStatus.Fail, gate.Status);
        StringAssert.Contains(gate.Detail, "50% on new code: changed lines + conditions in 2 file(s) (SonarQube formula); threshold 90%.");
        StringAssert.Contains(gate.Detail, "Below threshold: src/Data/Service.cs 0% (2 uncovered lines, 2 uncovered conditions); src/App/Handler.cs 75%");
        StringAssert.Contains(gate.Detail, "No coverage data (no test project exercises them; SonarCloud counts 0%): src/Other/Untested.cs.");
        Assert.AreEqual(50.0, report.CoveragePercent);
        CollectionAssert.AreEqual(new[] { "src/Other/Untested.cs" }, report.NotInstrumented.ToArray());

        var covered = new Dictionary<string, IReadOnlySet<int>?> { [Handler] = new HashSet<int> { 13 } };
        Assert.AreEqual(GateStatus.Pass, VerificationService.CoverageGate(coverage, new VerificationReport(), options, covered, repo.Root).Status);

        var nothing = new Dictionary<string, IReadOnlySet<int>?> { [Handler] = new HashSet<int> { 200 } };
        StringAssert.Contains(VerificationService.CoverageGate(coverage, new VerificationReport(), options, nothing, repo.Root).Detail, "No coverable new code");
    }
}
