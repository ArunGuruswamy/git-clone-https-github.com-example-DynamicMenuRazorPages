using Akzo.Sdd.Core.Artifacts;
using Akzo.Sdd.Core.Cli;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Pr;
using Akzo.Sdd.Core.Questions;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class RepositoryFitTests
{
    private const string MeasurementWarning = "Standard does not have measurement, Kindly add measurement for the Standard instance";

    private static string Fixture305912 => Path.Combine(AppContext.BaseDirectory, "Fixtures", "305912");

    private static PbiPackage Blocked() => PbiPackageReader.Read(Fixture305912);

    [TestMethod]
    public void Reader_ReadsReadinessBlockingQuestionsScopeAndCitedPaths()
    {
        var package = Blocked();

        Assert.IsTrue(package.IsBlocked);
        Assert.AreEqual("Blocked", package.Readiness);
        Assert.IsTrue(package.OpenQuestions.Single(q => q.Id == "Q-01").IsBlocking);
        Assert.IsFalse(package.OpenQuestions.Single(q => q.Id == "Q-02").IsBlocking);
        StringAssert.Contains(package.OutOfScope, "Changes to DAB or CDMS repositories");
        CollectionAssert.Contains(package.CitedPaths.ToList(), "Source/Formula/PaintSystem/PaintSystem/PaintSystemOperations.cs");
        Assert.IsFalse(PbiPackageReader.Read(TestRepo.FixtureFolder).IsBlocked);
    }

    [TestMethod]
    public void Analyse_DabRepositoryWithLegacyEvidence_ReportsEveryGap()
    {
        using var repo = new TestRepo();

        var fit = RepositoryFit.Analyse(Blocked(), repo.Root, ProjectRole.Dab);

        Assert.AreEqual(FitLevel.Blocked, fit[0].Level);
        StringAssert.Contains(fit[0].Text, "blocking question(s): Q-01");
        Assert.IsTrue(fit.Any(f => f.Level == FitLevel.Warn && f.Text.StartsWith("Out of scope mentions DAB", StringComparison.Ordinal)));
        Assert.IsTrue(fit.Any(f => f.Level == FitLevel.Warn && f.Text.StartsWith("None of the 7 source files", StringComparison.Ordinal)));
        Assert.IsTrue(fit.Any(f => f.Level == FitLevel.Info && f.Text == "Title tag [DAB API] matches this DAB repository."));
        var ui = fit.Single(f => f.Text.Contains("describe form/UI behaviour", StringComparison.Ordinal));
        StringAssert.Contains(ui.Text, "AC-01, AC-02, AC-05, AC-06, AC-10");
    }

    [TestMethod]
    public void Analyse_EvidenceFoundPartlyOrFully_IsInformational()
    {
        using var repo = new TestRepo();
        var package = Blocked();
        repo.AddFile("legacy/PaintSystemOperations.cs", "// moved");

        var partial = RepositoryFit.Analyse(package, repo.Root, ProjectRole.Dab);
        Assert.IsTrue(partial.Any(f => f.Level == FitLevel.Info && f.Text.StartsWith("1 of 7 cited source files exist here", StringComparison.Ordinal)));

        foreach (var path in package.CitedPaths)
        {
            repo.AddFile(path, "// present");
        }

        var full = RepositoryFit.Analyse(package, repo.Root, ProjectRole.Dab);
        Assert.IsTrue(full.Any(f => f.Text == "All 7 cited source files exist in this repository."));
        Assert.AreEqual(0, RepositoryFit.Analyse(package, Path.Combine(repo.Root, "missing"), ProjectRole.Dab).Count(f => f.Text.StartsWith("All", StringComparison.Ordinal)));
    }

    [TestMethod]
    public void Analyse_OtherRoles()
    {
        using var repo = new TestRepo();
        var package = Blocked();

        var cdms = RepositoryFit.Analyse(package, repo.Root, ProjectRole.Cdms);
        Assert.IsTrue(cdms.Any(f => f.Level == FitLevel.Warn && f.Text == "Title tag [DAB API] targets another project, but this repository is CDMS."));

        var ui = RepositoryFit.Analyse(package, repo.Root, ProjectRole.Ui);
        Assert.IsTrue(ui.Any(f => f.Level == FitLevel.Info && f.Text.Contains("describe API/backend outcomes", StringComparison.Ordinal)));

        var unknown = RepositoryFit.Analyse(package, repo.Root, ProjectRole.Unknown);
        Assert.IsFalse(unknown.Any(f => f.Text.Contains("Title tag", StringComparison.Ordinal) || f.Text.StartsWith("Out of scope", StringComparison.Ordinal)));
    }

    [TestMethod]
    public void Analyse_CdmsTagAndNoCitedPaths()
    {
        using var repo = new TestRepo();
        var package = new PbiPackage { Id = "1", Title = "[CDMS] [UI] Something", Folder = repo.Root, RefinedText = "# 1 - x" };

        var fit = RepositoryFit.Analyse(package, repo.Root, ProjectRole.Dab);

        Assert.AreEqual(1, fit.Count);
        Assert.AreEqual("Title tag [CDMS] [UI] targets another project, but this repository is DAB.", fit[0].Text);
        Assert.AreEqual(FitLevel.Info, RepositoryFit.Analyse(package, repo.Root, ProjectRole.Cdms)[0].Level);
    }

    [TestMethod]
    public void SuggestLayer_UsesOutcomeWording()
    {
        Assert.AreEqual(RepositoryFit.UiLayer, RepositoryFit.SuggestLayer(new AcceptanceCriterion("AC-1", "g", "w", "Color Name offers that MCI.")));
        Assert.AreEqual(RepositoryFit.ApiLayer, RepositoryFit.SuggestLayer(new AcceptanceCriterion("AC-2", "g", "w", "Save is blocked with `x`.")));
    }

    [TestMethod]
    public void Questions_BlockedPackageRecommendsWaitingAndAsksForFit()
    {
        var package = Blocked();
        var state = new SddState { PbiId = package.Id, Role = ProjectRole.Dab, FitWarnings = ["Out of scope mentions DAB."] };

        var questions = QuestionBuilder.Build(QuestionStage.Start, package, state, [], ["A"]);

        var biz = questions.Single(q => q.Id == QuestionBuilder.BusinessId);
        Assert.AreEqual(QuestionBuilder.Wait, biz.Recommended);
        StringAssert.Contains(biz.Prompt, "BLOCKED (Status: Blocked; Readiness: Blocked; blocking: Q-01)");
        var q01 = questions.Single(q => q.Id == "Q-01");
        Assert.AreEqual(QuestionBuilder.Blocked, q01.Recommended);
        StringAssert.StartsWith(q01.Prompt, "[BLOCKING] Open question Q-01 (Open - blocking)");
        Assert.IsNull(questions.Single(q => q.Id == "Q-02").Recommended);
        var fit = questions.Single(q => q.Id == QuestionBuilder.FitId);
        Assert.AreEqual("here", fit.Recommended);
        StringAssert.Contains(fit.Prompt, "this DAB repository: Out of scope mentions DAB.");

        state.Answers[QuestionBuilder.FitId] = QuestionBuilder.Blocked;
        CollectionAssert.Contains(QuestionBuilder.ApprovalBlockers(package, state).ToList(), "Q-FIT answered 'blocking'");
    }

    [TestMethod]
    public void Spec_ListsFitAndApprovedMessagesWithoutTrailingFullStop()
    {
        var package = Blocked();
        using var repo = new TestRepo();
        var fit = RepositoryFit.Analyse(package, repo.Root, ProjectRole.Dab);
        var context = new ArtifactContext(package, "AdaptationImitationRequest", ProjectRole.Dab, "docs/sdd/pbi-input/305912", new SddSettings()) { Fit = fit };

        var messages = context.ApprovedMessages();
        CollectionAssert.Contains(messages.ToList(), MeasurementWarning);
        CollectionAssert.Contains(messages.ToList(), "Only Adaption is allowed; Paint system does not exist for this Market Color Instance and Product");
        Assert.IsFalse(messages.Contains("SES1A__3FICESC_"));

        var spec = SpecWriter.Build(context);
        StringAssert.Contains(spec, "## Repository fit");
        StringAssert.Contains(spec, "- [BLOCKED] The PBI is BLOCKED");
        StringAssert.Contains(spec, "the Q-BIZ/Q-FIT answers");

        var clean = SpecWriter.Build(context with { Fit = [] });
        StringAssert.Contains(clean, "No fit issues found for this Dab repository.");
        var infoOnly = SpecWriter.Build(context with { Fit = [new FitFinding(FitLevel.Info, "All 1 cited source files exist in this repository.")] });
        Assert.IsFalse(infoOnly.Contains("the Q-BIZ/Q-FIT answers", StringComparison.Ordinal));

        var plan = PlanWriter.Build(context);
        StringAssert.Contains(plan, "| AC-01 | Color Name offers that MCI. | UI / form | TBD | TBD | TBD |");
        StringAssert.Contains(plan, "| AC-03 |");
    }

    [TestMethod]
    public void Validator_AppliesHereRules()
    {
        using var repo = new TestRepo();
        var package = PbiPackageReader.Read(TestRepo.FixtureFolder);
        var context = new ArtifactContext(package, "F", ProjectRole.Dab, "p", new SddSettings());
        var spec = repo.AddFile("s/spec.md", SpecWriter.Build(context));
        var planPath = repo.AddFile("s/plan.md", PlanWriter.Build(context));
        ArtifactFiller.Complete(spec, planPath);
        var plan = File.ReadAllText(planPath);

        File.WriteAllText(planPath, plan.Replace("| Yes | `ComplaintHandler.cs > ComplaintHandler > Handle` | `ComplaintHandlerTests.Handle_Ac` |", "| No - UI repository | N/A | N/A |", StringComparison.Ordinal));
        StringAssert.Contains(string.Join("|", ArtifactValidator.Validate(spec, planPath, package).Findings), "every AC is marked 'No'");

        var first = plan.IndexOf("| Yes |", StringComparison.Ordinal);
        File.WriteAllText(planPath, plan[..first] + "| Partial - API only | - | - |" + plan[(plan.IndexOf('\n', first))..]);
        StringAssert.Contains(string.Join("|", ArtifactValidator.Validate(spec, planPath, package).Findings), "AC-01 has no code + test");

        File.WriteAllText(planPath, plan.Replace("| AC-02 |", "| AC-99 |", StringComparison.Ordinal));
        StringAssert.Contains(string.Join("|", ArtifactValidator.Validate(spec, planPath, package).Findings), "AC-02 has no code + test");
    }

    [TestMethod]
    public void Pr_TeamTitleBlockedReadinessAndOtherRepositoryAcs()
    {
        var package = Blocked();
        var state = new SddState { PbiId = "305912", Title = package.Title, Feature = "AdaptationImitationRequest" };
        state.Answers[QuestionBuilder.BusinessId] = QuestionBuilder.Proceed;
        const string plan = "# P\n## Traceability (AC -> code -> test)\n| AC | Expected outcome | Layer (suggested) | Applies here | Code | Test |\n|---|---|---|---|---|---|\n| AC-01 | offers | UI / form | No - UI repository | N/A | N/A |\n| AC-03 | blocked | API / backend | Yes | c | t |\n";

        var text = PrDescriptionBuilder.Build(new PrInputs(state, package, "# S\n", plan, null, [], null, null, null, "b"));

        Assert.AreEqual("feat: Creation of Imitation Request & Paint System - Adaptation [SDD]", PrDescriptionBuilder.Title(state));
        Assert.AreEqual("feat: F [SDD]", PrDescriptionBuilder.Title(new SddState { Title = "[DAB] ", Feature = "F" }));
        StringAssert.Contains(text, "- PBI: #305912 - [CAA] [DAB API] Creation");
        StringAssert.Contains(text, "- **PBI readiness: BLOCKED** in the package (Readiness: Blocked); developer chose 'proceed'.");
        StringAssert.Contains(text, "**Not implemented in this repository (owned elsewhere):**\n- AC-01: No - UI repository\n");

        var unanswered = PrDescriptionBuilder.Build(new PrInputs(new SddState { PbiId = "305912", Title = "t", Feature = "F" }, package, "# S\n", "# P\n", null, [], null, null, null, "b"));
        StringAssert.Contains(unanswered, "developer chose 'not acknowledged'");
        Assert.IsFalse(unanswered.Contains("owned elsewhere", StringComparison.Ordinal));
    }

    [TestMethod]
    public async Task Cli_StartPrintsRepositoryFit()
    {
        using var repo = new TestRepo();
        repo.AddDabSignature();
        using var output = new StringWriter();
        using var http = new HttpClient();
        var app = new SddApp(new FakeRunner(), new FakeClock(), http, output);

        Assert.AreEqual(SddApp.Ok, await app.RunAsync(["start", "Start", "Development", "305912", "Adaptation", "(source:", Fixture305912 + ")", "--repo", repo.Root]));

        var text = output.ToString();
        StringAssert.Contains(text, "Repository fit:");
        StringAssert.Contains(text, "  [BLOCKED] The PBI is BLOCKED");
        StringAssert.Contains(text, "**Q-FIT** (required)");

        Assert.AreEqual(SddApp.Ok, await app.RunAsync(["next", "--repo", repo.Root]));
        StringAssert.Contains(output.ToString(), "| PBI readiness | BLOCKED (Readiness: Blocked) - not acknowledged |");
    }
}
