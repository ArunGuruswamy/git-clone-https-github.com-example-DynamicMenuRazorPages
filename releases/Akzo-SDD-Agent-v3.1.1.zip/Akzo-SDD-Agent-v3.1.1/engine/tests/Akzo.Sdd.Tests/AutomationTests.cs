using System.Text.Json;
using Akzo.Sdd.Core;
using Akzo.Sdd.Core.Automation;
using Akzo.Sdd.Core.Execution;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Verification;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class AutomationTests
{
    [TestMethod]
    public async Task SnapshotDetectsUntrackedEditsAndDeletions()
    {
        using var repo = await RealRepoAsync();
        var original = await SourceEvidence.CaptureAsync(repo.Root);
        repo.AddFile("new file.cs", "class NewClass {} ");
        var added = await SourceEvidence.CaptureAsync(repo.Root);
        Assert.AreNotEqual(original, added);
        repo.AddFile("new file.cs", "class OtherClass {} ");
        Assert.AreNotEqual(added, await SourceEvidence.CaptureAsync(repo.Root));
        File.Delete(Path.Combine(repo.Root, "source.cs"));
        Assert.AreNotEqual(original, await SourceEvidence.CaptureAsync(repo.Root));
    }

    [TestMethod]
    public async Task SnapshotIgnoresRuntimeEvidenceButTracksSettings()
    {
        using var repo = await RealRepoAsync();
        var original = await SourceEvidence.CaptureAsync(repo.Root);
        repo.AddFile("docs/sdd/changes/run/verification.json", "new output");
        repo.AddFile(".sonarqube/out/output.txt", "scanner output");
        repo.AddFile(".sdd/automation.lock", "");
        Assert.AreEqual(original, await SourceEvidence.CaptureAsync(repo.Root));
        repo.AddFile(".sdd/settings.json", "{}");
        Assert.AreNotEqual(original, await SourceEvidence.CaptureAsync(repo.Root));
    }

    [TestMethod]
    public async Task FinalEvidenceRejectsChangedSource()
    {
        using var repo = await RealRepoAsync();
        var (ws, state) = await EvidenceAsync(repo);
        await SourceEvidence.RequireCurrentAsync(ws, state, true);
        repo.AddFile("source.cs", "class Edited {} ");
        await Assert.ThrowsExceptionAsync<SddException>(() => SourceEvidence.RequireCurrentAsync(ws, state, true));
    }

    [TestMethod]
    public async Task FinalEvidenceRejectsEditedOrMissingReview()
    {
        using var repo = await RealRepoAsync();
        var (ws, state) = await EvidenceAsync(repo);
        await File.AppendAllTextAsync(ws.ChangeFile(state, SddConstants.ReviewFile), "tampered");
        await Assert.ThrowsExceptionAsync<SddException>(() => SourceEvidence.RequireCurrentAsync(ws, state, true));
        File.Delete(SourceEvidence.ReviewFile(ws, state));
        await Assert.ThrowsExceptionAsync<SddException>(() => SourceEvidence.RequireCurrentAsync(ws, state, true));
    }

    [TestMethod]
    public async Task CommitWritesExactMessageAndOnlyReviewedFiles()
    {
        using var repo = await RealRepoAsync();
        repo.AddFile("source.cs", "class Updated {} ");
        var (ws, state) = await EvidenceAsync(repo);
        var stamp = await SourceEvidence.CaptureAsync(repo.Root);
        var files = await CommitDelivery.FilesAsync(repo.Root);
        CollectionAssert.AreEqual(new[] { "source.cs" }, files);
        const string message = "feat: literal $(touch should-not-exist) & `text`\n\nPBI evidence verified";
        await CommitDelivery.CommitAsync(ws, state, stamp, files, message);
        Assert.AreEqual(message, (await NativeCommand.GitAsync(repo.Root, "log", "-1", "--format=%B")).TrimEnd());
        Assert.IsFalse(File.Exists(Path.Combine(repo.Root, "should-not-exist")));
        Assert.AreEqual(0, (await CommitDelivery.FilesAsync(repo.Root)).Length);
        // Old verification can never authorize a second commit after HEAD changes.
        await Assert.ThrowsExceptionAsync<SddException>(() => SourceEvidence.RequireCurrentAsync(ws, state, true));
    }

    [TestMethod]
    public async Task CommitRefusesExistingIndexAndPreservesIt()
    {
        using var repo = await RealRepoAsync();
        repo.AddFile("source.cs", "class Updated {} ");
        var (ws, state) = await EvidenceAsync(repo);
        var stamp = await SourceEvidence.CaptureAsync(repo.Root);
        var files = await CommitDelivery.FilesAsync(repo.Root);
        await NativeCommand.GitAsync(repo.Root, "add", "source.cs");
        await Assert.ThrowsExceptionAsync<SddException>(() => CommitDelivery.CommitAsync(ws, state, stamp, files, "message"));
        Assert.AreEqual("source.cs", (await NativeCommand.GitAsync(repo.Root, "diff", "--cached", "--name-only")).Trim());
        Assert.AreEqual(stamp.Head, (await NativeCommand.GitAsync(repo.Root, "rev-parse", "HEAD")).Trim());
    }

    [TestMethod]
    public async Task CommitRefusesChangedDialogFileList()
    {
        using var repo = await RealRepoAsync();
        repo.AddFile("source.cs", "class Updated {} ");
        var (ws, state) = await EvidenceAsync(repo);
        var stamp = await SourceEvidence.CaptureAsync(repo.Root);
        await Assert.ThrowsExceptionAsync<SddException>(() => CommitDelivery.CommitAsync(ws, state, stamp, [], "message"));
        Assert.AreEqual("", await NativeCommand.GitAsync(repo.Root, "diff", "--cached", "--name-only"));
    }

    [TestMethod]
    public async Task GitFailuresCannotBecomeEmptyPassingDiffs()
    {
        var runner = new FakeRunner { Handler = c => FakeRunner.Fail(c, "fatal: missing base") };
        var client = new GitClient(runner);
        await Assert.ThrowsExceptionAsync<SddException>(() => client.ChangedFilesAsync(".", "origin/develop"));
        await Assert.ThrowsExceptionAsync<SddException>(() => client.ChangedLinesAsync(".", "origin/develop"));
        await Assert.ThrowsExceptionAsync<SddException>(() => client.ChangedFilesAsync(".", "main; echo unsafe"));
    }

    [TestMethod]
    public async Task SnapshotDetectsBranchSwitchWithSameCommit()
    {
        using var repo = await RealRepoAsync();
        var stamp = await SourceEvidence.CaptureAsync(repo.Root);
        await NativeCommand.GitAsync(repo.Root, "checkout", "-b", "other-branch");
        Assert.AreNotEqual(stamp, await SourceEvidence.CaptureAsync(repo.Root));
    }

    [TestMethod]
    public async Task HookChangesAreReportedWithoutResettingCreatedCommit()
    {
        using var repo = await RealRepoAsync();
        repo.AddFile("source.cs", "class Updated {} ");
        var (ws, state) = await EvidenceAsync(repo);
        var stamp = await SourceEvidence.CaptureAsync(repo.Root);
        var files = await CommitDelivery.FilesAsync(repo.Root);
        var hook = repo.AddFile(".git/hooks/pre-commit", "#!/bin/sh\nprintf '// hook edit\\n' >> source.cs\ngit add -- source.cs\n");
        if (!OperatingSystem.IsWindows()) File.SetUnixFileMode(hook, UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute);
        var ex = await Assert.ThrowsExceptionAsync<SddException>(() => CommitDelivery.CommitAsync(ws, state, stamp, files, "hook commit"));
        StringAssert.Contains(ex.Message, "Commit was created");
        Assert.AreNotEqual(stamp.Head, (await NativeCommand.GitAsync(repo.Root, "rev-parse", "HEAD")).Trim());
    }

    private static async Task<TestRepo> RealRepoAsync()
    {
        var repo = new TestRepo(git: false, src: false);
        await NativeCommand.GitAsync(repo.Root, "init");
        await NativeCommand.GitAsync(repo.Root, "config", "user.name", "SDD Test");
        await NativeCommand.GitAsync(repo.Root, "config", "user.email", "sdd-test@example.invalid");
        repo.AddFile("source.cs", "class Original {} ");
        await NativeCommand.GitAsync(repo.Root, "add", "source.cs");
        await NativeCommand.GitAsync(repo.Root, "commit", "-m", "initial");
        return repo;
    }

    private static async Task<(SddWorkspace Workspace, SddState State)> EvidenceAsync(TestRepo repo)
    {
        var ws = new SddWorkspace(repo.Root, new FakeClock());
        var state = new SddState { PbiId = "42", Feature = "Automation" };
        Directory.CreateDirectory(ws.ChangeFolder(state));
        var stamp = await SourceEvidence.CaptureAsync(repo.Root);
        var report = new VerificationReport { Scope = "final", SourceHead = stamp.Head, SourceFingerprint = stamp.Fingerprint,
            Gates = [new GateResult("Build", GateStatus.Pass, "fixture")] };
        await File.WriteAllTextAsync(ws.ChangeFile(state, SddConstants.VerificationFile), JsonSerializer.Serialize(report, Json.Options));
        var review = ws.ChangeFile(state, SddConstants.ReviewFile);
        await File.WriteAllTextAsync(review, "| Verdict | READY FOR PR |\n");
        await File.WriteAllTextAsync(SourceEvidence.ReviewFile(ws, state), JsonSerializer.Serialize(new ReviewStamp(stamp, Akzo.Sdd.Core.IO.FileHash.OfFile(review)), Json.Options));
        return (ws, state);
    }
}
