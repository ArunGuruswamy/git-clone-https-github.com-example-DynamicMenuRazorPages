using Akzo.Sdd.Core.Approval;
using Akzo.Sdd.Core.Metrics;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Pr;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Verification;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class DeliveryTests
{
    private static readonly DateTimeOffset T0 = new(2026, 10, 15, 10, 0, 0, TimeSpan.Zero);

    [TestMethod]
    public void Metrics_PhasesTokensAndRender()
    {
        var state = new SddState { GeneratedCharacters = 24_000 };
        MetricsService.StartPhase(state, "Analysis", T0);
        MetricsService.StartPhase(state, "Implement", T0.AddMinutes(12));
        Assert.IsTrue(MetricsService.EndPhase(state, "implement", T0.AddHours(1).AddMinutes(30)));
        Assert.IsFalse(MetricsService.EndPhase(state, null, T0));
        MetricsService.StartPhase(state, "Review", T0.AddHours(2));
        MetricsService.AddTokens(state, new TokenEntry { Phase = "Analysis", Kind = TokenKind.Actual, Input = 12_000, Output = 3_000 });
        MetricsService.AddTokens(state, new TokenEntry { Phase = "Implement", Kind = TokenKind.Estimated, Input = 100, Output = 50 });

        var table = MetricsService.Render(state);

        Assert.AreEqual(TimeSpan.FromMinutes(90), MetricsService.TotalDuration(state));
        StringAssert.Contains(table, "| Analysis | 2026-10-15 10:00 | 12m 0s | 12,000 / 3,000 | Unknown |");
        StringAssert.Contains(table, "| Implement | 2026-10-15 10:12 | 1h 18m | Unknown | 100 / 50 |");
        StringAssert.Contains(table, "(running)");
        StringAssert.Contains(table, "**1h 30m**");
        StringAssert.Contains(table, "about 6,000 output tokens avoided");
        Assert.AreEqual(3, MetricsService.Estimate(9));
    }

    [TestMethod]
    public void Pr_NotReadyListsEveryGap()
    {
        var inputs = Inputs(approval: null, verification: null, verdict: null, sonar: new SonarGateResult("ERROR", []), stale: ["plan.md"]);

        var gaps = PrDescriptionBuilder.ReadinessGaps(inputs);
        var text = PrDescriptionBuilder.Build(inputs);

        Assert.AreEqual(5, gaps.Count);
        StringAssert.Contains(text, "**Status: NOT READY**");
        StringAssert.Contains(text, "- Approval: NOT RECORDED");
        StringAssert.Contains(text, "NOT EXECUTED: no verification recorded.");
        StringAssert.Contains(text, "- Not recorded (run `sdd verify`).");
        StringAssert.Contains(text, "| SonarQube quality gate | ERROR |");
    }

    [TestMethod]
    public void Pr_ReadyContainsTraceabilityEvidenceAndMetrics()
    {
        var verification = new VerificationReport
        {
            Scope = "final",
            StartedUtc = T0,
            DurationSeconds = 42,
            ChangedFiles = ["src/A.cs"],
            Gates =
            [
                new GateResult("Build", GateStatus.Pass, "ok"),
                new GateResult("Tests", GateStatus.Pass, "12 executed"),
                new GateResult("Coverage", GateStatus.Pass, "95%"),
                new GateResult("Extra", GateStatus.NotExecuted, "n/a"),
            ],
        };
        verification.Gates.RemoveAt(3);
        var approval = new ApprovalRecord { ApprovedBy = "Arun", Statement = "Approve", ApprovedUtc = T0 };

        var inputs = Inputs(approval, verification, "READY FOR PR", new SonarGateResult("OK", [new SonarCondition("new_coverage", "OK", "95", "90")]), []);
        var text = PrDescriptionBuilder.Build(inputs);

        Assert.AreEqual(0, PrDescriptionBuilder.ReadinessGaps(inputs).Count);
        StringAssert.StartsWith(text, "# feat: Title [SDD]");
        StringAssert.Contains(text, "**Status: READY FOR PR**");
        StringAssert.Contains(text, "| AC-01 | outcome | code | test |");
        StringAssert.Contains(text, "R-1 added");
        StringAssert.Contains(text, "D-01 (Proposed -> developer: accept)");
        StringAssert.Contains(text, "- Q-01: answered by PO");
        StringAssert.Contains(text, "- `src/A.cs`");
        StringAssert.Contains(text, "| Coverage | PASS | 95% |");
        StringAssert.Contains(text, "new_coverage=95 (OK)");
        StringAssert.Contains(text, "## 8. Delivery metrics");
    }

    [TestMethod]
    public void Pr_GateStatusTextAndVerdict()
    {
        var verification = new VerificationReport { Scope = "targeted", Gates = [new GateResult("Tests", GateStatus.NotExecuted, "x"), new GateResult("Build", GateStatus.Fail, "y")] };
        var text = PrDescriptionBuilder.Build(Inputs(null, verification, null, null, []));

        StringAssert.Contains(text, "| Tests | NOT EXECUTED | x |");
        StringAssert.Contains(text, "| Build | FAIL | y |");
        Assert.AreEqual("READY FOR PR", PrDescriptionBuilder.ReadVerdict("| Item | Value |\n|---|---|\n| Round | 1 |\n| Verdict | READY FOR PR |"));
        Assert.IsNull(PrDescriptionBuilder.ReadVerdict(" "));
        var template = Inputs(null, null, "READY FOR PR / CHANGES REQUIRED", null, []);
        CollectionAssert.Contains(PrDescriptionBuilder.ReadinessGaps(template).ToList(), "Independent review verdict is not READY FOR PR");
        Assert.IsNull(PrDescriptionBuilder.ReadVerdict("| A | B |\n|---|---|\n| x | y |"));
    }

    [TestMethod]
    public void Pr_GroupsChangedFiles()
    {
        var groups = PrDescriptionBuilder.GroupFiles(
        [
            "src/.github/specs/F/spec.md", "src/App/Handler.cs", "tests/App.Tests/HandlerTests.cs",
            "docs/sdd/changes/1-F/approval.json", ".sdd/settings.json", "docs/sdd/pbi-input/1/REFINED-PBI.md", "README.md",
        ]).ToDictionary(g => g.Key, g => g.Value.Count);

        Assert.AreEqual(1, groups["Specification (approved)"]);
        Assert.AreEqual(1, groups["Production code"]);
        Assert.AreEqual(1, groups["Tests"]);
        Assert.AreEqual(1, groups["Other - confirm each belongs in this PR"]);
        Assert.AreEqual(3, groups["Local SDD working files - do not include in the PR"]);
    }

    [TestMethod]
    public void Metrics_ShortPhaseShowsSeconds()
    {
        var state = new SddState();
        MetricsService.StartPhase(state, "Start", T0);
        MetricsService.EndPhase(state, "Start", T0.AddMilliseconds(320));

        StringAssert.Contains(MetricsService.Render(state), "| Start | 2026-10-15 10:00 | 0.3s |");
    }

    private static PrInputs Inputs(ApprovalRecord? approval, VerificationReport? verification, string? verdict, SonarGateResult? sonar, IReadOnlyList<string> stale)
    {
        var state = new SddState { PbiId = "306400", Title = "Title", Feature = "ComplaintPaintSystem" };
        state.Answers["Q-D-01"] = "accept";
        state.AnswerNotes["Q-01"] = "answered by PO";
        var package = new PbiPackage
        {
            Id = "306400",
            Title = "Title",
            Folder = ".",
            RefinedText = "# 306400 - Title",
            Decisions = [new Decision("D-01", "Treat as requested", "Proposed", "e", "BR-01")],
        };
        const string spec = "# S\n## Delta requirements (ADDED / MODIFIED / REMOVED)\nR-1 added\n";
        const string plan = "# P\n## Traceability (AC -> code -> test)\n| AC | Expected outcome | Code | Test |\n|---|---|---|---|\n| AC-01 | outcome | code | test |\n";
        return new PrInputs(state, package, spec, plan, approval, stale, verification, sonar, verdict, "feature/306400");
    }
}
