using Akzo.Sdd.Core;
using Akzo.Sdd.Core.Approval;
using Akzo.Sdd.Core.Cli;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Questions;
using Akzo.Sdd.Core.Services;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class ArtifactPathRepairTests
{
    [TestMethod]
    public async Task RenamedSpecFolder_IsFoundAgain_AndApprovalStaysValid()
    {
        using var repo = new TestRepo();
        var clock = new FakeClock();
        StartService.Start(new StartOptions(repo.Root, "Start Development 306400 Creation of Complaint PaintSystem", TestRepo.FixtureFolder, ProjectRole.Dab, null), clock);
        var ws = new SddWorkspace(repo.Root, clock);
        var state = ws.Load();
        var package = PbiPackageReader.Read(ws.Absolute(state.PackageFolder));
        ArtifactFiller.Complete(ws.Absolute(state.SpecPath), ws.Absolute(state.PlanPath));
        foreach (var q in QuestionBuilder.Build(QuestionStage.Start, package, state, [], []).Where(q => q.Blocking))
        {
            AnswerService.Answer(ws, state, package, q.Id, q.Recommended ?? q.Options[0].Key, "test");
        }

        ApprovalService.Approve(ws, state, package, "Approve", "Arun");
        Assert.IsNull(ArtifactPathRepair.Repair(ws, state));

        var oldFolder = Path.GetDirectoryName(ws.Absolute(state.SpecPath))!;
        Directory.Move(oldFolder, oldFolder + "s");

        var note = ArtifactPathRepair.Repair(ws, state);

        StringAssert.Contains(note!, "ComplaintPaintSystems/spec.md' (state updated)");
        Assert.AreEqual(state.SpecPath, ws.Load().SpecPath);
        Assert.AreEqual(0, ApprovalService.ChangedSinceApproval(ws, state, ApprovalService.Load(ws, state)!).Count);

        using var output = new StringWriter();
        using var http = new HttpClient();
        Assert.AreEqual(SddApp.Ok, await new SddApp(new FakeRunner(), clock, http, output).RunAsync(["next", "--repo", repo.Root]));
        StringAssert.Contains(output.ToString(), "ComplaintPaintSystems/plan.md");
    }

    [TestMethod]
    public void MissingFolder_ExplainsWhatToDo_AndUnapprovedStateIsRepairedWithoutApproval()
    {
        using var repo = new TestRepo();
        var clock = new FakeClock();
        StartService.Start(new StartOptions(repo.Root, "Start Development 306400 Creation of Complaint PaintSystem", TestRepo.FixtureFolder, ProjectRole.Dab, null), clock);
        var ws = new SddWorkspace(repo.Root, clock);
        var state = ws.Load();
        var folder = Path.GetDirectoryName(ws.Absolute(state.SpecPath))!;
        Directory.Move(folder, folder + "Renamed");
        StringAssert.Contains(ArtifactPathRepair.Repair(ws, state)!, "ComplaintPaintSystemRenamed");

        Directory.Delete(folder + "Renamed", recursive: true);
        var error = Assert.ThrowsException<SddException>(() => ArtifactPathRepair.Repair(ws, state));
        StringAssert.Contains(error.Message, "declaring 'PBI ID: 306400'");
        Assert.IsNull(ArtifactPathRepair.Repair(ws, new SddState()));
    }
}
