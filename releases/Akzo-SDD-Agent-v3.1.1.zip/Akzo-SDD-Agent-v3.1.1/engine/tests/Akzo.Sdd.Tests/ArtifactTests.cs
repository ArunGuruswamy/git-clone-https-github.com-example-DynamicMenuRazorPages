using Akzo.Sdd.Core.Artifacts;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class ArtifactTests
{
    private static ArtifactContext Context(ProjectRole role = ProjectRole.Dab) =>
        new(PbiPackageReader.Read(TestRepo.FixtureFolder), "ComplaintPaintSystem", role, "docs/sdd/pbi-input/306400", new SddSettings());

    [TestMethod]
    public void Spec_ContainsVerbatimPbiAndDerivedSections()
    {
        var spec = SpecWriter.Build(Context());

        StringAssert.StartsWith(spec, "# ComplaintPaintSystem - Specification");
        StringAssert.Contains(spec, "- PBI ID: 306400");
        StringAssert.Contains(spec, "<!-- sdd:pbi-source:begin sha256=");
        StringAssert.Contains(spec, "- **AC-11** - Given Color creation fails");
        StringAssert.Contains(spec, "| D-01 | Treat intake PS rules");
        StringAssert.Contains(spec, "9 recorded, 0 unresolved.");
        StringAssert.Contains(spec, "THEN PS version is `2.1`.");
        StringAssert.Contains(spec, "- `Product is missing. A Complaint Paint System cannot be created.`");
    }

    [TestMethod]
    public void ApprovedMessages_AreDistinctSentences()
    {
        var messages = Context().ApprovedMessages();

        Assert.AreEqual(7, messages.Count);
        Assert.IsFalse(messages.Contains("2.1"));
    }

    [TestMethod]
    public void Cell_EscapesPipesAndEmpty()
    {
        Assert.AreEqual("a\\|b", ArtifactContext.Cell("a|b"));
        Assert.AreEqual("-", ArtifactContext.Cell(" "));
    }

    [TestMethod]
    public void Plan_HasTraceabilityRowPerAcAndRoleCommands()
    {
        var plan = PlanWriter.Build(Context(ProjectRole.Ui));

        Assert.AreEqual(11, plan.Split('\n').Count(l => l.StartsWith("| AC-", StringComparison.Ordinal)));
        StringAssert.Contains(plan, "npx jest");
        StringAssert.Contains(plan, ">= 90% line coverage");
    }

    [TestMethod]
    public void Spec_WithoutDecisionLog_SaysNotApplicable()
    {
        using var repo = new TestRepo();
        var folder = Path.GetDirectoryName(repo.AddFile("p/REFINED-PBI.md", "# 5 - T\n"))!;
        var context = new ArtifactContext(PbiPackageReader.Read(folder), "T", ProjectRole.Dab, "p", new SddSettings());

        StringAssert.Contains(SpecWriter.Build(context), "N/A - no decision log in the package.");
    }

    [TestMethod]
    public void Validate_FreshDraftFails_FilledPasses()
    {
        using var repo = new TestRepo();
        var (spec, plan, package) = Write(repo);

        var draft = ArtifactValidator.Validate(spec, plan, package);
        var all = string.Join(" | ", draft.Findings);
        Assert.IsFalse(draft.Passed);
        Assert.IsTrue(draft.Findings.Any(f => f.Contains("sdd:fill", StringComparison.Ordinal)), all);
        Assert.IsTrue(draft.Findings.Any(f => f.Contains("TBD", StringComparison.Ordinal)), all);
        Assert.IsTrue(draft.Findings.Any(f => f.Contains("AC-01 'Applies here' is not decided", StringComparison.Ordinal)), all);
        Assert.IsTrue(draft.Findings.Any(f => f.Contains("no tasks", StringComparison.Ordinal)), all);

        ArtifactFiller.Complete(spec, plan);
        var filled = ArtifactValidator.Validate(spec, plan, package);
        Assert.IsTrue(filled.Passed, string.Join("; ", filled.Findings));
    }

    [TestMethod]
    public void Validate_DetectsEditedVerbatimBlockAndMissingSections()
    {
        using var repo = new TestRepo();
        var (spec, plan, package) = Write(repo);
        ArtifactFiller.Complete(spec, plan);
        File.WriteAllText(spec, File.ReadAllText(spec).Replace("Business need and actors", "Edited", StringComparison.Ordinal).Replace("## Testable scenarios", "## Removed", StringComparison.Ordinal));

        var report = ArtifactValidator.Validate(spec, plan, package);

        Assert.IsTrue(report.Findings.Any(f => f.Contains("verbatim PBI block was edited", StringComparison.Ordinal)));
        Assert.IsTrue(report.Findings.Any(f => f.Contains("missing section '## Testable scenarios'", StringComparison.Ordinal)));
    }

    [TestMethod]
    public void Validate_MissingMarkersAndFiles()
    {
        using var repo = new TestRepo();
        var (spec, plan, package) = Write(repo);
        ArtifactFiller.Complete(spec, plan);
        File.WriteAllText(spec, File.ReadAllText(spec).Replace("<!-- sdd:pbi-source:end -->", string.Empty, StringComparison.Ordinal));
        Assert.IsTrue(ArtifactValidator.Validate(spec, plan, package).Findings.Any(f => f.Contains("markers missing", StringComparison.Ordinal)));

        File.Delete(plan);
        StringAssert.Contains(ArtifactValidator.Validate(spec, plan, package).Findings[0], "Missing artifact");
        Assert.IsFalse(ArtifactValidator.Validate(Path.Combine(repo.Root, "none.md"), plan, package).Passed);
    }

    [TestMethod]
    public void ReadTasks_ParsesTickedAndOpen()
    {
        var tasks = ArtifactValidator.ReadTasks("- [ ] T1 a\n- [x] T2 b\n* [X] T3 c\nT4 not a task");

        Assert.AreEqual(3, tasks.Count);
        Assert.IsFalse(tasks["T1"]);
        Assert.IsTrue(tasks["t2"]);
        Assert.IsTrue(tasks["T3"]);
    }

    private static (string Spec, string Plan, PbiPackage Package) Write(TestRepo repo)
    {
        var context = Context();
        var spec = repo.AddFile("src/.github/specs/F/spec.md", SpecWriter.Build(context));
        var plan = repo.AddFile("src/.github/specs/F/plan.md", PlanWriter.Build(context));
        return (spec, plan, context.Package);
    }
}
