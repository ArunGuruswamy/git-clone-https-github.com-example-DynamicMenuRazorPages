using System.Net;
using System.Text;
using Akzo.Sdd.Core;
using Akzo.Sdd.Core.Automation;
using Akzo.Sdd.Core.Verification;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class ServerSonarAutomationTests
{
    [TestMethod]
    public async Task GateUsesSubmittedTaskAnalysisInsteadOfLatestProjectStatus()
    {
        using var handler = new QueueHandler(
            """{"task":{"status":"SUCCESS","analysisId":"analysis-current"}}""",
            """{"projectStatus":{"status":"OK","conditions":[]}}""");
        using var http = new HttpClient(handler);
        var scanner = new ServerSonar(http, ".", new SddSettings { SonarUrl = "https://sonar.example.invalid/base/" });
        var result = await scanner.WaitForGateAsync("submitted-task");
        Assert.AreEqual(GateStatus.Pass, result.Status);
        StringAssert.Contains(handler.Requests[0], "/base/api/ce/task?id=submitted-task");
        StringAssert.Contains(handler.Requests[1], "analysisId=analysis-current");
        Assert.IsFalse(handler.Requests.Exists(url => url.Contains("projectKey=", StringComparison.Ordinal)));
    }

    [TestMethod]
    public async Task ServerFailureNeverBecomesPass()
    {
        using var handler = new QueueHandler("""{"task":{"status":"FAILED"}}""");
        using var http = new HttpClient(handler);
        var scanner = new ServerSonar(http, ".", new SddSettings { SonarUrl = "https://sonar.example.invalid/" });
        await Assert.ThrowsExceptionAsync<SddException>(() => scanner.WaitForGateAsync("task"));
    }

    [TestMethod]
    public async Task FailedQualityGateBlocksReadiness()
    {
        using var handler = new QueueHandler("""{"task":{"status":"SUCCESS","analysisId":"a"}}""",
            """{"projectStatus":{"status":"ERROR","conditions":[]}}""");
        using var http = new HttpClient(handler);
        var scanner = new ServerSonar(http, ".", new SddSettings { SonarUrl = "https://sonar.example.invalid/" });
        Assert.AreEqual(GateStatus.Fail, (await scanner.WaitForGateAsync("task")).Status);
    }

    private sealed class QueueHandler(params string[] responses) : HttpMessageHandler
    {
        private readonly Queue<string> _responses = new(responses);
        internal List<string> Requests { get; } = [];
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Requests.Add(request.RequestUri!.AbsoluteUri);
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(_responses.Dequeue(), Encoding.UTF8, "application/json") });
        }
    }
}
