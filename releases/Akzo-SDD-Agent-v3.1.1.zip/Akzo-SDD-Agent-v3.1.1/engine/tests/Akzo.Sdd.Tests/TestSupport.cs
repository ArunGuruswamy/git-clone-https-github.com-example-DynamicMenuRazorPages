using Akzo.Sdd.Core.Execution;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.State;

namespace Akzo.Sdd.Tests;

internal sealed class FakeClock : IClock
{
    public DateTimeOffset UtcNow { get; set; } = new(2026, 10, 15, 10, 0, 0, TimeSpan.Zero);

    public void Advance(TimeSpan by) => UtcNow += by;
}

internal sealed class FakeRunner : IProcessRunner
{
    public List<string> Commands { get; } = [];

    public Func<string, ProcessResult>? Handler { get; set; }

    public Task<ProcessResult> RunAsync(string command, string workingDirectory, TimeSpan timeout)
    {
        Commands.Add(command);
        var result = Handler?.Invoke(command) ?? Ok(command, string.Empty);
        if (result.Succeeded && result.Output.Length == 0 && command.StartsWith("git merge-base", StringComparison.Ordinal))
            result = Ok(command, "fixture-base");
        return Task.FromResult(result);
    }

    public static ProcessResult Ok(string command, string output) => new(command, 0, output, TimeSpan.FromSeconds(1), false);

    public static ProcessResult Fail(string command, string output) => new(command, 1, output, TimeSpan.FromSeconds(1), false);
}

internal sealed class TestRepo : IDisposable
{
    public TestRepo(bool git = true, bool src = true)
    {
        Root = Path.Combine(Path.GetTempPath(), "sdd-tests-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(Root);
        if (git)
        {
            Directory.CreateDirectory(Path.Combine(Root, ".git"));
        }

        if (src)
        {
            Directory.CreateDirectory(Path.Combine(Root, "src"));
        }
    }

    public string Root { get; }

    public static string FixtureFolder => Path.Combine(AppContext.BaseDirectory, "Fixtures", "306400");

    public string AddFile(string relative, string content)
    {
        var path = Path.Combine(Root, relative);
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        File.WriteAllText(path, content);
        return path;
    }

    public void AddDabSignature() =>
        AddFile("src/AN.ColorAppsAzure.Formula/GraphqlAssets/Formula.graphql", "query Formula_Get { id }");

    public ImportResult ImportFixture() => PbiImporter.Import(FixtureFolder, Root);

    public void Dispose()
    {
        if (Directory.Exists(Root))
        {
            Directory.Delete(Root, recursive: true);
        }
    }
}

internal static class ArtifactFiller
{
    /// <summary>Replaces every sdd:fill marker and TBD the way the agent does after repository analysis.</summary>
    public static void Complete(string specPath, string planPath)
    {
        var spec = File.ReadAllText(specPath);
        spec = ReplaceMarkers(spec, "R-1 (AC-01) The system SHALL increment the major version. Evidence: `Formula.Application/PaintSystem/ComplaintHandler.cs > ComplaintHandler > Handle`.");
        spec = spec.Replace("| TBD | TBD |", "| MISSING | `ComplaintHandler.cs > ComplaintHandler > Handle` |", StringComparison.Ordinal);
        File.WriteAllText(specPath, spec);

        var plan = File.ReadAllText(planPath);
        plan = ReplaceMarkers(plan, "- [ ] T1 [BE] `ComplaintHandler.cs` - implement Complaint PS rules (AC-01..AC-11)\n- [ ] T2 [T] `ComplaintHandlerTests.cs` - tests for every AC");
        plan = plan.Replace("| TBD | TBD | TBD |", "| Yes | TBD | TBD |", StringComparison.Ordinal);
        plan = plan.Replace("| TBD | TBD |", "| `ComplaintHandler.cs > ComplaintHandler > Handle` | `ComplaintHandlerTests.Handle_Ac` |", StringComparison.Ordinal);
        File.WriteAllText(planPath, plan);
    }

    private static string ReplaceMarkers(string text, string replacement)
    {
        while (true)
        {
            var start = text.IndexOf("<!-- sdd:fill", StringComparison.Ordinal);
            if (start < 0)
            {
                return text;
            }

            var end = text.IndexOf("-->", start, StringComparison.Ordinal) + 3;
            text = text[..start] + replacement + text[end..];
        }
    }
}

internal static class TestData
{
    public const string Trx = """
        <?xml version="1.0" encoding="utf-8"?>
        <TestRun xmlns="http://microsoft.com/schemas/VisualStudio/TeamTest/2010">
          <ResultSummary outcome="Completed">
            <Counters total="12" executed="12" passed="12" failed="0" />
          </ResultSummary>
        </TestRun>
        """;

    public const string TrxZero = """
        <?xml version="1.0" encoding="utf-8"?>
        <TestRun xmlns="http://microsoft.com/schemas/VisualStudio/TeamTest/2010">
          <ResultSummary outcome="Completed"><Counters total="0" executed="0" passed="0" failed="0" /></ResultSummary>
        </TestRun>
        """;

    public const string TrxNoCounters = """
        <?xml version="1.0" encoding="utf-8"?>
        <TestRun xmlns="http://microsoft.com/schemas/VisualStudio/TeamTest/2010"><ResultSummary outcome="Completed" /></TestRun>
        """;

    public static string Cobertura(string file, int covered, int total)
    {
        var lines = string.Concat(Enumerable.Range(1, total).Select(i => $"<line number=\"{i}\" hits=\"{(i <= covered ? 1 : 0)}\" />"));
        return $"""
            <?xml version="1.0"?>
            <coverage><packages><package><classes>
            <class name="X" filename="{file}"><lines>{lines}</lines></class>
            </classes></package></packages></coverage>
            """;
    }
}
