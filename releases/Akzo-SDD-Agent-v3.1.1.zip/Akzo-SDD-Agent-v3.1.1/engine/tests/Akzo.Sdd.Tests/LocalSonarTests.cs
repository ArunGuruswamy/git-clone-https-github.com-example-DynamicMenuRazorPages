using Akzo.Sdd.Core.Execution;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Verification;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class LocalSonarTests
{
    private const string Handler = "src/Formula.Application/PaintSystem/CreatePaintSystemHandler.cs";
    private const string Validator = "src/Formula.Application/PaintSystem/ComplaintPaintSystemValidator.cs";

    private static string Warnings(string root) => $"""
        {root}/{Handler}(41,30): warning S1541: The Cyclomatic Complexity of this method is 15 which is greater than 10 authorized. (https://rules.sonarsource.com/csharp/RSPEC-1541) [{root}/src/Formula.Application/Formula.Application.csproj]
        {root}/{Handler}(12,18): warning S1200: Split this class into smaller and more specialized ones to reduce its dependencies on other types from 32 to the maximum authorized 30 or less. (https://rules.sonarsource.com/csharp/RSPEC-1200) [{root}/x.csproj]
        {root}/{Handler}(88,40): warning CS1573: Parameter 'isComplaint' has no matching param tag in the XML comment for 'CreatePaintSystemHandler.CreateLinkedColorAsync(CreatePaintSystemRequest, Guid, string, bool)' (but other parameters do) [{root}/x.csproj]
        {root}/{Validator}(20,5): warning S1541: The Cyclomatic Complexity of this method is 13 which is greater than 10 authorized. [{root}/x.csproj]
        {root}/src/Legacy/Old.cs(5,5): warning S1135: Complete the task associated to this 'TODO' comment. [{root}/x.csproj]
        {root}/src/Data/Generated/Client.cs(5,5): warning CS8618: Non-nullable property must contain a non-null value. [{root}/x.csproj]
        {root}/{Handler}(41,30): warning S1541: The Cyclomatic Complexity of this method is 15 which is greater than 10 authorized. [{root}/src/Formula.Application/Formula.Application.csproj]
        Build succeeded.
        """;

    [TestMethod]
    public void Regression_Pr55783_AllFourDiagnosticsBlockChangedFiles()
    {
        using var repo = new TestRepo();
        const string collaborator = "src/ComplaintPaintSystemCollaborator.cs";
        const string validator = "src/ComplaintPaintSystemValidator.cs";
        var output = $"{collaborator}(5,5): warning CS0169: field is never used\n"
            + $"{collaborator}(5,5): warning CS8618: field must contain a non-null value\n"
            + $"{collaborator}(5,5): warning S1144: remove unused private field\n"
            + $"{validator}(8,5): warning S3242: use IReadOnlyCollection instead\n";
        var issues = LocalSonarAnalysis.Parse(output, repo.Root);
        var result = LocalSonarAnalysis.Gate(issues, [collaborator, validator], LocalSonarAnalysis.DefaultAnalyzerVersion);
        Assert.AreEqual(GateStatus.Fail, result.Gate.Status);
        CollectionAssert.AreEquivalent(new[] { "CS0169", "CS8618", "S1144", "S3242" }, result.InChangedFiles.Select(i => i.Rule).ToArray());
    }

    [TestMethod]
    public void Regression_Pr55783_RulesExplicitlyRequestedInGeneratedConfiguration()
    {
        using var repo = new TestRepo();
        LocalSonarAnalysis.Prepare(repo.Root, LocalSonarAnalysis.DefaultAnalyzerVersion);
        var config = File.ReadAllText(Path.Combine(repo.Root, "sdd.sonar.globalconfig"));
        foreach (var rule in new[] { "CS0169", "CS8618", "S1144", "S3242" })
            StringAssert.Contains(config, $"dotnet_diagnostic.{rule}.severity = warning");
    }

    [TestMethod]
    public void Applies_OnlyToDotnetAndMsbuild()
    {
        Assert.IsTrue(LocalSonarAnalysis.Applies("dotnet build AN.ColorAppsAzure.BL.sln"));
        Assert.IsTrue(LocalSonarAnalysis.Applies("  msbuild x.sln /p:Configuration=Debug"));
        Assert.IsTrue(LocalSonarAnalysis.Applies("dotnet msbuild x.sln"));
        Assert.IsFalse(LocalSonarAnalysis.Applies("npx ng build"));
        Assert.IsFalse(LocalSonarAnalysis.Applies(null!));
    }

    [TestMethod]
    public void PrepareAndAugment_InjectAnalyzerLikeTheScanner()
    {
        using var repo = new TestRepo();
        var targets = LocalSonarAnalysis.Prepare(Path.Combine(repo.Root, "r"), "9.32.0.97167");

        var xml = File.ReadAllText(targets);
        StringAssert.Contains(xml, "<PackageReference Include=\"SonarAnalyzer.CSharp\" Version=\"9.32.0.97167\"");
        StringAssert.Contains(xml, "<PackageVersion Include=\"SonarAnalyzer.CSharp\"");
        StringAssert.Contains(xml, "<EditorConfigFiles Include=");
        var config = File.ReadAllText(Path.Combine(repo.Root, "r", "sdd.sonar.globalconfig"));
        StringAssert.Contains(config, "dotnet_diagnostic.S1541.severity = warning");
        StringAssert.Contains(config, "dotnet_diagnostic.S1200.severity = warning");

        Assert.AreEqual($"dotnet build x.sln --no-incremental -p:CustomBeforeMicrosoftCommonTargets=\"{targets}\"", LocalSonarAnalysis.Augment("dotnet build x.sln ", targets));
        StringAssert.StartsWith(LocalSonarAnalysis.Augment("msbuild x.sln", "t"), "msbuild x.sln -t:Rebuild -p:CustomBeforeMicrosoftCommonTargets=\"t\"");
    }

    [TestMethod]
    public void Parse_MakesPathsRelativeStripsLinksAndDeduplicates()
    {
        using var repo = new TestRepo();
        var root = repo.Root.Replace('\\', '/');

        var issues = LocalSonarAnalysis.Parse(Warnings(root), repo.Root);

        Assert.AreEqual(6, issues.Count);
        var first = issues[0];
        Assert.AreEqual(Handler, first.File);
        Assert.AreEqual(41, first.Line);
        Assert.AreEqual("S1541", first.Rule);
        Assert.AreEqual("The Cyclomatic Complexity of this method is 15 which is greater than 10 authorized.", first.Message);
        Assert.AreEqual(0, LocalSonarAnalysis.Parse(null!, repo.Root).Count);
        Assert.AreEqual("C:/other/A.cs", LocalSonarAnalysis.Parse("C:\\other\\A.cs(1,1): warning S1: m", repo.Root)[0].File);
    }

    [TestMethod]
    public void Gate_FailsOnChangedFilesOnly_IgnoresGeneratedAndUnchanged()
    {
        using var repo = new TestRepo();
        var issues = LocalSonarAnalysis.Parse(Warnings(repo.Root.Replace('\\', '/')), repo.Root);

        var (gate, found) = LocalSonarAnalysis.Gate(issues, [Handler, Validator, "src/Data/Generated/Client.cs", "README.md"], "9.32");

        Assert.AreEqual(GateStatus.Fail, gate.Status);
        Assert.AreEqual(4, found.Count);
        StringAssert.Contains(gate.Detail, "4 issue(s) in changed files - SonarCloud will report them on the PR");
        StringAssert.Contains(gate.Detail, $"{Handler}:12 S1200 Split this class");
        StringAssert.Contains(gate.Detail, $"{Handler}:88 CS1573 Parameter 'isComplaint'");
        StringAssert.Contains(gate.Detail, $"{Validator}:20 S1541");

        var (clean, none) = LocalSonarAnalysis.Gate(issues, ["src/Other.cs"], "9.32");
        Assert.AreEqual(GateStatus.Pass, clean.Status);
        Assert.AreEqual(0, none.Count);
        StringAssert.Contains(clean.Detail, "0 issues in 1 changed C# file(s)");
        StringAssert.Contains(clean.Detail, "S1541 cyclomatic complexity <= 10 per method");

        var many = Enumerable.Range(1, 12).Select(i => new CodeIssue(Handler, i, "S1", "m")).ToList();
        StringAssert.Contains(LocalSonarAnalysis.Gate(many, [Handler], "v").Gate.Detail, "and 2 more (verification.json)");
    }

    [TestMethod]
    public void IsAnalyzerUnavailable_DetectsRestoreFailure()
    {
        Assert.IsTrue(LocalSonarAnalysis.IsAnalyzerUnavailable("error NU1101: Unable to find package SonarAnalyzer.CSharp."));
        Assert.IsTrue(LocalSonarAnalysis.IsAnalyzerUnavailable("error NU1301: Unable to load the service index for source https://pkgs.dev.azure.com/x - 401 (Unauthorized)"));
        Assert.IsFalse(LocalSonarAnalysis.IsAnalyzerUnavailable("Build succeeded."));
        Assert.IsFalse(LocalSonarAnalysis.IsAnalyzerUnavailable(null!));
    }

    [TestMethod]
    public async Task Verify_RunsSonarGateOnChangedFiles()
    {
        var (ws, state, runner, root) = Setup();
        runner.Handler = cmd => cmd switch
        {
            _ when cmd.StartsWith("git status", StringComparison.Ordinal) => FakeRunner.Ok(cmd, $" M {Handler}\n"),
            _ when cmd.StartsWith("git", StringComparison.Ordinal) => FakeRunner.Ok(cmd, string.Empty),
            _ when cmd.StartsWith("dotnet build", StringComparison.Ordinal) => FakeRunner.Ok(cmd, Warnings(root)),
            _ => FakeRunner.Ok(cmd, "Tests: 3 passed, 3 total"),
        };

        var report = await new VerificationService(runner, new FakeClock()).RunAsync(ws, state, Options(sonar: true));

        StringAssert.Contains(runner.Commands[0], "-p:CustomBeforeMicrosoftCommonTargets=");
        var gate = report.Gates.Single(g => g.Name == LocalSonarAnalysis.GateName);
        Assert.AreEqual(GateStatus.Fail, gate.Status);
        Assert.AreEqual(3, report.CodeIssues.Count);
        Assert.IsFalse(report.Passed);

        var off = await new VerificationService(runner, new FakeClock()).RunAsync(ws, state, Options(sonar: false));
        Assert.IsFalse(off.Gates.Exists(g => g.Name == LocalSonarAnalysis.GateName));
    }

    [TestMethod]
    public async Task Verify_AnalyzerUnavailable_RebuildsWithoutItAndReportsNotExecuted()
    {
        var (ws, state, runner, _) = Setup();
        runner.Handler = cmd => cmd switch
        {
            _ when cmd.Contains("CustomBeforeMicrosoftCommonTargets", StringComparison.Ordinal) => FakeRunner.Fail(cmd, "error NU1301: Unable to load the service index; SonarAnalyzer.CSharp"),
            _ when cmd.StartsWith("git", StringComparison.Ordinal) => FakeRunner.Ok(cmd, string.Empty),
            _ => FakeRunner.Ok(cmd, "Tests: 1 passed, 1 total"),
        };

        var report = await new VerificationService(runner, new FakeClock()).RunAsync(ws, state, Options(sonar: true));

        Assert.AreEqual(GateStatus.Pass, report.Gates[0].Status);
        var gate = report.Gates.Single(g => g.Name == LocalSonarAnalysis.GateName);
        Assert.AreEqual(GateStatus.NotExecuted, gate.Status);
        StringAssert.Contains(gate.Detail, "\"localSonar\": false");
        Assert.AreEqual(2, runner.Commands.Count(c => c.StartsWith("dotnet build", StringComparison.Ordinal)));
    }

    [TestMethod]
    public async Task Verify_BuildFailure_SonarNotExecuted()
    {
        var (ws, state, runner, _) = Setup();
        runner.Handler = cmd => cmd.StartsWith("git", StringComparison.Ordinal) ? FakeRunner.Ok(cmd, string.Empty) : FakeRunner.Fail(cmd, "x.cs(1,1): error CS1002: ; expected");

        var report = await new VerificationService(runner, new FakeClock()).RunAsync(ws, state, Options(sonar: true));

        Assert.AreEqual("Build failed.", report.Gates.Single(g => g.Name == LocalSonarAnalysis.GateName).Detail);
    }

    [TestMethod]
    public void BuildGate_ExplainsFeedAuthenticationFailure()
    {
        var gate = VerificationService.BuildGate(FakeRunner.Fail("dotnet build", "error NU1301: Unable to load the service index for source https://pkgs.dev.azure.com/x. Response status code does not indicate success: 401 (Unauthorized)."));

        Assert.AreEqual(GateStatus.Fail, gate.Status);
        StringAssert.Contains(gate.Detail, "dotnet restore <solution> --interactive");
        StringAssert.Contains(VerificationService.BuildGate(FakeRunner.Fail("dotnet build", "Response 401 (Unauthorized)")).Detail, "--interactive");
    }

    [TestMethod]
    public void Settings_DefaultToLocalSonarOn()
    {
        using var repo = new TestRepo();
        var settings = SddSettings.Load(repo.Root);
        Assert.IsTrue(settings.LocalSonar);
        Assert.AreEqual(LocalSonarAnalysis.DefaultAnalyzerVersion, settings.SonarAnalyzerVersion);
    }

    private static VerificationOptions Options(bool sonar) =>
        new("targeted", "dotnet build x.sln", "dotnet test", 0, ChangedOnly: true, TimeSpan.FromMinutes(1), "origin/develop") { LocalSonar = sonar };

    private static (SddWorkspace Ws, SddState State, FakeRunner Runner, string Root) Setup()
    {
        var repo = new TestRepo();
        var ws = new SddWorkspace(repo.Root, new FakeClock());
        var state = new SddState { PbiId = "1", Feature = "F", Role = ProjectRole.Dab };
        ws.Save(state);
        return (ws, state, new FakeRunner(), repo.Root.Replace('\\', '/'));
    }
}
