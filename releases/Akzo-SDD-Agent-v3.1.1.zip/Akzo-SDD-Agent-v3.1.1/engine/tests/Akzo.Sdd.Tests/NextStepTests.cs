using System.Text.Json;
using Akzo.Sdd.Core;
using Akzo.Sdd.Core.Approval;
using Akzo.Sdd.Core.Cli;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Questions;
using Akzo.Sdd.Core.Services;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Verification;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class NextStepTests
{
    private TestRepo _repo = null!;
    private FakeClock _clock = null!;

    [TestInitialize]
    public void Init()
    {
        _repo = new TestRepo();
        _repo.AddDabSignature();
        _clock = new FakeClock();
    }

    [TestCleanup]
    public void Cleanup() => _repo.Dispose();

    [TestMethod]
    public void Decide_WalksTheWholeDeliveryFlow()
    {
        StartService.Start(new StartOptions(_repo.Root, "306400", TestRepo.FixtureFolder, ProjectRole.Unknown, null), _clock);
        var ws = new SddWorkspace(_repo.Root, _clock);
        var state = ws.Load();
        var package = PbiPackageReader.Read(ws.Absolute(state.PackageFolder));
        Assert.AreEqual(NextStep.CompleteAnalysis, NextStepService.Decide(ws, state, package));

        ArtifactFiller.Complete(ws.Absolute(state.SpecPath), ws.Absolute(state.PlanPath));
        Assert.AreEqual(NextStep.Approve, NextStepService.Decide(ws, state, package));

        AnswerService.Answer(ws, state, package, QuestionBuilder.BusinessId, "proceed", null);
        AnswerService.Answer(ws, state, package, "Q-D-01", "accept", "Routing gap tracked as separate PBI");
        AnswerService.Answer(ws, state, package, QuestionBuilder.FitId, "here", null);
        ApprovalService.Approve(ws, state, package, "Approve", "Arun");
        Assert.AreEqual(NextStep.Implement, NextStepService.Decide(ws, state, package));
        StringAssert.Contains(NextStepService.Render(ws, state, package), "remaining T1, T2");

        state.Tasks.Add(new TaskCheckpoint { Id = "T1" });
        state.Tasks.Add(new TaskCheckpoint { Id = "T2" });
        Assert.AreEqual(NextStep.Verify, NextStepService.Decide(ws, state, package));
        StringAssert.Contains(NextStepService.Render(ws, state, package), "| Verification | NOT EXECUTED |");

        WriteVerification(ws, state, passed: false);
        Assert.AreEqual(NextStep.Verify, NextStepService.Decide(ws, state, package));

        WriteVerification(ws, state, passed: true);
        Assert.AreEqual(NextStep.Review, NextStepService.Decide(ws, state, package));
        var review = NextStepService.Render(ws, state, package);
        StringAssert.Contains(review, "## Implementation complete - PBI 306400 ComplaintPaintSystem");
        StringAssert.Contains(review, "targeted PASS - tests 1971/1971, coverage 91.23% (>= 90%)");
        StringAssert.Contains(review, "**Akzo SDD Reviewer**");
        StringAssert.Contains(review, "Pending - developer chose 'proceed'");
        StringAssert.Contains(review, "Q-D-01: Routing gap tracked as separate PBI");

        var reviewPath = ws.ChangeFile(state, SddConstants.ReviewFile);
        File.WriteAllText(reviewPath, "| Item | Value |\n|---|---|\n| Verdict | CHANGES REQUIRED |\n");
        File.SetLastWriteTimeUtc(reviewPath, DateTime.UtcNow.AddMinutes(5));
        Assert.AreEqual(NextStep.FixFindings, NextStepService.Decide(ws, state, package));
        StringAssert.Contains(NextStepService.Render(ws, state, package), "`Fix review findings`");
        StringAssert.Contains(NextStepService.Render(ws, state, package), "click **Keep**");

        File.SetLastWriteTimeUtc(reviewPath, DateTime.UtcNow.AddMinutes(-5));
        Assert.AreEqual(NextStep.Review, NextStepService.Decide(ws, state, package));

        File.WriteAllText(ws.ChangeFile(state, SddConstants.ReviewFile), "| Item | Value |\n|---|---|\n| Verdict | READY FOR PR |\n");
        Assert.AreEqual(NextStep.FinalizePr, NextStepService.Decide(ws, state, package));
        StringAssert.Contains(NextStepService.Render(ws, state, package), "sdd verify --scope final");

        state.Phase = SddPhase.PrReady;
        Assert.AreEqual(NextStep.RaisePr, NextStepService.Decide(ws, state, package));
        var done = NextStepService.Render(ws, state, package);
        StringAssert.Contains(done, "docs/sdd/changes/306400-ComplaintPaintSystem/pr-description.md");
        StringAssert.Contains(done, "| Spec / plan (check in with the PR) | `" + state.SpecPath + "`");
        StringAssert.Contains(NextStepService.Render(ws, state, package), "sdd commit-dialog");
    }

    [TestMethod]
    public void Render_ApprovedPbiAndMissingTestCounts()
    {
        StartService.Start(new StartOptions(_repo.Root, "306400", TestRepo.FixtureFolder, ProjectRole.Unknown, null), _clock);
        var ws = new SddWorkspace(_repo.Root, _clock);
        var state = ws.Load();
        var package = PbiPackageReader.Read(ws.Absolute(state.PackageFolder));
        var approved = new PbiPackage { Id = package.Id, Title = package.Title, Folder = package.Folder, RefinedText = package.RefinedText, BusinessApproval = "Approved" };
        File.WriteAllText(ws.ChangeFile(state, SddConstants.VerificationFile), JsonSerializer.Serialize(new VerificationReport { Scope = "targeted", Gates = [new GateResult("Build", GateStatus.Fail, "x")] }, Json.Options));

        var text = NextStepService.Render(ws, state, approved);

        StringAssert.Contains(text, "| Business approval | Approved |");
        StringAssert.Contains(text, "targeted FAIL - tests n/a, coverage n/a");
        StringAssert.Contains(text, "| Review | not started |");
    }

    [TestMethod]
    public async Task Cli_NextPrintsReport()
    {
        using var output = new StringWriter();
        using var http = new HttpClient();
        var app = new SddApp(new FakeRunner(), _clock, http, output);
        await app.RunAsync(["start", "306400", "--source", TestRepo.FixtureFolder, "--repo", _repo.Root]);

        Assert.AreEqual(SddApp.Ok, await app.RunAsync(["next", "--repo", _repo.Root]));
        StringAssert.Contains(output.ToString(), "## Analysis in progress - PBI 306400");
    }

    private static void WriteVerification(SddWorkspace ws, SddState state, bool passed)
    {
        var report = new VerificationReport
        {
            Scope = "targeted",
            Threshold = 90,
            CoveragePercent = 91.23,
            Tests = new TestCounts(1971, 1971, 1971, 0, "trx"),
            Gates = [new GateResult("Build", GateStatus.Pass, "ok"), new GateResult("Coverage", passed ? GateStatus.Pass : GateStatus.Fail, "x")],
        };
        File.WriteAllText(ws.ChangeFile(state, SddConstants.VerificationFile), JsonSerializer.Serialize(report, Json.Options));
    }
}
