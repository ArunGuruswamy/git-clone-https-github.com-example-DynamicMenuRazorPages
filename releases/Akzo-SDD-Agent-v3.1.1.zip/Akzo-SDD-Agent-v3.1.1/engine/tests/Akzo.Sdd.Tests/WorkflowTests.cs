using Akzo.Sdd.Core;
using Akzo.Sdd.Core.Approval;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Questions;
using Akzo.Sdd.Core.Services;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class WorkflowTests
{
    private TestRepo _repo = null!;
    private FakeClock _clock = null!;

    [TestInitialize]
    public void Init()
    {
        _repo = new TestRepo();
        _repo.AddDabSignature();
        _clock = new FakeClock();
    }

    [TestCleanup]
    public void Cleanup() => _repo.Dispose();

    [TestMethod]
    public void Start_FromNestedFolderWithZipSource_WritesArtifactsAndQuestions()
    {
        var result = Start($"Start Development 306400 Creation of Complaint PaintSystem (source: {TestRepo.FixtureFolder})", Path.Combine(_repo.Root, "src"));

        Assert.AreEqual("Initialized", result.Status);
        Assert.AreEqual(ProjectRole.Dab, result.Role);
        Assert.AreEqual("dab-development", result.Skill);
        Assert.AreEqual("ComplaintPaintSystem", result.Feature);
        Assert.IsTrue(result.SpecCreated && result.PlanCreated);
        StringAssert.EndsWith(result.SpecPath.Replace('\\', '/'), "src/.github/specs/ComplaintPaintSystem/spec.md");
        CollectionAssert.AreEqual(
            new[] { QuestionBuilder.FeatureId, QuestionBuilder.BusinessId, QuestionBuilder.FitId, "Q-D-01", QuestionBuilder.ModeId },
            result.Questions.Select(q => q.Id).ToArray());
        Assert.IsTrue(result.Findings.Count > 0);
        StringAssert.Contains(result.PackageSummary, "11 AC");
        Assert.IsTrue(File.Exists(Path.Combine(result.ChangeFolder, SddConstants.QuestionsFile)));
    }

    [TestMethod]
    public void Start_Again_ResumesAndPreservesEditedSpec()
    {
        var first = Start("306400", source: TestRepo.FixtureFolder);
        File.AppendAllText(first.SpecPath, "\nedited by agent\n");

        var second = Start("Start Development 306400");

        Assert.AreEqual("Resumed", second.Status);
        Assert.IsFalse(second.SpecCreated);
        StringAssert.Contains(File.ReadAllText(second.SpecPath), "edited by agent");
    }

    [TestMethod]
    public void Start_NotFoundAndAmbiguous()
    {
        var missing = Start("Start Development 999");
        Assert.AreEqual(ErrorCodes.PbiNotFound, missing.Status);
        Assert.AreEqual(0, missing.Questions.Count);

        _repo.ImportFixture();
        _repo.AddFile("docs/sdd/pbi-input/111/REFINED-PBI.md", "# 111 - Other");
        var ambiguous = Start("Start Development");
        Assert.AreEqual(ErrorCodes.PbiAmbiguous, ambiguous.Status);
        Assert.AreEqual("Q-PBI", ambiguous.Questions[0].Id);
    }

    [TestMethod]
    public void Start_ExplicitRoleAndFeatureWin_UnknownRoleAsksQuestion()
    {
        _repo.ImportFixture();
        var explicitResult = StartService.Start(new StartOptions(_repo.Root, "306400", null, ProjectRole.Ui, "MyFeature"), _clock);
        Assert.AreEqual(ProjectRole.Ui, explicitResult.Role);
        Assert.AreEqual("MyFeature", explicitResult.Feature);

        using var plain = new TestRepo();
        plain.ImportFixture();
        var unknown = StartService.Start(new StartOptions(plain.Root, "306400", null, ProjectRole.Unknown, null), _clock);
        Assert.AreEqual(string.Empty, unknown.Skill);
        Assert.AreEqual(QuestionBuilder.RoleId, unknown.Questions[0].Id);
        Assert.AreEqual(3, unknown.Questions[0].Options.Count);
    }

    [TestMethod]
    public void Questions_RenderAndResolve()
    {
        var q = new ChoiceQuestion("Q-X", "Pick?", [new ChoiceOption("a", "A", "first"), new ChoiceOption("b", "B", "second")], "b", true, QuestionStage.Start);

        Assert.AreEqual("a", q.Resolve("1")!.Key);
        Assert.AreEqual("b", q.Resolve(" B ")!.Key);
        Assert.IsNull(q.Resolve("3"));
        Assert.IsNull(q.Resolve(null!));
        var md = q.ToMarkdown();
        StringAssert.Contains(md, "**Q-X** (required) Pick?");
        StringAssert.Contains(md, "2. B (Recommended) - second");
    }

    [TestMethod]
    public void Questions_ApprovalAndDeliveryStages()
    {
        var (_, state, package) = Started();

        var approval = QuestionBuilder.Build(QuestionStage.Approval, package, state, [], []);
        var delivery = QuestionBuilder.Build(QuestionStage.Delivery, package, state, [], []);

        Assert.AreEqual(QuestionBuilder.ApproveId, approval[0].Id);
        CollectionAssert.AreEqual(new[] { QuestionBuilder.ReviewId, QuestionBuilder.PrId }, delivery.Select(d => d.Id).ToArray());
    }

    [TestMethod]
    public void Questions_OpenQuestionAndApprovedPbi()
    {
        var package = new PbiPackage
        {
            Id = "1",
            Title = "T",
            Folder = ".",
            RefinedText = "# 1 - T",
            BusinessApproval = "Approved",
            OpenQuestions = [new OpenQuestion("Q-01", "Which?", "High", "PO", "Open"), new OpenQuestion("7", "Other?", string.Empty, "PO", "Open")],
        };
        var state = new SddState { Role = ProjectRole.Dab, Feature = "T" };

        var ids = QuestionBuilder.Build(QuestionStage.Start, package, state, [], ["T"]).Select(q => q.Id).ToList();

        CollectionAssert.DoesNotContain(ids, QuestionBuilder.BusinessId);
        CollectionAssert.Contains(ids, "Q-01");
        CollectionAssert.Contains(ids, "Q-7");
        Assert.AreEqual(2, QuestionBuilder.ApprovalBlockers(package, state).Count);
    }

    [TestMethod]
    public void Answer_RecordsModeNoteAndRejectsUnknown()
    {
        var (ws, state, package) = Started();

        AnswerService.Answer(ws, state, package, "q-mode", "2", null);
        AnswerService.Answer(ws, state, package, "Q-D-01", "accept", "Confirmed by PO in refinement call");

        var saved = ws.Load();
        Assert.AreEqual("STEP", saved.Mode);
        Assert.AreEqual("accept", saved.Answers["Q-D-01"]);
        Assert.AreEqual("Confirmed by PO in refinement call", saved.AnswerNotes["Q-D-01"]);
        Assert.ThrowsException<SddException>(() => AnswerService.Answer(ws, state, package, "Q-NOPE", "1", null));
        Assert.ThrowsException<SddException>(() => AnswerService.Answer(ws, state, package, "Q-MODE", "9", null));
    }

    [TestMethod]
    public void Answer_Role_RegeneratesUntouchedPlanOnly()
    {
        using var plain = new TestRepo();
        plain.ImportFixture();
        StartService.Start(new StartOptions(plain.Root, "306400", null, ProjectRole.Unknown, null), _clock);
        var ws = new SddWorkspace(plain.Root, _clock);
        var state = ws.Load();
        var package = PbiPackageReader.Read(ws.Absolute(state.PackageFolder));

        AnswerService.Answer(ws, state, package, QuestionBuilder.RoleId, "ui", null);
        StringAssert.Contains(File.ReadAllText(ws.Absolute(state.PlanPath)), "npx jest");

        File.AppendAllText(ws.Absolute(state.PlanPath), "agent edit");
        state.Answers.Remove(QuestionBuilder.RoleId);
        state.Role = ProjectRole.Unknown;
        AnswerService.Answer(ws, state, package, QuestionBuilder.RoleId, "cdms", null);
        StringAssert.Contains(File.ReadAllText(ws.Absolute(state.PlanPath)), "agent edit");
        Assert.AreEqual(ProjectRole.Cdms, ws.Load().Role);
    }

    [TestMethod]
    public void Answer_Feature_RenamesFoldersBeforeApprovalOnly()
    {
        var (ws, state, package) = Started();

        AnswerService.Answer(ws, state, package, QuestionBuilder.FeatureId, "ComplaintPaintSystem", null);
        AnswerService.Answer(ws, state, package, QuestionBuilder.FeatureId, "CreationOfComplaintPaintSystem", null);

        var saved = ws.Load();
        Assert.AreEqual("CreationOfComplaintPaintSystem", saved.Feature);
        Assert.IsTrue(File.Exists(ws.Absolute(saved.SpecPath)));
        StringAssert.StartsWith(File.ReadAllText(ws.Absolute(saved.SpecPath)), "# CreationOfComplaintPaintSystem - Specification");
        Assert.IsTrue(Directory.Exists(ws.ChangeFolder(saved)));

        Directory.CreateDirectory(Path.Combine(Path.GetDirectoryName(Path.GetDirectoryName(ws.Absolute(saved.SpecPath))!)!, "ComplaintPaintSystem"));
        Assert.ThrowsException<SddException>(() => AnswerService.Answer(ws, saved, package, QuestionBuilder.FeatureId, "ComplaintPaintSystem", null));

        saved.Phase = SddPhase.Implement;
        Assert.ThrowsException<SddException>(() => AnswerService.Answer(ws, saved, package, QuestionBuilder.FeatureId, "1", null));
    }

    [TestMethod]
    public void Approve_RefusedUntilCompleteAndAnswered_ThenHashBound()
    {
        var (ws, state, package) = Started();
        var refused = Assert.ThrowsException<SddException>(() => ApprovalService.Approve(ws, state, package, "go", "Arun"));
        StringAssert.Contains(refused.Message, "Q-BIZ unanswered");

        ArtifactFiller.Complete(ws.Absolute(state.SpecPath), ws.Absolute(state.PlanPath));
        AnswerService.Answer(ws, state, package, QuestionBuilder.BusinessId, "wait", null);
        AnswerService.Answer(ws, state, package, QuestionBuilder.FitId, "here", null);
        AnswerService.Answer(ws, state, package, "Q-D-01", "accept", null);
        StringAssert.Contains(Assert.ThrowsException<SddException>(() => ApprovalService.Approve(ws, state, package, "go", "Arun")).Message, "answered 'wait'");

        AnswerService.Answer(ws, state, package, QuestionBuilder.BusinessId, "proceed", null);
        var record = ApprovalService.Approve(ws, state, package, "Approve implementation", "Arun");

        Assert.AreEqual(SddPhase.Implement, ws.Load().Phase);
        Assert.IsFalse(record.PbiBusinessApproved);
        Assert.AreEqual(7, record.Hashes.Count);
        Assert.AreEqual(0, ApprovalService.ChangedSinceApproval(ws, state, ApprovalService.Load(ws, state)!).Count);

        File.AppendAllText(ws.Absolute(state.PlanPath), "\nchanged");
        CollectionAssert.Contains(ApprovalService.ChangedSinceApproval(ws, state, record).ToList(), state.PlanPath);
    }

    private StartResult Start(string request, string? folder = null, string? source = null) =>
        StartService.Start(new StartOptions(folder ?? _repo.Root, request, source, ProjectRole.Unknown, null), _clock);

    private (SddWorkspace Ws, SddState State, PbiPackage Package) Started()
    {
        Start("Start Development 306400 Creation of Complaint PaintSystem", source: TestRepo.FixtureFolder);
        var ws = new SddWorkspace(_repo.Root, _clock);
        var state = ws.Load();
        return (ws, state, PbiPackageReader.Read(ws.Absolute(state.PackageFolder)));
    }
}
