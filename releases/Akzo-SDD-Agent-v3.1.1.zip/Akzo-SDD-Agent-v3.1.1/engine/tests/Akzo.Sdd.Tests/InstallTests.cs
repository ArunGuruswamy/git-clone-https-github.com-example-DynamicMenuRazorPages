using Akzo.Sdd.Core;
using Akzo.Sdd.Core.Cli;
using Akzo.Sdd.Core.Services;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class InstallTests
{
    [TestMethod]
    public void Install_CreatesThenUpgradesUntouchedAndKeepsModified()
    {
        using var assets = new TestRepo(git: false, src: false);
        assets.AddFile("core/.github/agents/akzo-sdd.agent.md", "v1 agent");
        assets.AddFile("core/.github/sdd/workflow.md", "v1 workflow");
        assets.AddFile("dab/docs/architecture/A.md", "dab doc");
        assets.AddFile("ui/.github/instructions/ui.md", "ui only");
        using var repo = new TestRepo();

        var first = InstallService.Install(assets.Root, ProjectRole.Dab, repo.Root, force: false);
        Assert.AreEqual(3, first.Created.Count);
        Assert.IsFalse(File.Exists(Path.Combine(repo.Root, ".github/instructions/ui.md")));
        Assert.AreEqual(ProjectRole.Dab, SddSettings.Load(repo.Root).ConfiguredRole());
        StringAssert.Contains(File.ReadAllText(Path.Combine(repo.Root, ".git/info/exclude")), "docs/sdd/pbi-input/");

        File.WriteAllText(Path.Combine(repo.Root, ".github/sdd/workflow.md"), "team edit");
        assets.AddFile("core/.github/agents/akzo-sdd.agent.md", "v2 agent");
        assets.AddFile("core/.github/sdd/workflow.md", "v2 workflow");
        var second = InstallService.Install(assets.Root, ProjectRole.Dab, repo.Root, force: false);

        CollectionAssert.AreEqual(new[] { ".github/agents/akzo-sdd.agent.md" }, second.Updated.ToArray());
        CollectionAssert.AreEqual(new[] { ".github/sdd/workflow.md" }, second.KeptModified.ToArray());
        Assert.AreEqual(1, second.Unchanged.Count);
        Assert.AreEqual("team edit", File.ReadAllText(Path.Combine(repo.Root, ".github/sdd/workflow.md")));

        var third = InstallService.Install(assets.Root, ProjectRole.Dab, repo.Root, force: true);
        CollectionAssert.AreEqual(new[] { ".github/sdd/workflow.md" }, third.Updated.ToArray());
        Assert.AreEqual(2, File.ReadAllLines(Path.Combine(repo.Root, ".git/info/exclude")).Count(l => l.StartsWith("docs/", StringComparison.Ordinal)));
    }

    [TestMethod]
    public void Install_RoleFoldersAndErrors()
    {
        CollectionAssert.Contains(InstallService.Folders(ProjectRole.Cdms).ToList(), "backend");
        CollectionAssert.Contains(InstallService.Folders(ProjectRole.Ui).ToList(), "ui");
        CollectionAssert.Contains(InstallService.Folders(ProjectRole.Dab).ToList(), "dab");

        using var noGit = new TestRepo(git: false);
        using var assets = new TestRepo(git: false, src: false);
        assets.AddFile("core/x.md", "x");
        var result = InstallService.Install(assets.Root, ProjectRole.Ui, noGit.Root, force: false);
        Assert.AreEqual(1, result.Created.Count);
        Assert.ThrowsException<SddException>(() => InstallService.Install(noGit.Root, ProjectRole.Ui, noGit.Root, force: false));
    }

    [TestMethod]
    public async Task InstallCommand_UsesBundledAssetsAndValidatesRole()
    {
        using var repo = new TestRepo();
        using var output = new StringWriter();
        using var http = new HttpClient();
        var app = new SddApp(new FakeRunner(), new FakeClock(), http, output);

        Assert.AreEqual(SddApp.UsageError, await app.RunAsync(["install", "--repo", repo.Root]));
        using var assets = new TestRepo(git: false, src: false);
        assets.AddFile("core/.github/agents/a.agent.md", "a");
        repo.AddFile(".github/agents/a.agent.md", "team");
        Assert.AreEqual(SddApp.Ok, await app.RunAsync(["install", "--role", "cdms", "--repo", repo.Root, "--assets", assets.Root]));
        StringAssert.Contains(output.ToString(), "kept (agent file - rerun with --update-agents to replace): .github/agents/a.agent.md");
    }
}
