using System.Net;
using System.Runtime.InteropServices;
using System.Xml.Linq;
using Akzo.Sdd.Core;
using Akzo.Sdd.Core.Execution;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Verification;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class VerificationTests
{
    private const string Build = "dotnet build";
    private static readonly Uri SonarUri = new UriBuilder(Uri.UriSchemeHttps, "sonar.example").Uri;
    private const string Test = "dotnet test --results-directory \"{results}\"";

    [TestMethod]
    public void TrxParser_ReadsCountersAndSumsFolder()
    {
        using var repo = new TestRepo();
        repo.AddFile("r/a.trx", TestData.Trx);
        repo.AddFile("r/sub/b.trx", TestData.Trx);
        repo.AddFile("r/c.trx", TestData.TrxNoCounters);

        var counts = TrxParser.ParseFolder(Path.Combine(repo.Root, "r"))!;

        Assert.AreEqual(24, counts.Executed);
        Assert.AreEqual(24, counts.Passed);
        Assert.IsNull(TrxParser.ParseFolder(Path.Combine(repo.Root, "none")));
        Assert.IsNull(TrxParser.Parse(Path.Combine(repo.Root, "r", "c.trx")));
    }

    [TestMethod]
    public void JestSummary_ParsesLastSummary()
    {
        var counts = ConsoleSummaryParser.ParseJest("Tests: 9 passed, 9 total\nTests:       1 failed, 12 passed, 13 total\n")!;

        Assert.AreEqual(13, counts.Total);
        Assert.AreEqual(13, counts.Executed);
        Assert.AreEqual(1, counts.Failed);
        Assert.IsNull(ConsoleSummaryParser.ParseJest("nothing"));
        Assert.IsNull(ConsoleSummaryParser.ParseJest(null!));
    }

    [TestMethod]
    public void BuildOutputInspector_FlagsErrorsAndStaleBuilds()
    {
        var problems = BuildOutputInspector.Inspect("x.cs(1,1): error CS0234: missing\nerror CS0234 again\nContinuing with last successful build");

        Assert.AreEqual(2, problems.Count);
        StringAssert.Contains(problems[0], "CS0234");
        Assert.AreEqual(0, BuildOutputInspector.Inspect("Build succeeded. 0 Error(s)").Count);
        Assert.AreEqual(0, BuildOutputInspector.Inspect(null!).Count);
    }

    [TestMethod]
    public void Cobertura_MergesReportsAndFiltersChangedFiles()
    {
        var a = XDocument.Parse(TestData.Cobertura("src/App/Handler.cs", 9, 10));
        var b = XDocument.Parse(TestData.Cobertura("src/App/Handler.cs", 10, 10));
        var c = XDocument.Parse(TestData.Cobertura("src/App/Other.cs", 0, 10));

        var merged = CoberturaParser.Merge([a, b, c]);
        var (changed, matched) = merged.ForChangedFiles(["src\\App\\Handler.cs"]);

        Assert.AreEqual(50.0, merged.Percent);
        Assert.AreEqual(100.0, changed);
        Assert.AreEqual(1, matched.Count);
        Assert.IsNull(new CoverageReport([]).Percent);
    }

    [TestMethod]
    public void Cobertura_ParseFolder()
    {
        using var repo = new TestRepo();
        Assert.IsNull(CoberturaParser.ParseFolder(Path.Combine(repo.Root, "missing")));
        Assert.IsNull(CoberturaParser.ParseFolder(repo.Root));

        repo.AddFile("r/guid/coverage.cobertura.xml", TestData.Cobertura("A.cs", 3, 4));
        Assert.AreEqual(75.0, CoberturaParser.ParseFolder(Path.Combine(repo.Root, "r"))!.Percent);
    }

    [TestMethod]
    public void OpenCover_MergesSequencePointsPerFileAndIsUsedWhenNoCobertura()
    {
        const string report = """
            <CoverageSession><Modules><Module>
              <Files><File uid="1" fullPath="C:\repo\src\App\Handler.cs" /><File uid="2" fullPath="C:\repo\src\App\Other.cs" /></Files>
              <Classes><Class><Methods><Method><SequencePoints>
                <SequencePoint vc="1" sl="10" fileid="1" /><SequencePoint vc="0" sl="11" fileid="1" />
                <SequencePoint vc="3" sl="11" fileid="1" /><SequencePoint vc="0" sl="12" fileid="1" />
                <SequencePoint vc="0" sl="5" fileid="2" /><SequencePoint vc="1" sl="6" fileid="9" />
              </SequencePoints></Method></Methods></Class></Classes>
            </Module></Modules></CoverageSession>
            """;
        using var repo = new TestRepo();
        repo.AddFile("r/a/coverage.opencover.xml", report);

        var merged = CoberturaParser.ParseFolder(Path.Combine(repo.Root, "r"))!;
        var (changed, matched) = merged.ForChangedFiles(["src/App/Handler.cs"]);

        Assert.AreEqual(2, merged.Files.Count);
        Assert.AreEqual(1, matched.Count);
        Assert.AreEqual(66.67, changed);
        Assert.AreEqual(50.0, merged.Percent);

        repo.AddFile("r/b/coverage.cobertura.xml", TestData.Cobertura("A.cs", 1, 1));
        Assert.AreEqual(100.0, CoberturaParser.ParseFolder(Path.Combine(repo.Root, "r"))!.Percent);
    }

    [DataTestMethod]
    [DataRow("src/Formula.Application/PaintSystem/ComplaintHandler.cs", true)]
    [DataRow("src/app/paint-system/store.ts", true)]
    [DataRow("src/Latest/Feature.cs", true)]
    [DataRow("tests/Formula.Tests/ComplaintHandlerTests.cs", false)]
    [DataRow("src/Formula.Application.Tests/X.cs", false)]
    [DataRow("src/app/x.component.spec.ts", false)]
    [DataRow("src/Data/Generated/Client.cs", false)]
    [DataRow("src/types.d.ts", false)]
    [DataRow("README.md", false)]
    public void IsProductionSource(string path, bool expected)
    {
        Assert.AreEqual(expected, VerificationService.IsProductionSource(path));
    }

    [TestMethod]
    public async Task Run_AllGatesPass_OnChangedFiles()
    {
        var (ws, state, runner) = Setup();
        runner.Handler = cmd => cmd switch
        {
            _ when cmd.StartsWith("dotnet test", StringComparison.Ordinal) => WriteResults(cmd, TestData.Trx, TestData.Cobertura("src/App/Handler.cs", 19, 20)),
            _ when cmd.StartsWith("git status", StringComparison.Ordinal) => FakeRunner.Ok(cmd, " M src/App/Handler.cs\n?? tests/App.Tests/HandlerTests.cs\n"),
            _ when cmd.StartsWith("git diff", StringComparison.Ordinal) => FakeRunner.Ok(cmd, string.Empty),
            _ => FakeRunner.Ok(cmd, "Build succeeded."),
        };

        var report = await new VerificationService(runner, new FakeClock()).RunAsync(ws, state, Options("final"));

        Assert.IsTrue(report.Passed, string.Join("; ", report.Gates.Select(g => g.Detail)));
        Assert.AreEqual(95.0, report.CoveragePercent);
        StringAssert.Contains(report.CoverageScope, "changed production files (1)");
        Assert.AreEqual(2, report.ChangedFiles.Count);
        Assert.IsTrue(File.Exists(ws.ChangeFile(state, SddConstants.VerificationLogFile)));
        Assert.IsTrue(VerificationReport.Load(ws.ChangeFile(state, SddConstants.VerificationFile))!.Passed);
        Assert.IsNull(VerificationReport.Load(Path.Combine(ws.Root, "none.json")));
        Assert.IsFalse(runner.Commands.Exists(c => c.Contains("{results}", StringComparison.Ordinal)));
    }

    [TestMethod]
    public async Task Run_BuildFailure_SkipsTests()
    {
        var (ws, state, runner) = Setup();
        runner.Handler = cmd => FakeRunner.Fail(cmd, "Program.cs(3,1): error CS1002: ; expected");

        var report = await new VerificationService(runner, new FakeClock()).RunAsync(ws, state, Options("targeted"));

        Assert.IsFalse(report.Passed);
        Assert.AreEqual(GateStatus.Fail, report.Gates[0].Status);
        StringAssert.Contains(report.Gates[0].Detail, "CS1002");
        Assert.AreEqual(GateStatus.NotExecuted, report.Gates[1].Status);
        Assert.AreEqual(1, runner.Commands.Count(c => !c.StartsWith("git", StringComparison.Ordinal)));
    }

    [TestMethod]
    public async Task Run_ExitZeroWithStaleBuild_FailsBuildGate()
    {
        var (ws, state, runner) = Setup();
        runner.Handler = cmd => new ProcessResult(cmd, -1, "Continuing with last successful build", TimeSpan.Zero, TimedOut: true);

        var report = await new VerificationService(runner, new FakeClock()).RunAsync(ws, state, Options("targeted"));

        StringAssert.Contains(report.Gates[0].Detail, "timed out");
    }

    [TestMethod]
    public async Task Run_ZeroTests_NoTrx_FailingTests_LowCoverage()
    {
        await AssertTestGate(TestData.TrxZero, TestData.Cobertura("A.cs", 10, 10), "Zero tests executed", GateStatus.Fail);
        await AssertTestGate(null, TestData.Cobertura("A.cs", 10, 10), "not proven", GateStatus.Fail);
        await AssertTestGate(TestData.Trx.Replace("failed=\"0\"", "failed=\"2\"", StringComparison.Ordinal), TestData.Cobertura("A.cs", 10, 10), "2 failed", GateStatus.Fail);

        var (ws, state, runner) = Setup();
        runner.Handler = cmd => cmd.StartsWith("dotnet test", StringComparison.Ordinal) ? WriteResults(cmd, TestData.Trx, TestData.Cobertura("A.cs", 8, 10)) : FakeRunner.Ok(cmd, string.Empty);
        var low = await new VerificationService(runner, new FakeClock()).RunAsync(ws, state, Options("final"));
        Assert.AreEqual(GateStatus.Fail, low.Gates[2].Status);
        StringAssert.Contains(low.Gates[2].Detail, "80% line coverage on all instrumented files");

        runner.Handler = cmd => cmd.StartsWith("dotnet test", StringComparison.Ordinal) ? WriteResults(cmd, TestData.Trx, null) : FakeRunner.Ok(cmd, string.Empty);
        var none = await new VerificationService(runner, new FakeClock()).RunAsync(ws, state, Options("final"));
        StringAssert.Contains(none.Gates[2].Detail, "No coverage.cobertura.xml or coverage.opencover.xml");
    }

    [TestMethod]
    public async Task Run_JestOutputCountsWhenNoTrx()
    {
        var (ws, state, runner) = Setup();
        runner.Handler = cmd => cmd.StartsWith("dotnet test", StringComparison.Ordinal)
            ? WriteResults(cmd, null, TestData.Cobertura("a.ts", 10, 10), "Tests:       5 passed, 5 total")
            : FakeRunner.Ok(cmd, string.Empty);

        var report = await new VerificationService(runner, new FakeClock()).RunAsync(ws, state, Options("targeted"));

        Assert.IsTrue(report.Passed);
        Assert.AreEqual("console summary", report.Tests!.Source);
    }

    [TestMethod]
    public async Task ProcessRunner_RunsRealCommandAndTimesOut()
    {
        var runner = new ProcessRunner();
        var ok = await runner.RunAsync("dotnet --version", Directory.GetCurrentDirectory(), TimeSpan.FromMinutes(1));
        Assert.IsTrue(ok.Succeeded, ok.Output);
        Assert.IsTrue(ok.Output.Length > 0);

        var sleep = RuntimeInformation.IsOSPlatform(OSPlatform.Windows) ? "ping -n 10 127.0.0.1" : "sleep 10";
        var slow = await runner.RunAsync(sleep, Directory.GetCurrentDirectory(), TimeSpan.FromMilliseconds(300));
        Assert.IsTrue(slow.TimedOut);
        Assert.IsFalse(slow.Succeeded);
        Assert.AreEqual(-1, slow.ExitCode);
    }

    [TestMethod]
    public void ProcessRunner_WindowsPassesQuotedArgumentsVerbatim()
    {
        const string command = "dotnet test A.sln --collect:\"XPlat Code Coverage\" --results-directory \"C:\\r 1\"";

        var windows = ProcessRunner.CreateStartInfo(command, ".", isWindows: true);
        var unix = ProcessRunner.CreateStartInfo(command, ".", isWindows: false);

        Assert.AreEqual("cmd.exe", windows.FileName);
        Assert.AreEqual("/d /s /c \"" + command + "\"", windows.Arguments);
        Assert.AreEqual(0, windows.ArgumentList.Count);
        Assert.AreEqual("/bin/sh", unix.FileName);
        CollectionAssert.AreEqual(new[] { "-c", command }, unix.ArgumentList.ToArray());
    }

    [TestMethod]
    public async Task ProcessRunner_KeepsQuotedArgumentWithSpacesTogether()
    {
        var command = RuntimeInformation.IsOSPlatform(OSPlatform.Windows)
            ? "echo --collect:\"XPlat Code Coverage\""
            : "printf '%s|' --collect:\"XPlat Code Coverage\"";

        var result = await new ProcessRunner().RunAsync(command, Directory.GetCurrentDirectory(), TimeSpan.FromMinutes(1));

        StringAssert.Contains(result.Output, "XPlat Code Coverage");
    }

    [TestMethod]
    public async Task GitClient_ChangedFilesAndBranch()
    {
        var runner = new FakeRunner
        {
            Handler = cmd => cmd switch
            {
                _ when cmd.StartsWith("git diff", StringComparison.Ordinal) => FakeRunner.Ok(cmd, "src/A.cs\nwarning: x\n"),
                _ when cmd.StartsWith("git status", StringComparison.Ordinal) => FakeRunner.Ok(cmd, "R  old.cs -> src/New.cs\n M \"src/With Space.cs\"\n?\n"),
                _ => FakeRunner.Ok(cmd, "feature/306400-complaint\n"),
            },
        };
        var git = new GitClient(runner);

        var files = await git.ChangedFilesAsync(".", "origin/develop");

        CollectionAssert.AreEqual(new[] { "src/A.cs", "src/New.cs", "src/With Space.cs" }, files.ToArray());
        Assert.AreEqual("feature/306400-complaint", await git.CurrentBranchAsync("."));

        runner.Handler = cmd => FakeRunner.Fail(cmd, "fatal: not a git repository");
        await Assert.ThrowsExceptionAsync<SddException>(() => git.ChangedFilesAsync(".", "origin/develop"));
        Assert.AreEqual(string.Empty, await git.CurrentBranchAsync("."));
    }

    [TestMethod]
    public async Task Sonar_ParsesGateAndSendsQuery()
    {
        const string body = """{"projectStatus":{"status":"ERROR","conditions":[{"status":"ERROR","metricKey":"new_coverage","actualValue":"81.2","errorThreshold":"90"}]}}""";
        using var handler = new StubHandler(HttpStatusCode.OK, body);
        using var http = new HttpClient(handler);
        var client = new SonarGateClient(http);

        var result = await client.GetGateAsync(SonarUri, "akzo:formula", "token", "42", null);

        Assert.IsFalse(result.Passed);
        Assert.AreEqual("new_coverage", result.Conditions[0].Metric);
        Assert.AreEqual("81.2", result.Conditions[0].Actual);
        StringAssert.Contains(handler.LastUri!.ToString(), "pullRequest=42");
        Assert.AreEqual("Bearer", handler.LastAuthScheme);

        await client.GetGateAsync(SonarUri, "k", null, null, "develop");
        StringAssert.Contains(handler.LastUri!.ToString(), "branch=develop");
        Assert.IsNull(handler.LastAuthScheme);
        Assert.IsTrue(SonarGateClient.Parse("""{"projectStatus":{"status":"OK"}}""").Passed);
    }

    [TestMethod]
    public async Task Sonar_ErrorStatusThrows()
    {
        using var handler = new StubHandler(HttpStatusCode.Unauthorized, "no");
        using var http = new HttpClient(handler);

        await Assert.ThrowsExceptionAsync<SddException>(() => new SonarGateClient(http).GetGateAsync(SonarUri, "k", null, null, null));
    }

    [TestMethod]
    public async Task Sonar_TimeoutThrowsGateFailure()
    {
        using var handler = new ThrowingHandler();
        using var http = new HttpClient(handler);

        var ex = await Assert.ThrowsExceptionAsync<SddException>(() => new SonarGateClient(http).GetGateAsync(SonarUri, "k", null, null, null));

        StringAssert.Contains(ex.Message, "timed out");
    }

    private static async Task AssertTestGate(string? trx, string? cobertura, string expected, GateStatus status)
    {
        var (ws, state, runner) = Setup();
        runner.Handler = cmd => cmd.StartsWith("dotnet test", StringComparison.Ordinal) ? WriteResults(cmd, trx, cobertura) : FakeRunner.Ok(cmd, string.Empty);
        var report = await new VerificationService(runner, new FakeClock()).RunAsync(ws, state, Options("targeted"));
        Assert.AreEqual(status, report.Gates[1].Status);
        StringAssert.Contains(report.Gates[1].Detail, expected);
    }

    private static ProcessResult WriteResults(string command, string? trx, string? cobertura, string output = "")
    {
        var start = command.IndexOf('"', StringComparison.Ordinal) + 1;
        var folder = command[start..command.LastIndexOf('"')];
        if (trx is not null)
        {
            File.WriteAllText(Path.Combine(folder, "run.trx"), trx);
        }

        if (cobertura is not null)
        {
            Directory.CreateDirectory(Path.Combine(folder, "guid"));
            File.WriteAllText(Path.Combine(folder, "guid", "coverage.cobertura.xml"), cobertura);
        }

        return FakeRunner.Ok(command, output);
    }

    private static VerificationOptions Options(string scope) =>
        new(scope, Build, Test, 90, ChangedOnly: true, TimeSpan.FromMinutes(1), "origin/develop");

    private static (SddWorkspace Ws, SddState State, FakeRunner Runner) Setup()
    {
        var repo = new TestRepo();
        var ws = new SddWorkspace(repo.Root, new FakeClock());
        var state = new SddState { PbiId = "1", Feature = "F", Role = ProjectRole.Dab };
        ws.Save(state);
        return (ws, state, new FakeRunner());
    }

    private sealed class ThrowingHandler : HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken) =>
            throw new TaskCanceledException("timeout");
    }

    private sealed class StubHandler(HttpStatusCode status, string body) : HttpMessageHandler
    {
        public Uri? LastUri { get; private set; }

        public string? LastAuthScheme { get; private set; }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            LastUri = request.RequestUri;
            LastAuthScheme = request.Headers.Authorization?.Scheme;
            return Task.FromResult(new HttpResponseMessage(status) { Content = new StringContent(body) });
        }
    }
}
