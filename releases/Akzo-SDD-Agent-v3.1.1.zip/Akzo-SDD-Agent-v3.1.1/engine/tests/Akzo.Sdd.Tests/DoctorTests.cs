using Akzo.Sdd.Core.Cli;
using Akzo.Sdd.Core.Execution;
using Akzo.Sdd.Core.Services;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class DoctorTests
{
    private static FakeRunner Healthy() => new() { Handler = HealthyResult };

    private static ProcessResult HealthyResult(string cmd)
    {
        if (cmd.StartsWith("dotnet", StringComparison.Ordinal))
        {
            return FakeRunner.Ok(cmd, "8.0.404\n");
        }

        return cmd.Contains("check-ignore", StringComparison.Ordinal)
            ? FakeRunner.Fail(cmd, string.Empty)
            : FakeRunner.Ok(cmd, "git version 2.46.0.windows.1\n");
    }

    [TestMethod]
    public async Task Doctor_FreshRepoFailsUntilInstalled_ThenWarnsOnDefaultCommands()
    {
        using var repo = new TestRepo();
        var before = await DoctorService.RunAsync(repo.Root, Healthy());
        Assert.AreEqual(CheckStatus.Fail, DoctorService.Overall(before));
        Assert.AreEqual(CheckStatus.Fail, before.First(c => c.Name == "Agent version").Status);
        Assert.AreEqual(CheckStatus.Warn, before.First(c => c.Name == "Settings").Status);

        InstallService.Install(Path.Combine(AppContext.BaseDirectory, "agent"), ProjectRole.Dab, repo.Root, force: false);
        var after = await DoctorService.RunAsync(repo.Root, Healthy());
        Assert.AreEqual(CheckStatus.Warn, DoctorService.Overall(after), string.Join("; ", after.Where(c => c.Status != CheckStatus.Pass).Select(c => c.Name + " " + c.Detail)));
        StringAssert.Contains(after.First(c => c.Name == "Settings").Detail, "default build/test commands");

        new SddSettings { Role = "DAB", BuildCommand = "dotnet build x.sln", TestCommand = "dotnet test x.sln" }.Save(repo.Root);
        Assert.AreEqual(CheckStatus.Pass, DoctorService.Overall(await DoctorService.RunAsync(repo.Root, Healthy())));

        await File.WriteAllTextAsync(Path.Combine(repo.Root, ".github/agents/akzo-sdd.agent.md"), "old agent");
        Assert.AreEqual(CheckStatus.Warn, (await DoctorService.RunAsync(repo.Root, Healthy())).First(c => c.Name == "Agent version").Status);

        new SddSettings().Save(repo.Root);
        StringAssert.Contains((await DoctorService.RunAsync(repo.Root, Healthy())).First(c => c.Name == "Settings").Detail, "role not set");
    }

    [TestMethod]
    public async Task Doctor_MissingToolsAndNoGitRepository()
    {
        using var noGit = new TestRepo(git: false);
        var runner = new FakeRunner { Handler = cmd => cmd.StartsWith("dotnet", StringComparison.Ordinal) ? FakeRunner.Ok(cmd, "6.0.100") : FakeRunner.Fail(cmd, "not found") };

        var checks = await DoctorService.RunAsync(noGit.Root, runner);

        Assert.AreEqual(CheckStatus.Fail, checks.First(c => c.Name == ".NET SDK").Status);
        Assert.AreEqual(CheckStatus.Fail, checks.First(c => c.Name == "Git").Status);
        Assert.AreEqual(CheckStatus.Pass, DoctorService.Overall([]));

        var garbled = new FakeRunner { Handler = cmd => FakeRunner.Ok(cmd, "unknown") };
        Assert.AreEqual(CheckStatus.Fail, (await DoctorService.RunAsync(noGit.Root, garbled)).First(c => c.Name == ".NET SDK").Status);
    }

    [TestMethod]
    public async Task Cli_DoctorAndAutoRoleInstall()
    {
        using var repo = new TestRepo();
        using var output = new StringWriter();
        using var http = new HttpClient();
        var app = new SddApp(Healthy(), new FakeClock(), http, output);

        Assert.AreEqual(SddApp.GateFailed, await app.RunAsync(["doctor", "--repo", repo.Root]));
        Assert.AreEqual(SddApp.GateFailed, await app.RunAsync(["install", "--role", "auto", "--repo", repo.Root]));
        StringAssert.Contains(output.ToString(), "no signature found");

        repo.AddFile("angular.json", "{}");
        repo.AddDabSignature();
        Assert.AreEqual(SddApp.GateFailed, await app.RunAsync(["install", "--role", "auto", "--repo", repo.Root]));
        StringAssert.Contains(output.ToString(), "Choose the role explicitly");

        File.Delete(Path.Combine(repo.Root, "angular.json"));
        Assert.AreEqual(SddApp.Ok, await app.RunAsync(["install", "--role", "auto", "--repo", repo.Root]));
        StringAssert.Contains(output.ToString(), "installed for Dab");
        Assert.AreEqual(SddApp.Ok, await app.RunAsync(["doctor", "--repo", repo.Root]));
        StringAssert.Contains(output.ToString(), "Overall: WARN");
    }
}
