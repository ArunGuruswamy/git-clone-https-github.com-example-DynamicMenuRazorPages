using Akzo.Sdd.Core.Cli;
using Akzo.Sdd.Core.Services;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Tests;

[TestClass]
public sealed class SpecsFolderTests
{
    [TestMethod]
    public void SpecRoot_UsesConfiguredSpecsFolder()
    {
        using var repo = new TestRepo();
        StringAssert.EndsWith(RepositoryLocator.SpecRoot(repo.Root).Replace('\\', '/'), "src/.github/specs");

        new SddSettings { SpecsFolder = "/docs/specs" }.Save(repo.Root);

        StringAssert.EndsWith(RepositoryLocator.SpecRoot(repo.Root).Replace('\\', '/'), "/docs/specs");
        StringAssert.EndsWith(RepositoryLocator.DefaultSpecRoot(repo.Root).Replace('\\', '/'), "src/.github/specs");
    }

    [TestMethod]
    public void Install_RecordsSpecsFolderAndUpdateAgentsReplacesOnlyEngineFiles()
    {
        using var assets = new TestRepo(git: false, src: false);
        assets.AddFile("core/.github/agents/akzo-sdd.agent.md", "v1 agent");
        assets.AddFile("core/.github/sdd/constitution.md", "v1 constitution");
        using var repo = new TestRepo();
        new SddSettings { Role = "DAB", BuildCommand = "dotnet build x.sln" }.Save(repo.Root);

        InstallService.Install(assets.Root, ProjectRole.Dab, repo.Root, force: false);
        var settings = SddSettings.Load(repo.Root);
        Assert.AreEqual("src/.github/specs", settings.SpecsFolder);
        Assert.AreEqual("dotnet build x.sln", settings.BuildCommand);

        repo.AddFile(".github/agents/akzo-sdd.agent.md", "hand edit");
        repo.AddFile(".github/sdd/constitution.md", "team edit");
        assets.AddFile("core/.github/agents/akzo-sdd.agent.md", "v2 agent");
        assets.AddFile("core/.github/sdd/constitution.md", "v2 constitution");
        new SddSettings { Role = "DAB", SpecsFolder = "specs" }.Save(repo.Root);

        var result = InstallService.Install(assets.Root, ProjectRole.Dab, repo.Root, force: false, updateAgents: true);

        CollectionAssert.AreEqual(new[] { ".github/agents/akzo-sdd.agent.md" }, result.Updated.ToArray());
        CollectionAssert.AreEqual(new[] { ".github/sdd/constitution.md" }, result.KeptModified.ToArray());
        Assert.AreEqual("v2 agent", File.ReadAllText(Path.Combine(repo.Root, ".github/agents/akzo-sdd.agent.md")));
        Assert.AreEqual("specs", SddSettings.Load(repo.Root).SpecsFolder);
        Assert.IsTrue(InstallService.IsEngineOwned(".github/sdd/workflow.md"));
        Assert.IsTrue(InstallService.IsEngineOwned(".github/prompts/sdd-pr.prompt.md"));
        Assert.IsFalse(InstallService.IsEngineOwned(".github/sdd/review-learnings.md"));
        Assert.IsFalse(InstallService.IsEngineOwned(".github/instructions/sonar-rules.instructions.md"));
    }

    [TestMethod]
    public async Task Doctor_FailsWhenGitIgnoresSpecsFolder()
    {
        using var repo = new TestRepo();
        var ignored = new FakeRunner
        {
            Handler = cmd => cmd.Contains("check-ignore", StringComparison.Ordinal)
                ? FakeRunner.Ok(cmd, ".gitignore:4:src/.github/\tsrc/.github/specs/PBI-Feature/spec.md\n")
                : FakeRunner.Ok(cmd, "8.0.404"),
        };
        var tracked = new FakeRunner
        {
            Handler = cmd => cmd.Contains("check-ignore", StringComparison.Ordinal) ? FakeRunner.Fail(cmd, string.Empty) : FakeRunner.Ok(cmd, "8.0.404"),
        };

        var bad = (await DoctorService.RunAsync(repo.Root, ignored)).First(c => c.Name == "Specs folder");
        var good = (await DoctorService.RunAsync(repo.Root, tracked)).First(c => c.Name == "Specs folder");

        Assert.AreEqual(CheckStatus.Fail, bad.Status);
        StringAssert.Contains(bad.Detail, ".gitignore:4");
        Assert.AreEqual(CheckStatus.Pass, good.Status);
        StringAssert.Contains(good.Detail, "src/.github/specs/<PBI-Feature>");
    }

    [TestMethod]
    public async Task InstallCommand_ReportsSpecsFolderAndKeptFiles()
    {
        using var repo = new TestRepo();
        using var output = new StringWriter();
        using var http = new HttpClient();
        var app = new SddApp(new FakeRunner(), new FakeClock(), http, output);

        Assert.AreEqual(SddApp.Ok, await app.RunAsync(["install", "--role", "dab", "--repo", repo.Root]));
        StringAssert.Contains(output.ToString(), "Spec and plan folder: src/.github/specs/<Feature>/ (feature name only, no PBI number)");

        repo.AddFile(".github/agents/akzo-sdd.agent.md", "hand edit");
        repo.AddFile(".github/sdd/constitution.md", "team edit");
        Assert.AreEqual(SddApp.Ok, await app.RunAsync(["install", "--role", "dab", "--repo", repo.Root]));
        StringAssert.Contains(output.ToString(), "kept (agent file - rerun with --update-agents to replace): .github/agents/akzo-sdd.agent.md");
        StringAssert.Contains(output.ToString(), "kept (team-owned, not replaced): .github/sdd/constitution.md");

        Assert.AreEqual(SddApp.Ok, await app.RunAsync(["install", "--role", "dab", "--repo", repo.Root, "--update-agents"]));
        Assert.AreNotEqual("hand edit", await File.ReadAllTextAsync(Path.Combine(repo.Root, ".github/agents/akzo-sdd.agent.md")));
        Assert.AreEqual("team edit", await File.ReadAllTextAsync(Path.Combine(repo.Root, ".github/sdd/constitution.md")));
    }
}
