# Decision Log - 305912

Status: No business decisions approved.

| ID | Decision | Status | Evidence of approval | Notes |
| --- | --- | --- | --- | --- |
| D-01 | Adaptation is limited to active Industrial MCIs with empty Kind of Variation and a production-line suffix. | Proposed | Intake only | Current lookup is broader. |
| D-02 | The Reference Color outcome requires a measured Global/Standard MCI and the specified missing-measurement warning. | Proposed | Intake only | Existing client implementation is not equivalent in all respects. |
| D-03 | Adaptation PS Level is `Adapted`; other types are empty and locked. | Proposed | Intake only | Current UI behavior differs. |
| D-04 | Adaptation promotes the selected existing Industrial MCI to Global/Industry after actualization. | Proposed | Intake technical detail; current code is a close precedent | Pending Q-01 confirmation. |
| D-05 | Conditional Color Point replacement is required and disabled by default in production. | Proposed | Intake only | Pending Q-05 and feasibility review. |