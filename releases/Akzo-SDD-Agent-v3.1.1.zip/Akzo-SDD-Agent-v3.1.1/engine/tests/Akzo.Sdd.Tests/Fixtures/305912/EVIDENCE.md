# Evidence - 305912

Status: Draft evidence record. Legacy source was read from this repository. DAB and CDMS repositories are unconfigured and were not inspected.

| Source | Relevant sections | Finding | Confidence / gap |
| --- | --- | --- | --- |
| `Source/WebResources/ANAAC.DDC.ColorApps.WebResources/Scripts/OnloadImitationRequest.js` | `addFilter` | Adaptation lookup requires active state and Industrial role (`800000005`) only. | CONFIRMED; KoV and suffix requirements are absent. |
| `Source/WebResources/ANAAC.DDC.ColorApps.WebResources/Scripts/OnSaveImitationRecord.js` | `LoadColorReferences`, `setStandardReferenceColor` | Adaptation selects an Active/Actual Standard (`800000009`) MCI with a measurement from the same Market Color, if found. | CONFIRMED; role Global is not explicit and missing measurement has no specified warning. |
| `Source/Formula/ImitationRequest/ImitationRequest/ClsPostOnSaveImitationRequest.cs` | `CreateUpdateImitationRequest`, `CheckActiveImitationRequestWithProduct`, `CheckImitationRequestStatus` | Mandatory IR fields are validated; duplicate check is generic; Adaptation bypasses New Sample status validation. | CONFIRMED; no Adaptation-only Industrial MCI restriction found in reviewed path. |
| `Source/WebResources/ANAAC.DDC.ColorApps.WebResources/Scripts/PaintSystemLib.js` | `GetImitationRequestDetails` | UI sets PS Level to the IR option value for Adaptation and Industrialization. | CONFIRMED; does not clear/lock other types. |
| `Source/Formula/PaintSystem/PaintSystem/PaintSystemOperations.cs` | `ExecutePaintSystemOperation`, `AssociateProductionLine`, `ChangePaintSystemStatusForImprovedFormula`, `ReCalculateVersionForImproveFormula` | Adaptation shares Improved Formula PS branch. Automotive version recalculation and association filter are Improved Formula only. | CONFIRMED; Adaptation version/history applicability needs feasibility review. |
| `Source/Formula/PaintSystem/PaintSystem/PaintSystemStatusChange.cs` | ColorApps actualization section | Adaptation actualization updates selected MCI to Global/Industry, current-time promotion, and `(<production line>)`; it does not replace Color Point. | CONFIRMED; supplied `Update4Adaptation`, suffix helper, and compilation flag are not found in reviewed source. |
| `playbook/pbi-builder/sources.yaml` | source registry | Legacy source is this repository; DAB and CDMS paths are empty. | CONFIRMED; external API behavior is UNKNOWN. |

## Evidence gaps

- DAB API contract, availability, ownership, and whether it must be used cannot be verified from configured sources.
- The exact option values/labels for `Adapted` and `Industrialized` were not independently verified.
- No source evidence was located for the exact requested IR-name suffix rule or the supplied method names.
- Technical feasibility for Adaptation-specific versioning and production-line historic handling remains pending.