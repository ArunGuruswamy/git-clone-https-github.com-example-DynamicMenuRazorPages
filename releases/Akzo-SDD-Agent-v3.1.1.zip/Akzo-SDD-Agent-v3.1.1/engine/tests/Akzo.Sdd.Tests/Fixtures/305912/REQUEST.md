# 305912 - [CAA] [DAB API] Creation of Imitation Request & Paint System - Adaptation

## Original intake

Title: [[CAA] [DAB API] Creation of Imitation Request & Paint System - Adaptation

Description: [CAA] [DAB API] Creation of Imitation Request & Paint System - Adaptation

PBI number: 305912

Business reason: Not provided.

Business example: Not provided.

Business Unit / Sub-BU: Not provided.

### User story

- As a Formula App user,
- I want to create an Adaption Imitation Request & Paint system for a Market Color-Industrial Instance (Role=Industrial) by filling mandatory fields & BU optional fields.
- So that I can create Imitation Request & Paint System for Adaptation process.

### Instance definitions

- Industrial Instance: Role=Industrial; Kind of Variation=Empty; Variant suffix=Prod line.
- Industry Variant: Role=Global; Kind of Variation=Industry; Variant suffix=Prod line.

### Requested validations and behavior

- If the user creates an Adaption imitation request for a Market Color Industrial instance (Role=Industrial and KoV=Empty) and the Product and Local / Global combination exists, display: `Active imitation request already exists for same Market Color - "Industrial" instance and Product`.
- If the user creates an imitation request other than Adaption for a Market Color Industrial Instance (Role=Industrial and KoV=Empty), display: `Only Adaption is allowed; Paint system does not exist for this Market Color Instance and Product`.
- Adaption IR is allowed only for an Industrial instance.
- Fetch only Active Industrial instances in Color Name.
- For an Adaption imitation request, fetch Reference Color from the Standard Instance for the given Market Color: Role=Global and Kind of Variation=Standard.
- Reference Color must have a measurement.
- When Color Name is searched, check that the respective Market Color has a Standard Instance with a measurement.
- Automatically populate Reference Color from the corresponding Standard Market Color Instance. If it has no measurement, display: `Standard does not have measurement, Kindly add measurement for the Standard instance`.
- Introduce a new API for fetching Reference Color when IR type is Adaptation.
- Allow Adaptation requests for multiple Industrial Instances for one Market Color, associated with the same or different Production Lines.
- On creating an Adaptation IR, include the selected Industrial Instance Variant Suffix (Production Line Short Name) in the IR name. Example: Industrial Instance `SES1A__3`, Variant Suffix `FICESC`, IR Name `SES1A__3FICESC_`.
- Retrieve Imitation Request type and set Paint System Level during PS creation. For Adaptation set it to `Adapted`; for other IR types leave it empty and locked.
- Assign new Version and Alternative number `1.1`.

### Paint System business rules

- Validate that `cdms_imitationrequestid` and `cdms_developmenttool` exist; stop processing if either is missing.
- If Development Tool is ColorApps (2) or OwnColor (4), create Color Imitation and Formula with Layer Number = 1.
- Retrieve existing Paint Systems for the same Product, Color, and Geo condition.
- Generate Paint System Name. If Development Tool is ColorApps or OwnColor, create Color using the same naming convention.
- Evaluate Conversion To All Products Allowed. If false, associate Product to Paint System.
- If owner belongs to ICO or Consumer Electronics, force Conversion To All Products Allowed=false and automatically associate Product.
- When the Paint System becomes Actual, identify older Paint Systems for the same Product, Color, and Geo combination.
- If owner type is not Automotive, change all previous related Paint Systems to Historic.
- If owner type is Automotive, apply production-line-based historic handling.
- Paint Systems without a matching production line remain unchanged unless explicitly handled by production-line rules.

### Adaptation process and requested technical detail

Adaptation adapts an existing Market Color Instance for industrial production with production-line-specific metadata.

Process flow:

`UpdateImitationRequest()` -> retrieve existing Market Color Instance -> create Paint System -> `Update4Adaptation()` -> close Imitation Request.

The existing `cdms_marketcolorinstance` is modified, not created:

| Property | Requested value | Description |
| --- | --- | --- |
| `cdms_colorid` | Paint System color GUID | Optional, compilation flag |
| `cdms_role` | Global (`800000002`) | Promotes to Global role |
| `cdms_variantsuffix` | Updated with production line | Adds production-line short name |
| `cdms_kindofvariation` | Industry (`800000012`) | Industry variation type |
| `cdms_promotedon` | `DateTime.UtcNow` | Promotion timestamp |

Requested Variant Suffix logic:

```csharp
private string CreateVariantSuffix(Entity marketColorInstance)
{
    var variantSuffix = marketColorInstance["cdms_variantsuffix"] ?? "";
    var productionLine = GetLinkedProductionLine(marketColorInstance.Id);
    var productionLineShortName = productionLine["cdms_shortname"];

    if (string.IsNullOrEmpty(variantSuffix))
        return $"({productionLineShortName})";
    else if (!variantSuffix.Contains(productionLineShortName))
        return $"{variantSuffix}{productionLineShortName}";

    return variantSuffix;
}
```

Example: original `(B)`, Production Line `TSL`, result `(B)TSL`.

Color Point update is conditional behind `#if UPDATE_COLOR_POINT`: update the Market Color Instance color reference to the new Paint System color and make the previous color Historic (inactive). This is stated to be disabled in production builds.

### Known acceptance criteria

- Users can create an Adaption Imitation Request and Paint System.
- The system allows Adaptation requests for multiple Industrial Instances for one Market Color associated with different Production Lines.
- The system displays mandatory fields and permits users to fill required information.
- Save validates mandatory fields and business rules.
- The system assigns Version and Alternative numbers according to the rules during PS creation.
- Users can create, update, deactivate, and delete Paint Systems and Formula components.

### Requested handling

Save refinement documents in a separate folder under `playbook/pbis/`. Preserve this original requirement and other PBI folders. Record decisions as proposed until explicitly approved. Mark Development-Ready only after business approval, blocking-question resolution, and recorded technical-feasibility review. Do not modify application code or publish to Azure DevOps. Review available evidence, summarize understanding, and ask one unresolved business question at a time.