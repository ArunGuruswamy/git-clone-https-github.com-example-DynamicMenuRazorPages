# Open Questions - 305912

Status: Open

| ID | Question | Impact | Intended decision owner | Status |
| --- | --- | --- | --- | --- |
| Q-01 | After successful Adaptation, should the selected Industrial MCI always be promoted to Global/Industry and therefore no longer be eligible for another Adaptation, or must it remain/revert as an Industrial MCI so the same production line can be adapted again? | This determines the lifecycle rule, repeat-Adaptation behavior, lookup eligibility, and the meaning of multiple requests per production line. Current code promotes the existing MCI to Global/Industry. | PO/BA | Open - blocking |
| Q-02 | Is `SES1A__3FICESC_` the exact required IR-name format, including underscore placement and behavior when a suffix already has parentheses? | Controls observable naming and prevents inconsistent IR names. | PO/BA | Deferred until Q-01 is resolved |
| Q-03 | Does "new API" mean DAB must be the authoritative source for Reference Color, or is the business requirement satisfied by equivalent automatic population and validation? | DAB source is unconfigured; determines dependency and delivery scope. | PO/BA / DAB owner | Deferred until Q-01 is resolved |
| Q-04 | What version/alternative result is expected after existing versions, for example `1.1`, `1.2`, and `2.1`? | Intake specifies only the initial `1.1`; the legacy Adaptation path does not apply Improved Formula recalculation. | PO/BA | Deferred until Q-01 is resolved |
| Q-05 | Is conditional Color Point replacement a required production behavior, and who enables the stated compilation flag? | Existing Adaptation behavior leaves Color Point unchanged; this affects actualization outcomes. | PO/BA / technical owner | Deferred until Q-01 is resolved |