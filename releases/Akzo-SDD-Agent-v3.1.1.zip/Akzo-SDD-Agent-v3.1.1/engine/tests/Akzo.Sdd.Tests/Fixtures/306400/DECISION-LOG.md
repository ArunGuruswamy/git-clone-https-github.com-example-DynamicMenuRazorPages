# Decision Log - PBI 306400

| ID | Decision | Status | Evidence | Affected criteria |
| --- | --- | --- | --- | --- |
| D-01 | Treat intake PS rules as requested behavior for this separate Part 1 PBI. | Proposed | No explicit approval for 306400 recorded. | BR-01 to BR-05 |
| D-02 | Product 752 rejection applies only during IR creation and is not performed by Paint System Part 1. | Approved | User direction: `Apply while creating IR only`, 2026-10-07. | BR-05 |
| D-03 | Salcomix 1306 derived-product Complaint restriction applies during both IR creation and Paint System Part 1. | Approved | User direction: `Yes it applies for both IR and PS`, 2026-10-07. | BR-06; AC-04 |
| D-04 | Salcomix Paint System rejection uses `Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.` | Approved | User approval, 2026-10-07. | BR-06; AC-05 |
| D-05 | Invalid version format message is `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.` | Approved | User approval, 2026-10-07. | BR-07; AC-06 |
| D-06 | Missing Product message is `Product is missing. A Complaint Paint System cannot be created.` | Approved | User approval, 2026-10-07. | BR-08; AC-07 |
| D-07 | Missing existing PS message is `An existing Paint System is required. A Complaint Paint System cannot be created.` | Approved | User approval, 2026-10-07. | BR-09; AC-08 |
| D-08 | Failed Product association message is `Product association failed. The Complaint Paint System could not be completed.` | Approved | User approval, 2026-10-07. | BR-10; AC-09 |
| D-09 | An existing Product association is left unchanged; processing continues silently without creating a duplicate association. | Approved | User direction, 2026-10-07. | BR-11; AC-10 |
| D-10 | Failed Color creation message is `Color creation failed. The Complaint Paint System could not be completed.` | Approved | User approval, 2026-10-07. | BR-12; AC-11 |
