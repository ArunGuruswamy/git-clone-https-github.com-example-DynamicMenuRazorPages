# Open Questions - PBI 306400

| ID | Question | Impact | Owner | Status |
| --- | --- | --- | --- | --- |
| Q-01 | Does product 752 rejection in this Part 1 scope apply only to Complaint processing or to every IR type? | Defines product pre-validation scope. | PO/BA | Resolved: applies only while creating the IR, not during Paint System Part 1. |
| Q-02 | Does the Salcomix 1306 derived-product Complaint restriction also apply only while creating the IR, or must Paint System Part 1 revalidate it? | Defines remaining product-validation scope. | PO/BA | Resolved: applies at both IR creation and Paint System Part 1. |
| Q-03 | Must both IR creation and Paint System Part 1 show the same Salcomix rejection message, `Complaint Imitation Requests are not allowed for a derived product in the Salcomix 1306 product family.`? | Defines consistent user-visible behavior across the two stages. | PO/BA | Resolved: use stage-specific IR and Paint System messages. |
| Q-04 | What exact message must be displayed when Complaint Paint System processing finds an invalid version format? | Defines the required user-visible invalid-version outcome. | PO/BA | Resolved: `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.` |
| Q-05 | What exact message must be displayed when the Product is missing during Complaint Paint System processing? | Defines the user-visible missing-Product outcome. | PO/BA | Resolved: `Product is missing. A Complaint Paint System cannot be created.` |
| Q-06 | What exact message must be displayed when the required existing Paint System is missing during Complaint Paint System processing? | Defines the user-visible missing-PS outcome. | PO/BA | Resolved: `An existing Paint System is required. A Complaint Paint System cannot be created.` |
| Q-07 | What exact message must be displayed when Product association fails during Complaint Paint System processing? | Defines the user-visible failed-association outcome. | PO/BA | Resolved: `Product association failed. The Complaint Paint System could not be completed.` |
| Q-08 | If the Product is already associated to the Paint System, should processing continue silently without creating a duplicate association, or show a message? | Defines duplicate association handling. | PO/BA | Resolved: continue silently without a duplicate association. |
| Q-09 | What exact message must be displayed when Color creation fails during Complaint Paint System processing? | Defines the user-visible failed-Color-creation outcome. | PO/BA | Resolved: `Color creation failed. The Complaint Paint System could not be completed.` |

No unresolved business questions. Whole-PBI business approval and technical feasibility review remain pending.
