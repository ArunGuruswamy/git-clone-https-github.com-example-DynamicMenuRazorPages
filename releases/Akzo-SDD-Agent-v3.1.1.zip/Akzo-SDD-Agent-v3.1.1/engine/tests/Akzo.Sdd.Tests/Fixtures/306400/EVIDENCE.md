# Evidence - PBI 306400

- Legacy source available: `Source/Formula/PaintSystem/PaintSystem/PaintSystemOperations.cs`.
- Confirmed: Complaint Primary path increments major and sets alternative 1; Secondary path appends `C`; Salcomix 1306 derived-product conversion restriction exists.
- Gap: product 752 absolute rejection and DAB API cannot be verified from configured sources.
- PBI 305183 is a related but separate PBI; no decisions are inherited.
