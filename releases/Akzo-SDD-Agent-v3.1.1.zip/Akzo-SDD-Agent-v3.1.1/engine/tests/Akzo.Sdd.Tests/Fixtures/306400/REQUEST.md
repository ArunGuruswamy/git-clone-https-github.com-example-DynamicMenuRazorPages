# 306400 - [CAA] [DAB API] Creation of "Complaint" PaintSystem - (Part1)

## Original intake

Title: [CAA] [DAB API] Creation of "Complaint" PaintSystem - (Part1)

Description: [CAA] [DAB API] Creation of "Complaint" PaintSystem - (Part1)

PBI number: 306400

User story: As a user, create Complaint IR and Paint System for a Global MCI and Primary or Secondary Derived Product using New Sample mandatory fields and BU optional fields.

Requested scope: validate existing PS prerequisite, duplicate IR, due date, cross-over, active MCI, product 1306/752 rules; process Complaint PS for Primary and Secondary derived products; assign version/alternative; create Color; set conversion to all products; create product association when needed; support PS/Formula lifecycle actions.

Specified messages:

- `Paint system does not exist for this Market Color Instance and Product, only New Sample is allowed.`
- `Active imitation request already exist for same Market Color Instance and Product.`
- `It is not allowed to add an Imitation Request for a Due Date with Past Date. Due Date should Current or Future Date. Current Due Date submitted: [date]`

Primary PS rule: existing version `1.3` becomes `2.1`; name uses MCI, Product, Version; multilayer uses major version in the name; Conversion To All Derived Products Allowed is Yes; no product association required.

Secondary PS rule: if existing PS is available, create Product association only when absent.

Product rules: Complaint derived product is not allowed for Salcomix 1306, including a product under 1306 parent. Product 752 is rejected. Error handling includes invalid version, missing Product/PS, failed/duplicate association, and failed Color creation.

Business reason, example, and BU/Sub-BU: Not provided.

Preserve requirement; do not modify application code or publish to Azure DevOps.
