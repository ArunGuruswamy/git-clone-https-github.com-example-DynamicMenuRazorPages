# 306400 - [CAA] [DAB API] Creation of "Complaint" PaintSystem - (Part1)

Status: Ready for PO-BA review

## Original requirement

See `REQUEST.md`.

## Business need and actors

Users need Complaint Paint System processing for Primary and Secondary Derived Products after a valid Complaint IR.

## Current behavior and supporting evidence

**CONFIRMED:** Legacy `PaintSystemOperations` routes Complaint type 1 separately for Primary and Secondary Derived Products. Primary major version increments and alternative resets to 1; Secondary appends `C` to the alternative. Primary and Secondary paths create Color for tools 2/4. `Source/Formula/PaintSystem/PaintSystem/PaintSystemOperations.cs`.

**CONFIRMED:** Current conversion logic blocks Complaint conversion for Salcomix 1306 and a derived product under a 1306 parent. Product 752 returns false for conversion but absolute rejection was not confirmed in this path. Same source.

**INFERRED:** PBI 305183 covers substantially similar Complaint IR rules, but its decisions do not approve this separate PBI.

## Expected behavior

1. Process Complaint PS after approved IR validation and product pre-validation.
2. For Primary Derived Product, increment major version and reset alternative to 1; create Color; set conversion to all products allowed; do not associate Product.
3. For Secondary Derived Product, associate Product only when not already associated. If already associated, continue silently without a duplicate association.
4. Handle invalid version, missing Product/PS, association, and Color failures. Invalid version shows `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.` Missing Product shows `Product is missing. A Complaint Paint System cannot be created.` Missing existing PS shows `An existing Paint System is required. A Complaint Paint System cannot be created.` Failed Product association shows `Product association failed. The Complaint Paint System could not be completed.` Failed Color creation shows `Color creation failed. The Complaint Paint System could not be completed.`
5. Do not apply the product 752 rejection during Paint System Part 1 processing; it applies only while creating the IR.
6. Revalidate the Salcomix 1306 derived-product Complaint restriction during both IR creation and Paint System Part 1 processing.

## Business rules

| ID | Rule | Evidence / decision | Confidence / unresolved issue |
| --- | --- | --- | --- |
| BR-01 | Complaint type is processed separately for Primary and Secondary Derived Products. | Current source. | CONFIRMED |
| BR-02 | Primary version `{major+1}.1`; existing `1.3` becomes `2.1`. | Intake and current source. | CONFIRMED |
| BR-03 | Primary sets conversion allowed and creates Color; no Product association. | Intake; partial source support. | Feasibility review pending. |
| BR-04 | Secondary associates Product only if absent. | Intake and current source path. | Feasibility review pending. |
| BR-05 | Product 752 rejection applies only during IR creation and is out of scope for Paint System Part 1 processing. | User decision, 2026-10-07. | Approved business decision. |
| BR-06 | Salcomix 1306 derived-product Complaint restriction applies during both IR creation and Paint System Part 1 processing. IR shows `Complaint Imitation Requests are not allowed for a derived product in the Salcomix 1306 product family.` PS shows `Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.` | User decision, 2026-10-07. | Approved business decision; PS enforcement feasibility is pending. |
| BR-07 | Invalid existing PS version format blocks Complaint PS creation with the approved message. | User decision, 2026-10-07. | Approved business decision; technical validation behavior is pending review. |
| BR-08 | Missing Product blocks Complaint PS creation with the approved message. | User decision, 2026-10-07. | Approved business decision; technical validation behavior is pending review. |
| BR-09 | Missing existing PS blocks Complaint PS creation with the approved message. | User decision, 2026-10-07. | Approved business decision; technical validation behavior is pending review. |
| BR-10 | Failed Product association blocks Complaint PS completion with the approved message. | User decision, 2026-10-07. | Approved business decision; technical behavior is pending review. |
| BR-11 | Existing Product association does not create a duplicate or show a message; processing continues silently. | User decision, 2026-10-07. | Approved business decision; technical behavior is pending review. |
| BR-12 | Failed Color creation blocks Complaint PS completion with the approved message. | User decision, 2026-10-07. | Approved business decision; technical behavior is pending review. |

## Acceptance criteria

| ID | Given | When | Then |
| --- | --- | --- | --- |
| AC-01 | Primary Derived Product PS version is `1.3` | Complaint PS is created | PS version is `2.1`. |
| AC-02 | Primary Derived Product Complaint PS is created | Processing succeeds | Color is created and conversion is allowed without Product association. |
| AC-03 | Secondary Derived Product is not associated to existing PS | Complaint PS processing succeeds | Product association is created once. |
| AC-04 | Product is Salcomix 1306 derived | User creates Complaint IR | Creation is blocked with `Complaint Imitation Requests are not allowed for a derived product in the Salcomix 1306 product family.` |
| AC-05 | Product is Salcomix 1306 derived | Complaint Paint System Part 1 processing starts | Processing is blocked with `Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.` |
| AC-06 | Existing PS version format is invalid | Complaint PS processing starts | Processing is blocked with `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.` |
| AC-07 | Product is missing | Complaint PS processing starts | Processing is blocked with `Product is missing. A Complaint Paint System cannot be created.` |
| AC-08 | Required existing PS is missing | Complaint PS processing starts | Processing is blocked with `An existing Paint System is required. A Complaint Paint System cannot be created.` |
| AC-09 | Product association fails | Complaint PS processing starts | Processing is blocked with `Product association failed. The Complaint Paint System could not be completed.` |
| AC-10 | Product is already associated to the PS | Complaint PS processing starts | Processing continues without a duplicate association or message. |
| AC-11 | Color creation fails | Complaint PS processing starts | Processing is blocked with `Color creation failed. The Complaint Paint System could not be completed.` |

## Dependencies and affected business areas

Complaint IR validation, Product/parent Product, PS, Color, Formula, and Product association. DAB/CDMS source paths are unavailable.

## Open questions and blockers

See `OPEN-QUESTIONS.md`.

## PO/BA decisions

See `DECISION-LOG.md`.

## Review status

- Business approval: Pending
- Technical feasibility review: Pending
- Blocking questions: Resolved
- Readiness: Ready for PO-BA review
