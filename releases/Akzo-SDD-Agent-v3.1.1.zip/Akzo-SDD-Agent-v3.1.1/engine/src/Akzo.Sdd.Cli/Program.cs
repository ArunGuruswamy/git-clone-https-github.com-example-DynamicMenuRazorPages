using Akzo.Sdd.Core.Cli;
using Akzo.Sdd.Core.Execution;
using Akzo.Sdd.Core.State;

using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(60) };
var app = new SddApp(new ProcessRunner(), new SystemClock(), http, Console.Out);
return await app.RunAsync(args).ConfigureAwait(false);
