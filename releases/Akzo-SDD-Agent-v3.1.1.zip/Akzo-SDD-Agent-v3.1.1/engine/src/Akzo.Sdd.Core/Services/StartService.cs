using System.Text;
using Akzo.Sdd.Core.Artifacts;
using Akzo.Sdd.Core.IO;
using Akzo.Sdd.Core.Metrics;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Questions;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.Services;

/// <summary>Options for <see cref="StartService"/>.</summary>
/// <param name="Repository">Any folder inside the repository.</param>
/// <param name="Request">The developer's verbatim request.</param>
/// <param name="Source">Optional package to import.</param>
/// <param name="Role">Optional explicit role.</param>
/// <param name="Feature">Optional explicit feature name.</param>
public sealed record StartOptions(string Repository, string Request, string? Source, ProjectRole Role, string? Feature);

/// <summary>Start result (also printed as JSON for the agent).</summary>
public sealed class StartResult
{
    /// <summary>Initialized, Resumed, PbiNotFound or PbiAmbiguous.</summary>
    public string Status { get; set; } = string.Empty;

    /// <summary>Repository root.</summary>
    public string RepositoryRoot { get; set; } = string.Empty;

    /// <summary>PBI id.</summary>
    public string PbiId { get; set; } = string.Empty;

    /// <summary>PBI title.</summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>Feature folder name.</summary>
    public string Feature { get; set; } = string.Empty;

    /// <summary>Selected role.</summary>
    public ProjectRole Role { get; set; }

    /// <summary>Copilot skill to load.</summary>
    public string Skill { get; set; } = string.Empty;

    /// <summary>Repository-fit findings (readiness, title tags, scope, evidence files, UI-only ACs).</summary>
    public IReadOnlyList<FitFinding> Fit { get; set; } = [];

    /// <summary>Absolute spec.md path.</summary>
    public string SpecPath { get; set; } = string.Empty;

    /// <summary>Absolute plan.md path.</summary>
    public string PlanPath { get; set; } = string.Empty;

    /// <summary>Absolute change folder.</summary>
    public string ChangeFolder { get; set; } = string.Empty;

    /// <summary>True when spec.md was written by this run (false = existing file preserved).</summary>
    public bool SpecCreated { get; set; }

    /// <summary>True when plan.md was written by this run.</summary>
    public bool PlanCreated { get; set; }

    /// <summary>Counts read from the package.</summary>
    public string PackageSummary { get; set; } = string.Empty;

    /// <summary>Role detection evidence.</summary>
    public IReadOnlyList<string> RoleEvidence { get; set; } = [];

    /// <summary>Candidate PBI ids or searched folders when not found.</summary>
    public IReadOnlyList<string> Candidates { get; set; } = [];

    /// <summary>Unanswered multiple-choice questions.</summary>
    public IReadOnlyList<ChoiceQuestion> Questions { get; set; } = [];

    /// <summary>Remaining analysis findings (sdd:fill markers etc.).</summary>
    public IReadOnlyList<string> Findings { get; set; } = [];

    /// <summary>Engine run time in milliseconds.</summary>
    public long ElapsedMilliseconds { get; set; }
}

/// <summary>Implements <c>sdd start</c>: resolve root, import, read the PBI, detect role, write draft spec/plan, build questions.</summary>
public static class StartService
{
    /// <summary>Engine phase name recorded in metrics.</summary>
    public const string EnginePhase = "Start (sdd engine)";

    /// <summary>Analysis phase name recorded in metrics.</summary>
    public const string AnalysisPhase = "Analysis (agent)";

    /// <summary>Runs start.</summary>
    /// <param name="options">Options.</param>
    /// <param name="clock">Clock.</param>
    /// <returns>Result.</returns>
    public static StartResult Start(StartOptions options, IClock clock)
    {
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(clock);
        var began = clock.UtcNow;
        var watch = System.Diagnostics.Stopwatch.StartNew();
        var root = RepositoryLocator.FindRoot(options.Repository);
        var workspace = new SddWorkspace(root, clock);
        var request = StartRequest.Parse(options.Request);
        var pbiId = request.PbiId;
        var source = options.Source ?? request.Source;
        if (!string.IsNullOrWhiteSpace(source))
        {
            pbiId = PbiImporter.Import(source, root).PbiId;
        }

        var location = PbiLocator.Locate(root, pbiId);
        if (!location.Found)
        {
            return NotFound(root, pbiId, location);
        }

        var package = PbiPackageReader.Read(location.Folder!);
        var settings = SddSettings.Load(root);
        var existing = workspace.TryLoad(package.Id);
        var detection = RoleDetector.Detect(root);
        var role = FirstKnown(options.Role, existing?.Role ?? ProjectRole.Unknown, settings.ConfiguredRole(), detection.Role);
        var specRoot = RepositoryLocator.SpecRoot(root);
        var feature = FirstNonEmpty(
            options.Feature,
            existing?.Feature,
            RepositoryLocator.FindExistingFeature(specRoot, package.Id),
            FeatureNameBuilder.Candidates(package.Title, request.FeatureHint)[0]);

        var state = existing ?? new SddState { CreatedUtc = began };
        state.PbiId = package.Id;
        state.Title = package.Title;
        state.Feature = feature;
        state.Role = role;
        state.PackageFolder = FileHash.Relative(root, package.Folder);
        var specPath = Path.Combine(specRoot, feature, SddConstants.SpecFile);
        var planPath = Path.Combine(specRoot, feature, SddConstants.PlanFile);
        state.SpecPath = FileHash.Relative(root, specPath);
        state.PlanPath = FileHash.Relative(root, planPath);

        var fit = RepositoryFit.Analyse(package, root, role);
        if (state.Phase == SddPhase.Analysis)
        {
            state.FitWarnings = fit.Where(f => f.Level == FitLevel.Warn).Select(f => f.Text).ToList();
        }
        var context = new ArtifactContext(package, feature, role, state.PackageFolder, settings) { Fit = fit };
        var specCreated = WriteIfMissing(specPath, () => SpecWriter.Build(context), state);
        var planCreated = WriteIfMissing(planPath, () => PlanWriter.Build(context), state);
        if (planCreated)
        {
            state.GeneratedPlanHash = FileHash.OfFile(planPath);
        }

        RecordMetrics(state, existing is null, began, clock);
        var featureCandidates = FeatureNameBuilder.Candidates(package.Title, request.FeatureHint);
        var questions = QuestionBuilder.Build(QuestionStage.Start, package, state, detection.Candidates, featureCandidates);
        workspace.Save(state);
        File.WriteAllText(workspace.ChangeFile(state, SddConstants.QuestionsFile), RenderQuestions(questions));
        watch.Stop();

        return new StartResult
        {
            Status = existing is null ? "Initialized" : "Resumed",
            RepositoryRoot = root,
            PbiId = package.Id,
            Title = package.Title,
            Feature = feature,
            Role = role,
            Skill = role == ProjectRole.Unknown ? string.Empty : RoleProfile.For(role).Skill,
            SpecPath = specPath,
            PlanPath = planPath,
            ChangeFolder = workspace.ChangeFolder(state),
            SpecCreated = specCreated,
            PlanCreated = planCreated,
            PackageSummary = $"{package.AcceptanceCriteria.Count} AC, {package.BusinessRules.Count} business rules, {package.Decisions.Count} decisions ({package.Decisions.Count(d => !d.IsApproved)} not approved), {package.OpenQuestions.Count} questions ({package.OpenQuestions.Count(q => !q.IsResolved)} open), {package.Files.Count} files",
            RoleEvidence = detection.Evidence,
            Fit = fit,
            Questions = questions,
            Findings = ArtifactValidator.Validate(specPath, planPath, package).Findings,
            ElapsedMilliseconds = watch.ElapsedMilliseconds,
        };
    }

    /// <summary>Renders questions as Markdown for chats without a picker tool.</summary>
    /// <param name="questions">Questions.</param>
    /// <returns>Markdown.</returns>
    public static string RenderQuestions(IEnumerable<ChoiceQuestion> questions)
    {
        ArgumentNullException.ThrowIfNull(questions);
        var sb = new StringBuilder("# Pending questions\n\nReply with the question id and option number, e.g. `Q-BIZ 1`.\n\n");
        foreach (var question in questions)
        {
            sb.Append(question.ToMarkdown()).Append('\n');
        }

        return sb.ToString();
    }

    private static StartResult NotFound(string root, string pbiId, PbiLocation location)
    {
        var ambiguous = string.IsNullOrWhiteSpace(pbiId) && location.Candidates.Count > 1;
        var question = ambiguous
            ? new ChoiceQuestion(
                "Q-PBI",
                "Several PBI packages exist. Which one do you want to develop?",
                location.Candidates.Select(c => new ChoiceOption(c, c, $"Start Development {c}")).ToList(),
                null,
                Blocking: true,
                QuestionStage.Start)
            : null;
        return new StartResult
        {
            Status = ambiguous ? ErrorCodes.PbiAmbiguous : ErrorCodes.PbiNotFound,
            RepositoryRoot = root,
            PbiId = pbiId,
            Candidates = ambiguous ? location.Candidates : location.Searched,
            Questions = question is null ? [] : [question],
        };
    }

    private static bool WriteIfMissing(string path, Func<string> content, SddState state)
    {
        if (File.Exists(path))
        {
            return false;
        }

        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var text = content();
        File.WriteAllText(path, text);
        state.GeneratedCharacters += text.Length;
        return true;
    }

    private static void RecordMetrics(SddState state, bool isNew, DateTimeOffset began, IClock clock)
    {
        if (!isNew)
        {
            return;
        }

        MetricsService.StartPhase(state, EnginePhase, began);
        MetricsService.EndPhase(state, EnginePhase, clock.UtcNow);
        MetricsService.StartPhase(state, AnalysisPhase, clock.UtcNow);
    }

    private static ProjectRole FirstKnown(params ProjectRole[] roles) =>
        Array.Find(roles, r => r != ProjectRole.Unknown);

    private static string FirstNonEmpty(params string?[] values) =>
        values.First(v => !string.IsNullOrWhiteSpace(v))!;
}
