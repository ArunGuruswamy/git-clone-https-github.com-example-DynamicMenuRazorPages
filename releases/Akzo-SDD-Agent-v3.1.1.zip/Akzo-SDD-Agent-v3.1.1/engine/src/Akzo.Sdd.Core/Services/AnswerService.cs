using Akzo.Sdd.Core.Artifacts;
using Akzo.Sdd.Core.IO;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Questions;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.Services;

/// <summary>Records a multiple-choice answer and applies its effect (role, mode, feature rename).</summary>
public static class AnswerService
{
    /// <summary>Records the answer.</summary>
    /// <param name="workspace">Workspace.</param>
    /// <param name="state">State.</param>
    /// <param name="package">PBI package.</param>
    /// <param name="questionId">Question id.</param>
    /// <param name="answer">Option key or 1-based number.</param>
    /// <param name="note">Optional free text (for example the answer to an open question).</param>
    /// <returns>The chosen option.</returns>
    /// <exception cref="SddException">When the question or option is unknown.</exception>
    public static ChoiceOption Answer(SddWorkspace workspace, SddState state, PbiPackage package, string questionId, string answer, string? note)
    {
        ArgumentNullException.ThrowIfNull(workspace);
        ArgumentNullException.ThrowIfNull(state);
        ArgumentNullException.ThrowIfNull(package);
        var candidates = FeatureNameBuilder.Candidates(package.Title, null).Append(state.Feature).Distinct(StringComparer.Ordinal).ToList();
        var question = QuestionBuilder.All(package, state, candidates)
            .FirstOrDefault(q => string.Equals(q.Id, questionId, StringComparison.OrdinalIgnoreCase))
            ?? throw new SddException(ErrorCodes.InvalidAnswer, $"Unknown question '{questionId}'.");
        var option = question.Resolve(answer)
            ?? throw new SddException(ErrorCodes.InvalidAnswer, $"'{answer}' is not an option of {question.Id}: {string.Join(", ", question.Options.Select(o => o.Key))}.");

        Apply(workspace, state, package, question.Id, option.Key);
        state.Answers[question.Id] = option.Key;
        if (!string.IsNullOrWhiteSpace(note))
        {
            state.AnswerNotes[question.Id] = note.Trim();
        }

        workspace.Save(state);
        return option;
    }

    private static void Apply(SddWorkspace workspace, SddState state, PbiPackage package, string questionId, string key)
    {
        switch (questionId.ToUpperInvariant())
        {
            case QuestionBuilder.RoleId:
                state.Role = Enum.Parse<ProjectRole>(key, ignoreCase: true);
                RegeneratePlanIfUntouched(workspace, state, package);
                break;
            case QuestionBuilder.ModeId:
                state.Mode = key.ToUpperInvariant();
                break;
            case QuestionBuilder.FeatureId:
                Rename(workspace, state, key);
                break;
            default:
                break;
        }
    }

    private static void RegeneratePlanIfUntouched(SddWorkspace workspace, SddState state, PbiPackage package)
    {
        var plan = workspace.Absolute(state.PlanPath);
        if (File.Exists(plan) && string.Equals(FileHash.OfFile(plan), state.GeneratedPlanHash, StringComparison.Ordinal))
        {
            var context = new ArtifactContext(package, state.Feature, state.Role, state.PackageFolder, SddSettings.Load(workspace.Root));
            File.WriteAllText(plan, PlanWriter.Build(context));
            state.GeneratedPlanHash = FileHash.OfFile(plan);
        }
    }

    private static void Rename(SddWorkspace workspace, SddState state, string feature)
    {
        if (string.Equals(feature, state.Feature, StringComparison.Ordinal))
        {
            return;
        }

        if (state.Phase >= SddPhase.Implement)
        {
            throw new SddException(ErrorCodes.InvalidAnswer, "The feature folder cannot be renamed after implementation approval.");
        }

        var oldSpecFolder = Path.GetDirectoryName(workspace.Absolute(state.SpecPath))!;
        var newSpecFolder = Path.Combine(Path.GetDirectoryName(oldSpecFolder)!, feature);
        if (Directory.Exists(newSpecFolder))
        {
            throw new SddException(ErrorCodes.InvalidAnswer, $"Folder '{newSpecFolder}' already exists; it is never overwritten.");
        }

        var oldChange = workspace.ChangeFolder(state);
        var planUntouched = string.Equals(FileHash.OfFile(workspace.Absolute(state.PlanPath)), state.GeneratedPlanHash, StringComparison.Ordinal);
        Directory.Move(oldSpecFolder, newSpecFolder);
        foreach (var file in Directory.EnumerateFiles(newSpecFolder, "*.md"))
        {
            var text = File.ReadAllText(file)
                .Replace($"# {state.Feature} - ", $"# {feature} - ", StringComparison.Ordinal)
                .Replace($"- Feature folder: {state.Feature}", $"- Feature folder: {feature}", StringComparison.Ordinal);
            File.WriteAllText(file, text);
        }

        var oldFeature = state.Feature;
        state.Feature = feature;
        state.SpecPath = state.SpecPath.Replace("/" + oldFeature + "/", "/" + feature + "/", StringComparison.Ordinal);
        state.PlanPath = state.PlanPath.Replace("/" + oldFeature + "/", "/" + feature + "/", StringComparison.Ordinal);
        if (planUntouched)
        {
            state.GeneratedPlanHash = FileHash.OfFile(workspace.Absolute(state.PlanPath));
        }

        if (Directory.Exists(oldChange))
        {
            Directory.Move(oldChange, workspace.ChangeFolder(state));
        }
    }
}
