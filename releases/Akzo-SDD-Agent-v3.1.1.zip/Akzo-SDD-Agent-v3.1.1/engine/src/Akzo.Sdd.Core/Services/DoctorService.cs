using System.Text.RegularExpressions;
using Akzo.Sdd.Core.Execution;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.Services;

/// <summary>Health-check outcome.</summary>
public enum CheckStatus
{
    /// <summary>Check passed.</summary>
    Pass = 0,

    /// <summary>Works, but should be reviewed.</summary>
    Warn,

    /// <summary>Must be fixed before using the agent.</summary>
    Fail,
}

/// <summary>One health-check line.</summary>
/// <param name="Name">Check name.</param>
/// <param name="Status">Outcome.</param>
/// <param name="Detail">Evidence or how to fix.</param>
public sealed record DoctorCheck(string Name, CheckStatus Status, string Detail);

/// <summary>Verifies that a repository is ready for the Akzo SDD Agent (used by the setup wizard and for support).</summary>
public static partial class DoctorService
{
    private static readonly TimeSpan Timeout = TimeSpan.FromMinutes(1);

    private static readonly string[] RequiredFiles =
    [
        ".github/agents/akzo-sdd.agent.md",
        ".github/agents/akzo-sdd-reviewer.agent.md",
        ".github/sdd/workflow.md",
        ".github/sdd/constitution.md",
        ".github/instructions/sonar-rules.instructions.md",
    ];

    /// <summary>Runs all checks.</summary>
    /// <param name="repository">Any folder inside the repository.</param>
    /// <param name="runner">Process runner.</param>
    /// <returns>Checks in display order.</returns>
    public static async Task<IReadOnlyList<DoctorCheck>> RunAsync(string repository, IProcessRunner runner)
    {
        ArgumentNullException.ThrowIfNull(runner);
        var root = RepositoryLocator.FindRoot(repository);
        var checks = new List<DoctorCheck>
        {
            new("sdd tool", CheckStatus.Pass, "v" + SddConstants.Version),
            await DotnetCheckAsync(root, runner).ConfigureAwait(false),
            await GitCheckAsync(root, runner).ConfigureAwait(false),
            RepositoryCheck(root),
        };
        checks.AddRange(RequiredFiles.Select(f => FileCheck(root, f)));
        checks.AddRange(HeaderChecks(root));
        checks.Add(AgentVersionCheck(root));
        checks.Add(SettingsCheck(root));
        checks.Add(await SpecsFolderCheckAsync(root, runner).ConfigureAwait(false));
        return checks;
    }

    /// <summary>Overall outcome: the worst status found.</summary>
    /// <param name="checks">Checks.</param>
    /// <returns>Worst status.</returns>
    public static CheckStatus Overall(IEnumerable<DoctorCheck> checks) =>
        checks.Select(c => c.Status).DefaultIfEmpty(CheckStatus.Pass).Max();

    private static async Task<DoctorCheck> DotnetCheckAsync(string root, IProcessRunner runner)
    {
        var result = await runner.RunAsync("dotnet --version", root, Timeout).ConfigureAwait(false);
        var match = MajorRegex().Match(result.Output);
        var major = match.Success ? int.Parse(match.Groups["major"].Value, System.Globalization.CultureInfo.InvariantCulture) : 0;
        return result.Succeeded && major >= 8
            ? new DoctorCheck(".NET SDK", CheckStatus.Pass, result.Output.Trim())
            : new DoctorCheck(".NET SDK", CheckStatus.Fail, "Install the .NET 8 SDK or later: https://dotnet.microsoft.com/download");
    }

    private static async Task<DoctorCheck> GitCheckAsync(string root, IProcessRunner runner)
    {
        var result = await runner.RunAsync("git --version", root, Timeout).ConfigureAwait(false);
        return result.Succeeded
            ? new DoctorCheck("Git", CheckStatus.Pass, result.Output.Trim())
            : new DoctorCheck("Git", CheckStatus.Fail, "Install Git for Windows and reopen the command prompt.");
    }

    private static DoctorCheck RepositoryCheck(string root) =>
        Directory.Exists(Path.Combine(root, ".git")) || File.Exists(Path.Combine(root, ".git"))
            ? new DoctorCheck("Repository root", CheckStatus.Pass, root)
            : new DoctorCheck("Repository root", CheckStatus.Fail, $"No .git found at or above '{root}'. Choose the cloned repository folder.");

    private static DoctorCheck FileCheck(string root, string relative) =>
        File.Exists(Path.Combine(root, relative))
            ? new DoctorCheck(relative, CheckStatus.Pass, "present")
            : new DoctorCheck(relative, CheckStatus.Fail, "missing - run: sdd install --role <dab|cdms|ui> --repo <path>");

    private static IEnumerable<DoctorCheck> HeaderChecks(string root)
    {
        var github = Path.Combine(root, ".github");
        if (!Directory.Exists(github))
        {
            return [];
        }

        return Directory.EnumerateFiles(github, "*.md", SearchOption.AllDirectories)
            .Where(f => f.EndsWith(".agent.md", StringComparison.OrdinalIgnoreCase)
                        || f.EndsWith(".prompt.md", StringComparison.OrdinalIgnoreCase)
                        || f.EndsWith(".instructions.md", StringComparison.OrdinalIgnoreCase))
            .Select(f => (Path: Path.GetRelativePath(root, f).Replace('\\', '/'), Problems: FrontmatterValidator.Validate(File.ReadAllText(f))))
            .Where(r => r.Problems.Count > 0)
            .Select(r => new DoctorCheck("Header " + r.Path, CheckStatus.Fail, "Copilot will ignore this file: " + string.Join("; ", r.Problems)));
    }

    private static DoctorCheck AgentVersionCheck(string root)
    {
        var path = Path.Combine(root, RequiredFiles[0]);
        if (!File.Exists(path))
        {
            return new DoctorCheck("Agent version", CheckStatus.Fail, "agent file missing");
        }

        var marker = "akzo-sdd-agent: " + SddConstants.Version;
        return File.ReadAllText(path).Contains(marker, StringComparison.Ordinal)
            ? new DoctorCheck("Agent version", CheckStatus.Pass, SddConstants.Version)
            : new DoctorCheck("Agent version", CheckStatus.Warn, $"agent file is not v{SddConstants.Version} (team-modified or older) - review, then sdd install --force");
    }

    private static DoctorCheck SettingsCheck(string root)
    {
        if (!File.Exists(Path.Combine(root, SddConstants.SettingsFile)))
        {
            return new DoctorCheck("Settings", CheckStatus.Warn, ".sdd/settings.json missing - role is auto-detected and default commands are used");
        }

        var settings = SddSettings.Load(root);
        var role = settings.ConfiguredRole();
        if (role == ProjectRole.Unknown)
        {
            return new DoctorCheck("Settings", CheckStatus.Warn, "role not set in .sdd/settings.json");
        }

        return string.IsNullOrWhiteSpace(settings.BuildCommand) || string.IsNullOrWhiteSpace(settings.TestCommand)
            ? new DoctorCheck("Settings", CheckStatus.Warn, $"role {role}; default build/test commands in use - set buildCommand/testCommand for your solution")
            : new DoctorCheck("Settings", CheckStatus.Pass, $"role {role}; custom build/test commands");
    }

    private static async Task<DoctorCheck> SpecsFolderCheckAsync(string root, IProcessRunner runner)
    {
        var folder = Path.GetRelativePath(root, RepositoryLocator.SpecRoot(root)).Replace('\\', '/');
        var probe = folder + "/PBI-Feature/spec.md";
        var ignored = await runner.RunAsync($"git check-ignore -v \"{probe}\"", root, Timeout).ConfigureAwait(false);
        return ignored.Succeeded
            ? new DoctorCheck("Specs folder", CheckStatus.Fail, $"Git ignores {folder}/ ({ignored.Output.Trim()}) - remove that rule so spec.md and plan.md show in Git Changes")
            : new DoctorCheck("Specs folder", CheckStatus.Pass, $"{folder}/<PBI-Feature>/spec.md and plan.md (checked in with the PR)");
    }

    [GeneratedRegex(@"^(?<major>\d+)\.", RegexOptions.Multiline, 1000)]
    private static partial Regex MajorRegex();
}
