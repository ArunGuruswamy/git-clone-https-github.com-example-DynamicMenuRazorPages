using System.Globalization;
using System.Text;
using Akzo.Sdd.Core.Approval;
using Akzo.Sdd.Core.Artifacts;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Pr;
using Akzo.Sdd.Core.Questions;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Verification;

namespace Akzo.Sdd.Core.Services;

/// <summary>Where the PBI is in the delivery flow.</summary>
public enum NextStep
{
    /// <summary>Analysis artifacts are incomplete.</summary>
    CompleteAnalysis = 0,

    /// <summary>Waiting for the developer's approval.</summary>
    Approve,

    /// <summary>Approved tasks remain.</summary>
    Implement,

    /// <summary>All tasks recorded; targeted verification missing or failing.</summary>
    Verify,

    /// <summary>Ready for the independent reviewer.</summary>
    Review,

    /// <summary>Reviewer found issues to fix.</summary>
    FixFindings,

    /// <summary>Review is READY FOR PR; final verification and PR text remain.</summary>
    FinalizePr,

    /// <summary>PR text generated; the developer commits and raises the PR.</summary>
    RaisePr,
}

/// <summary>Builds the deterministic status report and the single next action, ending every agent phase.</summary>
public static class NextStepService
{
    /// <summary>Decides the next step from real state on disk.</summary>
    /// <param name="workspace">Workspace.</param>
    /// <param name="state">State.</param>
    /// <param name="package">PBI package.</param>
    /// <returns>Next step.</returns>
    public static NextStep Decide(SddWorkspace workspace, SddState state, PbiPackage package)
    {
        ArgumentNullException.ThrowIfNull(workspace);
        ArgumentNullException.ThrowIfNull(state);
        if (state.Phase == SddPhase.PrReady)
        {
            return NextStep.RaisePr;
        }

        if (ApprovalService.Load(workspace, state) is null)
        {
            var analysisDone = ArtifactValidator.Validate(workspace.Absolute(state.SpecPath), workspace.Absolute(state.PlanPath), package).Passed;
            return analysisDone ? NextStep.Approve : NextStep.CompleteAnalysis;
        }

        if (RemainingTasks(workspace, state).Count > 0)
        {
            return NextStep.Implement;
        }

        var verificationPath = workspace.ChangeFile(state, SddConstants.VerificationFile);
        var verified = VerificationReport.Load(verificationPath) is { Passed: true };
        var verdict = Verdict(workspace, state);
        if (verdict is null)
        {
            return verified ? NextStep.Review : NextStep.Verify;
        }

        if (string.Equals(verdict, PrDescriptionBuilder.ReadyVerdict, StringComparison.OrdinalIgnoreCase))
        {
            return NextStep.FinalizePr;
        }

        var fixedAfterReview = verified
            && File.GetLastWriteTimeUtc(verificationPath) > File.GetLastWriteTimeUtc(workspace.ChangeFile(state, SddConstants.ReviewFile));
        return fixedAfterReview ? NextStep.Review : NextStep.FixFindings;
    }

    /// <summary>Renders the report shown to the developer at the end of a phase.</summary>
    /// <param name="workspace">Workspace.</param>
    /// <param name="state">State.</param>
    /// <param name="package">PBI package.</param>
    /// <returns>Markdown.</returns>
    public static string Render(SddWorkspace workspace, SddState state, PbiPackage package)
    {
        ArgumentNullException.ThrowIfNull(workspace);
        ArgumentNullException.ThrowIfNull(state);
        ArgumentNullException.ThrowIfNull(package);
        var step = Decide(workspace, state, package);
        var sb = new StringBuilder();
        Line(sb, $"## {Title(step)} - PBI {state.PbiId} {state.Feature}");
        Line(sb, string.Empty);
        Line(sb, "| Item | Status |");
        Line(sb, "|---|---|");
        Line(sb, $"| Phase | {state.Phase} ({state.Mode}) |");
        Line(sb, $"| Tasks | {TaskSummary(workspace, state)} |");
        Line(sb, $"| Verification | {VerificationSummary(workspace, state)} |");
        Line(sb, $"| Review | {Verdict(workspace, state) ?? "not started"} |");
        Line(sb, $"| Business approval | {(package.IsBusinessApproved ? "Approved" : "Pending - " + Answer(state, QuestionBuilder.BusinessId))} |");
        if (package.IsBlocked)
        {
            Line(sb, $"| PBI readiness | BLOCKED (Readiness: {package.Readiness}) - {Answer(state, QuestionBuilder.BusinessId)} |");
        }

        Line(sb, $"| Spec / plan (check in with the PR) | `{state.SpecPath}`, `{state.PlanPath}` |");
        Line(sb, string.Empty);
        OpenItems(sb, state);
        Line(sb, "### Next");
        Line(sb, Action(step, workspace, state));
        return sb.ToString();
    }

    private static IReadOnlyList<string> RemainingTasks(SddWorkspace workspace, SddState state)
    {
        var planned = ArtifactValidator.ReadTasks(File.ReadAllText(workspace.Absolute(state.PlanPath))).Keys;
        return planned.Where(t => !state.Tasks.Exists(d => string.Equals(d.Id, t, StringComparison.OrdinalIgnoreCase))).ToList();
    }

    private static string? Verdict(SddWorkspace workspace, SddState state)
    {
        var path = workspace.ChangeFile(state, SddConstants.ReviewFile);
        return File.Exists(path) ? PrDescriptionBuilder.ReadVerdict(File.ReadAllText(path)) : null;
    }

    private static string TaskSummary(SddWorkspace workspace, SddState state)
    {
        var remaining = RemainingTasks(workspace, state);
        var done = state.Tasks.Select(t => t.Id).OrderBy(t => t, StringComparer.Ordinal);
        return remaining.Count == 0
            ? $"all recorded ({string.Join(", ", done)})"
            : $"remaining {string.Join(", ", remaining)}";
    }

    private static string VerificationSummary(SddWorkspace workspace, SddState state)
    {
        var v = VerificationReport.Load(workspace.ChangeFile(state, SddConstants.VerificationFile));
        if (v is null)
        {
            return "NOT EXECUTED";
        }

        var tests = v.Tests is null ? "tests n/a" : $"tests {v.Tests.Passed}/{v.Tests.Executed}";
        var coverage = v.CoveragePercent is null ? "coverage n/a" : string.Create(CultureInfo.InvariantCulture, $"coverage {v.CoveragePercent:0.##}% (>= {v.Threshold:0.#}%)");
        return $"{v.Scope} {(v.Passed ? "PASS" : "FAIL")} - {tests}, {coverage}";
    }

    private static void OpenItems(StringBuilder sb, SddState state)
    {
        var notes = state.AnswerNotes.Select(n => $"{n.Key}: {n.Value}").ToList();
        if (notes.Count == 0)
        {
            return;
        }

        Line(sb, "### Recorded decisions and dependencies");
        foreach (var note in notes)
        {
            Line(sb, "- " + note);
        }

        Line(sb, string.Empty);
    }

    private static string Answer(SddState state, string id) =>
        state.Answers.TryGetValue(id, out var value) ? "developer chose '" + value + "'" : "not acknowledged";

    private static string Title(NextStep step) => step switch
    {
        NextStep.CompleteAnalysis => "Analysis in progress",
        NextStep.Approve => "Analysis complete - approval needed",
        NextStep.Implement => "Implementation in progress",
        NextStep.Verify => "Implementation done - verification needed",
        NextStep.Review => "Implementation complete",
        NextStep.FixFindings => "Review: changes required",
        NextStep.FinalizePr => "Review passed",
        _ => "PR ready",
    };

    private static string Action(NextStep step, SddWorkspace workspace, SddState state) => step switch
    {
        NextStep.CompleteAnalysis => "Agent: fill the remaining sdd:fill/TBD items, then `sdd check`.",
        NextStep.Approve => "Developer: answer **Q-APPROVE** (`sdd questions --stage approval`).",
        NextStep.Implement => "Agent: continue the remaining tasks, `sdd verify --scope targeted`, then `sdd task <T-id>`.",
        NextStep.Verify => "Agent: run `sdd verify --scope targeted` and fix until Build, Tests and Coverage PASS.",
        NextStep.Review => """
            **Independent review (switch agent once):**
            0. First click **Keep** (Accept all) on Copilot's pending edits, so they are saved to disk before you switch.
            1. In the Copilot Chat agent picker choose **Akzo SDD Reviewer** (VS Code: click *Start pre-PR review*).
            2. Send: `Review`
            The reviewer writes review.md and, when READY FOR PR, runs the final verification and generates the PR text automatically.
            """,
        NextStep.FixFindings => """
            **Fix review findings (switch agent):**
            0. First click **Keep** (Accept all) on any pending Copilot edits.
            1. Choose **Akzo SDD Agent** in the agent picker (VS Code: click *Fix review findings*).
            2. Send: `Fix review findings`
            After the fixes it hands back here for re-review (max 3 rounds).
            """,
        NextStep.FinalizePr => "Reviewer: run `sdd verify --scope final`, complete the independent review, `sdd review-seal`, then `sdd finish`.",
        _ => $"Agent: run `sdd commit-dialog` to show the explicit local commit selection. PR text: `{PrPath(workspace, state)}`. Push, PR creation and merge remain manual.",
    };

    private static string PrPath(SddWorkspace workspace, SddState state) =>
        Path.GetRelativePath(workspace.Root, workspace.ChangeFile(state, SddConstants.PrFile)).Replace('\\', '/');

    private static void Line(StringBuilder sb, string text) => sb.Append(text).Append('\n');
}
