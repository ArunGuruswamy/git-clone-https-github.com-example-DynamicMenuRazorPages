using System.Text.Json;
using Akzo.Sdd.Core.IO;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.Services;

/// <summary>Result of installing the Copilot agent assets into a repository.</summary>
public sealed class InstallResult
{
    /// <summary>Files newly created.</summary>
    public List<string> Created { get; } = [];

    /// <summary>Files updated because the installed copy was unmodified.</summary>
    public List<string> Updated { get; } = [];

    /// <summary>Files already identical.</summary>
    public List<string> Unchanged { get; } = [];

    /// <summary>Files left alone because the team modified them (use --force after review).</summary>
    public List<string> KeptModified { get; } = [];
}

/// <summary>Copies the agent, prompts, instructions, skills and role docs into a repository.
/// Never overwrites a file the team changed unless forced. Never stages or commits.</summary>
public static class InstallService
{
    /// <summary>Manifest of installed file hashes.</summary>
    public const string ManifestFile = ".sdd/installed.json";

    /// <summary>Engine-owned paths that <c>--update-agents</c> replaces even when edited locally.
    /// Team-owned files (constitution, review learnings, instructions, skills) are never in this list.</summary>
    private static readonly string[] EngineOwned =
    [
        ".github/agents/",
        ".github/prompts/",
        ".github/sdd/templates/",
        ".github/sdd/workflow.md",
        ".github/sdd/README.md",
    ];

    /// <summary>Asset folders per role (core is always installed).</summary>
    /// <param name="role">Role.</param>
    /// <returns>Folder names under the assets root.</returns>
    public static IReadOnlyList<string> Folders(ProjectRole role) => role switch
    {
        ProjectRole.Cdms => ["core", "cdms", "backend", "shared"],
        ProjectRole.Ui => ["core", "ui", "shared"],
        _ => ["core", "dab", "shared"],
    };

    /// <summary>Installs or upgrades the assets.</summary>
    /// <param name="assetsRoot">Folder containing core/, dab/, cdms/, ui/, shared/, backend/.</param>
    /// <param name="role">Repository role.</param>
    /// <param name="repository">Repository root (or any folder inside it).</param>
    /// <param name="force">Overwrite files the team modified.</param>
    /// <returns>Result.</returns>
    /// <exception cref="SddException">When the assets folder is missing.</exception>
    public static InstallResult Install(string assetsRoot, ProjectRole role, string repository, bool force) =>
        Install(assetsRoot, role, repository, force, updateAgents: false);

    /// <summary>Installs or upgrades the assets.</summary>
    /// <param name="assetsRoot">Folder containing core/, dab/, cdms/, ui/, shared/, backend/.</param>
    /// <param name="role">Repository role.</param>
    /// <param name="repository">Repository root (or any folder inside it).</param>
    /// <param name="force">Overwrite every file the team modified.</param>
    /// <param name="updateAgents">Overwrite only engine-owned files (agents, prompts, workflow, templates).</param>
    /// <returns>Result.</returns>
    /// <exception cref="SddException">When the assets folder is missing.</exception>
    public static InstallResult Install(string assetsRoot, ProjectRole role, string repository, bool force, bool updateAgents)
    {
        if (!Directory.Exists(Path.Combine(assetsRoot, "core")))
        {
            throw new SddException(ErrorCodes.Failed, $"Agent assets not found in '{assetsRoot}'.");
        }

        var root = RepositoryLocator.FindRoot(repository);
        var manifestPath = Path.Combine(root, ManifestFile);
        var manifest = File.Exists(manifestPath)
            ? JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(manifestPath)) ?? []
            : [];
        var result = new InstallResult();

        foreach (var folder in Folders(role).Select(f => Path.Combine(assetsRoot, f)).Where(Directory.Exists))
        {
            foreach (var source in Directory.EnumerateFiles(folder, "*", SearchOption.AllDirectories))
            {
                var relative = FileHash.Relative(folder, source);
                // Ship as a template: NuGet tool installation must not execute desktop UI scripts.
                if (relative == ".github/sdd/ui/CommitDialog.ps1.template") relative = relative[..^".template".Length];
                var overwrite = force || (updateAgents && IsEngineOwned(relative));
                manifest[relative] = CopyOne(source, Path.Combine(root, relative), relative, manifest, overwrite, result);
            }
        }

        Directory.CreateDirectory(Path.GetDirectoryName(manifestPath)!);
        File.WriteAllText(manifestPath, JsonSerializer.Serialize(manifest, Json.Options));
        WriteSettings(root, role);
        ExcludeLocalFolders(root);
        return result;
    }

    private static string CopyOne(string source, string target, string relative, Dictionary<string, string> manifest, bool force, InstallResult result)
    {
        var sourceHash = FileHash.OfFile(source);
        if (!File.Exists(target))
        {
            Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            File.Copy(source, target);
            result.Created.Add(relative);
            return sourceHash;
        }

        var targetHash = FileHash.OfFile(target);
        if (string.Equals(targetHash, sourceHash, StringComparison.Ordinal))
        {
            result.Unchanged.Add(relative);
            return sourceHash;
        }

        var untouched = manifest.TryGetValue(relative, out var installedHash) && string.Equals(installedHash, targetHash, StringComparison.Ordinal);
        if (untouched || force)
        {
            File.Copy(source, target, overwrite: true);
            result.Updated.Add(relative);
            return sourceHash;
        }

        result.KeptModified.Add(relative);
        return installedHash ?? targetHash;
    }

    /// <summary>True for files the engine owns and may replace with <c>--update-agents</c>.</summary>
    /// <param name="relative">Repository-relative path with forward slashes.</param>
    /// <returns>True when engine-owned.</returns>
    public static bool IsEngineOwned(string relative) =>
        Array.Exists(EngineOwned, p => p.EndsWith('/')
            ? relative.StartsWith(p, StringComparison.OrdinalIgnoreCase)
            : string.Equals(relative, p, StringComparison.OrdinalIgnoreCase));

    private static void WriteSettings(string root, ProjectRole role)
    {
        var exists = File.Exists(Path.Combine(root, SddConstants.SettingsFile));
        var settings = exists ? SddSettings.Load(root) : new SddSettings { Role = role.ToString().ToUpperInvariant() };
        if (exists && !string.IsNullOrWhiteSpace(settings.SpecsFolder))
        {
            return;
        }

        settings.SpecsFolder = FileHash.Relative(root, RepositoryLocator.DefaultSpecRoot(root));
        settings.Save(root);
    }

    private static void ExcludeLocalFolders(string root)
    {
        var info = Path.Combine(root, ".git", "info");
        if (!Directory.Exists(Path.Combine(root, ".git")))
        {
            return;
        }

        Directory.CreateDirectory(info);
        var exclude = Path.Combine(info, "exclude");
        var existing = File.Exists(exclude) ? File.ReadAllLines(exclude) : [];
        string[] wanted = ["docs/sdd/pbi-input/", "docs/sdd/changes/", ".sdd/installed.json", ".sdd/tools/", ".sdd/automation.lock", ".sonarqube/"];
        var missing = wanted.Where(w => !existing.Contains(w, StringComparer.Ordinal)).ToList();
        if (missing.Count > 0)
        {
            File.AppendAllLines(exclude, missing);
        }
    }
}
