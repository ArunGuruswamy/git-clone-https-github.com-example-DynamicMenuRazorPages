using System.Text.RegularExpressions;

namespace Akzo.Sdd.Core.Services;

/// <summary>Detects YAML front-matter mistakes that make Copilot silently skip an agent, prompt or instruction file.</summary>
public static partial class FrontmatterValidator
{
    /// <summary>Returns problems in the front matter of <paramref name="text"/>; empty when valid.</summary>
    /// <param name="text">File content.</param>
    /// <returns>Problems, one per offending line.</returns>
    public static IReadOnlyList<string> Validate(string text)
    {
        ArgumentNullException.ThrowIfNull(text);
        var lines = text.Replace("\r\n", "\n", StringComparison.Ordinal).Split('\n');
        if (lines.Length == 0 || lines[0].Trim() != "---")
        {
            return ["front matter must start with '---' on the first line"];
        }

        var end = Array.FindIndex(lines, 1, l => l.Trim() == "---");
        if (end < 0)
        {
            return ["front matter is not closed with '---'"];
        }

        var problems = new List<string>();
        for (var i = 1; i < end; i++)
        {
            var match = EntryRegex().Match(lines[i]);
            if (match.Success && IsUnsafePlainScalar(match.Groups["value"].Value.Trim()))
            {
                problems.Add($"line {i + 1}: value of '{match.Groups["key"].Value}' must be quoted (contains ': ' or ' #')");
            }
        }

        return problems;
    }

    private static bool IsUnsafePlainScalar(string value)
    {
        var quoted = value.Length >= 2
            && ((value[0] == '\'' && value[^1] == '\'') || (value[0] == '"' && value[^1] == '"'));
        var flow = value.StartsWith('[') || value.StartsWith('{');
        return !quoted && !flow && (value.Contains(": ", StringComparison.Ordinal) || value.Contains(" #", StringComparison.Ordinal));
    }

    [GeneratedRegex(@"^\s*(?:-\s+)?(?<key>[A-Za-z][\w-]*):\s+(?<value>\S.*)$", RegexOptions.None, 1000)]
    private static partial Regex EntryRegex();
}
