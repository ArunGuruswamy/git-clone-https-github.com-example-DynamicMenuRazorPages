using System.Globalization;
using Akzo.Sdd.Core.Automation;
using System.Text;
using System.Text.Json;
using Akzo.Sdd.Core.Execution;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.Verification;

/// <summary>Gate outcome. NOT EXECUTED is never reported as PASS.</summary>
public enum GateStatus
{
    /// <summary>Executed and passed.</summary>
    Pass = 0,

    /// <summary>Executed and failed.</summary>
    Fail,

    /// <summary>Not executed (blocked by an earlier failure or unavailable).</summary>
    NotExecuted,
}

/// <summary>One gate result.</summary>
/// <param name="Name">Gate name.</param>
/// <param name="Status">Outcome.</param>
/// <param name="Detail">Evidence or reason.</param>
public sealed record GateResult(string Name, GateStatus Status, string Detail);

/// <summary>Options for one verification run.</summary>
/// <param name="Scope">targeted or final.</param>
/// <param name="BuildCommand">Build command.</param>
/// <param name="TestCommand">Test command (<c>{results}</c> placeholder supported).</param>
/// <param name="Threshold">Minimum coverage percent.</param>
/// <param name="ChangedOnly">Measure coverage on changed production files only (Sonar new-code view).</param>
/// <param name="Timeout">Per-command timeout.</param>
/// <param name="IntegrationBranch">Base branch for changed files.</param>
public sealed record VerificationOptions(
    string Scope,
    string BuildCommand,
    string TestCommand,
    double Threshold,
    bool ChangedOnly,
    TimeSpan Timeout,
    string IntegrationBranch)
{
    /// <summary>Run the Sonar rules locally (only for .NET build commands).</summary>
    public bool LocalSonar { get; init; }

    /// <summary>SonarAnalyzer.CSharp version for the local Sonar gate.</summary>
    public string AnalyzerVersion { get; init; } = LocalSonarAnalysis.DefaultAnalyzerVersion;

    /// <summary>Extra Sonar rule ids enabled for the local gate (to mirror the SonarCloud quality profile).</summary>
    public IReadOnlyList<string> ExtraRules { get; init; } = [];

    /// <summary>Current-run coverage directory, optionally supplied by server scanner orchestration.</summary>
    public string? ResultsFolder { get; init; }

}

/// <summary>Verification record written to verification.json.</summary>
public sealed class VerificationReport
{
    /// <summary>targeted or final.</summary>
    public string Scope { get; set; } = string.Empty;

    /// <summary>Commit tested by this run.</summary>
    public string SourceHead { get; set; } = string.Empty;

    /// <summary>Content fingerprint including uncommitted source and settings.</summary>
    public string SourceFingerprint { get; set; } = string.Empty;

    /// <summary>Start time.</summary>
    public DateTimeOffset StartedUtc { get; set; }

    /// <summary>Total duration in seconds.</summary>
    public double DurationSeconds { get; set; }

    /// <summary>Gate results.</summary>
    public List<GateResult> Gates { get; set; } = [];

    /// <summary>Test counts, when known.</summary>
    public TestCounts? Tests { get; set; }

    /// <summary>Measured coverage percent, when known.</summary>
    public double? CoveragePercent { get; set; }

    /// <summary>Description of what the coverage percent covers.</summary>
    public string CoverageScope { get; set; } = string.Empty;

    /// <summary>Minimum coverage percent applied.</summary>
    public double Threshold { get; set; }

    /// <summary>Analyzer and compiler warnings in changed files (local Sonar gate).</summary>
    public List<CodeIssue> CodeIssues { get; set; } = [];

    /// <summary>New-code coverage per changed production file (SonarQube formula).</summary>
    public List<NewCodeFile> NewCode { get; set; } = [];

    /// <summary>Changed production files whose project produced no coverage data at all.</summary>
    public List<string> NotInstrumented { get; set; } = [];

    /// <summary>Changed files used for coverage and the PR.</summary>
    public List<string> ChangedFiles { get; set; } = [];

    /// <summary>True when every gate passed.</summary>
    public bool Passed => Gates.Count > 0 && Gates.TrueForAll(g => g.Status == GateStatus.Pass);

    /// <summary>Loads a report.</summary>
    /// <param name="path">verification.json path.</param>
    /// <returns>The report, or null when absent.</returns>
    public static VerificationReport? Load(string path) =>
        File.Exists(path) ? JsonSerializer.Deserialize<VerificationReport>(File.ReadAllText(path), Json.Options) : null;
}

/// <summary>Runs the real build and tests, then applies the zero-test, failure and coverage gates.</summary>
public sealed class VerificationService
{
    private const int TailLines = 25;
    private readonly IProcessRunner _runner;
    private readonly IClock _clock;

    /// <summary>Creates the service.</summary>
    /// <param name="runner">Process runner.</param>
    /// <param name="clock">Clock.</param>
    public VerificationService(IProcessRunner runner, IClock clock)
    {
        _runner = runner;
        _clock = clock;
    }

    /// <summary>Runs verification and writes verification.json and verification.log.</summary>
    /// <param name="workspace">Workspace.</param>
    /// <param name="state">State.</param>
    /// <param name="options">Options.</param>
    /// <returns>The report.</returns>
    public async Task<VerificationReport> RunAsync(SddWorkspace workspace, SddState state, VerificationOptions options)
    {
        ArgumentNullException.ThrowIfNull(workspace);
        ArgumentNullException.ThrowIfNull(options);
        var started = _clock.UtcNow;
        var report = new VerificationReport { Scope = options.Scope, StartedUtc = started, Threshold = options.Threshold };
        var results = options.ResultsFolder ?? Path.Combine(workspace.ChangeFolder(state), "test-results", started.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture) + "-" + Guid.NewGuid().ToString("N")[..6]);
        Directory.CreateDirectory(results);
        var log = new StringBuilder();

        var sonar = options.LocalSonar && LocalSonarAnalysis.Applies(options.BuildCommand);
        var buildCommand = sonar ? LocalSonarAnalysis.Augment(options.BuildCommand, LocalSonarAnalysis.Prepare(results, options.AnalyzerVersion, options.ExtraRules)) : options.BuildCommand;
        var build = await _runner.RunAsync(buildCommand, workspace.Root, options.Timeout).ConfigureAwait(false);
        Log(log, build);
        var analyzerUnavailable = sonar && !build.Succeeded && LocalSonarAnalysis.IsAnalyzerUnavailable(build.Output);
        if (analyzerUnavailable)
        {
            build = await _runner.RunAsync(options.BuildCommand, workspace.Root, options.Timeout).ConfigureAwait(false);
            Log(log, build);
        }

        report.Gates.Add(BuildGate(build));

        if (report.Gates[0].Status == GateStatus.Pass)
        {
            report.ChangedFiles = [.. await new GitClient(_runner).ChangedFilesAsync(workspace.Root, options.IntegrationBranch).ConfigureAwait(false)];
            var testCommand = options.TestCommand.Replace(SddConstants.ResultsPlaceholder, results, StringComparison.Ordinal);
            var test = await _runner.RunAsync(testCommand, workspace.Root, options.Timeout).ConfigureAwait(false);
            Log(log, test);
            report.Tests = TrxParser.ParseFolder(results) ?? ConsoleSummaryParser.ParseJest(test.Output);
            report.Gates.Add(TestGate(test, report.Tests));
            var changedLines = options.ChangedOnly
                ? await new GitClient(_runner).ChangedLinesAsync(workspace.Root, options.IntegrationBranch).ConfigureAwait(false)
                : new Dictionary<string, IReadOnlySet<int>?>();
            report.Gates.Add(CoverageGate(CoberturaParser.ParseFolder(results), report, options, changedLines, workspace.Root));
        }
        else
        {
            report.Gates.Add(new GateResult("Tests", GateStatus.NotExecuted, "Build failed; tests were not run against stale binaries."));
            report.Gates.Add(new GateResult("Coverage", GateStatus.NotExecuted, "Build failed."));
        }

        if (sonar)
        {
            report.Gates.Add(SonarGate(build, report, workspace.Root, options, analyzerUnavailable));
        }

        report.DurationSeconds = Math.Round((_clock.UtcNow - started).TotalSeconds, 1);
        await File.WriteAllTextAsync(workspace.ChangeFile(state, SddConstants.VerificationLogFile), log.ToString()).ConfigureAwait(false);
        await File.WriteAllTextAsync(workspace.ChangeFile(state, SddConstants.VerificationFile), JsonSerializer.Serialize(report, Json.Options)).ConfigureAwait(false);
        return report;
    }

    /// <summary>True for production source files (C# / TypeScript, not tests or generated code).</summary>
    /// <param name="path">Repository-relative path.</param>
    /// <returns>True when the file counts toward new-code coverage.</returns>
    public static bool IsProductionSource(string path)
    {
        ArgumentNullException.ThrowIfNull(path);
        var p = path.Replace('\\', '/');
        var isCode = p.EndsWith(".cs", StringComparison.OrdinalIgnoreCase) || p.EndsWith(".ts", StringComparison.OrdinalIgnoreCase);
        var isExcluded = Array.Exists(p.Split('/'), IsTestSegment)
                         || p.Contains("Generated", StringComparison.OrdinalIgnoreCase)
                         || p.EndsWith(".d.ts", StringComparison.OrdinalIgnoreCase);
        return isCode && !isExcluded;
    }

    private static bool IsTestSegment(string segment) =>
        segment.EndsWith("Tests", StringComparison.OrdinalIgnoreCase)
        || segment.EndsWith("Tests.cs", StringComparison.OrdinalIgnoreCase)
        || segment.EndsWith("Test.cs", StringComparison.OrdinalIgnoreCase)
        || segment.EndsWith(".spec.ts", StringComparison.OrdinalIgnoreCase)
        || segment.Equals("test", StringComparison.OrdinalIgnoreCase)
        || segment.Equals("__tests__", StringComparison.OrdinalIgnoreCase);

    internal static GateResult BuildGate(ProcessResult build)
    {
        var problems = BuildOutputInspector.Inspect(build.Output);
        if (build.Succeeded && problems.Count == 0)
        {
            return new GateResult("Build", GateStatus.Pass, $"`{build.Command}` exit 0 in {build.Duration.TotalSeconds:0.0}s");
        }

        var reason = build.TimedOut ? "timed out" : $"exit {build.ExitCode}";
        if (build.Output.Contains("NU1301", StringComparison.Ordinal) || build.Output.Contains("401 (Unauthorized)", StringComparison.Ordinal))
        {
            problems = [.. problems, "NuGet feed authentication failed: sign in once with `dotnet restore <solution> --interactive` in a terminal, then verify again"];
        }

        return new GateResult("Build", GateStatus.Fail, $"`{build.Command}` {reason}. {string.Join("; ", problems)} {Tail(build.Output)}".Trim());
    }

    internal static GateResult TestGate(ProcessResult test, TestCounts? counts)
    {
        if (counts is null)
        {
            return new GateResult("Tests", GateStatus.Fail, "No TRX or Jest summary found: test execution is not proven.");
        }

        var summary = $"{counts.Executed} executed, {counts.Passed} passed, {counts.Failed} failed (source: {counts.Source})";
        var problems = BuildOutputInspector.Inspect(test.Output);
        if (counts.Executed == 0)
        {
            return new GateResult("Tests", GateStatus.Fail, "Zero tests executed. " + summary);
        }

        return counts.Failed > 0 || !test.Succeeded || problems.Count > 0
            ? new GateResult("Tests", GateStatus.Fail, $"{summary}; exit {test.ExitCode}. {string.Join("; ", problems)}".Trim())
            : new GateResult("Tests", GateStatus.Pass, summary);
    }

    internal static GateResult CoverageGate(CoverageReport? coverage, VerificationReport report, VerificationOptions options) =>
        CoverageGate(coverage, report, options, new Dictionary<string, IReadOnlySet<int>?>(), string.Empty);

    internal static GateResult CoverageGate(CoverageReport? coverage, VerificationReport report, VerificationOptions options, IReadOnlyDictionary<string, IReadOnlySet<int>?> changedLines, string root)
    {
        if (coverage is null)
        {
            return new GateResult("Coverage", GateStatus.Fail, "No coverage.cobertura.xml or coverage.opencover.xml produced; coverage not measured.");
        }

        var newCode = changedLines
            .Where(kv => IsProductionSource(kv.Key))
            .ToDictionary(kv => kv.Key, kv => kv.Value, StringComparer.OrdinalIgnoreCase);
        return options.ChangedOnly && newCode.Count > 0
            ? NewCodeGate(coverage, report, options, newCode, root)
            : FileGate(coverage, report, options);
    }

    private static GateResult NewCodeGate(CoverageReport coverage, VerificationReport report, VerificationOptions options, Dictionary<string, IReadOnlySet<int>?> newCode, string root)
    {
        var (files, missing) = coverage.ForChangedLines(newCode);
        report.NewCode = [.. files.Where(f => f.LinesToCover + f.ConditionsToCover > 0)];
        report.NotInstrumented = [.. missing.Where(m => !ProjectInstrumented(coverage, root, m))];
        report.CoveragePercent = CoverageReport.NewCodePercent(report.NewCode);
        report.CoverageScope = $"new code: changed lines + conditions in {report.NewCode.Count} file(s) (SonarQube formula)";
        var lowest = string.Join("; ", report.NewCode
            .Where(f => f.Percent < options.Threshold)
            .OrderBy(f => f.Percent)
            .Take(5)
            .Select(f => string.Create(CultureInfo.InvariantCulture, $"{f.Path} {f.Percent:0.#}% ({f.UncoveredLines} uncovered lines, {f.UncoveredConditions} uncovered conditions)")));
        var notInstrumented = report.NotInstrumented.Count == 0
            ? string.Empty
            : " No coverage data (no test project exercises them; SonarCloud counts 0%): " + string.Join(", ", report.NotInstrumented) + ".";
        if (report.CoveragePercent is null && report.NotInstrumented.Count == 0)
        {
            return new GateResult("Coverage", GateStatus.Pass, "No coverable new code in changed production files.");
        }

        var percent = report.CoveragePercent ?? 0;
        var passed = percent >= options.Threshold && report.NotInstrumented.Count == 0;
        var detail = string.Create(CultureInfo.InvariantCulture, $"{percent:0.#}% on {report.CoverageScope}; threshold {options.Threshold:0.#}%.");
        detail += (lowest.Length > 0 ? " Below threshold: " + lowest + "." : string.Empty) + notInstrumented;
        return new GateResult("Coverage", passed ? GateStatus.Pass : GateStatus.Fail, detail);
    }

    private static GateResult FileGate(CoverageReport coverage, VerificationReport report, VerificationOptions options)
    {
        var changed = report.ChangedFiles.Where(IsProductionSource).ToList();
        var (changedPercent, matched) = coverage.ForChangedFiles(changed);
        var useChanged = options.ChangedOnly && matched.Count > 0;
        report.CoveragePercent = useChanged ? changedPercent : coverage.Percent;
        report.CoverageScope = useChanged
            ? $"changed production files ({matched.Count})"
            : $"all instrumented files ({coverage.Files.Count})";
        var percent = report.CoveragePercent ?? 0;
        var detail = string.Create(CultureInfo.InvariantCulture, $"{percent:0.##}% line coverage on {report.CoverageScope}; threshold {options.Threshold:0.#}%");
        return new GateResult("Coverage", percent >= options.Threshold ? GateStatus.Pass : GateStatus.Fail, detail);
    }

    private static bool ProjectInstrumented(CoverageReport coverage, string root, string file)
    {
        var project = ProjectFolder(root, file);
        return project is null
            || coverage.Files.Any(f => f.Path.Contains("/" + project + "/", StringComparison.OrdinalIgnoreCase) || f.Path.StartsWith(project + "/", StringComparison.OrdinalIgnoreCase));
    }

    private static string? ProjectFolder(string root, string file)
    {
        if (root.Length == 0 || !file.EndsWith(".cs", StringComparison.OrdinalIgnoreCase))
        {
            return null;
        }

        for (var dir = Path.GetDirectoryName(Path.Combine(root, file)); dir is not null && dir.Length >= root.Length; dir = Path.GetDirectoryName(dir))
        {
            if (Directory.Exists(dir) && Directory.EnumerateFiles(dir, "*.csproj").Any())
            {
                return Path.GetRelativePath(root, dir).Replace('\\', '/');
            }
        }

        return null;
    }

    internal static GateResult SonarGate(ProcessResult build, VerificationReport report, string root, VerificationOptions options, bool analyzerUnavailable)
    {
        if (analyzerUnavailable)
        {
            return new GateResult(LocalSonarAnalysis.GateName, GateStatus.NotExecuted, $"NuGet restore failed for the analysis build (SonarAnalyzer.CSharp {options.AnalyzerVersion}). If a private feed returns 401, sign in once with `dotnet restore <solution> --interactive`; otherwise set \"localSonar\": false in .sdd/settings.json (SonarCloud then stays the only Sonar check).");
        }

        if (!build.Succeeded)
        {
            return new GateResult(LocalSonarAnalysis.GateName, GateStatus.NotExecuted, "Build failed.");
        }

        var (gate, found) = LocalSonarAnalysis.Gate(LocalSonarAnalysis.Parse(build.Output, root), report.ChangedFiles, options.AnalyzerVersion);
        report.CodeIssues = [.. found];
        return gate;
    }

    private static void Log(StringBuilder log, ProcessResult result)
    {
        log.Append(CultureInfo.InvariantCulture, $"$ {result.Command}\n");
        log.Append(result.Output);
        log.Append(CultureInfo.InvariantCulture, $"[exit {result.ExitCode}, {result.Duration.TotalSeconds:0.0}s, timedOut={result.TimedOut}]\n\n");
    }

    private static string Tail(string output)
    {
        var lines = output.Split('\n', StringSplitOptions.RemoveEmptyEntries);
        return string.Join(" | ", lines.Skip(Math.Max(0, lines.Length - TailLines)).Where(l => l.Contains("error", StringComparison.OrdinalIgnoreCase)).Take(5));
    }
}
