using System.Net.Http.Headers;
using System.Text.Json;

namespace Akzo.Sdd.Core.Verification;

/// <summary>One Sonar quality-gate condition.</summary>
/// <param name="Metric">Metric key, for example new_coverage.</param>
/// <param name="Status">OK / ERROR / WARN.</param>
/// <param name="Actual">Actual value.</param>
/// <param name="Threshold">Error threshold.</param>
public sealed record SonarCondition(string Metric, string Status, string Actual, string Threshold);

/// <summary>Sonar quality-gate status.</summary>
/// <param name="Status">OK / ERROR / NONE.</param>
/// <param name="Conditions">Conditions.</param>
public sealed record SonarGateResult(string Status, IReadOnlyList<SonarCondition> Conditions)
{
    /// <summary>True when the gate is OK.</summary>
    public bool Passed => string.Equals(Status, "OK", StringComparison.OrdinalIgnoreCase);
}

/// <summary>Reads the SonarQube / SonarCloud quality gate for a project, branch or pull request (read-only).</summary>
public sealed class SonarGateClient
{
    private readonly HttpClient _http;

    /// <summary>Creates the client.</summary>
    /// <param name="http">HTTP client (one shared instance).</param>
    public SonarGateClient(HttpClient http)
    {
        _http = http;
    }

    /// <summary>Gets the quality gate status.</summary>
    /// <param name="baseUrl">Sonar base URL.</param>
    /// <param name="projectKey">Project key.</param>
    /// <param name="token">User token (from SONAR_TOKEN).</param>
    /// <param name="pullRequest">Pull request id, optional.</param>
    /// <param name="branch">Branch, optional.</param>
    /// <returns>The gate result.</returns>
    public async Task<SonarGateResult> GetGateAsync(Uri baseUrl, string projectKey, string? token, string? pullRequest, string? branch)
    {
        ArgumentNullException.ThrowIfNull(baseUrl);
        var query = "api/qualitygates/project_status?projectKey=" + Uri.EscapeDataString(projectKey);
        if (!string.IsNullOrWhiteSpace(pullRequest))
        {
            query += "&pullRequest=" + Uri.EscapeDataString(pullRequest);
        }
        else if (!string.IsNullOrWhiteSpace(branch))
        {
            query += "&branch=" + Uri.EscapeDataString(branch);
        }

        using var request = new HttpRequestMessage(HttpMethod.Get, new Uri(baseUrl, query));
        if (!string.IsNullOrWhiteSpace(token))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        HttpResponseMessage response;
        try
        {
            response = await _http.SendAsync(request).ConfigureAwait(false);
        }
        catch (HttpRequestException ex)
        {
            throw new SddException(ErrorCodes.GateFailed, "Sonar unreachable: " + ex.Message);
        }
        catch (TaskCanceledException ex)
        {
            throw new SddException(ErrorCodes.GateFailed, "Sonar request timed out: " + ex.Message);
        }

        using var owned = response;
        var body = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
        if (!response.IsSuccessStatusCode)
        {
            throw new SddException(ErrorCodes.GateFailed, $"Sonar returned {(int)response.StatusCode}: {body}");
        }

        return Parse(body);
    }

    /// <summary>Parses the project_status JSON.</summary>
    /// <param name="json">Response body.</param>
    /// <returns>The gate result.</returns>
    public static SonarGateResult Parse(string json)
    {
        using var document = JsonDocument.Parse(json);
        var status = document.RootElement.GetProperty("projectStatus");
        var conditions = status.TryGetProperty("conditions", out var list)
            ? list.EnumerateArray().Select(c => new SonarCondition(
                Text(c, "metricKey"), Text(c, "status"), Text(c, "actualValue"), Text(c, "errorThreshold"))).ToList()
            : [];
        return new SonarGateResult(Text(status, "status"), conditions);
    }

    private static string Text(JsonElement element, string name) =>
        element.TryGetProperty(name, out var value) ? value.ToString() : string.Empty;
}
