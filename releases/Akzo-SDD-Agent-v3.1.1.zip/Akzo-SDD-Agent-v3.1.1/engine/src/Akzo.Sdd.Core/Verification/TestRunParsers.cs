using System.Globalization;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace Akzo.Sdd.Core.Verification;

/// <summary>Test counts from a real run.</summary>
/// <param name="Total">Tests discovered.</param>
/// <param name="Executed">Tests executed.</param>
/// <param name="Passed">Tests passed.</param>
/// <param name="Failed">Tests failed.</param>
/// <param name="Source">Where the counts came from.</param>
public sealed record TestCounts(int Total, int Executed, int Passed, int Failed, string Source)
{
    /// <summary>Adds two count sets.</summary>
    /// <param name="other">Other counts.</param>
    /// <returns>Sum.</returns>
    public TestCounts Add(TestCounts other)
    {
        ArgumentNullException.ThrowIfNull(other);
        return new TestCounts(Total + other.Total, Executed + other.Executed, Passed + other.Passed, Failed + other.Failed, Source + ";" + other.Source);
    }
}

/// <summary>Parses VSTest TRX result files.</summary>
public static class TrxParser
{
    private static readonly XNamespace Ns = "http://microsoft.com/schemas/VisualStudio/TeamTest/2010";

    /// <summary>Parses one TRX file.</summary>
    /// <param name="path">TRX path.</param>
    /// <returns>Counts, or null when the file has no counters.</returns>
    public static TestCounts? Parse(string path)
    {
        var counters = XDocument.Load(path).Descendants(Ns + "Counters").FirstOrDefault();
        return counters is null
            ? null
            : new TestCounts(Int(counters, "total"), Int(counters, "executed"), Int(counters, "passed"), Int(counters, "failed"), Path.GetFileName(path));
    }

    /// <summary>Sums every TRX file under a folder.</summary>
    /// <param name="folder">Results folder.</param>
    /// <returns>Counts, or null when none exist.</returns>
    public static TestCounts? ParseFolder(string folder)
    {
        if (!Directory.Exists(folder))
        {
            return null;
        }

        return Directory.EnumerateFiles(folder, "*.trx", SearchOption.AllDirectories)
            .Select(Parse)
            .OfType<TestCounts>()
            .Aggregate((TestCounts?)null, (sum, next) => sum is null ? next : sum.Add(next));
    }

    private static int Int(XElement element, string name) =>
        int.TryParse(element.Attribute(name)?.Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var value) ? value : 0;
}

/// <summary>Parses console summaries from Jest and from <c>dotnet test</c>.</summary>
public static partial class ConsoleSummaryParser
{
    /// <summary>Parses the Jest summary line (<c>Tests: 1 failed, 12 passed, 13 total</c>).</summary>
    /// <param name="output">Console output.</param>
    /// <returns>Counts, or null when absent.</returns>
    public static TestCounts? ParseJest(string output)
    {
        var match = JestRegex().Matches(output ?? string.Empty).LastOrDefault();
        if (match is null)
        {
            return null;
        }

        var text = match.Groups["body"].Value;
        var failed = Count(text, "failed");
        var passed = Count(text, "passed");
        var total = Count(text, "total");
        return new TestCounts(total, failed + passed, passed, failed, "console summary");
    }

    private static int Count(string text, string label)
    {
        var match = Regex.Match(text, @"(\d+)\s+" + label, RegexOptions.None, TimeSpan.FromSeconds(1));
        return match.Success ? int.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture) : 0;
    }

    [GeneratedRegex(@"^Tests:\s+(?<body>.+)$", RegexOptions.Multiline, 1000)]
    private static partial Regex JestRegex();
}

/// <summary>Detects build failures that wrappers report with exit code 0.</summary>
public static partial class BuildOutputInspector
{
    private static readonly string[] StaleBuildPhrases =
    [
        "last successful build",
        "continuing with last successful",
        "No test is available",
        "No test matches the given testcase filter",
    ];

    /// <summary>Returns problems found in build or test output.</summary>
    /// <param name="output">Console output.</param>
    /// <returns>Problems; empty when clean.</returns>
    public static IReadOnlyList<string> Inspect(string output)
    {
        var text = output ?? string.Empty;
        var problems = new List<string>();
        var errors = CompilerErrorRegex().Matches(text).Select(m => m.Groups["code"].Value).Distinct(StringComparer.Ordinal).ToList();
        if (errors.Count > 0)
        {
            problems.Add("Compiler errors: " + string.Join(", ", errors));
        }

        var stale = Array.Find(StaleBuildPhrases, p => text.Contains(p, StringComparison.OrdinalIgnoreCase));
        if (stale is not null)
        {
            problems.Add($"Output contains '{stale}'");
        }

        return problems;
    }

    [GeneratedRegex(@"error (?<code>(?:CS|MSB|NU|TS|NG)\d+)", RegexOptions.None, 1000)]
    private static partial Regex CompilerErrorRegex();
}
