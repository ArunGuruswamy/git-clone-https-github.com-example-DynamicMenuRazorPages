using System.Text.RegularExpressions;

namespace Akzo.Sdd.Core.Verification;

/// <summary>One analyzer or compiler warning reported by the build.</summary>
/// <param name="File">Repository-relative path (forward slashes).</param>
/// <param name="Line">Line number.</param>
/// <param name="Rule">Rule id, for example <c>S1541</c> or <c>CS1573</c>.</param>
/// <param name="Message">Message text.</param>
public sealed record CodeIssue(string File, int Line, string Rule, string Message);

/// <summary>Runs the SonarCloud rules locally: the build is compiled with SonarAnalyzer.CSharp injected through
/// <c>CustomBeforeMicrosoftCommonTargets</c> (the way the SonarScanner for .NET does it), with the team's extra rules
/// switched on. Analyzer and compiler warnings in the changed C# files fail the gate.</summary>
public static partial class LocalSonarAnalysis
{
    /// <summary>Gate name.</summary>
    public const string GateName = "Sonar rules (local)";

    /// <summary>Default SonarAnalyzer.CSharp version.</summary>
    public const string DefaultAnalyzerVersion = "9.32.0.97167";

    /// <summary>Rules outside Sonar Way that the team's SonarCloud profile enforces, with the thresholds it applies.</summary>
    public static readonly IReadOnlyList<(string Rule, string Limit)> TeamRules =
    [
        ("S1541", "cyclomatic complexity <= 10 per method"),
        ("S3776", "cognitive complexity <= 15 per method"),
        ("S1200", "<= 30 dependent types per class"),
        ("S107", "<= 7 parameters"),
        ("S3242", "parameters use the most general type"),
        ("S1144", "no unused private members"),
        ("CS0169", "no unused private fields"),
        ("CS8618", "initialize non-nullable fields when nullable analysis is enabled"),
    ];

    private const int MaxListed = 10;
    private const string TargetsFile = "sdd.sonar.targets";
    private const string ConfigFile = "sdd.sonar.globalconfig";
    private const string AnalyzerPackage = "SonarAnalyzer.CSharp";
    private static readonly string[] RestoreFailureCodes = ["NU1101", "NU1102", "NU1301"];

    /// <summary>True when the build command is a .NET build that can host the analyzer.</summary>
    /// <param name="buildCommand">Build command.</param>
    /// <returns>True for dotnet build / dotnet msbuild / msbuild.</returns>
    public static bool Applies(string buildCommand)
    {
        var command = (buildCommand ?? string.Empty).TrimStart().ToLowerInvariant();
        return command.StartsWith("dotnet build", StringComparison.Ordinal)
            || command.StartsWith("dotnet msbuild", StringComparison.Ordinal)
            || command.StartsWith("msbuild", StringComparison.Ordinal);
    }

    /// <summary>Writes the MSBuild targets and global analyzer config into <paramref name="folder"/>.</summary>
    /// <param name="folder">Folder (the verification results folder).</param>
    /// <param name="analyzerVersion">SonarAnalyzer.CSharp version.</param>
    /// <returns>Path of the targets file.</returns>
    public static string Prepare(string folder, string analyzerVersion) => Prepare(folder, analyzerVersion, []);

    /// <summary>Writes the MSBuild targets and global analyzer config, enabling the team rules plus <paramref name="extraRules"/>.</summary>
    /// <param name="folder">Folder (the verification results folder).</param>
    /// <param name="analyzerVersion">SonarAnalyzer.CSharp version.</param>
    /// <param name="extraRules">Additional rule ids from <c>sonarExtraRules</c> in .sdd/settings.json.</param>
    /// <returns>Path of the targets file.</returns>
    public static string Prepare(string folder, string analyzerVersion, IReadOnlyList<string> extraRules)
    {
        ArgumentNullException.ThrowIfNull(extraRules);
        Directory.CreateDirectory(folder);
        var config = Path.Combine(folder, ConfigFile);
        var lines = new List<string> { "is_global = true", "global_level = 100" };
        lines.AddRange(TeamRules.Select(r => r.Rule).Concat(extraRules).Distinct(StringComparer.OrdinalIgnoreCase).Select(r => $"dotnet_diagnostic.{r}.severity = warning"));
        File.WriteAllLines(config, lines);

        var noReference = $"'@(PackageReference->WithMetadataValue('Identity','{AnalyzerPackage}'))' == ''";
        var noVersion = $"'@(PackageVersion->WithMetadataValue('Identity','{AnalyzerPackage}'))' == ''";
        var targets = Path.Combine(folder, TargetsFile);
        File.WriteAllText(targets, $"""
            <Project>
              <ItemGroup Condition="'$(MSBuildProjectExtension)' == '.csproj' and {noReference}">
                <PackageReference Include="{AnalyzerPackage}" Version="{analyzerVersion}" PrivateAssets="all" Condition="'$(ManagePackageVersionsCentrally)' != 'true'" />
                <PackageVersion Include="{AnalyzerPackage}" Version="{analyzerVersion}" Condition="'$(ManagePackageVersionsCentrally)' == 'true' and {noVersion}" />
                <PackageReference Include="{AnalyzerPackage}" PrivateAssets="all" Condition="'$(ManagePackageVersionsCentrally)' == 'true'" />
              </ItemGroup>
              <ItemGroup Condition="'$(MSBuildProjectExtension)' == '.csproj'">
                <EditorConfigFiles Include="{config}" />
              </ItemGroup>
              <Target Name="SddRequireSonarAnalyzer" BeforeTargets="CoreCompile" Condition="'$(MSBuildProjectExtension)' == '.csproj'">
                <Error Condition="'@(Analyzer->WithMetadataValue('Filename','SonarAnalyzer.CSharp'))' == ''" Text="SDD: Sonar analyzer was not loaded; analysis cannot pass." />
                <Error Condition="'$(RunAnalyzers)' == 'false' or '$(RunAnalyzersDuringBuild)' == 'false'" Text="SDD: analyzers are disabled." />
              </Target>
            </Project>
            """);
        return targets;
    }

    /// <summary>Adds the analyzer targets to the build command and forces a full compile so every warning is reported.</summary>
    /// <param name="buildCommand">Original build command.</param>
    /// <param name="targetsPath">Targets file written by Prepare.</param>
    /// <returns>The analysis build command.</returns>
    public static string Augment(string buildCommand, string targetsPath)
    {
        ArgumentNullException.ThrowIfNull(buildCommand);
        var rebuild = buildCommand.TrimStart().StartsWith("dotnet build", StringComparison.OrdinalIgnoreCase) ? " --no-incremental" : " -t:Rebuild";
        return $"{buildCommand.TrimEnd()}{rebuild} -p:CustomBeforeMicrosoftCommonTargets=\"{targetsPath}\"";
    }

    /// <summary>True when the analysis build failed in NuGet restore (analyzer package or an unreachable/unauthorised feed).
    /// The build is then re-run exactly as configured, so the Build gate reports the repository's own result.</summary>
    /// <param name="output">Build output.</param>
    /// <returns>True when the analysis build could not restore.</returns>
    public static bool IsAnalyzerUnavailable(string output)
    {
        var text = output ?? string.Empty;
        return Array.Exists(RestoreFailureCodes, c => text.Contains(c, StringComparison.Ordinal));
    }

    /// <summary>Parses MSBuild warnings (<c>file(line,col): warning RULE: message [project]</c>).</summary>
    /// <param name="output">Build output.</param>
    /// <param name="repoRoot">Repository root, to make paths relative.</param>
    /// <returns>Distinct issues.</returns>
    public static IReadOnlyList<CodeIssue> Parse(string output, string repoRoot)
    {
        var root = Normalise(Path.GetFullPath(repoRoot)).TrimEnd('/') + "/";
        return WarningRegex().Matches(output ?? string.Empty)
            .Select(m => new CodeIssue(
                Relative(Normalise(m.Groups["file"].Value.Trim()), root),
                int.Parse(m.Groups["line"].Value, System.Globalization.CultureInfo.InvariantCulture),
                m.Groups["rule"].Value,
                StripRuleLink(m.Groups["message"].Value.Trim())))
            .DistinctBy(i => (i.File.ToUpperInvariant(), i.Line, i.Rule))
            .ToList();
    }

    /// <summary>Applies the gate: every warning in a changed C# file (generated code excluded) fails it.</summary>
    /// <param name="issues">All parsed issues.</param>
    /// <param name="changedFiles">Changed repository-relative files.</param>
    /// <param name="analyzerVersion">Analyzer version used.</param>
    /// <returns>Gate result and the issues in changed files.</returns>
    public static (GateResult Gate, IReadOnlyList<CodeIssue> InChangedFiles) Gate(IReadOnlyList<CodeIssue> issues, IReadOnlyList<string> changedFiles, string analyzerVersion)
    {
        ArgumentNullException.ThrowIfNull(issues);
        ArgumentNullException.ThrowIfNull(changedFiles);
        var changed = changedFiles
            .Select(Normalise)
            .Where(f => f.EndsWith(".cs", StringComparison.OrdinalIgnoreCase) && !f.Contains("Generated", StringComparison.OrdinalIgnoreCase))
            .ToList();
        var found = issues.Where(i => changed.Exists(c => SamePath(i.File, c))).OrderBy(i => i.File, StringComparer.Ordinal).ThenBy(i => i.Line).ToList();
        var rules = string.Join(", ", TeamRules.Select(r => $"{r.Rule} {r.Limit}"));
        if (found.Count == 0)
        {
            return (new GateResult(GateName, GateStatus.Pass, $"0 issues in {changed.Count} changed C# file(s) (SonarAnalyzer.CSharp {analyzerVersion}: Sonar Way + {rules}; compiler warnings)"), found);
        }

        var listed = string.Join("; ", found.Take(MaxListed).Select(i => $"{i.File}:{i.Line} {i.Rule} {i.Message}"));
        var more = found.Count > MaxListed ? $"; and {found.Count - MaxListed} more (verification.json)" : string.Empty;
        return (new GateResult(GateName, GateStatus.Fail, $"{found.Count} issue(s) in changed files - SonarCloud will report them on the PR: {listed}{more}"), found);
    }

    private static bool SamePath(string issueFile, string changedFile) =>
        string.Equals(issueFile, changedFile, StringComparison.OrdinalIgnoreCase)
        || issueFile.EndsWith("/" + changedFile, StringComparison.OrdinalIgnoreCase);

    private static string StripRuleLink(string message)
    {
        var link = message.IndexOf(" (https://", StringComparison.Ordinal);
        return link > 0 ? message[..link] : message;
    }

    private static string Normalise(string path) => path.Replace('\\', '/');

    private static string Relative(string file, string root) =>
        file.StartsWith(root, StringComparison.OrdinalIgnoreCase) ? file[root.Length..] : file;

    [GeneratedRegex(@"^\s*(?<file>[^\r\n(]+?\.cs)\((?<line>\d+),\d+(?:,\d+,\d+)?\): warning (?<rule>[A-Z]+\d+): (?<message>[^\r\n]*?)(?: \[[^\]\r\n]*\])?\r?$", RegexOptions.Multiline, 2000)]
    private static partial Regex WarningRegex();
}
