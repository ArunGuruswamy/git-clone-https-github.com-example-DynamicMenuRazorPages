using System.Globalization;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace Akzo.Sdd.Core.Verification;

/// <summary>Coverage of one source line.</summary>
/// <param name="Hit">True when the line was executed.</param>
/// <param name="Conditions">Branch conditions on the line (0 when none).</param>
/// <param name="CoveredConditions">Conditions that were taken.</param>
public sealed record LineCoverage(bool Hit, int Conditions, int CoveredConditions);

/// <summary>Line coverage of one source file.</summary>
/// <param name="Path">File path as written in the report (forward slashes).</param>
/// <param name="Covered">Covered line count.</param>
/// <param name="Valid">Coverable line count.</param>
public sealed record FileCoverage(string Path, int Covered, int Valid)
{
    /// <summary>Per-line coverage, keyed by line number.</summary>
    public IReadOnlyDictionary<int, LineCoverage> Lines { get; init; } = new Dictionary<int, LineCoverage>();
}

/// <summary>Coverage of the new code in one changed file, using the SonarQube formula.</summary>
/// <param name="Path">Repository-relative path.</param>
/// <param name="LinesToCover">Changed lines that are coverable.</param>
/// <param name="UncoveredLines">Of those, not executed.</param>
/// <param name="ConditionsToCover">Conditions on changed lines.</param>
/// <param name="UncoveredConditions">Of those, not taken.</param>
public sealed record NewCodeFile(string Path, int LinesToCover, int UncoveredLines, int ConditionsToCover, int UncoveredConditions)
{
    /// <summary>(covered lines + covered conditions) / (lines + conditions), or null when nothing is coverable.</summary>
    public double? Percent => LinesToCover + ConditionsToCover == 0
        ? null
        : Math.Round(100.0 * (LinesToCover - UncoveredLines + ConditionsToCover - UncoveredConditions) / (LinesToCover + ConditionsToCover), 1);
}

/// <summary>Merged coverage of one or more Cobertura or OpenCover reports.</summary>
/// <param name="Files">Per-file coverage.</param>
public sealed record CoverageReport(IReadOnlyList<FileCoverage> Files)
{
    /// <summary>Line coverage percent over all files, or null when nothing is coverable.</summary>
    public double? Percent => Rate(Files);

    /// <summary>Line coverage percent restricted to files ending with one of <paramref name="changedFiles"/>.</summary>
    /// <param name="changedFiles">Changed repository-relative paths.</param>
    /// <returns>Percent (null when no file matched) and the matched files.</returns>
    public (double? Percent, IReadOnlyList<FileCoverage> Matched) ForChangedFiles(IEnumerable<string> changedFiles)
    {
        var changed = changedFiles.Select(Normalise).ToList();
        var matched = Files.Where(f => changed.Exists(c => SameFile(f.Path, c))).ToList();
        return (Rate(matched), matched);
    }

    /// <summary>SonarQube "Coverage on New Code": lines and conditions on the changed lines only.</summary>
    /// <param name="changedLines">Changed file to changed line numbers (null = whole file is new).</param>
    /// <returns>Per-file new-code coverage for files present in the report, and changed files with no coverage data.</returns>
    public (IReadOnlyList<NewCodeFile> Files, IReadOnlyList<string> NotInReport) ForChangedLines(IReadOnlyDictionary<string, IReadOnlySet<int>?> changedLines)
    {
        ArgumentNullException.ThrowIfNull(changedLines);
        var files = new List<NewCodeFile>();
        var missing = new List<string>();
        foreach (var (path, lines) in changedLines)
        {
            var file = Files.FirstOrDefault(f => SameFile(f.Path, Normalise(path)));
            if (file is null)
            {
                missing.Add(path);
                continue;
            }

            var newLines = file.Lines.Where(l => lines is null || lines.Contains(l.Key)).Select(l => l.Value).ToList();
            files.Add(new NewCodeFile(
                path,
                newLines.Count,
                newLines.Count(l => !l.Hit),
                newLines.Sum(l => l.Conditions),
                newLines.Sum(l => l.Conditions - l.CoveredConditions)));
        }

        return (files, missing);
    }

    /// <summary>Combined new-code percent over <paramref name="files"/>, or null when nothing is coverable.</summary>
    /// <param name="files">New-code files.</param>
    /// <returns>Percent.</returns>
    public static double? NewCodePercent(IReadOnlyCollection<NewCodeFile> files)
    {
        ArgumentNullException.ThrowIfNull(files);
        var total = files.Sum(f => f.LinesToCover + f.ConditionsToCover);
        var uncovered = files.Sum(f => f.UncoveredLines + f.UncoveredConditions);
        return total == 0 ? null : Math.Round(100.0 * (total - uncovered) / total, 1);
    }

    internal static string Normalise(string path) => path.Replace('\\', '/').TrimStart('.', '/');

    private static bool SameFile(string reportPath, string changed) =>
        reportPath.EndsWith(changed, StringComparison.OrdinalIgnoreCase) || changed.EndsWith(reportPath, StringComparison.OrdinalIgnoreCase);

    private static double? Rate(IReadOnlyCollection<FileCoverage> files)
    {
        var valid = files.Sum(f => f.Valid);
        return valid == 0 ? null : Math.Round(100.0 * files.Sum(f => f.Covered) / valid, 2);
    }
}

/// <summary>Reads Cobertura (coverlet / Jest) and OpenCover (coverlet for SonarCloud) reports.</summary>
public static partial class CoberturaParser
{
    /// <summary>Report file names searched in the results folder.</summary>
    public static readonly IReadOnlyList<string> ReportNames = ["coverage.cobertura.xml", "cobertura-coverage.xml"];

    /// <summary>OpenCover report file name (used when no Cobertura report exists).</summary>
    public const string OpenCoverName = "coverage.opencover.xml";

    /// <summary>Merges every Cobertura report under <paramref name="folder"/>; falls back to OpenCover.</summary>
    /// <param name="folder">Results folder.</param>
    /// <returns>The merged report, or null when none was produced.</returns>
    public static CoverageReport? ParseFolder(string folder)
    {
        if (!Directory.Exists(folder))
        {
            return null;
        }

        var cobertura = ReportNames
            .SelectMany(n => Directory.EnumerateFiles(folder, n, SearchOption.AllDirectories))
            .ToList();
        if (cobertura.Count > 0)
        {
            return Merge(cobertura.Select(f => XDocument.Load(f)));
        }

        var openCover = Directory.EnumerateFiles(folder, OpenCoverName, SearchOption.AllDirectories).ToList();
        return openCover.Count == 0 ? null : MergeOpenCover(openCover.Select(f => XDocument.Load(f)));
    }

    /// <summary>Merges Cobertura documents; a line or condition counts as covered when any report covers it.</summary>
    /// <param name="documents">Cobertura XML documents.</param>
    /// <returns>Merged report.</returns>
    public static CoverageReport Merge(IEnumerable<XDocument> documents)
    {
        var lines = new Dictionary<string, Dictionary<int, LineCoverage>>(StringComparer.OrdinalIgnoreCase);
        foreach (var cls in documents.SelectMany(d => d.Descendants("class")))
        {
            var fileLines = FileLines(lines, cls.Attribute("filename")?.Value);
            foreach (var line in cls.Elements("lines").Elements("line"))
            {
                var (conditions, covered) = Conditions(line.Attribute("condition-coverage")?.Value);
                Record(fileLines, Int(line.Attribute("number")?.Value), new LineCoverage(Int(line.Attribute("hits")?.Value) > 0, conditions, covered));
            }
        }

        return ToReport(lines);
    }

    /// <summary>Merges OpenCover documents (sequence points per line, branch points as conditions).</summary>
    /// <param name="documents">OpenCover XML documents.</param>
    /// <returns>Merged report.</returns>
    public static CoverageReport MergeOpenCover(IEnumerable<XDocument> documents)
    {
        var lines = new Dictionary<string, Dictionary<int, LineCoverage>>(StringComparer.OrdinalIgnoreCase);
        foreach (var module in documents.SelectMany(d => d.Descendants("Module")))
        {
            var files = module.Elements("Files").Elements("File")
                .ToDictionary(f => f.Attribute("uid")?.Value ?? string.Empty, f => f.Attribute("fullPath")?.Value, StringComparer.Ordinal);
            foreach (var method in module.Descendants("Method"))
            {
                RecordOpenCoverMethod(method, files, lines);
            }
        }

        return ToReport(lines);
    }

    private static void RecordOpenCoverMethod(XElement method, Dictionary<string, string?> files, Dictionary<string, Dictionary<int, LineCoverage>> lines)
    {
        var points = method.Descendants("SequencePoint").ToList();
        foreach (var point in points)
        {
            if (files.TryGetValue(point.Attribute("fileid")?.Value ?? string.Empty, out var path))
            {
                Record(FileLines(lines, path), Int(point.Attribute("sl")?.Value), new LineCoverage(Int(point.Attribute("vc")?.Value) > 0, 0, 0));
            }
        }

        var fileId = points.Select(p => p.Attribute("fileid")?.Value).FirstOrDefault(v => v is not null) ?? string.Empty;
        if (!files.TryGetValue(fileId, out var methodFile))
        {
            return;
        }

        foreach (var branches in method.Descendants("BranchPoint").GroupBy(b => Int(b.Attribute("sl")?.Value)))
        {
            Record(FileLines(lines, methodFile), branches.Key, new LineCoverage(false, branches.Count(), branches.Count(b => Int(b.Attribute("vc")?.Value) > 0)));
        }
    }

    private static Dictionary<int, LineCoverage> FileLines(Dictionary<string, Dictionary<int, LineCoverage>> lines, string? file)
    {
        var path = CoverageReport.Normalise(file ?? string.Empty);
        if (!lines.TryGetValue(path, out var fileLines))
        {
            fileLines = [];
            lines[path] = fileLines;
        }

        return fileLines;
    }

    private static void Record(Dictionary<int, LineCoverage> fileLines, int number, LineCoverage line)
    {
        if (!fileLines.TryGetValue(number, out var previous))
        {
            fileLines[number] = line;
            return;
        }

        var conditions = Math.Max(previous.Conditions, line.Conditions);
        var covered = Math.Min(conditions, Math.Max(previous.CoveredConditions, line.CoveredConditions));
        fileLines[number] = new LineCoverage(previous.Hit || line.Hit, conditions, covered);
    }

    private static CoverageReport ToReport(Dictionary<string, Dictionary<int, LineCoverage>> lines) =>
        new(lines
            .Select(kv => new FileCoverage(kv.Key, kv.Value.Count(l => l.Value.Hit), kv.Value.Count) { Lines = kv.Value })
            .OrderBy(f => f.Path, StringComparer.Ordinal)
            .ToList());

    private static (int Conditions, int Covered) Conditions(string? conditionCoverage)
    {
        var match = ConditionRegex().Match(conditionCoverage ?? string.Empty);
        return match.Success ? (Int(match.Groups["total"].Value), Int(match.Groups["covered"].Value)) : (0, 0);
    }

    private static int Int(string? value) =>
        int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var result) ? result : 0;

    [GeneratedRegex(@"\((?<covered>\d+)/(?<total>\d+)\)", RegexOptions.None, 1000)]
    private static partial Regex ConditionRegex();
}
