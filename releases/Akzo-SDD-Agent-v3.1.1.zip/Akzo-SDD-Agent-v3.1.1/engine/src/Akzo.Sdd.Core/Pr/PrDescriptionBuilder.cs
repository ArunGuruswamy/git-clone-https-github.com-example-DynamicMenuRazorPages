using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using Akzo.Sdd.Core.Approval;
using Akzo.Sdd.Core.Artifacts;
using Akzo.Sdd.Core.Markdown;
using Akzo.Sdd.Core.Metrics;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Questions;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Verification;

namespace Akzo.Sdd.Core.Pr;

/// <summary>Inputs for the SDD pull-request description.</summary>
/// <param name="State">State.</param>
/// <param name="Package">PBI package.</param>
/// <param name="SpecText">spec.md text.</param>
/// <param name="PlanText">plan.md text.</param>
/// <param name="Approval">Approval record, if any.</param>
/// <param name="StaleFiles">Files changed since approval.</param>
/// <param name="Verification">Latest verification, if any.</param>
/// <param name="Sonar">Sonar gate, if queried.</param>
/// <param name="ReviewVerdict">Verdict line from review.md, if any.</param>
/// <param name="Branch">Current branch.</param>
public sealed record PrInputs(
    SddState State,
    PbiPackage Package,
    string SpecText,
    string PlanText,
    ApprovalRecord? Approval,
    IReadOnlyList<string> StaleFiles,
    VerificationReport? Verification,
    SonarGateResult? Sonar,
    string? ReviewVerdict,
    string Branch);

/// <summary>Builds the pull-request title and description in SDD format.</summary>
public static partial class PrDescriptionBuilder
{
    /// <summary>The only verdict that allows a PR.</summary>
    public const string ReadyVerdict = "READY FOR PR";

    /// <summary>Builds the PR title in the team format, for example <c>feat: Creation of Complaint PaintSystem [SDD]</c>.
    /// Leading <c>[tags]</c> and the PBI number are left out; the work item is linked in the description.</summary>
    /// <param name="state">State.</param>
    /// <returns>Title.</returns>
    public static string Title(SddState state)
    {
        ArgumentNullException.ThrowIfNull(state);
        var clean = LeadingTagsRegex().Replace(state.Title, string.Empty).Trim();
        return $"feat: {(clean.Length == 0 ? state.Feature : clean)} [SDD]";
    }

    /// <summary>Lists the reasons the PR is not ready (empty when ready).</summary>
    /// <param name="inputs">Inputs.</param>
    /// <returns>Reasons.</returns>
    public static IReadOnlyList<string> ReadinessGaps(PrInputs inputs)
    {
        ArgumentNullException.ThrowIfNull(inputs);
        var gaps = new List<string>();
        if (inputs.Approval is null)
        {
            gaps.Add("Implementation approval not recorded");
        }

        if (inputs.StaleFiles.Count > 0)
        {
            gaps.Add("Approved artifacts changed after approval: " + string.Join(", ", inputs.StaleFiles));
        }

        if (inputs.Verification is null || !inputs.Verification.Passed || !string.Equals(inputs.Verification.Scope, "final", StringComparison.OrdinalIgnoreCase))
        {
            gaps.Add("Final verification (sdd verify --scope final) has not passed");
        }

        if (!string.Equals(inputs.ReviewVerdict?.Trim(), ReadyVerdict, StringComparison.OrdinalIgnoreCase))
        {
            gaps.Add("Independent review verdict is not READY FOR PR");
        }

        if (inputs.Sonar is not null && !inputs.Sonar.Passed)
        {
            gaps.Add("Sonar quality gate is " + inputs.Sonar.Status);
        }

        return gaps;
    }

    /// <summary>Builds the full Markdown description.</summary>
    /// <param name="inputs">Inputs.</param>
    /// <returns>Markdown.</returns>
    public static string Build(PrInputs inputs)
    {
        ArgumentNullException.ThrowIfNull(inputs);
        var s = inputs.State;
        var sb = new StringBuilder();
        var gaps = ReadinessGaps(inputs);
        Add(sb, "# " + Title(s));
        Add(sb, string.Empty);
        Add(sb, gaps.Count == 0 ? "> **Status: READY FOR PR** - all SDD gates passed." : "> **Status: NOT READY** - " + string.Join("; ", gaps) + ".");
        Add(sb, string.Empty);

        Add(sb, "## 1. Why - PBI");
        Add(sb, $"- PBI: #{s.PbiId} - {s.Title} (AB#{s.PbiId})");
        Add(sb, $"- Business approval: {Display(inputs.Package.BusinessApproval)}; technical review: {Display(inputs.Package.TechnicalReview)}");
        if (inputs.Package.IsBlocked)
        {
            var choice = s.Answers.TryGetValue(QuestionBuilder.BusinessId, out var value) ? value : "not acknowledged";
            Add(sb, $"- **PBI readiness: BLOCKED** in the package (Readiness: {Display(inputs.Package.Readiness)}); developer chose '{choice}'. Assumptions are listed in section 4.");
        }
        Add(sb, $"- Role: {s.Role} | Branch: `{Display(inputs.Branch)}` | Mode: {s.Mode}");
        Add(sb, $"- Spec: `{s.SpecPath}` | Plan: `{s.PlanPath}`");
        Add(sb, ApprovalLine(inputs));
        Add(sb, string.Empty);

        Section(sb, "## 2. What - delta requirements", inputs.SpecText, "Delta requirements");
        Section(sb, "## 3. Acceptance criteria traceability (AC -> code -> test)", inputs.PlanText, PlanWriter.TraceabilityHeading);
        OtherRepositories(sb, inputs.PlanText);
        Decisions(sb, inputs);
        Files(sb, inputs.Verification);
        Evidence(sb, inputs);

        Add(sb, "## 7. Review");
        Add(sb, "- Independent review (Akzo SDD Reviewer): " + Display(inputs.ReviewVerdict));
        Add(sb, string.Empty);
        Add(sb, "## 8. Delivery metrics");
        Add(sb, MetricsService.Render(s));
        Add(sb, "## 9. Reviewer checklist");
        Add(sb, "- [ ] Every AC marked Yes / Partial above has code and a passing test");
        Add(sb, "- [ ] Messages match the approved text exactly (constants)");
        Add(sb, "- [ ] No unplanned files, deletions, suppressions or package changes");
        Add(sb, "- [ ] Contract parity (route, verb, envelope) kept for the UI");
        return sb.ToString();
    }

    /// <summary>Extracts the verdict line from review.md.</summary>
    /// <param name="reviewText">review.md text.</param>
    /// <returns>Verdict, or null.</returns>
    public static string? ReadVerdict(string? reviewText)
    {
        if (string.IsNullOrWhiteSpace(reviewText))
        {
            return null;
        }

        var row = MarkdownTable.Parse(reviewText).FirstOrDefault(r => r.Cells.Count > 1 && r.Cells[0].StartsWith("Verdict", StringComparison.OrdinalIgnoreCase));
        return row?.Cells[1];
    }

    private static string ApprovalLine(PrInputs inputs)
    {
        if (inputs.Approval is null)
        {
            return "- Approval: NOT RECORDED";
        }

        var freshness = inputs.StaleFiles.Count == 0 ? "unchanged since approval" : "CHANGED since approval";
        return string.Create(CultureInfo.InvariantCulture, $"- Approved by {inputs.Approval.ApprovedBy} on {inputs.Approval.ApprovedUtc:yyyy-MM-dd HH:mm} UTC: \"{inputs.Approval.Statement}\" (hash-bound; {freshness})");
    }

    private static void Decisions(StringBuilder sb, PrInputs inputs)
    {
        Add(sb, "## 4. Decisions applied");
        foreach (var d in inputs.Package.Decisions)
        {
            var answer = inputs.State.Answers.TryGetValue("Q-" + d.Id, out var a) ? $" -> developer: {a}" : string.Empty;
            Add(sb, $"- {d.Id} ({d.Status}{answer}): {d.Text}");
        }

        foreach (var note in inputs.State.AnswerNotes)
        {
            Add(sb, $"- {note.Key}: {note.Value}");
        }

        Add(sb, string.Empty);
    }

    /// <summary>Groups changed files for the PR: specification, production code, tests, local SDD files and others.</summary>
    /// <param name="files">Repository-relative paths.</param>
    /// <returns>Non-empty groups in display order.</returns>
    public static IReadOnlyList<KeyValuePair<string, List<string>>> GroupFiles(IEnumerable<string> files)
    {
        ArgumentNullException.ThrowIfNull(files);
        string[] order = [SpecGroup, CodeGroup, TestGroup, OtherGroup, LocalGroup];
        var groups = order.ToDictionary(g => g, _ => new List<string>(), StringComparer.Ordinal);
        foreach (var file in files)
        {
            groups[Classify(file)].Add(file);
        }

        return order.Where(g => groups[g].Count > 0).Select(g => new KeyValuePair<string, List<string>>(g, groups[g])).ToList();
    }

    private const string SpecGroup = "Specification (approved)";
    private const string CodeGroup = "Production code";
    private const string TestGroup = "Tests";
    private const string OtherGroup = "Other - confirm each belongs in this PR";
    private const string LocalGroup = "Local SDD working files - do not include in the PR";

    private static string Classify(string file)
    {
        var path = file.Replace('\\', '/');
        if (path.StartsWith("docs/sdd/changes/", StringComparison.OrdinalIgnoreCase)
            || path.StartsWith("docs/sdd/pbi-input/", StringComparison.OrdinalIgnoreCase)
            || path.StartsWith(".sdd/", StringComparison.OrdinalIgnoreCase))
        {
            return LocalGroup;
        }

        if (path.Contains(".github/specs/", StringComparison.OrdinalIgnoreCase))
        {
            return SpecGroup;
        }

        if (VerificationService.IsProductionSource(path))
        {
            return CodeGroup;
        }

        var isCode = path.EndsWith(".cs", StringComparison.OrdinalIgnoreCase) || path.EndsWith(".ts", StringComparison.OrdinalIgnoreCase);
        return isCode ? TestGroup : OtherGroup;
    }

    private static void Files(StringBuilder sb, VerificationReport? verification)
    {
        Add(sb, "## 5. Files changed");
        var files = verification?.ChangedFiles ?? [];
        if (files.Count == 0)
        {
            Add(sb, "- Not recorded (run `sdd verify`).");
        }

        foreach (var group in GroupFiles(files))
        {
            Add(sb, string.Create(CultureInfo.InvariantCulture, $"**{group.Key} ({group.Value.Count})**"));
            foreach (var file in group.Value)
            {
                Add(sb, $"- `{file}`");
            }
        }

        Add(sb, string.Empty);
    }

    private static void Evidence(StringBuilder sb, PrInputs inputs)
    {
        Add(sb, "## 6. Verification evidence");
        var v = inputs.Verification;
        if (v is null)
        {
            Add(sb, "- NOT EXECUTED: no verification recorded.");
        }
        else
        {
            Add(sb, string.Create(CultureInfo.InvariantCulture, $"Scope **{v.Scope}**, run {v.StartedUtc:yyyy-MM-dd HH:mm} UTC, {v.DurationSeconds:0.#}s."));
            Add(sb, string.Empty);
            Add(sb, "| Gate | Result | Evidence |");
            Add(sb, "|---|---|---|");
            foreach (var gate in v.Gates)
            {
                Add(sb, $"| {gate.Name} | {StatusText(gate.Status)} | {ArtifactContext.Cell(gate.Detail)} |");
            }
        }

        if (inputs.Sonar is not null)
        {
            Add(sb, $"| SonarQube quality gate | {inputs.Sonar.Status} | {string.Join("; ", inputs.Sonar.Conditions.Select(c => $"{c.Metric}={c.Actual} ({c.Status})"))} |");
        }

        Add(sb, string.Empty);
    }

    private static void OtherRepositories(StringBuilder sb, string planText)
    {
        var section = MarkdownDocument.Parse(planText).Find(PlanWriter.TraceabilityHeading);
        var elsewhere = (section is null ? [] : MarkdownTable.Parse(section.Body))
            .Where(r => r.Get(PlanWriter.AppliesHeader).StartsWith("No", StringComparison.OrdinalIgnoreCase))
            .Select(r => $"- {r.Cells[0]}: {r.Get(PlanWriter.AppliesHeader)}")
            .ToList();
        if (elsewhere.Count == 0)
        {
            return;
        }

        Add(sb, "**Not implemented in this repository (owned elsewhere):**");
        foreach (var line in elsewhere)
        {
            Add(sb, line);
        }

        Add(sb, string.Empty);
    }

    private static void Section(StringBuilder sb, string title, string source, string heading)
    {
        Add(sb, title);
        var section = MarkdownDocument.Parse(source).Find(heading);
        Add(sb, section is null || section.Body.Length == 0 ? "Not documented." : section.Body);
        Add(sb, string.Empty);
    }

    private static string StatusText(GateStatus status) => status switch
    {
        GateStatus.Pass => "PASS",
        GateStatus.Fail => "FAIL",
        _ => "NOT EXECUTED",
    };

    private static string Display(string? value) => string.IsNullOrWhiteSpace(value) ? "not recorded" : value;

    private static void Add(StringBuilder sb, string line) => sb.Append(line).Append('\n');

    [GeneratedRegex(@"^(\s*\[[^\]]*\]\s*)+", RegexOptions.None, 1000)]
    private static partial Regex LeadingTagsRegex();
}
