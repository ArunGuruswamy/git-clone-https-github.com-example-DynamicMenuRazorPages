using System.Security.Cryptography;
using System.Text;

namespace Akzo.Sdd.Core.IO;

/// <summary>SHA-256 helpers.</summary>
public static class FileHash
{
    /// <summary>Hashes a file.</summary>
    /// <param name="path">File path.</param>
    /// <returns>Lower-case hex SHA-256.</returns>
    public static string OfFile(string path)
    {
        using var stream = File.OpenRead(path);
        return Convert.ToHexString(SHA256.HashData(stream)).ToLowerInvariant();
    }

    /// <summary>Hashes text as UTF-8 after normalising line endings to LF.</summary>
    /// <param name="text">Text.</param>
    /// <returns>Lower-case hex SHA-256.</returns>
    public static string OfText(string text)
    {
        ArgumentNullException.ThrowIfNull(text);
        var normalised = text.Replace("\r\n", "\n", StringComparison.Ordinal);
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(normalised))).ToLowerInvariant();
    }

    /// <summary>Converts a path to forward-slash form relative to <paramref name="root"/>.</summary>
    /// <param name="root">Base folder.</param>
    /// <param name="path">Absolute path.</param>
    /// <returns>Relative path with forward slashes.</returns>
    public static string Relative(string root, string path) =>
        Path.GetRelativePath(root, path).Replace('\\', '/');
}
