namespace Akzo.Sdd.Core.Markdown;

/// <summary>One data row of a Markdown table, addressed by header name.</summary>
public sealed class MarkdownTableRow
{
    private readonly IReadOnlyList<string> _headers;
    private readonly IReadOnlyList<string> _cells;

    internal MarkdownTableRow(IReadOnlyList<string> headers, IReadOnlyList<string> cells)
    {
        _headers = headers;
        _cells = cells;
    }

    /// <summary>Raw cells in column order.</summary>
    public IReadOnlyList<string> Cells => _cells;

    /// <summary>Returns the cell whose header starts with <paramref name="headerPrefix"/>, or empty.</summary>
    /// <param name="headerPrefix">Header prefix (case-insensitive).</param>
    /// <returns>Cell text.</returns>
    public string Get(string headerPrefix)
    {
        for (var i = 0; i < _headers.Count; i++)
        {
            if (_headers[i].StartsWith(headerPrefix, StringComparison.OrdinalIgnoreCase))
            {
                return i < _cells.Count ? _cells[i] : string.Empty;
            }
        }

        return string.Empty;
    }
}

/// <summary>Parses the first pipe table in a block of Markdown.</summary>
public static class MarkdownTable
{
    /// <summary>Parses the first table found in <paramref name="markdown"/>.</summary>
    /// <param name="markdown">Markdown text.</param>
    /// <returns>Data rows; empty when no table is present.</returns>
    public static IReadOnlyList<MarkdownTableRow> Parse(string markdown)
    {
        ArgumentNullException.ThrowIfNull(markdown);
        var tableLines = markdown.Replace("\r\n", "\n", StringComparison.Ordinal)
            .Split('\n')
            .Select(l => l.Trim())
            .SkipWhile(l => !l.StartsWith('|'))
            .TakeWhile(l => l.StartsWith('|'))
            .ToList();

        if (tableLines.Count < 2 || !IsSeparator(tableLines[1]))
        {
            return [];
        }

        var headers = SplitRow(tableLines[0]);
        return tableLines.Skip(2).Select(l => new MarkdownTableRow(headers, SplitRow(l))).ToList();
    }

    /// <summary>Splits a pipe-delimited row into trimmed cells.</summary>
    /// <param name="line">Row text.</param>
    /// <returns>Cells.</returns>
    public static IReadOnlyList<string> SplitRow(string line)
    {
        ArgumentNullException.ThrowIfNull(line);
        var trimmed = line.Trim();
        if (trimmed.StartsWith('|'))
        {
            trimmed = trimmed[1..];
        }

        if (trimmed.EndsWith('|'))
        {
            trimmed = trimmed[..^1];
        }

        return trimmed.Split('|').Select(c => c.Trim()).ToList();
    }

    private static bool IsSeparator(string line) =>
        SplitRow(line).All(c => c.Length > 0 && c.All(ch => ch is '-' or ':' or ' '));
}
