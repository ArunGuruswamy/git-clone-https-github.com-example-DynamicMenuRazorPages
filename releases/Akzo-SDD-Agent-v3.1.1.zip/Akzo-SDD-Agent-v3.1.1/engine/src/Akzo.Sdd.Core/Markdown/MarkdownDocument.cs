using System.Text.RegularExpressions;

namespace Akzo.Sdd.Core.Markdown;

/// <summary>A level-two section of a Markdown document.</summary>
/// <param name="Heading">Heading text without the hashes.</param>
/// <param name="Body">Text below the heading up to the next level-two heading.</param>
public sealed record MarkdownSection(string Heading, string Body);

/// <summary>Minimal Markdown reader: title, level-two sections and <c>Key: value</c> fields.</summary>
public sealed partial class MarkdownDocument
{
    private MarkdownDocument(string title, IReadOnlyList<MarkdownSection> sections, string text)
    {
        Title = title;
        Sections = sections;
        Text = text;
    }

    /// <summary>Text of the first level-one heading, or empty.</summary>
    public string Title { get; }

    /// <summary>Level-two sections in document order.</summary>
    public IReadOnlyList<MarkdownSection> Sections { get; }

    /// <summary>Original text.</summary>
    public string Text { get; }

    /// <summary>Parses Markdown text.</summary>
    /// <param name="text">Markdown content.</param>
    /// <returns>The parsed document.</returns>
    public static MarkdownDocument Parse(string text)
    {
        ArgumentNullException.ThrowIfNull(text);
        var lines = text.Replace("\r\n", "\n", StringComparison.Ordinal).Split('\n');
        var title = string.Empty;
        var sections = new List<MarkdownSection>();
        string? heading = null;
        var body = new List<string>();
        var fence = 0;

        foreach (var line in lines)
        {
            fence = TrackFence(line, fence);
            if (fence > 0 || line.StartsWith("```", StringComparison.Ordinal))
            {
                body.Add(line);
                continue;
            }

            if (title.Length == 0 && line.StartsWith("# ", StringComparison.Ordinal))
            {
                title = line[2..].Trim();
                continue;
            }

            if (line.StartsWith("## ", StringComparison.Ordinal))
            {
                AddSection(sections, heading, body);
                heading = line[3..].Trim();
                body.Clear();
                continue;
            }

            body.Add(line);
        }

        AddSection(sections, heading, body);
        return new MarkdownDocument(title, sections, text);
    }

    /// <summary>Finds the first section whose heading starts with the given text (case-insensitive).</summary>
    /// <param name="headingPrefix">Heading prefix.</param>
    /// <returns>The section, or <c>null</c>.</returns>
    public MarkdownSection? Find(string headingPrefix) =>
        Sections.FirstOrDefault(s => s.Heading.StartsWith(headingPrefix, StringComparison.OrdinalIgnoreCase));

    /// <summary>Reads a <c>Key: value</c> field (optionally bulleted) anywhere in the document.</summary>
    /// <param name="key">Field name.</param>
    /// <returns>Trimmed value, or empty.</returns>
    public string GetField(string key)
    {
        var match = FieldRegex().Matches(Text)
            .FirstOrDefault(m => string.Equals(m.Groups["key"].Value.Trim(), key, StringComparison.OrdinalIgnoreCase));
        return match is null ? string.Empty : match.Groups["value"].Value.Trim();
    }

    /// <summary>Returns the open fence length after <paramref name="line"/> (0 = outside a fence).</summary>
    /// <param name="line">Line.</param>
    /// <param name="open">Fence length before the line.</param>
    /// <returns>Fence length after the line.</returns>
    internal static int TrackFence(string line, int open)
    {
        var trimmed = line.Trim();
        var run = trimmed.TakeWhile(c => c == '`').Count();
        if (open == 0)
        {
            return run >= 3 ? run : 0;
        }

        return run >= open && run == trimmed.Length ? 0 : open;
    }

    private static void AddSection(List<MarkdownSection> sections, string? heading, List<string> body)
    {
        if (heading is not null)
        {
            sections.Add(new MarkdownSection(heading, string.Join('\n', body).Trim('\n')));
        }
    }

    [GeneratedRegex(@"^\s*(?:[-*]\s+)?(?<key>[A-Za-z][A-Za-z /-]{1,40}):\s*(?<value>.+?)\s*$", RegexOptions.Multiline, 1000)]
    private static partial Regex FieldRegex();
}
