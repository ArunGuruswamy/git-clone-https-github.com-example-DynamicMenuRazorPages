using System.Globalization;
using System.Text;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Workspace;
using static Akzo.Sdd.Core.Artifacts.ArtifactContext;
using static Akzo.Sdd.Core.Artifacts.SpecWriter;

namespace Akzo.Sdd.Core.Artifacts;

/// <summary>Generates plan.md with a pre-built traceability matrix, test strategy, Sonar rules and verification commands.</summary>
public static class PlanWriter
{
    /// <summary>Heading of the traceability table.</summary>
    public const string TraceabilityHeading = "Traceability (AC -> code -> test)";

    /// <summary>Traceability column that says whether the AC is implemented in this repository.</summary>
    public const string AppliesHeader = "Applies here";

    /// <summary>Heading of the task list.</summary>
    public const string TasksHeading = "Implementation tasks";

    /// <summary>Required level-two headings.</summary>
    public static readonly IReadOnlyList<string> RequiredHeadings =
    [
        "Current implementation inventory",
        "Implementation impact matrix",
        TraceabilityHeading,
        TasksHeading,
        "Test strategy and coverage gate",
        "Sonar quality rules",
        "Build and test verification",
        "Dependency and contract checks",
        "Risks and implementation sequence",
    ];

    /// <summary>Builds the plan text.</summary>
    /// <param name="context">Generation context.</param>
    /// <returns>Markdown.</returns>
    public static string Build(ArtifactContext context)
    {
        ArgumentNullException.ThrowIfNull(context);
        var sb = new StringBuilder();
        Header(sb, context, "Implementation Plan");
        Line(sb, string.Empty);

        Fill(sb, "Current implementation inventory",
            "existing files, classes, handlers, validators, GraphQL operations, services/stores and tests found by search (file > class > method).");
        Line(sb, "## Implementation impact matrix");
        Line(sb, string.Empty);
        Line(sb, "| Area | File or component | Change (new/modify) | AC | Risk |");
        Line(sb, "|---|---|---|---|---|");
        Line(sb, $"{SddConstants.FillMarker}: one row per file to change. -->");
        Line(sb, string.Empty);

        Traceability(sb, context);
        Line(sb, "## " + TasksHeading);
        Line(sb, string.Empty);
        Line(sb, $"{SddConstants.FillMarker}: ordered checklist, one coherent change per task, e.g. '- [ ] T1 [BE] `path/File.cs` - change (AC-01)'; tests are tasks too. -->");
        Line(sb, string.Empty);
        TestStrategy(sb, context);
        Sonar(sb);
        Verification(sb, context);
        Fill(sb, "Dependency and contract checks",
            "DI registration, StrawberryShake regeneration, RoutingMiddleware / FeatureFlags_Cdms, UI contract parity.");
        Fill(sb, "Risks and implementation sequence", "risks with mitigation; deployment order (backend before UI).");
        return sb.ToString();
    }

    private static void Traceability(StringBuilder sb, ArtifactContext context)
    {
        Line(sb, "## " + TraceabilityHeading);
        Line(sb, string.Empty);
        Line(sb, $"'{AppliesHeader}': Yes, Partial (say which part) or No - <owning repository>. Rows marked No need no code or test here (write N/A); they are listed in the PR.");
        Line(sb, string.Empty);
        Line(sb, $"| AC | Expected outcome | Layer (suggested) | {AppliesHeader} | Code (file > class > method) | Test (class.method) |");
        Line(sb, "|---|---|---|---|---|---|");
        foreach (var ac in context.Package.AcceptanceCriteria)
        {
            Line(sb, $"| {ac.Id} | {Cell(ac.Then)} | {RepositoryFit.SuggestLayer(ac)} | {SddConstants.ToBeDetermined} | {SddConstants.ToBeDetermined} | {SddConstants.ToBeDetermined} |");
        }

        Line(sb, string.Empty);
    }

    private static void TestStrategy(StringBuilder sb, ArtifactContext context)
    {
        var threshold = context.Settings.CoverageThreshold.ToString("0.#", CultureInfo.InvariantCulture);
        Line(sb, "## Test strategy and coverage gate");
        Line(sb, string.Empty);
        Line(sb, "- Every AC has at least one automated test asserting the exact outcome or message.");
        Line(sb, "- Every handler/service path: success, validation failure, dependency failure.");
        Line(sb, "- Tests are written with the code (same task group), never deleted or ignored to go green.");
        Line(sb, $"- Coverage gate: >= {threshold}% line coverage on new/changed code (SonarQube 'Coverage on New Code'), enforced by `sdd verify`.");
        Line(sb, "- A run with zero executed tests, failed tests, compiler errors or a stale-build fallback fails verification.");
        Line(sb, string.Empty);
    }

    private static void Sonar(StringBuilder sb)
    {
        Line(sb, "## Sonar quality rules");
        Line(sb, string.Empty);
        Line(sb, "- Cognitive complexity <= 15 (S3776), cyclomatic <= 10 per method (S1541), <= 7 parameters (S107), <= 30 dependent types per class (S1200).");
        Line(sb, "- Every parameter of a documented member has its `<param>` tag (CS1573). New rule logic goes into its own validator/helper, not into a handler near the limits.");
        Line(sb, "- Enforced by `sdd verify`: the 'Sonar rules (local)' gate fails on any analyzer/compiler warning in a changed file (same issues SonarCloud raises).");
        Line(sb, "- No magic strings/numbers (messages as constants), no unused code, no commented-out code, no new suppressions.");
        Line(sb, "- Async all the way (no .Result/.Wait), `using` for IDisposable, fatal-exception filter on broad catches, never swallow.");
        Line(sb, "- Full rules: `.github/instructions/sonar-rules.instructions.md`.");
        Line(sb, string.Empty);
    }

    private static void Verification(StringBuilder sb, ArtifactContext context)
    {
        var profile = RoleProfile.For(context.Role);
        Line(sb, "## Build and test verification");
        Line(sb, string.Empty);
        Line(sb, $"- Build: `{context.Settings.BuildCommand ?? profile.BuildCommand}`");
        Line(sb, $"- Test: `{context.Settings.TestCommand ?? profile.TestCommand}`");
        Line(sb, "- Targeted checkpoint: `sdd verify --scope targeted`; final regression: `sdd verify --scope final`.");
        Line(sb, string.Empty);
    }
}
