using System.Text.RegularExpressions;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.Artifacts;

/// <summary>Inputs needed to generate spec.md and plan.md.</summary>
/// <param name="Package">Parsed PBI package.</param>
/// <param name="Feature">Feature folder name.</param>
/// <param name="Role">Selected role.</param>
/// <param name="PackageRelative">Package folder relative to the repository root.</param>
/// <param name="Settings">Repository settings.</param>
public sealed partial record ArtifactContext(PbiPackage Package, string Feature, ProjectRole Role, string PackageRelative, SddSettings Settings)
{
    private const int MinimumMessageLength = 20;
    private const int MinimumMessageWords = 4;

    /// <summary>Repository-fit findings shown in spec.md.</summary>
    public IReadOnlyList<FitFinding> Fit { get; init; } = [];

    /// <summary>Distinct user-visible messages quoted in acceptance criteria and business rules.</summary>
    /// <returns>Messages in first-seen order.</returns>
    public IReadOnlyList<string> ApprovedMessages()
    {
        var sources = Package.AcceptanceCriteria.Select(a => a.Then)
            .Concat(Package.BusinessRules.Select(b => b.Rule));
        return sources
            .SelectMany(s => QuotedRegex().Matches(s).Select(m => m.Groups["text"].Value))
            .Where(IsMessage)
            .Distinct(StringComparer.Ordinal)
            .ToList();
    }

    /// <summary>True for quoted text that reads as a user-visible sentence rather than a code identifier or value.</summary>
    /// <param name="text">Quoted text.</param>
    /// <returns>True when it is a message.</returns>
    public static bool IsMessage(string text) =>
        !string.IsNullOrWhiteSpace(text)
        && text.Length >= MinimumMessageLength
        && text.Split(' ', StringSplitOptions.RemoveEmptyEntries).Length >= MinimumMessageWords;

    /// <summary>Escapes a value for use inside a Markdown table cell.</summary>
    /// <param name="value">Value.</param>
    /// <returns>Escaped value.</returns>
    public static string Cell(string? value) =>
        string.IsNullOrWhiteSpace(value) ? "-" : value.Replace("|", "\\|", StringComparison.Ordinal).Replace('\n', ' ');

    [GeneratedRegex("`(?<text>[^`]+)`", RegexOptions.None, 1000)]
    private static partial Regex QuotedRegex();
}
