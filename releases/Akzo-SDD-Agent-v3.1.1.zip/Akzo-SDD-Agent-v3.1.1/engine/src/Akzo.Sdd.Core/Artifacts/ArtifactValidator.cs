using System.Text.RegularExpressions;
using Akzo.Sdd.Core.IO;
using Akzo.Sdd.Core.Markdown;
using Akzo.Sdd.Core.Pbi;

namespace Akzo.Sdd.Core.Artifacts;

/// <summary>Result of the AnalysisComplete gate.</summary>
/// <param name="Findings">Problems found; empty means PASS.</param>
public sealed record ValidationReport(IReadOnlyList<string> Findings)
{
    /// <summary>True when no findings exist.</summary>
    public bool Passed => Findings.Count == 0;
}

/// <summary>AnalysisComplete gate: spec.md and plan.md are complete, traceable and the verbatim PBI is intact.</summary>
public static partial class ArtifactValidator
{
    /// <summary>Validates both artifacts against the package.</summary>
    /// <param name="specPath">spec.md path.</param>
    /// <param name="planPath">plan.md path.</param>
    /// <param name="package">PBI package.</param>
    /// <returns>Validation report.</returns>
    public static ValidationReport Validate(string specPath, string planPath, PbiPackage package)
    {
        ArgumentNullException.ThrowIfNull(package);
        var findings = new List<string>();
        if (!File.Exists(specPath) || !File.Exists(planPath))
        {
            findings.Add($"Missing artifact: {(File.Exists(specPath) ? planPath : specPath)}");
            return new ValidationReport(findings);
        }

        var spec = SpecWriter.NormaliseVerbatim(File.ReadAllText(specPath));
        var plan = SpecWriter.NormaliseVerbatim(File.ReadAllText(planPath));
        CheckHeadings(SddConstants.SpecFile, spec, SpecWriter.RequiredHeadings, findings);
        CheckHeadings(SddConstants.PlanFile, plan, PlanWriter.RequiredHeadings, findings);
        CheckPlaceholders(SddConstants.SpecFile, StripVerbatim(spec), findings);
        CheckPlaceholders(SddConstants.PlanFile, plan, findings);
        CheckVerbatim(spec, package, findings);
        CheckTraceability(plan, package, findings);
        CheckTasks(plan, findings);
        return new ValidationReport(findings);
    }

    /// <summary>Extracts task ids (T1, T2 ...) and whether each is ticked.</summary>
    /// <param name="plan">plan.md text.</param>
    /// <returns>Task id to done flag.</returns>
    public static IReadOnlyDictionary<string, bool> ReadTasks(string plan)
    {
        ArgumentNullException.ThrowIfNull(plan);
        return TaskRegex().Matches(plan)
            .GroupBy(m => m.Groups["id"].Value, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => !string.IsNullOrWhiteSpace(g.First().Groups["done"].Value), StringComparer.OrdinalIgnoreCase);
    }

    private static void CheckHeadings(string name, string text, IReadOnlyList<string> required, List<string> findings)
    {
        var document = MarkdownDocument.Parse(text);
        findings.AddRange(required
            .Where(h => document.Find(h) is null)
            .Select(h => $"{name}: missing section '## {h}'"));
    }

    private static void CheckPlaceholders(string name, string text, List<string> findings)
    {
        var markers = Regex.Matches(text, Regex.Escape(SddConstants.FillMarker), RegexOptions.None, TimeSpan.FromSeconds(1)).Count;
        if (markers > 0)
        {
            findings.Add($"{name}: {markers} unfilled 'sdd:fill' marker(s)");
        }

        var tbd = TbdRegex().Matches(text).Count;
        if (tbd > 0)
        {
            findings.Add($"{name}: {tbd} '{SddConstants.ToBeDetermined}' placeholder(s)");
        }
    }

    private static void CheckVerbatim(string spec, PbiPackage package, List<string> findings)
    {
        var block = VerbatimRegex().Match(spec);
        if (!block.Success)
        {
            findings.Add("spec.md: verbatim PBI block markers missing");
            return;
        }

        var expected = FileHash.OfText(SpecWriter.NormaliseVerbatim(package.RefinedText));
        var actual = FileHash.OfText(SpecWriter.NormaliseVerbatim(block.Groups["body"].Value));
        if (!string.Equals(expected, actual, StringComparison.Ordinal))
        {
            findings.Add("spec.md: verbatim PBI block was edited or the refined PBI changed (re-run sdd start)");
        }
    }

    private static void CheckTraceability(string plan, PbiPackage package, List<string> findings)
    {
        var section = MarkdownDocument.Parse(plan).Find(PlanWriter.TraceabilityHeading);
        var rows = section is null ? [] : MarkdownTable.Parse(section.Body);
        var byId = rows.Where(r => r.Cells.Count >= 4)
            .GroupBy(r => r.Cells[0], StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
        var verdicts = package.AcceptanceCriteria.Select(ac => TraceVerdict(ac.Id, byId)).ToList();
        findings.AddRange(verdicts.Where(v => v.Problem is not null).Select(v => v.Problem!));
        if (verdicts.Count > 0 && verdicts.TrueForAll(v => v.NotHere))
        {
            findings.Add("plan.md: every AC is marked 'No' for this repository - nothing to implement here (wrong repository?)");
        }
    }

    private static (string? Problem, bool NotHere) TraceVerdict(string id, Dictionary<string, MarkdownTableRow> byId)
    {
        if (!byId.TryGetValue(id, out var row))
        {
            return ($"plan.md: {id} has no code + test in the traceability table", false);
        }

        var hasApplies = row.Cells.Count >= 6;
        var applies = row.Get(PlanWriter.AppliesHeader);
        if (hasApplies && !IsFilled(applies))
        {
            return ($"plan.md: {id} '{PlanWriter.AppliesHeader}' is not decided (Yes / Partial / No - <owning repository>)", false);
        }

        if (hasApplies && applies.StartsWith("No", StringComparison.OrdinalIgnoreCase))
        {
            return (null, true);
        }

        var code = hasApplies ? row.Get("Code") : row.Cells[2];
        var test = hasApplies ? row.Get("Test") : row.Cells[3];
        return IsFilled(code) && IsFilled(test) ? (null, false) : ($"plan.md: {id} has no code + test in the traceability table", false);
    }

    private static void CheckTasks(string plan, List<string> findings)
    {
        if (ReadTasks(plan).Count == 0)
        {
            findings.Add("plan.md: no tasks ('- [ ] T1 ...') in Implementation tasks");
        }
    }

    private static bool IsFilled(string cell) =>
        cell.Length > 1 && !TbdRegex().IsMatch(cell);

    private static string StripVerbatim(string spec) => VerbatimRegex().Replace(spec, string.Empty);

    [GeneratedRegex(@"\bTBD\b", RegexOptions.None, 1000)]
    private static partial Regex TbdRegex();

    [GeneratedRegex(@"<!-- sdd:pbi-source:begin[^\n]*-->\n````markdown\n(?<body>.*?)\n````\n<!-- sdd:pbi-source:end -->", RegexOptions.Singleline, 2000)]
    private static partial Regex VerbatimRegex();

    [GeneratedRegex(@"^\s*[-*]\s*\[(?<done>[ xX]?)\]\s*(?<id>T\d+)\b", RegexOptions.Multiline, 1000)]
    private static partial Regex TaskRegex();
}
