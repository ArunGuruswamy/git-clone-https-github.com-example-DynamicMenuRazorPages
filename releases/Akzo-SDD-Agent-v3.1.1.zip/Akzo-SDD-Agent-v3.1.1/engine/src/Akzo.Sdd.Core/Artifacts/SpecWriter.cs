using System.Globalization;
using System.Text;
using Akzo.Sdd.Core.IO;
using static Akzo.Sdd.Core.Artifacts.ArtifactContext;

namespace Akzo.Sdd.Core.Artifacts;

/// <summary>Generates spec.md. Everything derivable from the PBI package is written deterministically;
/// only repository evidence is left for the agent, marked with <c>sdd:fill</c>.</summary>
public static class SpecWriter
{
    /// <summary>Required level-two headings, validated by <see cref="ArtifactValidator"/>.</summary>
    public static readonly IReadOnlyList<string> RequiredHeadings =
    [
        "Refined PBI (verbatim source)",
        "Acceptance criteria",
        "PBI sources and attachments",
        "Decisions",
        "Open questions",
        "Business rules",
        "Existing implementation and repository evidence",
        "Delta requirements",
        "API and GraphQL contracts",
        "Validation rules and messages",
        "Testable scenarios",
    ];

    /// <summary>Heading of the repository-fit section (generated; not required in older specs).</summary>
    public const string RepositoryFitHeading = "Repository fit";

    /// <summary>Builds the spec text.</summary>
    /// <param name="context">Generation context.</param>
    /// <returns>Markdown.</returns>
    public static string Build(ArtifactContext context)
    {
        ArgumentNullException.ThrowIfNull(context);
        var p = context.Package;
        var sb = new StringBuilder();
        Header(sb, context, "Specification");
        Line(sb, $"- Refined PBI approval: {Cell(p.BusinessApproval)} (status: {Cell(p.Status)})");
        Line(sb, $"- Technical feasibility review: {Cell(p.TechnicalReview)}");
        Line(sb, string.Empty);

        Line(sb, "## Refined PBI (verbatim source)");
        Line(sb, string.Empty);
        var verbatim = NormaliseVerbatim(p.RefinedText);
        Line(sb, $"{SddConstants.PbiSourceBegin} sha256={FileHash.OfText(verbatim)} -->");
        Line(sb, VerbatimFence + "markdown");
        Line(sb, verbatim);
        Line(sb, VerbatimFence);
        Line(sb, SddConstants.PbiSourceEnd);
        Line(sb, string.Empty);

        AcceptanceCriteria(sb, context);
        RepositoryFitSection(sb, context);
        Sources(sb, context);
        Decisions(sb, context);
        OpenQuestions(sb, context);
        BusinessRules(sb, context);
        Evidence(sb, context);
        Fill(sb, "Delta requirements (ADDED / MODIFIED / REMOVED)",
            "ADDED / MODIFIED / REMOVED requirements R-n (AC-nn) 'The system SHALL ...', each citing current behaviour (file > class > method).");
        Fill(sb, "API and GraphQL contracts",
            "route, verb, request/response, GraphQL operations, generated client impact, which backend serves the route (DAB handler or forwarded to CDMS), UI change yes/no.");
        Messages(sb, context);
        Scenarios(sb, context);
        return sb.ToString();
    }

    /// <summary>Fence that wraps the verbatim PBI so its headings do not become spec sections.</summary>
    public const string VerbatimFence = "````";

    /// <summary>Normalises verbatim text (LF line endings, no trailing blank lines) before hashing.</summary>
    /// <param name="text">Text.</param>
    /// <returns>Normalised text.</returns>
    public static string NormaliseVerbatim(string text)
    {
        ArgumentNullException.ThrowIfNull(text);
        return text.Replace("\r\n", "\n", StringComparison.Ordinal).TrimEnd('\n');
    }

    internal static void Header(StringBuilder sb, ArtifactContext context, string kind)
    {
        var p = context.Package;
        Line(sb, $"# {context.Feature} - {kind}");
        Line(sb, string.Empty);
        Line(sb, $"- PBI ID: {p.Id}");
        Line(sb, $"- PBI title: {p.Title}");
        Line(sb, $"- Feature folder: {context.Feature}");
        Line(sb, $"- Primary project role: {context.Role}");
        Line(sb, $"- PBI input package: `{context.PackageRelative}` ({p.Files.Count} files)");
        Line(sb, $"- SDD agent: v{SddConstants.Version}");
    }

    internal static void Line(StringBuilder sb, string text) => sb.Append(text).Append('\n');

    internal static void Fill(StringBuilder sb, string heading, string instruction)
    {
        Line(sb, "## " + heading);
        Line(sb, string.Empty);
        Line(sb, $"{SddConstants.FillMarker}: {instruction} -->");
        Line(sb, string.Empty);
    }

    private static void AcceptanceCriteria(StringBuilder sb, ArtifactContext context)
    {
        Line(sb, "## Acceptance criteria");
        Line(sb, string.Empty);
        foreach (var ac in context.Package.AcceptanceCriteria)
        {
            Line(sb, $"- **{ac.Id}** - Given {ac.Given}; When {ac.When}; Then {ac.Then}");
        }

        Line(sb, string.Empty);
    }

    private static void RepositoryFitSection(StringBuilder sb, ArtifactContext context)
    {
        Line(sb, "## " + RepositoryFitHeading);
        Line(sb, string.Empty);
        if (context.Fit.Count == 0)
        {
            Line(sb, $"No fit issues found for this {context.Role} repository.");
            Line(sb, string.Empty);
            return;
        }

        Line(sb, $"Checked by `sdd start` against this {context.Role} repository:");
        Line(sb, string.Empty);
        foreach (var finding in context.Fit)
        {
            Line(sb, $"- [{finding.Level.ToString().ToUpperInvariant()}] {finding.Text}");
        }

        Line(sb, string.Empty);
        if (context.Fit.Any(f => f.Level != Pbi.FitLevel.Info))
        {
            Line(sb, $"{SddConstants.FillMarker}: for every BLOCKED/WARN line state how it is handled - the Q-BIZ/Q-FIT answers, which ACs belong to another repository (and which one), and the current behaviour re-traced in THIS repository (file > class > method). -->");
            Line(sb, string.Empty);
        }
    }

    private static void Sources(StringBuilder sb, ArtifactContext context)
    {
        Line(sb, "## PBI sources and attachments");
        Line(sb, string.Empty);
        Line(sb, "The refined PBI is the source of truth. Other files are evidence and add no scope by themselves.");
        Line(sb, string.Empty);
        Line(sb, "| File | Size (bytes) | SHA-256 (12) | Status |");
        Line(sb, "|---|---|---|---|");
        foreach (var file in context.Package.Files)
        {
            var status = file.RelativePath.EndsWith(".md", StringComparison.OrdinalIgnoreCase) ? "Read by sdd" : "Agent review required";
            Line(sb, $"| `{file.RelativePath}` | {file.Size.ToString(CultureInfo.InvariantCulture)} | {file.Sha256[..12]} | {status} |");
        }

        Line(sb, string.Empty);
    }

    private static void Decisions(StringBuilder sb, ArtifactContext context)
    {
        Line(sb, "## Decisions (DECISION-LOG.md)");
        Line(sb, string.Empty);
        if (context.Package.Decisions.Count == 0)
        {
            Line(sb, "N/A - no decision log in the package.");
            Line(sb, string.Empty);
            return;
        }

        Line(sb, "| ID | Decision | Status | Affected |");
        Line(sb, "|---|---|---|---|");
        foreach (var d in context.Package.Decisions)
        {
            Line(sb, $"| {d.Id} | {Cell(d.Text)} | {Cell(d.Status)} | {Cell(d.Affected)} |");
        }

        Line(sb, string.Empty);
    }

    private static void OpenQuestions(StringBuilder sb, ArtifactContext context)
    {
        var questions = context.Package.OpenQuestions;
        var open = questions.Count(q => !q.IsResolved);
        Line(sb, "## Open questions");
        Line(sb, string.Empty);
        Line(sb, $"{questions.Count} recorded, {open} unresolved.");
        Line(sb, string.Empty);
        foreach (var q in questions)
        {
            Line(sb, $"- {q.Id} [{(q.IsResolved ? "RESOLVED" : "OPEN")}] {q.Question} -> {q.Status}");
        }

        Line(sb, string.Empty);
    }

    private static void BusinessRules(StringBuilder sb, ArtifactContext context)
    {
        Line(sb, "## Business rules");
        Line(sb, string.Empty);
        Line(sb, "| ID | Rule | Evidence | Confidence |");
        Line(sb, "|---|---|---|---|");
        foreach (var r in context.Package.BusinessRules)
        {
            Line(sb, $"| {r.Id} | {Cell(r.Rule)} | {Cell(r.Evidence)} | {Cell(r.Confidence)} |");
        }

        Line(sb, string.Empty);
    }

    private static void Evidence(StringBuilder sb, ArtifactContext context)
    {
        Line(sb, "## Existing implementation and repository evidence");
        Line(sb, string.Empty);
        Line(sb, $"{SddConstants.FillMarker}: replace every {SddConstants.ToBeDetermined} with EXISTS / PARTIAL / MISSING / CONFLICT and file > class > method evidence, then delete this marker. -->");
        Line(sb, string.Empty);
        Line(sb, "| AC | Status | Evidence (file > class > method) |");
        Line(sb, "|---|---|---|");
        foreach (var ac in context.Package.AcceptanceCriteria)
        {
            Line(sb, $"| {ac.Id} | {SddConstants.ToBeDetermined} | {SddConstants.ToBeDetermined} |");
        }

        Line(sb, string.Empty);
    }

    private static void Messages(StringBuilder sb, ArtifactContext context)
    {
        Line(sb, "## Validation rules and messages");
        Line(sb, string.Empty);
        Line(sb, "Approved user-visible messages (verbatim; implement as constants, assert exact text in tests):");
        Line(sb, string.Empty);
        foreach (var message in context.ApprovedMessages())
        {
            Line(sb, $"- `{message}`");
        }

        Line(sb, string.Empty);
        Line(sb, $"{SddConstants.FillMarker}: validator/exception type, error code and response envelope used by this repository. -->");
        Line(sb, string.Empty);
    }

    private static void Scenarios(StringBuilder sb, ArtifactContext context)
    {
        Line(sb, "## Testable scenarios");
        Line(sb, string.Empty);
        foreach (var ac in context.Package.AcceptanceCriteria)
        {
            Line(sb, $"### {ac.Id}");
            Line(sb, $"GIVEN {ac.Given}");
            Line(sb, $"WHEN {ac.When}");
            Line(sb, $"THEN {ac.Then}");
            Line(sb, string.Empty);
        }
    }
}
