using System.Globalization;
using System.Text;
using Akzo.Sdd.Core.State;

namespace Akzo.Sdd.Core.Metrics;

/// <summary>Records phase timings and token usage, and renders the metrics table.</summary>
public static class MetricsService
{
    /// <summary>Starts a phase (closing any phase still running).</summary>
    /// <param name="state">State.</param>
    /// <param name="phase">Phase name.</param>
    /// <param name="now">Current time.</param>
    public static void StartPhase(SddState state, string phase, DateTimeOffset now)
    {
        ArgumentNullException.ThrowIfNull(state);
        foreach (var running in state.Phases.Where(p => p.EndedUtc is null))
        {
            running.EndedUtc = now;
        }

        state.Phases.Add(new PhaseTiming { Name = phase, StartedUtc = now });
    }

    /// <summary>Ends the named phase, or the running phase when no name is given.</summary>
    /// <param name="state">State.</param>
    /// <param name="phase">Phase name, optional.</param>
    /// <param name="now">Current time.</param>
    /// <returns>True when a running phase was closed.</returns>
    public static bool EndPhase(SddState state, string? phase, DateTimeOffset now)
    {
        ArgumentNullException.ThrowIfNull(state);
        var running = state.Phases.LastOrDefault(p => p.EndedUtc is null
            && (string.IsNullOrWhiteSpace(phase) || string.Equals(p.Name, phase, StringComparison.OrdinalIgnoreCase)));
        if (running is null)
        {
            return false;
        }

        running.EndedUtc = now;
        return true;
    }

    /// <summary>Records token usage.</summary>
    /// <param name="state">State.</param>
    /// <param name="entry">Entry.</param>
    public static void AddTokens(SddState state, TokenEntry entry)
    {
        ArgumentNullException.ThrowIfNull(state);
        state.Tokens.Add(entry);
    }

    /// <summary>Estimates tokens for text as characters / 4. Always recorded as <see cref="TokenKind.Estimated"/>.</summary>
    /// <param name="characters">Character count.</param>
    /// <returns>Estimated tokens.</returns>
    public static long Estimate(long characters) => (characters + SddConstants.CharactersPerToken - 1) / SddConstants.CharactersPerToken;

    /// <summary>Total elapsed time across closed phases.</summary>
    /// <param name="state">State.</param>
    /// <returns>Total duration.</returns>
    public static TimeSpan TotalDuration(SddState state)
    {
        ArgumentNullException.ThrowIfNull(state);
        return state.Phases.Where(p => p.Duration is not null).Aggregate(TimeSpan.Zero, (sum, p) => sum + p.Duration!.Value);
    }

    /// <summary>Renders the metrics Markdown table.</summary>
    /// <param name="state">State.</param>
    /// <returns>Markdown.</returns>
    public static string Render(SddState state)
    {
        ArgumentNullException.ThrowIfNull(state);
        var sb = new StringBuilder();
        sb.Append("| Phase | Started (UTC) | Duration | Tokens in/out (actual) | Tokens in/out (estimated) |\n");
        sb.Append("|---|---|---|---|---|\n");
        var names = state.Phases.Select(p => p.Name).Concat(state.Tokens.Select(t => t.Phase)).Distinct(StringComparer.OrdinalIgnoreCase);
        foreach (var name in names)
        {
            var timings = state.Phases.Where(p => string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase)).ToList();
            var started = timings.Count > 0 ? timings[0].StartedUtc.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture) : "-";
            var duration = timings.Count == 0 ? "-" : Format(timings.Aggregate(TimeSpan.Zero, (s, p) => s + (p.Duration ?? TimeSpan.Zero)), timings.Exists(p => p.EndedUtc is null));
            sb.Append(CultureInfo.InvariantCulture, $"| {name} | {started} | {duration} | {Tokens(state, name, TokenKind.Actual)} | {Tokens(state, name, TokenKind.Estimated)} |\n");
        }

        sb.Append(CultureInfo.InvariantCulture, $"| **Total** | | **{Format(TotalDuration(state), false)}** | **{Tokens(state, null, TokenKind.Actual)}** | **{Tokens(state, null, TokenKind.Estimated)}** |\n");
        if (state.GeneratedCharacters > 0)
        {
            sb.Append(CultureInfo.InvariantCulture, $"\nDeterministic generation by `sdd`: {state.GeneratedCharacters:N0} characters of spec/plan written without the LLM (about {Estimate(state.GeneratedCharacters):N0} output tokens avoided, estimated).\n");
        }

        sb.Append("\nActual tokens come from the Copilot/provider usage view entered with `sdd tokens --actual`; estimated tokens are characters/4 and are never reported as actual. Unknown means not recorded.\n");
        return sb.ToString();
    }

    private static string Tokens(SddState state, string? phase, TokenKind kind)
    {
        var entries = state.Tokens.Where(t => t.Kind == kind
            && (phase is null || string.Equals(t.Phase, phase, StringComparison.OrdinalIgnoreCase))).ToList();
        return entries.Count == 0
            ? "Unknown"
            : string.Create(CultureInfo.InvariantCulture, $"{entries.Sum(e => e.Input):N0} / {entries.Sum(e => e.Output):N0}");
    }

    private static string Format(TimeSpan duration, bool running)
    {
        string text;
        if (duration.TotalHours >= 1)
        {
            text = string.Create(CultureInfo.InvariantCulture, $"{(int)duration.TotalHours}h {duration.Minutes}m");
        }
        else if (duration.TotalMinutes >= 1)
        {
            text = string.Create(CultureInfo.InvariantCulture, $"{duration.Minutes}m {duration.Seconds}s");
        }
        else
        {
            text = string.Create(CultureInfo.InvariantCulture, $"{duration.TotalSeconds:0.0}s");
        }

        return running ? text + " (running)" : text;
    }
}
