using System.Net.Http.Headers;
using System.Text.Json;
using Akzo.Sdd.Core.Verification;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.Automation;

internal sealed class ServerSonar(HttpClient http, string root, SddSettings settings)
{
    private readonly DateTime _started = DateTime.UtcNow;
    private string Scanner => Path.Combine(root, ".sdd", "tools", "sonar-" + settings.SonarScannerVersion,
        OperatingSystem.IsWindows() ? "dotnet-sonarscanner.exe" : "dotnet-sonarscanner");
    private static string Token => Environment.GetEnvironmentVariable("SONAR_TOKEN") ?? string.Empty;

    internal async Task BeginAsync(string branch)
    {
        if (Token.Length == 0 || string.IsNullOrWhiteSpace(settings.SonarProjectKey)
            || !Uri.TryCreate(settings.SonarUrl, UriKind.Absolute, out var uri) || uri.Scheme != "https"
            || uri.UserInfo.Length > 0 || uri.Query.Length > 0 || uri.Fragment.Length > 0)
            throw new SddException(ErrorCodes.GateFailed, "Configure HTTPS sonarUrl, sonarProjectKey and SONAR_TOKEN securely before final verification.");
        if (!System.Text.RegularExpressions.Regex.IsMatch(settings.SonarScannerVersion, @"^\d+\.\d+\.\d+$", System.Text.RegularExpressions.RegexOptions.None, TimeSpan.FromSeconds(1)))
            throw new SddException("sonarScannerVersion must be a pinned stable version.");
        if (!File.Exists(Scanner))
            await NativeCommand.RunAsync(root, "dotnet", ["tool", "install", "dotnet-sonarscanner", "--version", settings.SonarScannerVersion,
                "--tool-path", Path.GetDirectoryName(Scanner)!]).ConfigureAwait(false);
        var arguments = new List<string> { "begin", "/k:" + settings.SonarProjectKey, "/d:sonar.host.url=" + settings.SonarUrl,
            "/d:sonar.token=" + Token };
        // Dedicated test-result path is appended by the caller; never glob historical coverage.
        arguments.Add("/d:sonar.cs.opencover.reportsPaths=" + CoveragePath);
        if (!string.IsNullOrWhiteSpace(settings.SonarOrganization)) arguments.Add("/o:" + settings.SonarOrganization);
        if (!string.IsNullOrWhiteSpace(branch)) arguments.Add("/d:sonar.branch.name=" + branch);
        await RunScannerAsync(arguments).ConfigureAwait(false);
    }

    internal string CoveragePath { get; set; } = string.Empty;

    internal async Task<GateResult> EndAsync()
    {
        await RunScannerAsync(["end", "/d:sonar.token=" + Token]).ConfigureAwait(false);
        var report = Path.Combine(root, ".sonarqube", "out", ".sonar", "report-task.txt");
        if (!File.Exists(report) || File.GetLastWriteTimeUtc(report) < _started)
            throw new SddException(ErrorCodes.GateFailed, "Scanner did not produce a fresh report-task.txt.");
        var properties = (await File.ReadAllLinesAsync(report).ConfigureAwait(false))
            .Where(line => line.Contains('=')).Select(line => line.Split('=', 2))
            .ToDictionary(pair => pair[0], pair => pair[1], StringComparer.Ordinal);
        if (!properties.TryGetValue("ceTaskId", out var taskId) || string.IsNullOrWhiteSpace(taskId))
            throw new SddException("Scanner task ID is missing.");
        return await WaitForGateAsync(taskId).ConfigureAwait(false);
    }

    internal async Task<GateResult> WaitForGateAsync(string taskId)
    {
        using var deadline = new CancellationTokenSource(TimeSpan.FromMinutes(settings.TimeoutMinutes));
        try
        {
            while (true)
            {
                using var result = await GetAsync("api/ce/task?id=" + Uri.EscapeDataString(taskId), deadline.Token).ConfigureAwait(false);
                var task = result.RootElement.GetProperty("task");
                var status = task.GetProperty("status").GetString();
                if (status == "SUCCESS")
                {
                    var analysis = task.GetProperty("analysisId").GetString() ?? throw new SddException("Missing analysisId.");
                    using var gateJson = await GetAsync("api/qualitygates/project_status?analysisId=" + Uri.EscapeDataString(analysis), deadline.Token).ConfigureAwait(false);
                    var gate = SonarGateClient.Parse(gateJson.RootElement.GetRawText());
                    return new GateResult("Sonar server", gate.Passed ? GateStatus.Pass : GateStatus.Fail,
                        $"Analysis {analysis}; task {taskId}; quality gate {gate.Status}.");
                }
                if (status is "FAILED" or "CANCELED") throw new SddException("Sonar processing " + status);
                await Task.Delay(TimeSpan.FromSeconds(2), deadline.Token).ConfigureAwait(false);
            }
        }
        catch (OperationCanceledException) { throw new SddException(ErrorCodes.GateFailed, "Sonar processing timed out; no passing gate recorded."); }
    }

    private async Task RunScannerAsync(IEnumerable<string> arguments)
    {
        try
        {
            await NativeCommand.RunAsync(root, Scanner, arguments, TimeSpan.FromMinutes(settings.TimeoutMinutes)).ConfigureAwait(false);
        }
        catch (SddException ex)
        {
            throw new SddException(ex.Code, ex.Message.Replace(Token, "[REDACTED]", StringComparison.Ordinal));
        }
    }

    private async Task<JsonDocument> GetAsync(string relative, CancellationToken cancellation)
    {
        var baseUri = new Uri(settings.SonarUrl!.TrimEnd(SddConstants.UrlPathSeparator) + SddConstants.UrlPathSeparator);
        using var request = new HttpRequestMessage(HttpMethod.Get, new Uri(baseUri, relative));
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", Token);
        using var response = await http.SendAsync(request, cancellation).ConfigureAwait(false);
        if (!response.IsSuccessStatusCode) throw new SddException("Sonar API returned HTTP " + (int)response.StatusCode);
        return JsonDocument.Parse(await response.Content.ReadAsStringAsync(cancellation).ConfigureAwait(false));
    }
}
