using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Verification;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.Automation;

internal sealed record SourceStamp(string Head, string Fingerprint);
internal sealed record ReviewStamp(SourceStamp Source, string ReviewHash);

internal static class SourceEvidence
{
    internal static async Task<SourceStamp> CaptureAsync(string root)
    {
        var head = (await NativeCommand.GitAsync(root, "rev-parse", "--verify", "HEAD").ConfigureAwait(false)).Trim();
        var files = await NativeCommand.GitAsync(root, "ls-files", "-z", "--cached", "--others", "--exclude-standard").ConfigureAwait(false);
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        var branch = await NativeCommand.GitAsync(root, "rev-parse", "--abbrev-ref", "HEAD").ConfigureAwait(false);
        hash.AppendData(Encoding.UTF8.GetBytes(branch));
        foreach (var file in files.Split('\0', StringSplitOptions.RemoveEmptyEntries).Distinct(StringComparer.Ordinal).Order(StringComparer.Ordinal))
        {
            // Runtime evidence changes throughout the workflow; never include it in the source identity.
            if (file.StartsWith("docs/sdd/changes/", StringComparison.Ordinal)
                || file.StartsWith(".sonarqube/", StringComparison.Ordinal)
                || file.StartsWith(".sdd/tools/", StringComparison.Ordinal)
                || file == ".sdd/automation.lock" || file == ".sdd/installed.json") continue;
            var path = Path.Combine(root, file);
            hash.AppendData(Encoding.UTF8.GetBytes(file + "\0"));
            hash.AppendData(File.Exists(path) ? SHA256.HashData(await File.ReadAllBytesAsync(path).ConfigureAwait(false)) : [0]);
        }
        return new SourceStamp(head, Convert.ToHexString(hash.GetHashAndReset()));
    }

    internal static string ReviewFile(SddWorkspace ws, SddState state) => ws.ChangeFile(state, "review-evidence.json");

    internal static async Task RequireCurrentAsync(SddWorkspace ws, SddState state, bool review)
    {
        var report = VerificationReport.Load(ws.ChangeFile(state, SddConstants.VerificationFile));
        var current = await CaptureAsync(ws.Root).ConfigureAwait(false);
        if (report is not { Passed: true, Scope: "final" } || report.SourceHead != current.Head || report.SourceFingerprint != current.Fingerprint)
            throw new SddException(ErrorCodes.GateFailed, "Final verification is missing, failed or stale. Run sdd verify --scope final.");
        if (!review) return;
        var path = ReviewFile(ws, state);
        var stamp = File.Exists(path) ? JsonSerializer.Deserialize<ReviewStamp>(await File.ReadAllTextAsync(path).ConfigureAwait(false), Json.Options) : null;
        var reviewPath = ws.ChangeFile(state, SddConstants.ReviewFile);
        if (stamp is null || stamp.Source != current || !File.Exists(reviewPath)
            || stamp.ReviewHash != IO.FileHash.OfFile(reviewPath))
            throw new SddException(ErrorCodes.GateFailed, "Review evidence is missing or stale. Re-review, then sdd review-seal.");
    }
}
