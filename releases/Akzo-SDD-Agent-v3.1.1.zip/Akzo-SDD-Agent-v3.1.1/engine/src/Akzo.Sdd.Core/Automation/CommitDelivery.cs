using System.Text.Json;
using Akzo.Sdd.Core.Pr;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.Automation;

internal sealed record CommitProposal(string Repository, string Branch, string Message, string[] Files, string Checks);
internal sealed record CommitChoice(bool Confirmed, string Message);

internal static class CommitDelivery
{
    internal static async Task<string[]> FilesAsync(string root)
    {
        var tracked = await NativeCommand.GitAsync(root, "diff", "--name-only", "-z", "HEAD").ConfigureAwait(false);
        var others = await NativeCommand.GitAsync(root, "ls-files", "--others", "--exclude-standard", "-z").ConfigureAwait(false);
        return (tracked + others).Split('\0', StringSplitOptions.RemoveEmptyEntries).Distinct(StringComparer.Ordinal)
            .Where(f => !f.StartsWith("docs/sdd/changes/", StringComparison.Ordinal)
                && !f.StartsWith(".sonarqube/", StringComparison.Ordinal)
                && !f.StartsWith(".sdd/tools/", StringComparison.Ordinal)
                && f != ".sdd/automation.lock" && f != ".sdd/installed.json")
            .Order(StringComparer.Ordinal).ToArray();
    }

    internal static async Task<string> ShowAsync(SddWorkspace ws, SddState state)
    {
        if (!OperatingSystem.IsWindows()) throw new SddException("The desktop commit dialog requires interactive Windows. Use Visual Studio on Windows.");
        await SourceEvidence.RequireCurrentAsync(ws, state, true).ConfigureAwait(false);
        await RequireEmptyIndexAsync(ws.Root).ConfigureAwait(false);
        var branch = (await NativeCommand.GitAsync(ws.Root, "symbolic-ref", "--short", "HEAD").ConfigureAwait(false)).Trim();
        var files = await FilesAsync(ws.Root).ConfigureAwait(false);
        if (files.Length == 0) throw new SddException("No changed files to commit.");
        var stamp = await SourceEvidence.CaptureAsync(ws.Root).ConfigureAwait(false);
        var folder = Path.Combine(ws.ChangeFolder(state), "commit-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(folder);
        var request = Path.Combine(folder, "request.json");
        var response = Path.Combine(folder, "response.json");
        var proposal = new CommitProposal(ws.Root, branch, PrDescriptionBuilder.Title(state), files,
            "PASS: final build, tests, coverage, configured Sonar gates; source-bound review. No push, PR or merge.");
        await File.WriteAllTextAsync(request, JsonSerializer.Serialize(proposal, Json.Options)).ConfigureAwait(false);
        var script = Path.Combine(ws.Root, ".github", "sdd", "ui", "CommitDialog.ps1");
        if (!File.Exists(script)) throw new SddException("Commit dialog missing. Upgrade repository assets with sdd install.");
        await NativeCommand.RunAsync(ws.Root, "powershell.exe", ["-NoProfile", "-STA", "-File", script,
            "-RequestPath", request, "-ResponsePath", response], TimeSpan.FromHours(1)).ConfigureAwait(false);
        var choice = File.Exists(response) ? JsonSerializer.Deserialize<CommitChoice>(await File.ReadAllTextAsync(response).ConfigureAwait(false), Json.Options) : null;
        if (choice is not { Confirmed: true }) return "Cancelled. No files staged or committed.";
        if (string.IsNullOrWhiteSpace(choice.Message)) throw new SddException("Commit message is empty.");
        await CommitAsync(ws, state, stamp, files, choice.Message).ConfigureAwait(false);
        return "Committed locally: " + (await NativeCommand.GitAsync(ws.Root, "rev-parse", "HEAD").ConfigureAwait(false)).Trim()
            + ". Create and merge the PR manually.";
    }

    internal static async Task CommitAsync(SddWorkspace ws, SddState state, SourceStamp stamp, string[] files, string message)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(message);
        await SourceEvidence.RequireCurrentAsync(ws, state, true).ConfigureAwait(false);
        await RequireEmptyIndexAsync(ws.Root).ConfigureAwait(false);
        if (stamp != await SourceEvidence.CaptureAsync(ws.Root).ConfigureAwait(false)
            || !files.SequenceEqual(await FilesAsync(ws.Root).ConfigureAwait(false), StringComparer.Ordinal))
            throw new SddException("Files changed while the dialog was open. Reverify and reopen the dialog.");
        await NativeCommand.GitAsync(ws.Root, ["add", "--", .. files]).ConfigureAwait(false);
        // Leave staging intact on failure; never reset or discard concurrent developer work.
        var staged = (await NativeCommand.GitAsync(ws.Root, "diff", "--cached", "--name-only", "-z").ConfigureAwait(false))
            .Split('\0', StringSplitOptions.RemoveEmptyEntries).Order(StringComparer.Ordinal);
        if (!files.SequenceEqual(staged, StringComparer.Ordinal) || stamp != await SourceEvidence.CaptureAsync(ws.Root).ConfigureAwait(false))
            throw new SddException("Index/source changed before commit. No commit made; inspect staged files manually.");
        var messagePath = ws.ChangeFile(state, "commit-message.txt");
        await File.WriteAllTextAsync(messagePath, message).ConfigureAwait(false);
        var expectedTree = (await NativeCommand.GitAsync(ws.Root, "write-tree").ConfigureAwait(false)).Trim();
        await NativeCommand.GitAsync(ws.Root, "commit", "--file", messagePath).ConfigureAwait(false);
        var actualTree = (await NativeCommand.GitAsync(ws.Root, "rev-parse", "HEAD^{tree}").ConfigureAwait(false)).Trim();
        var after = await SourceEvidence.CaptureAsync(ws.Root).ConfigureAwait(false);
        if (actualTree != expectedTree || after.Fingerprint != stamp.Fingerprint)
            throw new SddException("Commit was created, but a hook or concurrent edit changed validated content. Do not deliver it yet; reverify/review manually. No reset or amend was attempted.");
    }

    private static async Task RequireEmptyIndexAsync(string root)
    {
        if ((await NativeCommand.GitAsync(root, "diff", "--cached", "--name-only", "-z").ConfigureAwait(false)).Length > 0)
            throw new SddException("Existing staged changes found. Handle them in Visual Studio before using the automated commit dialog.");
    }
}
