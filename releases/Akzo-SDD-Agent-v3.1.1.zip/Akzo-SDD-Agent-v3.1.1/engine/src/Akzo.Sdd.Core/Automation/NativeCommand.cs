using System.Diagnostics;

namespace Akzo.Sdd.Core.Automation;

// Deliberately bypass the shell for Git, scanner installation and desktop UI arguments.
internal static class NativeCommand
{
    internal static async Task<string> RunAsync(string root, string executable, IEnumerable<string> arguments,
        TimeSpan? timeout = null, IReadOnlyDictionary<string, string>? environment = null)
    {
        var info = new ProcessStartInfo(executable) { WorkingDirectory = root, RedirectStandardOutput = true,
            RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
        foreach (var argument in arguments) info.ArgumentList.Add(argument);
        if (environment is not null)
            foreach (var pair in environment) info.Environment[pair.Key] = pair.Value;
        using var process = Process.Start(info) ?? throw new SddException("Cannot start " + executable);
        var output = process.StandardOutput.ReadToEndAsync();
        var error = process.StandardError.ReadToEndAsync();
        using var cancellation = new CancellationTokenSource(timeout ?? TimeSpan.FromMinutes(5));
        try { await process.WaitForExitAsync(cancellation.Token).ConfigureAwait(false); }
        catch (OperationCanceledException)
        {
            process.Kill(true);
            await process.WaitForExitAsync().ConfigureAwait(false);
            throw new SddException(ErrorCodes.GateFailed, executable + " timed out.");
        }
        var text = await output.ConfigureAwait(false);
        var diagnostic = await error.ConfigureAwait(false);
        if (process.ExitCode != 0)
            throw new SddException(ErrorCodes.GateFailed, executable + " failed: " + diagnostic + text);
        return text;
    }

    internal static Task<string> GitAsync(string root, params string[] arguments) => RunAsync(root, "git", arguments);
}
