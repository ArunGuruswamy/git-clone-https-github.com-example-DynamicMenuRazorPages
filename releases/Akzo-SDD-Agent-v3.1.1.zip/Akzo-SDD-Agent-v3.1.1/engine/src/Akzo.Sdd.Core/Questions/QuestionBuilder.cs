using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.Questions;

/// <summary>Builds the predefined multiple-choice questions from the PBI package and current state.</summary>
public static class QuestionBuilder
{
    /// <summary>Question id: project role.</summary>
    public const string RoleId = "Q-ROLE";

    /// <summary>Question id: feature folder name.</summary>
    public const string FeatureId = "Q-FEATURE";

    /// <summary>Question id: business approval acknowledgement.</summary>
    public const string BusinessId = "Q-BIZ";

    /// <summary>Question id: how to scope a PBI that does not fully fit this repository.</summary>
    public const string FitId = "Q-FIT";

    /// <summary>Question id: execution mode.</summary>
    public const string ModeId = "Q-MODE";

    /// <summary>Question id: implementation approval.</summary>
    public const string ApproveId = "Q-APPROVE";

    /// <summary>Question id: start independent review.</summary>
    public const string ReviewId = "Q-REVIEW";

    /// <summary>Question id: generate PR description.</summary>
    public const string PrId = "Q-PR";

    /// <summary>Answer key: proceed without business approval.</summary>
    public const string Proceed = "proceed";

    /// <summary>Answer key: wait for business approval.</summary>
    public const string Wait = "wait";

    /// <summary>Answer key: approve.</summary>
    public const string Approve = "approve";

    /// <summary>Answer key: decision or question still blocking.</summary>
    public const string Blocked = "blocking";

    /// <summary>Builds all unanswered questions for a stage.</summary>
    /// <param name="stage">Stage.</param>
    /// <param name="package">PBI package.</param>
    /// <param name="state">Current state.</param>
    /// <param name="roleCandidates">Role candidates when detection was ambiguous; empty otherwise.</param>
    /// <param name="featureCandidates">Feature name candidates, recommended first.</param>
    /// <returns>Unanswered questions.</returns>
    public static IReadOnlyList<ChoiceQuestion> Build(
        QuestionStage stage,
        PbiPackage package,
        SddState state,
        IReadOnlyList<ProjectRole> roleCandidates,
        IReadOnlyList<string> featureCandidates)
    {
        ArgumentNullException.ThrowIfNull(package);
        ArgumentNullException.ThrowIfNull(state);
        var all = stage switch
        {
            QuestionStage.Approval => ApprovalQuestions(state),
            QuestionStage.Delivery => DeliveryQuestions(),
            _ => StartQuestions(package, state, roleCandidates, featureCandidates),
        };
        return all.Where(q => !state.Answers.ContainsKey(q.Id)).ToList();
    }

    /// <summary>Every question for every stage, ignoring answers (used to validate an answer).</summary>
    /// <param name="package">PBI package.</param>
    /// <param name="state">Current state.</param>
    /// <param name="featureCandidates">Feature name candidates.</param>
    /// <returns>All questions.</returns>
    public static IReadOnlyList<ChoiceQuestion> All(PbiPackage package, SddState state, IReadOnlyList<string> featureCandidates)
    {
        ArgumentNullException.ThrowIfNull(package);
        ArgumentNullException.ThrowIfNull(state);
        return StartQuestions(package, state, [], featureCandidates)
            .Concat(ApprovalQuestions(state))
            .Concat(DeliveryQuestions())
            .ToList();
    }

    /// <summary>Returns ids of required start questions that are still unanswered or answered as blocking.</summary>
    /// <param name="package">PBI package.</param>
    /// <param name="state">State.</param>
    /// <returns>Blocking reasons.</returns>
    public static IReadOnlyList<string> ApprovalBlockers(PbiPackage package, SddState state)
    {
        ArgumentNullException.ThrowIfNull(package);
        ArgumentNullException.ThrowIfNull(state);
        var blockers = StartQuestions(package, state, [], [])
            .Where(q => q.Blocking && !state.Answers.ContainsKey(q.Id))
            .Select(q => $"{q.Id} unanswered")
            .ToList();
        blockers.AddRange(state.Answers
            .Where(a => string.Equals(a.Value, Blocked, StringComparison.OrdinalIgnoreCase)
                        || (string.Equals(a.Key, BusinessId, StringComparison.OrdinalIgnoreCase) && string.Equals(a.Value, Wait, StringComparison.OrdinalIgnoreCase)))
            .Select(a => $"{a.Key} answered '{a.Value}'"));
        return blockers;
    }

    private static List<ChoiceQuestion> StartQuestions(
        PbiPackage package,
        SddState state,
        IReadOnlyList<ProjectRole> roleCandidates,
        IReadOnlyList<string> featureCandidates)
    {
        var questions = new List<ChoiceQuestion>();
        if (state.Role == ProjectRole.Unknown)
        {
            var roles = roleCandidates.Count > 1 ? roleCandidates : [ProjectRole.Dab, ProjectRole.Cdms, ProjectRole.Ui];
            questions.Add(new ChoiceQuestion(
                RoleId,
                "Which project does this PBI change?",
                roles.Select(r => new ChoiceOption(r.ToString().ToLowerInvariant(), r.ToString().ToUpperInvariant(), RoleDescription(r))).ToList(),
                null,
                Blocking: true,
                QuestionStage.Start));
        }

        if (featureCandidates.Count > 1)
        {
            questions.Add(new ChoiceQuestion(
                FeatureId,
                $"Feature folder for spec.md and plan.md (current: {state.Feature})?",
                featureCandidates.Select(f => new ChoiceOption(f, f, $"Use .../specs/{f}/")).ToList(),
                featureCandidates[0],
                Blocking: false,
                QuestionStage.Start));
        }

        if (!package.IsBusinessApproved || package.IsBlocked)
        {
            questions.Add(BusinessQuestion(package));
        }

        if (state.FitWarnings.Count > 0)
        {
            questions.Add(new ChoiceQuestion(
                FitId,
                $"The PBI does not fully fit this {state.Role.ToString().ToUpperInvariant()} repository: {string.Join(" | ", state.FitWarnings)} How should I scope it?",
                [
                    new ChoiceOption("here", "Implement what applies here", "Mark every AC in plan.md as Yes / Partial / No - <owning repository>; only Yes and Partial are implemented and tested here; the PR lists the rest."),
                    new ChoiceOption("all", "Implement every AC here", "Treat the whole PBI as this repository's scope."),
                    new ChoiceOption(Blocked, "Wrong repository / needs PO/BA", "Finish analysis only; implementation approval is blocked."),
                ],
                "here",
                Blocking: true,
                QuestionStage.Start));
        }

        questions.AddRange(package.Decisions.Where(d => !d.IsApproved).Select(DecisionQuestion));
        questions.AddRange(package.OpenQuestions.Where(q => !q.IsResolved).Select(OpenQuestionQuestion));
        questions.Add(new ChoiceQuestion(
            ModeId,
            "Execution mode after approval?",
            [
                new ChoiceOption("fast", "FAST", "Implement all tasks continuously; verify at checkpoints; no per-file pauses."),
                new ChoiceOption("step", "STEP", "One task per message; wait for my build result before the next."),
            ],
            "fast",
            Blocking: false,
            QuestionStage.Start));
        return questions;
    }

    private static ChoiceQuestion BusinessQuestion(PbiPackage package)
    {
        var blocking = package.OpenQuestions.Where(q => q.IsBlocking).Select(q => q.Id).ToList();
        var blockingText = blocking.Count > 0 ? "; blocking: " + string.Join(", ", blocking) : string.Empty;
        var text = package.IsBlocked
            ? $"The refined PBI is BLOCKED (Status: {Display(package.Status)}; Readiness: {Display(package.Readiness)}{blockingText}) and business approval is {Display(package.BusinessApproval)}. How should I proceed?"
            : $"The refined PBI is not business-approved (Business approval: {Display(package.BusinessApproval)}). How should I proceed?";
        return new ChoiceQuestion(
            BusinessId,
            text,
            [
                new ChoiceOption(Proceed, "Proceed and record it", "Analyse and implement; approval.json and the PR state the PBI was not business-approved" + (package.IsBlocked ? " and was blocked." : ".")),
                new ChoiceOption(Wait, "Wait for PO/BA", "Finish analysis only; implementation stays blocked until the PBI is approved."),
            ],
            package.IsBlocked ? Wait : Proceed,
            Blocking: true,
            QuestionStage.Start);
    }

    private static ChoiceQuestion DecisionQuestion(Decision decision) => new(
        "Q-" + decision.Id,
        $"Decision {decision.Id} is '{Display(decision.Status)}': \"{decision.Text}\" (affects {Display(decision.Affected)}). Confirm?",
        [
            new ChoiceOption("accept", "Accept for this PBI", "Treat it as approved scope; recorded in approval.json."),
            new ChoiceOption("reject", "Reject", "Exclude the affected behaviour; plan marks it out of scope."),
            new ChoiceOption(Blocked, "Needs PO/BA", "Keep it open; implementation approval is blocked."),
        ],
        "accept",
        Blocking: true,
        QuestionStage.Start);

    private static ChoiceQuestion OpenQuestionQuestion(OpenQuestion question) => new(
        question.Id.StartsWith("Q-", StringComparison.OrdinalIgnoreCase) ? question.Id : "Q-" + question.Id,
        $"{(question.IsBlocking ? "[BLOCKING] " : string.Empty)}Open question {question.Id} ({Display(question.Status)}): {question.Question} (impact: {Display(question.Impact)})",
        [
            new ChoiceOption("answer", "I will answer now", "Type the answer; it is recorded as a confirmed decision."),
            new ChoiceOption("assume", "Proceed with an assumption", "Record an ASSUMPTION in spec.md; not used as a requirement."),
            new ChoiceOption(Blocked, "Needs PO/BA", "Implementation approval is blocked until answered."),
        ],
        question.IsBlocking ? Blocked : null,
        Blocking: true,
        QuestionStage.Start);

    private static List<ChoiceQuestion> ApprovalQuestions(SddState state) =>
    [
        new ChoiceQuestion(
            ApproveId,
            $"spec.md and plan.md for PBI {state.PbiId} passed the AnalysisComplete gate. Approve implementation?",
            [
                new ChoiceOption(Approve, "Approve implementation", "Hash-bind spec, plan and PBI inputs; start implementing in " + state.Mode + " mode."),
                new ChoiceOption("revise", "Revise first", "Tell me what to change; approval is asked again after the update."),
                new ChoiceOption("stop", "Stop here", "Keep the analysis; no source code is edited."),
            ],
            Approve,
            Blocking: true,
            QuestionStage.Approval),
    ];

    private static List<ChoiceQuestion> DeliveryQuestions() =>
    [
        new ChoiceQuestion(
            ReviewId,
            "All tasks are done and targeted verification passed. Start the independent pre-PR review?",
            [
                new ChoiceOption("review", "Start review now", "Switch to Akzo SDD Reviewer and send Review; it reviews, then finishes the PR text when READY FOR PR."),
                new ChoiceOption("changes", "I have more changes", "Stay in implementation; ask again later."),
            ],
            "review",
            Blocking: true,
            QuestionStage.Delivery),
        new ChoiceQuestion(
            PrId,
            "Final verification passed. Generate the SDD pull-request description?",
            [
                new ChoiceOption("generate", "Generate PR description", "Write pr-description.md with traceability, evidence and metrics. Nothing is committed or pushed."),
                new ChoiceOption("later", "Later", "Skip for now."),
            ],
            "generate",
            Blocking: false,
            QuestionStage.Delivery),
    ];

    private static string RoleDescription(ProjectRole role) => role switch
    {
        ProjectRole.Cdms => "ColorDMS Dataverse/XRM Azure Functions (.NET Framework 4.8)",
        ProjectRole.Ui => "AN.ColorAppsAzure.UI Angular front end",
        _ => "Formula DAB/GraphQL Azure Functions (AN.ColorAppsAzure.BL)",
    };

    private static string Display(string value) => string.IsNullOrWhiteSpace(value) ? "not stated" : value;
}
