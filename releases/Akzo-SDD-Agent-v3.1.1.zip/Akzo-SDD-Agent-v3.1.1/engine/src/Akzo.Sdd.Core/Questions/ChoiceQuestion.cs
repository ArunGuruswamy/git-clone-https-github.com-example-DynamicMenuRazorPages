using System.Globalization;
using System.Text;

namespace Akzo.Sdd.Core.Questions;

/// <summary>When in the lifecycle a question is asked.</summary>
public enum QuestionStage
{
    /// <summary>Right after <c>sdd start</c>, before analysis is finalised.</summary>
    Start = 0,

    /// <summary>At the implementation approval gate.</summary>
    Approval,

    /// <summary>After implementation: review and PR.</summary>
    Delivery,
}

/// <summary>One predefined answer.</summary>
/// <param name="Key">Stable key passed to <c>sdd answer</c>.</param>
/// <param name="Label">Short label shown to the developer.</param>
/// <param name="Description">What choosing it leads to.</param>
public sealed record ChoiceOption(string Key, string Label, string Description);

/// <summary>A multiple-choice question for the developer.</summary>
/// <param name="Id">Stable id, for example <c>Q-BIZ</c> or <c>Q-D-01</c>.</param>
/// <param name="Prompt">Question text.</param>
/// <param name="Options">Predefined answers.</param>
/// <param name="Recommended">Recommended option key, or null.</param>
/// <param name="Blocking">True when approval is refused until it is answered.</param>
/// <param name="Stage">Lifecycle stage.</param>
public sealed record ChoiceQuestion(
    string Id,
    string Prompt,
    IReadOnlyList<ChoiceOption> Options,
    string? Recommended,
    bool Blocking,
    QuestionStage Stage)
{
    /// <summary>Resolves an answer given as option key or 1-based number.</summary>
    /// <param name="answer">Key or number.</param>
    /// <returns>The option, or null when it does not match.</returns>
    public ChoiceOption? Resolve(string answer)
    {
        var value = (answer ?? string.Empty).Trim();
        if (int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var number)
            && number >= 1 && number <= Options.Count)
        {
            return Options[number - 1];
        }

        return Options.FirstOrDefault(o => string.Equals(o.Key, value, StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>Renders the question as a numbered Markdown block for chats without a picker tool.</summary>
    /// <returns>Markdown.</returns>
    public string ToMarkdown()
    {
        var sb = new StringBuilder();
        sb.Append("**").Append(Id).Append("**").Append(Blocking ? " (required)" : string.Empty).Append(' ').Append(Prompt).Append('\n');
        for (var i = 0; i < Options.Count; i++)
        {
            var option = Options[i];
            var recommended = string.Equals(option.Key, Recommended, StringComparison.OrdinalIgnoreCase) ? " (Recommended)" : string.Empty;
            sb.Append(CultureInfo.InvariantCulture, $"  {i + 1}. {option.Label}{recommended} - {option.Description}\n");
        }

        return sb.ToString();
    }
}
