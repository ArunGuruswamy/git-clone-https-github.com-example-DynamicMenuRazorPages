using System.Text.Json;
using Akzo.Sdd.Core.Artifacts;
using Akzo.Sdd.Core.IO;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Questions;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.Approval;

/// <summary>Hash-bound approval record (<c>approval.json</c>).</summary>
public sealed class ApprovalRecord
{
    /// <summary>PBI id.</summary>
    public string PbiId { get; set; } = string.Empty;

    /// <summary>Person who approved (never an agent).</summary>
    public string ApprovedBy { get; set; } = string.Empty;

    /// <summary>The developer's verbatim approval words.</summary>
    public string Statement { get; set; } = string.Empty;

    /// <summary>Approval time.</summary>
    public DateTimeOffset ApprovedUtc { get; set; }

    /// <summary>True when the refined PBI was business-approved at approval time.</summary>
    public bool PbiBusinessApproved { get; set; }

    /// <summary>Answers recorded at approval time.</summary>
    public Dictionary<string, string> Answers { get; set; } = [];

    /// <summary>Repository-relative path to SHA-256 for spec, plan and every PBI input file.</summary>
    public Dictionary<string, string> Hashes { get; set; } = [];
}

/// <summary>Records and checks implementation approval.</summary>
public static class ApprovalService
{
    /// <summary>Approves implementation after the AnalysisComplete gate and all required answers.</summary>
    /// <param name="workspace">Workspace.</param>
    /// <param name="state">State (updated to Implement).</param>
    /// <param name="package">PBI package.</param>
    /// <param name="statement">Developer's verbatim words.</param>
    /// <param name="approvedBy">Developer name.</param>
    /// <returns>The approval record.</returns>
    /// <exception cref="SddException">When a gate or required answer is missing.</exception>
    public static ApprovalRecord Approve(SddWorkspace workspace, SddState state, PbiPackage package, string statement, string approvedBy)
    {
        ArgumentNullException.ThrowIfNull(workspace);
        ArgumentNullException.ThrowIfNull(state);
        ArgumentException.ThrowIfNullOrWhiteSpace(statement);
        ArgumentException.ThrowIfNullOrWhiteSpace(approvedBy);

        var validation = ArtifactValidator.Validate(workspace.Absolute(state.SpecPath), workspace.Absolute(state.PlanPath), package);
        var blockers = QuestionBuilder.ApprovalBlockers(package, state);
        var problems = validation.Findings.Concat(blockers).ToList();
        if (problems.Count > 0)
        {
            throw new SddException(ErrorCodes.GateFailed, "Approval refused:\n- " + string.Join("\n- ", problems));
        }

        var record = new ApprovalRecord
        {
            PbiId = state.PbiId,
            ApprovedBy = approvedBy,
            Statement = statement,
            ApprovedUtc = workspace.Clock.UtcNow,
            PbiBusinessApproved = package.IsBusinessApproved,
            Answers = new Dictionary<string, string>(state.Answers, StringComparer.OrdinalIgnoreCase),
            Hashes = CurrentHashes(workspace, state),
        };
        File.WriteAllText(workspace.ChangeFile(state, SddConstants.ApprovalFile), JsonSerializer.Serialize(record, Json.Options));
        state.Phase = SddPhase.Implement;
        workspace.Save(state);
        return record;
    }

    /// <summary>Loads the approval record, or null.</summary>
    /// <param name="workspace">Workspace.</param>
    /// <param name="state">State.</param>
    /// <returns>Record or null.</returns>
    public static ApprovalRecord? Load(SddWorkspace workspace, SddState state)
    {
        ArgumentNullException.ThrowIfNull(workspace);
        var path = workspace.ChangeFile(state, SddConstants.ApprovalFile);
        return File.Exists(path) ? JsonSerializer.Deserialize<ApprovalRecord>(File.ReadAllText(path), Json.Options) : null;
    }

    /// <summary>Returns files whose hash changed since approval (empty means the approval is current).</summary>
    /// <param name="workspace">Workspace.</param>
    /// <param name="state">State.</param>
    /// <param name="record">Approval record.</param>
    /// <returns>Changed or missing files.</returns>
    public static IReadOnlyList<string> ChangedSinceApproval(SddWorkspace workspace, SddState state, ApprovalRecord record)
    {
        ArgumentNullException.ThrowIfNull(record);
        var current = CurrentHashes(workspace, state);
        return record.Hashes
            .Where(kv => !current.TryGetValue(kv.Key, out var hash) || !string.Equals(hash, kv.Value, StringComparison.Ordinal))
            .Select(kv => kv.Key)
            .Concat(current.Keys.Where(k => !record.Hashes.ContainsKey(k)))
            .ToList();
    }

    private static Dictionary<string, string> CurrentHashes(SddWorkspace workspace, SddState state)
    {
        var hashes = new Dictionary<string, string>(StringComparer.Ordinal)
        {
            [state.SpecPath] = FileHash.OfFile(workspace.Absolute(state.SpecPath)),
            [state.PlanPath] = FileHash.OfFile(workspace.Absolute(state.PlanPath)),
        };
        var package = workspace.Absolute(state.PackageFolder);
        foreach (var file in Directory.EnumerateFiles(package, "*", SearchOption.AllDirectories))
        {
            hashes[FileHash.Relative(workspace.Root, file)] = FileHash.OfFile(file);
        }

        return hashes;
    }
}
