namespace Akzo.Sdd.Core;

/// <summary>An expected SDD failure with a stable machine-readable code.</summary>
public sealed class SddException : Exception
{
    /// <summary>Creates the exception.</summary>
    /// <param name="code">Stable result code, for example <c>PbiNotFound</c>.</param>
    /// <param name="message">Human-readable explanation.</param>
    public SddException(string code, string message) : base(message)
    {
        Code = code;
    }

    /// <summary>Creates the exception with the default code.</summary>
    public SddException() : this(ErrorCodes.Failed, ErrorCodes.Failed)
    {
    }

    /// <summary>Creates the exception with the default code.</summary>
    /// <param name="message">Human-readable explanation.</param>
    public SddException(string message) : this(ErrorCodes.Failed, message)
    {
    }

    /// <summary>Creates the exception with an inner exception.</summary>
    /// <param name="message">Human-readable explanation.</param>
    /// <param name="innerException">Cause.</param>
    public SddException(string message, Exception innerException) : base(message, innerException)
    {
        Code = ErrorCodes.Failed;
    }

    /// <summary>Stable result code.</summary>
    public string Code { get; }
}

/// <summary>Stable result codes returned by the engine.</summary>
public static class ErrorCodes
{
    /// <summary>Generic failure.</summary>
    public const string Failed = "Failed";

    /// <summary>No PBI package was found.</summary>
    public const string PbiNotFound = "PbiNotFound";

    /// <summary>More than one PBI package matches.</summary>
    public const string PbiAmbiguous = "PbiAmbiguous";

    /// <summary>The request could not be parsed.</summary>
    public const string InvalidRequest = "InvalidRequest";

    /// <summary>No active PBI is recorded.</summary>
    public const string NoActivePbi = "NoActivePbi";

    /// <summary>A gate did not pass.</summary>
    public const string GateFailed = "GateFailed";

    /// <summary>An answer does not match a known question or option.</summary>
    public const string InvalidAnswer = "InvalidAnswer";

    /// <summary>A required source changed after approval.</summary>
    public const string ApprovalStale = "ApprovalStale";
}
