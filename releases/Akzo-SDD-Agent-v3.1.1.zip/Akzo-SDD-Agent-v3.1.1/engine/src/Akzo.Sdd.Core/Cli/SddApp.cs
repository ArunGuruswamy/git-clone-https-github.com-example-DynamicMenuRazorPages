using System.Globalization;
using Akzo.Sdd.Core.Automation;
using System.Text.Json;
using Akzo.Sdd.Core.Approval;
using Akzo.Sdd.Core.Artifacts;
using Akzo.Sdd.Core.Execution;
using Akzo.Sdd.Core.IO;
using Akzo.Sdd.Core.Metrics;
using Akzo.Sdd.Core.Pbi;
using Akzo.Sdd.Core.Pr;
using Akzo.Sdd.Core.Questions;
using Akzo.Sdd.Core.Services;
using Akzo.Sdd.Core.State;
using Akzo.Sdd.Core.Verification;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.Cli;

/// <summary>Command dispatcher for the <c>sdd</c> tool.</summary>
public sealed class SddApp
{
    /// <summary>Exit code: success.</summary>
    public const int Ok = 0;

    /// <summary>Exit code: a gate failed or an answer is needed.</summary>
    public const int GateFailed = 1;

    /// <summary>Exit code: usage error.</summary>
    public const int UsageError = 2;

    /// <summary>Exit code: PBI or state not found.</summary>
    public const int NotFound = 3;

    private const string Usage = """
        sdd - Akzo SDD engine v{0}

          sdd start "Start Development <PBI-ID> <Feature>" [--source <zip|folder>] [--role dab|cdms|ui] [--feature Name] [--json]
          sdd questions [--stage start|approval|delivery] [--json]
          sdd answer <Q-ID> <option-key|number> [--note "text"]
          sdd check [--json]                      AnalysisComplete gate (spec.md + plan.md)
          sdd approve --statement "<your words>" --by "<your name>"
          sdd task <T-id> --evidence "<command + result>"
          sdd verify [--scope targeted|final] [--min-coverage 90] [--all-files] [--build "cmd"] [--test "cmd"] [--no-sonar] [--json]
          sdd sonar [--url <sonar url>] [--project <key>] [--pr <id>] [--branch <name>]   (token: SONAR_TOKEN)
          sdd phase start|end <name>
          sdd tokens --phase <name> --input <n> --output <n> [--actual]
          sdd metrics
          sdd pr [--sonar]                        writes pr-description.md (never commits or pushes)
          sdd status [--json]
          sdd install --role auto|dab|cdms|ui [--repo <path>] [--update-agents] [--force]   install/upgrade the Copilot agent files
                                                  --update-agents replaces agents, prompts, workflow and templates even if edited
                                                  --force replaces every file (also your instructions, skills, constitution)
          sdd review-seal                         bind completed READY FOR PR review to current source
          sdd finish                              final verification, PR text, then Windows commit dialog
          sdd commit-dialog                       final explicit local commit selection (no push/PR/merge)
          sdd next                                status report + the single next action (agents end every phase with it)
          sdd doctor [--repo <path>]              check that the repository is ready (tool, .NET, Git, agent files, settings)

        Common options: --repo <path> (default: current folder), --pbi <id> (default: active PBI)
        """;

    private readonly IProcessRunner _runner;
    private readonly IClock _clock;
    private readonly HttpClient _http;
    private readonly TextWriter _out;

    /// <summary>Creates the app.</summary>
    /// <param name="runner">Process runner.</param>
    /// <param name="clock">Clock.</param>
    /// <param name="http">Shared HTTP client for Sonar.</param>
    /// <param name="output">Output writer.</param>
    public SddApp(IProcessRunner runner, IClock clock, HttpClient http, TextWriter output)
    {
        _runner = runner;
        _clock = clock;
        _http = http;
        _out = output;
    }

    /// <summary>Runs one command.</summary>
    /// <param name="args">Arguments.</param>
    /// <returns>Exit code.</returns>
    public async Task<int> RunAsync(IReadOnlyList<string> args)
    {
        var a = CommandArgs.Parse(args);
        try
        {
            return a.Command switch
            {
                "start" => Start(a),
                "questions" => Questions(a),
                "answer" => Answer(a),
                "check" => Check(a),
                "approve" => Approve(a),
                "task" => TaskDone(a),
                "verify" => await VerifyAsync(a).ConfigureAwait(false),
                "sonar" => await SonarAsync(a).ConfigureAwait(false),
                "review-seal" => await SealReviewAsync(a).ConfigureAwait(false),
                "finish" => await FinishAsync(a).ConfigureAwait(false),
                "commit-dialog" => await CommitDialogAsync(a).ConfigureAwait(false),
                "phase" => Phase(a),
                "tokens" => Tokens(a),
                "metrics" => Metrics(a),
                "pr" => await PrAsync(a).ConfigureAwait(false),
                "status" => Status(a),
                "version" => Write(SddConstants.Version, Ok),
                "install" => Install(a),
                "doctor" => await DoctorAsync(a).ConfigureAwait(false),
                "next" => Next(a),
                _ => Write(string.Format(CultureInfo.InvariantCulture, Usage, SddConstants.Version), a.Command == "help" ? Ok : UsageError),
            };
        }
        catch (SddException ex)
        {
            await _out.WriteLineAsync($"{ex.Code}: {ex.Message}").ConfigureAwait(false);
            return ex.Code is ErrorCodes.NoActivePbi or ErrorCodes.PbiNotFound ? NotFound : GateFailed;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or System.ComponentModel.Win32Exception
            or HttpRequestException or JsonException)
        {
            await _out.WriteLineAsync("Blocked: " + ex.Message).ConfigureAwait(false);
            return GateFailed;
        }
        catch (ArgumentException ex)
        {
            await _out.WriteLineAsync("Usage error: " + ex.Message).ConfigureAwait(false);
            return UsageError;
        }
    }

    private int Start(CommandArgs a)
    {
        var role = Enum.TryParse<ProjectRole>(a.Option("role"), true, out var r) ? r : ProjectRole.Unknown;
        var result = StartService.Start(new StartOptions(Repo(a), a.Rest(), a.Option("source"), role, a.Option("feature")), _clock);
        if (a.Flag("json"))
        {
            return Write(JsonSerializer.Serialize(result, Json.Options), result.SpecPath.Length > 0 ? Ok : NotFound);
        }

        if (result.SpecPath.Length == 0)
        {
            _out.WriteLine($"{result.Status}: searched/candidates: {string.Join(", ", result.Candidates)}");
            _out.Write(StartService.RenderQuestions(result.Questions));
            return NotFound;
        }

        _out.WriteLine($"{result.Status} PBI {result.PbiId} - {result.Title}");
        _out.WriteLine($"Role: {result.Role} (skill: {Display(result.Skill)}) | Feature: {result.Feature} | {result.ElapsedMilliseconds} ms");
        _out.WriteLine($"Package: {result.PackageSummary}");
        _out.WriteLine($"spec.md: {result.SpecPath} ({(result.SpecCreated ? "created" : "existing, preserved")})");
        _out.WriteLine($"plan.md: {result.PlanPath} ({(result.PlanCreated ? "created" : "existing, preserved")})");
        _out.WriteLine($"Remaining analysis items: {result.Findings.Count}");
        if (result.Fit.Count > 0)
        {
            _out.WriteLine("Repository fit:");
            foreach (var finding in result.Fit)
            {
                _out.WriteLine($"  [{finding.Level.ToString().ToUpperInvariant()}] {finding.Text}");
            }
        }

        _out.Write(StartService.RenderQuestions(result.Questions));
        return Ok;
    }

    private int Install(CommandArgs a)
    {
        var role = ResolveInstallRole(a.Option("role"), Repo(a));

        var assets = a.Option("assets") ?? Path.Combine(AppContext.BaseDirectory, "agent");
        var result = InstallService.Install(assets, role, Repo(a), a.Flag("force"), a.Flag("update-agents"));
        _out.WriteLine($"Akzo SDD Agent v{SddConstants.Version} installed for {role}: {result.Created.Count} created, {result.Updated.Count} updated, {result.Unchanged.Count} unchanged, {result.KeptModified.Count} kept (team-modified).");
        foreach (var kept in result.KeptModified)
        {
            _out.WriteLine((InstallService.IsEngineOwned(kept) ? "  kept (agent file - rerun with --update-agents to replace): " : "  kept (team-owned, not replaced): ") + kept);
        }

        var root = RepositoryLocator.FindRoot(Repo(a));
        _out.WriteLine("Spec and plan folder: " + FileHash.Relative(root, RepositoryLocator.SpecRoot(root)) + "/<Feature>/ (feature name only, no PBI number)");
        _out.WriteLine("Next: reopen Copilot Chat, pick agent 'Akzo SDD Agent', type: Start Development <PBI-ID> <Feature>. Nothing was staged or committed.");
        return Ok;
    }

    private static ProjectRole ResolveInstallRole(string? value, string repository)
    {
        if (string.Equals(value, "auto", StringComparison.OrdinalIgnoreCase))
        {
            var detection = RoleDetector.Detect(RepositoryLocator.FindRoot(repository));
            if (detection.IsDecisive)
            {
                return detection.Role;
            }

            var evidence = detection.Evidence.Count == 0 ? "no signature found" : string.Join("; ", detection.Evidence);
            throw new SddException(ErrorCodes.Failed, $"Could not detect DAB/CDMS/UI ({evidence}). Choose the role explicitly.");
        }

        return Enum.TryParse<ProjectRole>(value, true, out var role) && role != ProjectRole.Unknown
            ? role
            : throw new ArgumentException("sdd install --role auto|dab|cdms|ui [--repo <path>]");
    }

    private async Task<int> DoctorAsync(CommandArgs a)
    {
        var checks = await DoctorService.RunAsync(Repo(a), _runner).ConfigureAwait(false);
        foreach (var check in checks)
        {
            await _out.WriteLineAsync($"[{check.Status.ToString().ToUpperInvariant()}] {check.Name}: {check.Detail}").ConfigureAwait(false);
        }

        var overall = DoctorService.Overall(checks);
        await _out.WriteLineAsync($"Overall: {overall.ToString().ToUpperInvariant()}").ConfigureAwait(false);
        return overall == CheckStatus.Fail ? GateFailed : Ok;
    }

    private int Next(CommandArgs a)
    {
        var (ws, state, package) = Load(a);
        return Write(NextStepService.Render(ws, state, package), Ok);
    }

    private int Questions(CommandArgs a)
    {
        var (ws, state, package) = Load(a);
        var stage = Enum.TryParse<QuestionStage>(a.Option("stage"), true, out var s) ? s : QuestionStage.Start;
        var questions = QuestionBuilder.Build(stage, package, state, [], FeatureNameBuilder.Candidates(package.Title, null));
        File.WriteAllText(ws.ChangeFile(state, SddConstants.QuestionsFile), StartService.RenderQuestions(questions));
        if (a.Flag("json"))
        {
            return Write(JsonSerializer.Serialize(questions, Json.Options), Ok);
        }

        var text = questions.Count == 0 ? "No pending questions." : StartService.RenderQuestions(questions);
        return Write(text, Ok);
    }

    private int Answer(CommandArgs a)
    {
        if (a.Positional.Count < 2)
        {
            throw new ArgumentException("sdd answer <Q-ID> <option>");
        }

        var (ws, state, package) = Load(a);
        var option = AnswerService.Answer(ws, state, package, a.Positional[0], a.Positional[1], a.Option("note"));
        return Write($"Recorded {a.Positional[0].ToUpperInvariant()} = {option.Key} ({option.Label}).", Ok);
    }

    private int Check(CommandArgs a)
    {
        var (ws, state, package) = Load(a);
        var report = ArtifactValidator.Validate(ws.Absolute(state.SpecPath), ws.Absolute(state.PlanPath), package);
        var blockers = QuestionBuilder.ApprovalBlockers(package, state);
        if (report.Passed && state.Phase == SddPhase.Analysis)
        {
            MetricsService.EndPhase(state, StartService.AnalysisPhase, _clock.UtcNow);
            state.Phase = SddPhase.AwaitingApproval;
            ws.Save(state);
        }

        if (a.Flag("json"))
        {
            return Write(JsonSerializer.Serialize(new { gate = "AnalysisComplete", passed = report.Passed, report.Findings, blockers }, Json.Options), report.Passed ? Ok : GateFailed);
        }

        _out.WriteLine($"AnalysisComplete: {(report.Passed ? "PASS" : "FAIL")}");
        foreach (var finding in report.Findings.Concat(blockers.Select(b => "Approval blocker: " + b)))
        {
            _out.WriteLine("- " + finding);
        }

        return report.Passed ? Ok : GateFailed;
    }

    private int Approve(CommandArgs a)
    {
        var (ws, state, package) = Load(a);
        var record = ApprovalService.Approve(ws, state, package, a.Option("statement") ?? string.Empty, a.Option("by") ?? string.Empty);
        MetricsService.EndPhase(state, null, _clock.UtcNow);
        MetricsService.StartPhase(state, "Implementation (agent)", _clock.UtcNow);
        state.Answers[QuestionBuilder.ApproveId] = QuestionBuilder.Approve;
        ws.Save(state);
        _out.WriteLine($"ImplementationApproved: PASS by {record.ApprovedBy} ({record.Hashes.Count} files hash-bound). Mode: {state.Mode}.");
        _out.WriteLine($"spec.md: {ws.Absolute(state.SpecPath)}");
        _out.WriteLine($"plan.md: {ws.Absolute(state.PlanPath)}");
        return Ok;
    }

    private int TaskDone(CommandArgs a)
    {
        if (a.Positional.Count < 1 || string.IsNullOrWhiteSpace(a.Option("evidence")))
        {
            throw new ArgumentException("sdd task <T-id> --evidence \"<command + result>\"");
        }

        var (ws, state, _) = Load(a);
        RequireApproval(ws, state);
        var id = a.Positional[0].ToUpperInvariant();
        state.Tasks.RemoveAll(t => string.Equals(t.Id, id, StringComparison.OrdinalIgnoreCase));
        state.Tasks.Add(new TaskCheckpoint { Id = id, Evidence = a.Option("evidence")!, CompletedUtc = _clock.UtcNow });
        ws.Save(state);
        var planned = ArtifactValidator.ReadTasks(File.ReadAllText(ws.Absolute(state.PlanPath))).Keys;
        var remaining = planned.Where(t => !state.Tasks.Exists(d => string.Equals(d.Id, t, StringComparison.OrdinalIgnoreCase))).ToList();
        return Write($"{id} recorded. Remaining: {(remaining.Count == 0 ? "none - run sdd verify --scope targeted, then sdd next" : string.Join(", ", remaining))}", Ok);
    }

    private async Task<int> VerifyAsync(CommandArgs a)
    {
        var (ws, state, _) = Load(a);
        var settings = SddSettings.Load(ws.Root);
        var scope = a.Option("scope") ?? "targeted";
        if (scope is not ("targeted" or "final")) throw new ArgumentException("scope must be targeted or final");
        if (settings.TimeoutMinutes <= 0 || settings.CoverageThreshold is < 0 or > 100)
            throw new ArgumentException("Invalid timeout or coverage threshold.");
        Directory.CreateDirectory(Path.Combine(ws.Root, ".sdd"));
        using var operation = new FileStream(Path.Combine(ws.Root, ".sdd", "automation.lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
        var reportPath = ws.ChangeFile(state, SddConstants.VerificationFile);
        // Invalidate previous PASS before starting any operation that can fail.
        await File.WriteAllTextAsync(reportPath, JsonSerializer.Serialize(new VerificationReport {
            Scope = scope, Gates = [new GateResult("Verification", GateStatus.NotExecuted, "Run started; completion not yet proven.")]
        }, Json.Options)).ConfigureAwait(false);
        var before = await SourceEvidence.CaptureAsync(ws.Root).ConfigureAwait(false);
        var profile = RoleProfile.For(state.Role);
        var useServer = scope == "final" && settings.RequireServerSonar;
        var runResults = Path.Combine(ws.ChangeFolder(state), "test-results", Guid.NewGuid().ToString("N"));
        ServerSonar? server = null;
        if (useServer)
        {
            server = new ServerSonar(_http, ws.Root, settings) { CoveragePath = Path.Combine(runResults, "**", "coverage.opencover.xml").Replace('\\', '/') };
            await server.BeginAsync(await new GitClient(_runner).CurrentBranchAsync(ws.Root).ConfigureAwait(false)).ConfigureAwait(false);
        }
        var options = new VerificationOptions(
            scope,
            BuildCommand(a, settings, profile, useServer),
            TestCommand(a, settings, profile, useServer),
            a.Number("min-coverage", settings.CoverageThreshold),
            !a.Flag("all-files"),
            TimeSpan.FromMinutes(settings.TimeoutMinutes),
            settings.IntegrationBranch)
        {
            LocalSonar = !useServer && settings.LocalSonar && !a.Flag("no-sonar"),
            ResultsFolder = runResults,
            AnalyzerVersion = settings.SonarAnalyzerVersion,
            ExtraRules = settings.SonarExtraRules,
        };
        var report = await new VerificationService(_runner, _clock).RunAsync(ws, state, options).ConfigureAwait(false);
        if (server is not null)
        {
            if (!Directory.EnumerateFiles(runResults, "coverage.opencover.xml", SearchOption.AllDirectories).Any())
                report.Gates.Add(new GateResult("Sonar coverage export", GateStatus.Fail, "Current run must produce coverage.opencover.xml; configure coverlet formats cobertura,opencover."));
            // Persist a non-passing placeholder before any network operation can fail.
            var gateIndex = report.Gates.Count;
            report.Gates.Add(new GateResult("Sonar server", GateStatus.NotExecuted, "Submission/processing pending."));
            await File.WriteAllTextAsync(reportPath, JsonSerializer.Serialize(report, Json.Options)).ConfigureAwait(false);
            try { report.Gates[gateIndex] = await server.EndAsync().ConfigureAwait(false); }
            catch (Exception ex) when (ex is SddException or HttpRequestException or JsonException or IOException or OperationCanceledException)
            {
                report.Gates[gateIndex] = new GateResult("Sonar server", GateStatus.Fail, ex.Message);
            }
        }
        var after = await SourceEvidence.CaptureAsync(ws.Root).ConfigureAwait(false);
        report.SourceHead = before.Head;
        report.SourceFingerprint = before.Fingerprint;
        if (before != after) report.Gates.Add(new GateResult("Source freshness", GateStatus.Fail, "Source changed during verification; rerun."));
        await File.WriteAllTextAsync(reportPath, JsonSerializer.Serialize(report, Json.Options)).ConfigureAwait(false);
        if (a.Flag("json"))
        {
            return Write(JsonSerializer.Serialize(report, Json.Options), report.Passed ? Ok : GateFailed);
        }

        await _out.WriteLineAsync($"Verification ({report.Scope}): {(report.Passed ? "PASS" : "FAIL")} in {report.DurationSeconds:0.#}s").ConfigureAwait(false);
        foreach (var gate in report.Gates)
        {
            await _out.WriteLineAsync($"- {gate.Name}: {gate.Status} - {gate.Detail}").ConfigureAwait(false);
        }

        await _out.WriteLineAsync($"Log: {ws.ChangeFile(state, SddConstants.VerificationLogFile)}").ConfigureAwait(false);
        return report.Passed ? Ok : GateFailed;
    }

    private static string TestCommand(CommandArgs a, SddSettings settings, RoleProfile profile, bool server)
    {
        var command = a.Option("test") ?? settings.TestCommand ?? profile.TestCommand;
        if (!server) return command;
        if (!command.TrimStart().StartsWith("dotnet test", StringComparison.OrdinalIgnoreCase))
            throw new SddException("Server scanner currently supports dotnet test with Coverlet collector; configure testCommand.");
        var separator = command.Contains(" -- ", StringComparison.Ordinal) ? " " : " -- ";
        return command + separator + "DataCollectionRunSettings.DataCollectors.DataCollector.Configuration.Format=cobertura,opencover";
    }

    private static string BuildCommand(CommandArgs a, SddSettings settings, RoleProfile profile, bool server)
    {
        var command = a.Option("build") ?? settings.BuildCommand ?? profile.BuildCommand;
        if (!server) return command;
        if (!LocalSonarAnalysis.Applies(command)) throw new SddException("Server scanner requires a .NET build command in this release.");
        return command.TrimStart().StartsWith("dotnet build", StringComparison.OrdinalIgnoreCase)
            ? command + " --no-incremental" : command + " -t:Rebuild";
    }

    private async Task<int> SealReviewAsync(CommandArgs a)
    {
        var (ws, state, _) = Load(a);
        await SourceEvidence.RequireCurrentAsync(ws, state, false).ConfigureAwait(false);
        var path = ws.ChangeFile(state, SddConstants.ReviewFile);
        if (!File.Exists(path) || PrDescriptionBuilder.ReadVerdict(await File.ReadAllTextAsync(path).ConfigureAwait(false)) != PrDescriptionBuilder.ReadyVerdict)
            throw new SddException("A completed READY FOR PR review is required.");
        var stamp = new ReviewStamp(await SourceEvidence.CaptureAsync(ws.Root).ConfigureAwait(false), FileHash.OfFile(path));
        await File.WriteAllTextAsync(SourceEvidence.ReviewFile(ws, state), JsonSerializer.Serialize(stamp, Json.Options)).ConfigureAwait(false);
        return Write("Review bound to current verified source. This records reviewer evidence; it does not perform a review.", Ok);
    }

    private async Task<int> CommitDialogAsync(CommandArgs a)
    {
        var (ws, state, _) = Load(a);
        RequireApproval(ws, state);
        Directory.CreateDirectory(Path.Combine(ws.Root, ".sdd"));
        using var operation = new FileStream(Path.Combine(ws.Root, ".sdd", "automation.lock"), FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
        return Write(await CommitDelivery.ShowAsync(ws, state).ConfigureAwait(false), Ok);
    }

    private async Task<int> FinishAsync(CommandArgs a)
    {
        var args = new List<string> { "verify", "--scope", "final", "--repo", Repo(a) };
        if (a.Option("pbi") is { } pbi) args.AddRange(["--pbi", pbi]);
        var verified = await VerifyAsync(CommandArgs.Parse(args)).ConfigureAwait(false);
        if (verified != Ok) return verified;
        var ready = await PrAsync(a).ConfigureAwait(false);
        return ready == Ok ? await CommitDialogAsync(a).ConfigureAwait(false) : ready;
    }

    private async Task<int> SonarAsync(CommandArgs a)
    {
        var (ws, _, _) = Load(a);
        var result = await QuerySonarAsync(a, SddSettings.Load(ws.Root)).ConfigureAwait(false);
        if (result is null)
        {
            return Write("Sonar: NOT EXECUTED - set --url and --project (or sonarUrl/sonarProjectKey in .sdd/settings.json).", GateFailed);
        }

        await _out.WriteLineAsync($"Sonar quality gate: {result.Status}").ConfigureAwait(false);
        foreach (var c in result.Conditions)
        {
            await _out.WriteLineAsync($"- {c.Metric}: {c.Actual} (threshold {c.Threshold}) {c.Status}").ConfigureAwait(false);
        }

        return result.Passed ? Ok : GateFailed;
    }

    private int Phase(CommandArgs a)
    {
        if (a.Positional.Count < 2)
        {
            throw new ArgumentException("sdd phase start|end <name>");
        }

        var (ws, state, _) = Load(a);
        var name = string.Join(' ', a.Positional.Skip(1));
        if (string.Equals(a.Positional[0], "start", StringComparison.OrdinalIgnoreCase))
        {
            MetricsService.StartPhase(state, name, _clock.UtcNow);
        }
        else if (!MetricsService.EndPhase(state, name, _clock.UtcNow))
        {
            return Write($"No running phase '{name}'.", GateFailed);
        }

        ws.Save(state);
        return Write($"Phase '{name}' {a.Positional[0].ToLowerInvariant()}ed at {_clock.UtcNow:HH:mm:ss} UTC.", Ok);
    }

    private int Tokens(CommandArgs a)
    {
        var phase = a.Option("phase") ?? throw new ArgumentException("--phase is required");
        var (ws, state, _) = Load(a);
        var entry = new TokenEntry
        {
            Phase = phase,
            Kind = a.Flag("actual") ? TokenKind.Actual : TokenKind.Estimated,
            Input = (long)a.Number("input", 0),
            Output = (long)a.Number("output", 0),
            Source = a.Option("source") ?? (a.Flag("actual") ? "Copilot usage view" : "characters / 4"),
        };
        MetricsService.AddTokens(state, entry);
        ws.Save(state);
        return Write($"Recorded {entry.Kind} tokens for '{phase}': {entry.Input} in / {entry.Output} out.", Ok);
    }

    private int Metrics(CommandArgs a)
    {
        var (ws, state, _) = Load(a);
        var text = $"# Metrics - PBI {state.PbiId} {state.Feature}\n\n{MetricsService.Render(state)}";
        File.WriteAllText(ws.ChangeFile(state, SddConstants.MetricsFile), text);
        return Write(text, Ok);
    }

    private async Task<int> PrAsync(CommandArgs a)
    {
        var (ws, state, package) = Load(a);
        await SourceEvidence.RequireCurrentAsync(ws, state, true).ConfigureAwait(false);
        var approval = ApprovalService.Load(ws, state);
        var stale = approval is null ? [] : ApprovalService.ChangedSinceApproval(ws, state, approval);
        var reviewPath = ws.ChangeFile(state, SddConstants.ReviewFile);
        var sonar = a.Flag("sonar") ? await QuerySonarAsync(a, SddSettings.Load(ws.Root)).ConfigureAwait(false) : null;
        var inputs = new PrInputs(
            state,
            package,
            await File.ReadAllTextAsync(ws.Absolute(state.SpecPath)).ConfigureAwait(false),
            await File.ReadAllTextAsync(ws.Absolute(state.PlanPath)).ConfigureAwait(false),
            approval,
            stale,
            VerificationReport.Load(ws.ChangeFile(state, SddConstants.VerificationFile)),
            sonar,
            PrDescriptionBuilder.ReadVerdict(File.Exists(reviewPath) ? await File.ReadAllTextAsync(reviewPath).ConfigureAwait(false) : null),
            await new GitClient(_runner).CurrentBranchAsync(ws.Root).ConfigureAwait(false));
        var gaps = PrDescriptionBuilder.ReadinessGaps(inputs);
        MetricsService.EndPhase(state, null, _clock.UtcNow);
        if (gaps.Count == 0)
        {
            state.Phase = SddPhase.PrReady;
        }

        ws.Save(state);
        var path = ws.ChangeFile(state, SddConstants.PrFile);
        await File.WriteAllTextAsync(path, PrDescriptionBuilder.Build(inputs)).ConfigureAwait(false);
        await _out.WriteLineAsync($"PR title: {PrDescriptionBuilder.Title(state)}").ConfigureAwait(false);
        await _out.WriteLineAsync($"PR description: {path}").ConfigureAwait(false);
        await _out.WriteLineAsync(gaps.Count == 0 ? "PRReady: PASS" : "PRReady: FAIL\n- " + string.Join("\n- ", gaps)).ConfigureAwait(false);
        return gaps.Count == 0 ? Ok : GateFailed;
    }

    private int Status(CommandArgs a)
    {
        var (ws, state, package) = Load(a);
        var validation = ArtifactValidator.Validate(ws.Absolute(state.SpecPath), ws.Absolute(state.PlanPath), package);
        var verification = VerificationReport.Load(ws.ChangeFile(state, SddConstants.VerificationFile));
        var summary = new
        {
            state.PbiId,
            state.Title,
            state.Feature,
            state.Role,
            state.Mode,
            state.Phase,
            spec = ws.Absolute(state.SpecPath),
            plan = ws.Absolute(state.PlanPath),
            analysisComplete = validation.Passed,
            approved = ApprovalService.Load(ws, state) is not null,
            tasksDone = state.Tasks.Select(t => t.Id).ToList(),
            lastVerification = DescribeVerification(verification),
            elapsed = MetricsService.TotalDuration(state).ToString(@"hh\:mm\:ss", CultureInfo.InvariantCulture),
        };
        return Write(JsonSerializer.Serialize(summary, Json.Options), Ok);
    }

    private static string DescribeVerification(VerificationReport? verification)
    {
        if (verification is null)
        {
            return "NOT EXECUTED";
        }

        var outcome = verification.Passed ? "PASS" : "FAIL";
        var coverage = verification.CoveragePercent?.ToString("0.##", CultureInfo.InvariantCulture) ?? "n/a";
        return $"{verification.Scope} {outcome} coverage {coverage}%";
    }

    private async Task<SonarGateResult?> QuerySonarAsync(CommandArgs a, SddSettings settings)
    {
        var url = a.Option("url") ?? settings.SonarUrl;
        var project = a.Option("project") ?? settings.SonarProjectKey;
        if (string.IsNullOrWhiteSpace(url) || string.IsNullOrWhiteSpace(project))
        {
            return null;
        }

        var path = new UriBuilder(url).Path.TrimEnd(SddConstants.UrlPathSeparator) + SddConstants.UrlPathSeparator;
        var baseUrl = new UriBuilder(url) { Path = path }.Uri;
        return await new SonarGateClient(_http)
            .GetGateAsync(baseUrl, project, Environment.GetEnvironmentVariable("SONAR_TOKEN"), a.Option("pr"), a.Option("branch"))
            .ConfigureAwait(false);
    }

    private static void RequireApproval(SddWorkspace ws, SddState state)
    {
        var approval = ApprovalService.Load(ws, state)
            ?? throw new SddException(ErrorCodes.GateFailed, "Implementation is not approved. Run sdd check, then sdd approve.");
        var stale = ApprovalService.ChangedSinceApproval(ws, state, approval);
        if (stale.Count > 0)
        {
            throw new SddException(ErrorCodes.ApprovalStale, "Approved files changed since approval; re-approval required: " + string.Join(", ", stale));
        }
    }

    private (SddWorkspace Workspace, SddState State, PbiPackage Package) Load(CommandArgs a)
    {
        var ws = new SddWorkspace(RepositoryLocator.FindRoot(Repo(a)), _clock);
        var state = ws.Load(a.Option("pbi"));
        ArtifactPathRepair.Repair(ws, state);
        return (ws, state, PbiPackageReader.Read(ws.Absolute(state.PackageFolder)));
    }

    private static string Repo(CommandArgs a) => a.Option("repo") ?? Directory.GetCurrentDirectory();

    private static string Display(string value) => string.IsNullOrWhiteSpace(value) ? "answer Q-ROLE" : value;

    private int Write(string text, int code)
    {
        _out.WriteLine(text);
        return code;
    }
}
