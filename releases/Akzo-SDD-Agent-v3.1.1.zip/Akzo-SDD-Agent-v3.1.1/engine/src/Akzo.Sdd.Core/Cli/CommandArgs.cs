using System.Globalization;

namespace Akzo.Sdd.Core.Cli;

/// <summary>Parsed command line: command, positional values, <c>--name value</c> options and flags.</summary>
public sealed class CommandArgs
{
    private static readonly HashSet<string> Flags = new(StringComparer.OrdinalIgnoreCase) { "json", "actual", "all-files", "sonar", "help", "force" };
    private readonly Dictionary<string, string> _options = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _flags = new(StringComparer.OrdinalIgnoreCase);
    private readonly List<string> _positional = [];

    private CommandArgs(string command)
    {
        Command = command;
    }

    /// <summary>Command name (lower case), or <c>help</c>.</summary>
    public string Command { get; }

    /// <summary>Positional arguments after the command.</summary>
    public IReadOnlyList<string> Positional => _positional;

    /// <summary>Parses arguments.</summary>
    /// <param name="args">Raw arguments.</param>
    /// <returns>Parsed arguments.</returns>
    public static CommandArgs Parse(IReadOnlyList<string> args)
    {
        ArgumentNullException.ThrowIfNull(args);
        var parsed = new CommandArgs(args.Count == 0 ? "help" : args[0].ToLowerInvariant());
        var index = 1;
        while (index < args.Count)
        {
            index += parsed.Consume(args, index);
        }

        return parsed;
    }

    private int Consume(IReadOnlyList<string> args, int index)
    {
        var token = args[index];
        if (!token.StartsWith("--", StringComparison.Ordinal))
        {
            _positional.Add(token);
            return 1;
        }

        var name = token[2..];
        var hasValue = !Flags.Contains(name) && index + 1 < args.Count && !args[index + 1].StartsWith("--", StringComparison.Ordinal);
        if (!hasValue)
        {
            _flags.Add(name);
            return 1;
        }

        _options[name] = args[index + 1];
        return 2;
    }

    /// <summary>Returns an option value or null.</summary>
    /// <param name="name">Option name without dashes.</param>
    /// <returns>Value or null.</returns>
    public string? Option(string name) => _options.TryGetValue(name, out var value) ? value : null;

    /// <summary>Returns a numeric option or the default.</summary>
    /// <param name="name">Option name.</param>
    /// <param name="fallback">Default.</param>
    /// <returns>Value.</returns>
    public double Number(string name, double fallback) =>
        double.TryParse(Option(name), NumberStyles.Float, CultureInfo.InvariantCulture, out var value) ? value : fallback;

    /// <summary>True when the flag is present.</summary>
    /// <param name="name">Flag name.</param>
    /// <returns>True when set.</returns>
    public bool Flag(string name) => _flags.Contains(name);

    /// <summary>Positional arguments joined with spaces.</summary>
    /// <returns>Joined text.</returns>
    public string Rest() => string.Join(' ', _positional);
}
