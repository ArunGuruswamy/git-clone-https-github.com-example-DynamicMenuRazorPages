using System.Text.Json;
using Akzo.Sdd.Core.Approval;
using Akzo.Sdd.Core.IO;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.State;

/// <summary>Finds spec.md and plan.md again when their folder was renamed (for example
/// <c>ComplaintPaintSystem</c> to <c>ComplaintPaintSystems</c>) and updates the state and approval keys.</summary>
public static class ArtifactPathRepair
{
    /// <summary>Repairs the spec/plan paths when the recorded files no longer exist.</summary>
    /// <param name="workspace">Workspace.</param>
    /// <param name="state">State (updated and saved when repaired).</param>
    /// <returns>A description of the repair, or null when nothing was needed.</returns>
    /// <exception cref="SddException">When no folder under the specs root declares the PBI id.</exception>
    public static string? Repair(SddWorkspace workspace, SddState state)
    {
        ArgumentNullException.ThrowIfNull(workspace);
        ArgumentNullException.ThrowIfNull(state);
        if (state.SpecPath.Length == 0 || (File.Exists(workspace.Absolute(state.SpecPath)) && File.Exists(workspace.Absolute(state.PlanPath))))
        {
            return null;
        }

        var specRoot = RepositoryLocator.SpecRoot(workspace.Root);
        var folder = RepositoryLocator.FindExistingFeature(specRoot, state.PbiId);
        var newPlan = folder is null ? null : Path.Combine(specRoot, folder, SddConstants.PlanFile);
        if (newPlan is null || !File.Exists(newPlan))
        {
            throw new SddException(
                ErrorCodes.Failed,
                $"spec.md/plan.md not found at '{state.SpecPath}', and no folder under '{FileHash.Relative(workspace.Root, specRoot)}' has a spec.md declaring 'PBI ID: {state.PbiId}' next to a plan.md. Restore the folder (git status) or run sdd start again.");
        }

        var oldSpec = state.SpecPath;
        var oldPlan = state.PlanPath;
        state.SpecPath = FileHash.Relative(workspace.Root, Path.Combine(specRoot, folder!, SddConstants.SpecFile));
        state.PlanPath = FileHash.Relative(workspace.Root, newPlan);
        RekeyApproval(workspace, state, (oldSpec, state.SpecPath), (oldPlan, state.PlanPath));
        workspace.Save(state);
        return $"spec/plan folder moved: '{oldSpec}' -> '{state.SpecPath}' (state updated)";
    }

    private static void RekeyApproval(SddWorkspace workspace, SddState state, params (string Old, string New)[] moves)
    {
        var record = ApprovalService.Load(workspace, state);
        if (record is null)
        {
            return;
        }

        foreach (var (oldKey, newKey) in moves.Where(m => record.Hashes.ContainsKey(m.Old)))
        {
            record.Hashes[newKey] = record.Hashes[oldKey];
            record.Hashes.Remove(oldKey);
        }

        File.WriteAllText(workspace.ChangeFile(state, SddConstants.ApprovalFile), JsonSerializer.Serialize(record, Json.Options));
    }
}
