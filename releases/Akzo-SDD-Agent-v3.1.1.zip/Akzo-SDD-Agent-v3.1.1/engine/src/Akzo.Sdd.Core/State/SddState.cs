using System.Text.Json;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.State;

/// <summary>SDD lifecycle phase.</summary>
public enum SddPhase
{
    /// <summary>Draft spec/plan written; analysis in progress.</summary>
    Analysis = 0,

    /// <summary>Artifacts validated; waiting for the developer's approval.</summary>
    AwaitingApproval,

    /// <summary>Approved; implementation running.</summary>
    Implement,

    /// <summary>Independent review in progress.</summary>
    Review,

    /// <summary>Final verification passed; PR text generated.</summary>
    PrReady,
}

/// <summary>Kind of token figure.</summary>
public enum TokenKind
{
    /// <summary>Estimated as characters / 4. Never presented as actual.</summary>
    Estimated = 0,

    /// <summary>Reported by the provider or IDE usage view.</summary>
    Actual,
}

/// <summary>Timing of one phase.</summary>
public sealed class PhaseTiming
{
    /// <summary>Phase name.</summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>Start time (UTC).</summary>
    public DateTimeOffset StartedUtc { get; set; }

    /// <summary>End time (UTC), null while running.</summary>
    public DateTimeOffset? EndedUtc { get; set; }

    /// <summary>Elapsed time, or null while running.</summary>
    public TimeSpan? Duration => EndedUtc - StartedUtc;
}

/// <summary>One token usage entry.</summary>
public sealed class TokenEntry
{
    /// <summary>Phase name.</summary>
    public string Phase { get; set; } = string.Empty;

    /// <summary>Estimated or actual.</summary>
    public TokenKind Kind { get; set; }

    /// <summary>Input (prompt) tokens.</summary>
    public long Input { get; set; }

    /// <summary>Output (completion) tokens.</summary>
    public long Output { get; set; }

    /// <summary>Where the figure came from.</summary>
    public string Source { get; set; } = string.Empty;
}

/// <summary>One implementation task checkpoint.</summary>
public sealed class TaskCheckpoint
{
    /// <summary>Task id, for example T1.</summary>
    public string Id { get; set; } = string.Empty;

    /// <summary>Verification evidence.</summary>
    public string Evidence { get; set; } = string.Empty;

    /// <summary>When it was recorded.</summary>
    public DateTimeOffset CompletedUtc { get; set; }
}

/// <summary>Persistent per-PBI state (<c>sdd-state.json</c>).</summary>
public sealed class SddState
{
    /// <summary>Engine version that wrote the state.</summary>
    public string EngineVersion { get; set; } = SddConstants.Version;

    /// <summary>PBI id.</summary>
    public string PbiId { get; set; } = string.Empty;

    /// <summary>PBI title.</summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>Feature folder name.</summary>
    public string Feature { get; set; } = string.Empty;

    /// <summary>Selected role.</summary>
    public ProjectRole Role { get; set; }

    /// <summary>FAST or STEP.</summary>
    public string Mode { get; set; } = "FAST";

    /// <summary>Current phase.</summary>
    public SddPhase Phase { get; set; }

    /// <summary>Package folder relative to the repository root.</summary>
    public string PackageFolder { get; set; } = string.Empty;

    /// <summary>Spec path relative to the repository root.</summary>
    public string SpecPath { get; set; } = string.Empty;

    /// <summary>Plan path relative to the repository root.</summary>
    public string PlanPath { get; set; } = string.Empty;

    /// <summary>Repository-fit warnings found by <c>sdd start</c>; they drive the Q-FIT question.</summary>
    public List<string> FitWarnings { get; set; } = [];

    /// <summary>Answers to multiple-choice questions keyed by question id.</summary>
    public Dictionary<string, string> Answers { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>Free-text notes supplied with answers (for example the answer to an open question).</summary>
    public Dictionary<string, string> AnswerNotes { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>Phase timings.</summary>
    public List<PhaseTiming> Phases { get; set; } = [];

    /// <summary>Token entries.</summary>
    public List<TokenEntry> Tokens { get; set; } = [];

    /// <summary>Completed task checkpoints.</summary>
    public List<TaskCheckpoint> Tasks { get; set; } = [];

    /// <summary>Characters of spec/plan content generated deterministically by the engine (no LLM tokens).</summary>
    public long GeneratedCharacters { get; set; }

    /// <summary>Hash of plan.md as generated; used to regenerate it safely when the role changes.</summary>
    public string GeneratedPlanHash { get; set; } = string.Empty;

    /// <summary>Creation time.</summary>
    public DateTimeOffset CreatedUtc { get; set; }

    /// <summary>Last update time.</summary>
    public DateTimeOffset UpdatedUtc { get; set; }

    /// <summary>Change folder name (<c>&lt;id&gt;-&lt;Feature&gt;</c>).</summary>
    public string ChangeFolderName => $"{PbiId}-{Feature}";

    /// <summary>Serialises the state.</summary>
    /// <returns>JSON.</returns>
    public string ToJson() => JsonSerializer.Serialize(this, Json.Options);

    /// <summary>Deserialises the state.</summary>
    /// <param name="json">JSON.</param>
    /// <returns>State.</returns>
    public static SddState FromJson(string json) =>
        JsonSerializer.Deserialize<SddState>(json, Json.Options)
        ?? throw new SddException(ErrorCodes.NoActivePbi, "State file is empty.");
}
