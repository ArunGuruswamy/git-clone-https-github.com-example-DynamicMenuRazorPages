namespace Akzo.Sdd.Core.State;

/// <summary>Clock abstraction for deterministic tests.</summary>
public interface IClock
{
    /// <summary>Current UTC time.</summary>
    DateTimeOffset UtcNow { get; }
}

/// <summary>System clock.</summary>
public sealed class SystemClock : IClock
{
    /// <inheritdoc />
    public DateTimeOffset UtcNow => DateTimeOffset.UtcNow;
}

/// <summary>Paths and state persistence for one repository.</summary>
public sealed class SddWorkspace
{
    /// <summary>Creates the workspace for a repository root.</summary>
    /// <param name="repoRoot">Repository root (absolute).</param>
    /// <param name="clock">Clock.</param>
    public SddWorkspace(string repoRoot, IClock clock)
    {
        Root = Path.GetFullPath(repoRoot);
        Clock = clock;
    }

    /// <summary>Repository root.</summary>
    public string Root { get; }

    /// <summary>Clock.</summary>
    public IClock Clock { get; }

    /// <summary>Absolute changes folder.</summary>
    public string ChangesRoot => Path.Combine(Root, SddConstants.ChangesFolder);

    /// <summary>Absolute change folder for a state.</summary>
    /// <param name="state">State.</param>
    /// <returns>Folder path.</returns>
    public string ChangeFolder(SddState state)
    {
        ArgumentNullException.ThrowIfNull(state);
        return Path.Combine(ChangesRoot, state.ChangeFolderName);
    }

    /// <summary>Absolute path of a file in the change folder.</summary>
    /// <param name="state">State.</param>
    /// <param name="fileName">File name.</param>
    /// <returns>Path.</returns>
    public string ChangeFile(SddState state, string fileName) => Path.Combine(ChangeFolder(state), fileName);

    /// <summary>Absolute path from a repository-relative path.</summary>
    /// <param name="relative">Relative path.</param>
    /// <returns>Absolute path.</returns>
    public string Absolute(string relative) => Path.GetFullPath(Path.Combine(Root, relative));

    /// <summary>Saves the state and marks it active.</summary>
    /// <param name="state">State.</param>
    public void Save(SddState state)
    {
        ArgumentNullException.ThrowIfNull(state);
        state.UpdatedUtc = Clock.UtcNow;
        Directory.CreateDirectory(ChangeFolder(state));
        File.WriteAllText(ChangeFile(state, SddConstants.StateFile), state.ToJson());
        File.WriteAllText(Path.Combine(ChangesRoot, SddConstants.ActivePointerFile), state.ChangeFolderName);
    }

    /// <summary>Loads the active state, or the state for <paramref name="pbiId"/> when given.</summary>
    /// <param name="pbiId">Optional PBI id.</param>
    /// <returns>State.</returns>
    /// <exception cref="SddException">When no state exists.</exception>
    public SddState Load(string? pbiId = null)
    {
        var folder = string.IsNullOrWhiteSpace(pbiId) ? ActiveFolderName() : FolderForPbi(pbiId);
        var path = folder is null ? null : Path.Combine(ChangesRoot, folder, SddConstants.StateFile);
        if (path is null || !File.Exists(path))
        {
            throw new SddException(ErrorCodes.NoActivePbi, "No active PBI. Run: sdd start \"Start Development <PBI-ID> <Feature>\".");
        }

        return SddState.FromJson(File.ReadAllText(path));
    }

    /// <summary>Returns the state or null when none exists.</summary>
    /// <param name="pbiId">Optional PBI id.</param>
    /// <returns>State or null.</returns>
    public SddState? TryLoad(string? pbiId = null)
    {
        try
        {
            return Load(pbiId);
        }
        catch (SddException)
        {
            return null;
        }
    }

    private string? ActiveFolderName()
    {
        var pointer = Path.Combine(ChangesRoot, SddConstants.ActivePointerFile);
        return File.Exists(pointer) ? File.ReadAllText(pointer).Trim() : null;
    }

    private string? FolderForPbi(string pbiId) =>
        Directory.Exists(ChangesRoot)
            ? Directory.EnumerateDirectories(ChangesRoot, pbiId + "-*").Select(Path.GetFileName).FirstOrDefault()
            : null;
}
