namespace Akzo.Sdd.Core.Execution;

/// <summary>Read-only Git queries. Never stages, commits, pushes or switches branches.</summary>
public sealed class GitClient
{
    private static readonly TimeSpan Timeout = TimeSpan.FromMinutes(2);
    private readonly IProcessRunner _runner;

    /// <summary>Creates the client.</summary>
    /// <param name="runner">Process runner.</param>
    public GitClient(IProcessRunner runner)
    {
        _runner = runner;
    }

    /// <summary>Files changed against the integration branch plus uncommitted and untracked files.</summary>
    /// <param name="repoRoot">Repository root.</param>
    /// <param name="baseBranch">Integration branch, for example origin/develop.</param>
    /// <returns>Distinct repository-relative paths (forward slashes).</returns>
    public async Task<IReadOnlyList<string>> ChangedFilesAsync(string repoRoot, string baseBranch)
    {
        ValidateRef(baseBranch);
        var committed = await _runner.RunAsync($"git diff --name-only {baseBranch}...HEAD", repoRoot, Timeout).ConfigureAwait(false);
        var working = await _runner.RunAsync("git status --porcelain --untracked-files=all", repoRoot, Timeout).ConfigureAwait(false);
        if (!committed.Succeeded || !working.Succeeded)
            throw new SddException(ErrorCodes.GateFailed, "Cannot establish changed files. Check the integration ref and Git status. " + committed.Output + working.Output);
        var files = new List<string>();
        if (committed.Succeeded)
        {
            files.AddRange(Lines(committed.Output));
        }

        if (working.Succeeded)
        {
            files.AddRange(working.Output.Split('\n', StringSplitOptions.RemoveEmptyEntries)
                .Select(l => l.TrimEnd('\r'))
                .Where(l => l.Length > 3)
                .Select(ParsePorcelain));
        }

        return files.Select(f => f.Replace('\\', '/')).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(f => f, StringComparer.Ordinal).ToList();
    }

    /// <summary>Lines changed against the merge base with <paramref name="baseBranch"/> (committed and uncommitted),
    /// in current-file line numbers. Untracked files map to null (the whole file is new).</summary>
    /// <param name="repoRoot">Repository root.</param>
    /// <param name="baseBranch">Integration branch, for example origin/develop.</param>
    /// <returns>Changed file to changed lines.</returns>
    public async Task<IReadOnlyDictionary<string, IReadOnlySet<int>?>> ChangedLinesAsync(string repoRoot, string baseBranch)
    {
        ValidateRef(baseBranch);
        var mergeBase = await _runner.RunAsync($"git merge-base {baseBranch} HEAD", repoRoot, Timeout).ConfigureAwait(false);
        if (!mergeBase.Succeeded || mergeBase.Output.Trim().Length == 0)
            throw new SddException(ErrorCodes.GateFailed, "Cannot establish merge base: " + mergeBase.Output);
        var from = mergeBase.Output.Trim();
        var diff = await _runner.RunAsync($"git diff -U0 --no-color --no-ext-diff {from}", repoRoot, Timeout).ConfigureAwait(false);
        var untracked = await _runner.RunAsync("git ls-files --others --exclude-standard", repoRoot, Timeout).ConfigureAwait(false);
        if (!diff.Succeeded || !untracked.Succeeded)
            throw new SddException(ErrorCodes.GateFailed, "Cannot establish changed lines: " + diff.Output + untracked.Output);
        var result = new Dictionary<string, IReadOnlySet<int>?>(StringComparer.OrdinalIgnoreCase);
        if (diff.Succeeded)
        {
            foreach (var (file, lines) in ParseUnifiedDiff(diff.Output))
            {
                result[file] = lines;
            }
        }

        if (untracked.Succeeded)
        {
            foreach (var file in Lines(untracked.Output))
            {
                result[file.Replace('\\', '/')] = null;
            }
        }

        return result;
    }

    /// <summary>Parses <c>git diff -U0</c> output into new-side line numbers per file.</summary>
    /// <param name="diff">Diff text.</param>
    /// <returns>File to added/changed lines (deleted files are skipped).</returns>
    internal static Dictionary<string, IReadOnlySet<int>> ParseUnifiedDiff(string diff)
    {
        var result = new Dictionary<string, IReadOnlySet<int>>(StringComparer.OrdinalIgnoreCase);
        HashSet<int>? current = null;
        foreach (var raw in diff.Split('\n'))
        {
            var line = raw.TrimEnd('\r');
            if (line.StartsWith("+++ ", StringComparison.Ordinal))
            {
                current = line == "+++ /dev/null" ? null : [];
                if (current is not null)
                {
                    result[line[4..].StartsWith("b/", StringComparison.Ordinal) ? line[6..] : line[4..]] = current;
                }
            }
            else if (current is not null && line.StartsWith("@@", StringComparison.Ordinal))
            {
                AddHunk(current, line);
            }
        }

        return result;
    }

    private static void AddHunk(HashSet<int> lines, string header)
    {
        var plus = header.IndexOf('+', StringComparison.Ordinal);
        var end = header.IndexOf(' ', plus);
        var range = header[(plus + 1)..end].Split(',');
        var start = int.Parse(range[0], System.Globalization.CultureInfo.InvariantCulture);
        var count = range.Length > 1 ? int.Parse(range[1], System.Globalization.CultureInfo.InvariantCulture) : 1;
        for (var i = 0; i < count; i++)
        {
            lines.Add(start + i);
        }
    }

    /// <summary>Current branch name, or empty.</summary>
    /// <param name="repoRoot">Repository root.</param>
    /// <returns>Branch name.</returns>
    public async Task<string> CurrentBranchAsync(string repoRoot)
    {
        var result = await _runner.RunAsync("git rev-parse --abbrev-ref HEAD", repoRoot, Timeout).ConfigureAwait(false);
        return result.Succeeded ? result.Output.Trim() : string.Empty;
    }

    internal static string ParsePorcelain(string line)
    {
        var path = line[3..].Trim().Trim('"');
        var arrow = path.IndexOf(" -> ", StringComparison.Ordinal);
        return arrow >= 0 ? path[(arrow + 4)..] : path;
    }

    private static void ValidateRef(string value)
    {
        if (!System.Text.RegularExpressions.Regex.IsMatch(value, @"^[A-Za-z0-9_][A-Za-z0-9_./-]*$", System.Text.RegularExpressions.RegexOptions.None, TimeSpan.FromSeconds(1)))
            throw new SddException("Integration branch contains unsupported characters.");
    }

    private static IEnumerable<string> Lines(string output) =>
        output.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(l => !l.StartsWith("fatal:", StringComparison.Ordinal) && !l.StartsWith("warning:", StringComparison.Ordinal));
}
