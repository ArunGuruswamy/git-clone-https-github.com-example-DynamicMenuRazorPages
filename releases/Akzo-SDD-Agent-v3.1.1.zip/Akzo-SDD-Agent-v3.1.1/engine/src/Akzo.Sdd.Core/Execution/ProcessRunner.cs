using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace Akzo.Sdd.Core.Execution;

/// <summary>Outcome of one shell command.</summary>
/// <param name="Command">Command text.</param>
/// <param name="ExitCode">Process exit code (-1 when it timed out).</param>
/// <param name="Output">Combined stdout and stderr.</param>
/// <param name="Duration">Wall-clock duration.</param>
/// <param name="TimedOut">True when the timeout killed the process.</param>
public sealed record ProcessResult(string Command, int ExitCode, string Output, TimeSpan Duration, bool TimedOut)
{
    /// <summary>True when the process exited 0 within the timeout.</summary>
    public bool Succeeded => ExitCode == 0 && !TimedOut;
}

/// <summary>Runs shell commands. Abstracted so gates can be tested without real builds.</summary>
public interface IProcessRunner
{
    /// <summary>Runs a command through the platform shell.</summary>
    /// <param name="command">Command line.</param>
    /// <param name="workingDirectory">Working directory.</param>
    /// <param name="timeout">Timeout.</param>
    /// <returns>Result with real captured output.</returns>
    Task<ProcessResult> RunAsync(string command, string workingDirectory, TimeSpan timeout);
}

/// <summary>Real process runner (cmd.exe on Windows, /bin/sh elsewhere).</summary>
public sealed class ProcessRunner : IProcessRunner
{
    /// <inheritdoc />
    public async Task<ProcessResult> RunAsync(string command, string workingDirectory, TimeSpan timeout)
    {
        var info = CreateStartInfo(command, workingDirectory, RuntimeInformation.IsOSPlatform(OSPlatform.Windows));

        var output = new StringBuilder();
        var gate = new object();
        using var process = new Process { StartInfo = info };
        process.OutputDataReceived += (_, e) => Append(output, gate, e.Data);
        process.ErrorDataReceived += (_, e) => Append(output, gate, e.Data);

        var watch = Stopwatch.StartNew();
        process.Start();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();

        using var cancellation = new CancellationTokenSource(timeout);
        var timedOut = false;
        try
        {
            await process.WaitForExitAsync(cancellation.Token).ConfigureAwait(false);
        }
        catch (OperationCanceledException)
        {
            timedOut = true;
            process.Kill(entireProcessTree: true);
            await process.WaitForExitAsync().ConfigureAwait(false);
        }

        watch.Stop();
        string text;
        lock (gate)
        {
            text = output.ToString();
        }

        return new ProcessResult(command, timedOut ? -1 : process.ExitCode, text, watch.Elapsed, timedOut);
    }

    /// <summary>Builds the shell start info. On Windows the command is passed to cmd.exe verbatim
    /// (<c>cmd /d /s /c "&lt;command&gt;"</c>) so quoted arguments such as <c>--collect:"XPlat Code Coverage"</c>
    /// reach the program unchanged; C-style escaping would split them (MSB1008).</summary>
    /// <param name="command">Command line exactly as configured.</param>
    /// <param name="workingDirectory">Working directory.</param>
    /// <param name="isWindows">True to use cmd.exe.</param>
    /// <returns>Start info.</returns>
    internal static ProcessStartInfo CreateStartInfo(string command, string workingDirectory, bool isWindows)
    {
        var info = new ProcessStartInfo
        {
            FileName = isWindows ? "cmd.exe" : "/bin/sh",
            WorkingDirectory = workingDirectory,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
        };
        if (isWindows)
        {
            info.Arguments = "/d /s /c \"" + command + "\"";
        }
        else
        {
            info.ArgumentList.Add("-c");
            info.ArgumentList.Add(command);
        }

        return info;
    }

    private static void Append(StringBuilder output, object gate, string? line)
    {
        if (line is null)
        {
            return;
        }

        lock (gate)
        {
            output.Append(line).Append('\n');
        }
    }
}
