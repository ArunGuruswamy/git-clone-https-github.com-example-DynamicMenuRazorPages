using System.Text.RegularExpressions;
using Akzo.Sdd.Core.IO;
using Akzo.Sdd.Core.Markdown;

namespace Akzo.Sdd.Core.Pbi;

/// <summary>Reads a PBI package folder (REFINED-PBI.md plus PBI Builder companions).</summary>
public static partial class PbiPackageReader
{
    /// <summary>Reads and parses the package in <paramref name="folder"/>.</summary>
    /// <param name="folder">Package folder.</param>
    /// <returns>The parsed package.</returns>
    /// <exception cref="SddException">When REFINED-PBI.md is missing or has no PBI id.</exception>
    public static PbiPackage Read(string folder)
    {
        var refinedPath = Path.Combine(folder, SddConstants.RefinedPbiFile);
        if (!File.Exists(refinedPath))
        {
            throw new SddException(ErrorCodes.PbiNotFound, $"{SddConstants.RefinedPbiFile} not found in {folder}.");
        }

        var refinedText = File.ReadAllText(refinedPath);
        var refined = MarkdownDocument.Parse(refinedText);
        var (id, title) = ParseTitle(refined.Title);

        return new PbiPackage
        {
            Id = id,
            Title = title,
            Folder = Path.GetFullPath(folder),
            RefinedText = refinedText,
            Status = refined.GetField("Status"),
            BusinessApproval = refined.GetField("Business approval"),
            TechnicalReview = refined.GetField("Technical feasibility review"),
            Readiness = refined.GetField("Readiness"),
            OutOfScope = refined.Find("Out of scope")?.Body ?? string.Empty,
            CitedPaths = ReadCitedPaths(refinedText, Path.Combine(folder, SddConstants.EvidenceFile)),
            AcceptanceCriteria = ReadAcceptanceCriteria(refined),
            BusinessRules = ReadBusinessRules(refined),
            Decisions = ReadDecisions(folder),
            OpenQuestions = ReadOpenQuestions(folder),
            Files = ListFiles(folder),
        };
    }

    /// <summary>Splits a title such as <c>306400 - Some title</c> into id and title.</summary>
    /// <param name="heading">Level-one heading text.</param>
    /// <returns>PBI id and title.</returns>
    /// <exception cref="SddException">When the heading has no numeric PBI id.</exception>
    public static (string Id, string Title) ParseTitle(string heading)
    {
        var match = TitleRegex().Match(heading ?? string.Empty);
        if (!match.Success)
        {
            throw new SddException(ErrorCodes.PbiNotFound, $"The first heading must be '# <PBI-ID> - <Title>' but was '{heading}'.");
        }

        return (match.Groups["id"].Value, match.Groups["title"].Value.Trim());
    }

    private static List<AcceptanceCriterion> ReadAcceptanceCriteria(MarkdownDocument refined)
    {
        var section = refined.Find("Acceptance criteria");
        if (section is null)
        {
            return [];
        }

        var rows = MarkdownTable.Parse(section.Body);
        if (rows.Count > 0)
        {
            return rows
                .Where(r => r.Get("ID").Length > 0)
                .Select(r => new AcceptanceCriterion(r.Get("ID"), r.Get("Given"), r.Get("When"), r.Get("Then")))
                .ToList();
        }

        return BulletCriteriaRegex().Matches(section.Body)
            .Select(m => new AcceptanceCriterion(m.Groups["id"].Value, string.Empty, string.Empty, m.Groups["text"].Value.Trim()))
            .ToList();
    }

    private static List<BusinessRule> ReadBusinessRules(MarkdownDocument refined)
    {
        var section = refined.Find("Business rules");
        return section is null
            ? []
            : MarkdownTable.Parse(section.Body)
                .Where(r => r.Get("ID").Length > 0)
                .Select(r => new BusinessRule(r.Get("ID"), r.Get("Rule"), r.Get("Evidence"), r.Get("Confidence")))
                .ToList();
    }

    private static List<Decision> ReadDecisions(string folder) =>
        ReadTable(folder, SddConstants.DecisionLogFile)
            .Where(r => r.Get("ID").Length > 0)
            .Select(r => new Decision(r.Get("ID"), r.Get("Decision"), r.Get("Status"), r.Get("Evidence"), r.Get("Affected")))
            .ToList();

    private static List<OpenQuestion> ReadOpenQuestions(string folder) =>
        ReadTable(folder, SddConstants.OpenQuestionsFile)
            .Where(r => r.Get("ID").Length > 0)
            .Select(r => new OpenQuestion(r.Get("ID"), r.Get("Question"), r.Get("Impact"), r.Get("Owner"), r.Get("Status")))
            .ToList();

    private static IReadOnlyList<MarkdownTableRow> ReadTable(string folder, string fileName)
    {
        var path = Path.Combine(folder, fileName);
        return File.Exists(path) ? MarkdownTable.Parse(File.ReadAllText(path)) : [];
    }

    private static List<string> ReadCitedPaths(string refinedText, string evidencePath)
    {
        var text = refinedText + "\n" + (File.Exists(evidencePath) ? File.ReadAllText(evidencePath) : string.Empty);
        return CitedPathRegex().Matches(text)
            .Select(m => m.Groups["path"].Value.Replace('\\', '/'))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    private static List<PbiSourceFile> ListFiles(string folder) =>
        Directory.EnumerateFiles(folder, "*", SearchOption.AllDirectories)
            .Select(p => new PbiSourceFile(FileHash.Relative(folder, p), new FileInfo(p).Length, FileHash.OfFile(p)))
            .OrderBy(f => f.RelativePath, StringComparer.Ordinal)
            .ToList();

    [GeneratedRegex(@"`(?<path>[\w.\-]+(?:[/\\][\w.\-]+)+\.(?:cs|js|ts|tsx|json|graphql|gql|xml|csproj|sln|yaml|yml|html|scss|sql|md))`", RegexOptions.None, 1000)]
    private static partial Regex CitedPathRegex();

    [GeneratedRegex(@"^\s*(?<id>\d+)\s*[-–:]\s*(?<title>.+)$", RegexOptions.None, 1000)]
    private static partial Regex TitleRegex();

    [GeneratedRegex(@"^\s*[-*]?\s*\**(?<id>AC-?\d+)\**\s*[:.)\-–]\s*(?<text>.+)$", RegexOptions.Multiline, 1000)]
    private static partial Regex BulletCriteriaRegex();
}
