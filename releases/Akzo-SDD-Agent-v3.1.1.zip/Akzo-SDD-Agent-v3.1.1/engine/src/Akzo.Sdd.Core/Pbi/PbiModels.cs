namespace Akzo.Sdd.Core.Pbi;

/// <summary>One acceptance criterion in GIVEN/WHEN/THEN form.</summary>
/// <param name="Id">Identifier such as <c>AC-01</c>.</param>
/// <param name="Given">Precondition.</param>
/// <param name="When">Trigger.</param>
/// <param name="Then">Expected outcome.</param>
public sealed record AcceptanceCriterion(string Id, string Given, string When, string Then);

/// <summary>One business rule from the refined PBI.</summary>
/// <param name="Id">Identifier such as <c>BR-01</c>.</param>
/// <param name="Rule">Rule text.</param>
/// <param name="Evidence">Evidence or decision reference.</param>
/// <param name="Confidence">Confidence or unresolved issue.</param>
public sealed record BusinessRule(string Id, string Rule, string Evidence, string Confidence);

/// <summary>One PO/BA decision from the decision log.</summary>
/// <param name="Id">Identifier such as <c>D-01</c>.</param>
/// <param name="Text">Decision text.</param>
/// <param name="Status">Status, for example Approved or Proposed.</param>
/// <param name="Evidence">Evidence.</param>
/// <param name="Affected">Affected criteria.</param>
public sealed record Decision(string Id, string Text, string Status, string Evidence, string Affected)
{
    /// <summary>True when the decision status is Approved.</summary>
    public bool IsApproved => Status.StartsWith("Approved", StringComparison.OrdinalIgnoreCase);
}

/// <summary>One open question.</summary>
/// <param name="Id">Identifier such as <c>Q-01</c>.</param>
/// <param name="Question">Question text.</param>
/// <param name="Impact">Impact.</param>
/// <param name="Owner">Owner.</param>
/// <param name="Status">Status text.</param>
public sealed record OpenQuestion(string Id, string Question, string Impact, string Owner, string Status)
{
    /// <summary>True when the status says the question is resolved or closed.</summary>
    public bool IsResolved =>
        Status.StartsWith("Resolved", StringComparison.OrdinalIgnoreCase)
        || Status.StartsWith("Closed", StringComparison.OrdinalIgnoreCase)
        || Status.StartsWith("Answered", StringComparison.OrdinalIgnoreCase);

    /// <summary>True when the package marks this unresolved question as blocking.</summary>
    public bool IsBlocking => !IsResolved && Status.Contains("blocking", StringComparison.OrdinalIgnoreCase);
}

/// <summary>One file in the PBI package.</summary>
/// <param name="RelativePath">Path relative to the package folder, forward slashes.</param>
/// <param name="Size">Size in bytes.</param>
/// <param name="Sha256">Lower-case SHA-256 hash.</param>
public sealed record PbiSourceFile(string RelativePath, long Size, string Sha256);

/// <summary>A parsed PBI package.</summary>
public sealed class PbiPackage
{
    /// <summary>PBI number.</summary>
    public required string Id { get; init; }

    /// <summary>Full PBI title.</summary>
    public required string Title { get; init; }

    /// <summary>Package folder (absolute).</summary>
    public required string Folder { get; init; }

    /// <summary>Raw refined PBI text, unchanged.</summary>
    public required string RefinedText { get; init; }

    /// <summary>Readiness status from the <c>Status:</c> line.</summary>
    public string Status { get; init; } = string.Empty;

    /// <summary>Business approval value from the review status section.</summary>
    public string BusinessApproval { get; init; } = string.Empty;

    /// <summary>Technical feasibility review value.</summary>
    public string TechnicalReview { get; init; } = string.Empty;

    /// <summary>Acceptance criteria in document order.</summary>
    public IReadOnlyList<AcceptanceCriterion> AcceptanceCriteria { get; init; } = [];

    /// <summary>Business rules in document order.</summary>
    public IReadOnlyList<BusinessRule> BusinessRules { get; init; } = [];

    /// <summary>Decision log entries.</summary>
    public IReadOnlyList<Decision> Decisions { get; init; } = [];

    /// <summary>Open questions.</summary>
    public IReadOnlyList<OpenQuestion> OpenQuestions { get; init; } = [];

    /// <summary>Every file in the package with its hash.</summary>
    public IReadOnlyList<PbiSourceFile> Files { get; init; } = [];

    /// <summary>Readiness from the review status (for example <c>Ready</c> or <c>Blocked</c>).</summary>
    public string Readiness { get; init; } = string.Empty;

    /// <summary>Body of the <c>Out of scope</c> section.</summary>
    public string OutOfScope { get; init; } = string.Empty;

    /// <summary>Source-file paths cited by REFINED-PBI.md and EVIDENCE.md.</summary>
    public IReadOnlyList<string> CitedPaths { get; init; } = [];

    /// <summary>True when the package status or readiness says Blocked.</summary>
    public bool IsBlocked =>
        Status.StartsWith("Blocked", StringComparison.OrdinalIgnoreCase)
        || Readiness.StartsWith("Blocked", StringComparison.OrdinalIgnoreCase);

    /// <summary>True when the PBI is business-approved.</summary>
    public bool IsBusinessApproved => BusinessApproval.StartsWith("Approved", StringComparison.OrdinalIgnoreCase);
}
