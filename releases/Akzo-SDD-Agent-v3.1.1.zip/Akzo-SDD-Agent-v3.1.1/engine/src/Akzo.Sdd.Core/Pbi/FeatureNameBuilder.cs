using System.Globalization;
using System.Text.RegularExpressions;

namespace Akzo.Sdd.Core.Pbi;

/// <summary>Builds the short PascalCase feature folder name (no PBI number) from a title.</summary>
public static partial class FeatureNameBuilder
{
    private const int MaxWords = 4;
    private const string Fallback = "Feature";

    private static readonly HashSet<string> StopWords = new(StringComparer.OrdinalIgnoreCase)
    {
        "a", "an", "the", "of", "for", "to", "and", "in", "on", "with", "creation", "part",
    };

    /// <summary>Builds the recommended name.</summary>
    /// <param name="title">PBI title or free-text feature hint.</param>
    /// <returns>PascalCase name, for example <c>ComplaintPaintSystem</c>.</returns>
    public static string Build(string? title)
    {
        var words = Words(title).Where(w => !StopWords.Contains(w)).Take(MaxWords).ToList();
        return words.Count == 0 ? Fallback : string.Concat(words.Select(Capitalise));
    }

    /// <summary>Builds distinct candidate names: the recommended one first, then the full-title variant.</summary>
    /// <param name="title">PBI title.</param>
    /// <param name="hint">Optional free-text name supplied by the developer.</param>
    /// <returns>Distinct candidates, recommended first.</returns>
    public static IReadOnlyList<string> Candidates(string? title, string? hint)
    {
        var candidates = new List<string>();
        if (!string.IsNullOrWhiteSpace(hint))
        {
            candidates.Add(Build(hint));
        }

        candidates.Add(Build(title));
        var full = Words(title).Where(w => !string.Equals(w, "part", StringComparison.OrdinalIgnoreCase)).Take(MaxWords + 1).ToList();
        if (full.Count > 0)
        {
            candidates.Add(string.Concat(full.Select(Capitalise)));
        }

        return candidates.Distinct(StringComparer.Ordinal).ToList();
    }

    private static IEnumerable<string> Words(string? title)
    {
        var cleaned = TagRegex().Replace(title ?? string.Empty, " ");
        cleaned = ParenRegex().Replace(cleaned, " ");
        return SplitRegex().Split(cleaned).Where(w => w.Length > 0 && !w.All(char.IsDigit));
    }

    private static string Capitalise(string word) =>
        char.ToUpper(word[0], CultureInfo.InvariantCulture) + word[1..];

    [GeneratedRegex(@"\[[^\]]*\]", RegexOptions.None, 1000)]
    private static partial Regex TagRegex();

    [GeneratedRegex(@"\([^)]*\)", RegexOptions.None, 1000)]
    private static partial Regex ParenRegex();

    [GeneratedRegex(@"[^A-Za-z0-9]+", RegexOptions.None, 1000)]
    private static partial Regex SplitRegex();
}
