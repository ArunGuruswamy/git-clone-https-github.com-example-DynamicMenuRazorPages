namespace Akzo.Sdd.Core.Pbi;

/// <summary>Result of looking for a PBI package.</summary>
/// <param name="Folder">Package folder when exactly one was found.</param>
/// <param name="Candidates">PBI ids found when the request named none and several exist.</param>
/// <param name="Searched">Folders that were searched.</param>
public sealed record PbiLocation(string? Folder, IReadOnlyList<string> Candidates, IReadOnlyList<string> Searched)
{
    /// <summary>True when exactly one package was resolved.</summary>
    public bool Found => Folder is not null;
}

/// <summary>Finds the PBI package folder in a repository.</summary>
public static class PbiLocator
{
    /// <summary>Locates the package for <paramref name="pbiId"/>, or the only package when no id is given.</summary>
    /// <param name="repoRoot">Repository root.</param>
    /// <param name="pbiId">PBI id, may be empty.</param>
    /// <returns>The location result.</returns>
    public static PbiLocation Locate(string repoRoot, string? pbiId)
    {
        var inputRoot = Path.Combine(repoRoot, SddConstants.PbiInputFolder);
        var sourcesRoot = Path.Combine(repoRoot, SddConstants.PbiSourcesFolder);
        var searched = new List<string> { inputRoot, sourcesRoot };

        if (string.IsNullOrWhiteSpace(pbiId))
        {
            var ids = PackageIds(inputRoot);
            return ids.Count == 1
                ? new PbiLocation(Path.Combine(inputRoot, ids[0]), ids, searched)
                : new PbiLocation(null, ids, searched);
        }

        var direct = Path.Combine(inputRoot, pbiId);
        if (HasRefined(direct))
        {
            return new PbiLocation(direct, [pbiId], searched);
        }

        var legacy = Directory.Exists(sourcesRoot)
            ? Directory.EnumerateDirectories(sourcesRoot, pbiId + "-*").Where(HasRefined).ToList()
            : [];
        return legacy.Count == 1
            ? new PbiLocation(legacy[0], [pbiId], searched)
            : new PbiLocation(null, legacy.Select(Path.GetFileName).OfType<string>().ToList(), searched);
    }

    private static List<string> PackageIds(string inputRoot) =>
        Directory.Exists(inputRoot)
            ? Directory.EnumerateDirectories(inputRoot)
                .Where(HasRefined)
                .Select(Path.GetFileName)
                .OfType<string>()
                .OrderBy(n => n, StringComparer.Ordinal)
                .ToList()
            : [];

    private static bool HasRefined(string folder) =>
        File.Exists(Path.Combine(folder, SddConstants.RefinedPbiFile));
}
