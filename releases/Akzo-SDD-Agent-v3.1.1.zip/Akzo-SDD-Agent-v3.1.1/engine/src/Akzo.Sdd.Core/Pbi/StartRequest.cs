using System.Text.RegularExpressions;

namespace Akzo.Sdd.Core.Pbi;

/// <summary>A parsed <c>Start Development &lt;PBI-ID&gt; &lt;Feature&gt; (source: path)</c> request.</summary>
/// <param name="PbiId">PBI number, or empty when the request names none.</param>
/// <param name="FeatureHint">Free-text feature name, may be empty.</param>
/// <param name="Source">Optional package path to import.</param>
public sealed partial record StartRequest(string PbiId, string FeatureHint, string? Source)
{
    /// <summary>Parses the developer's request text.</summary>
    /// <param name="text">Request text.</param>
    /// <returns>The parsed request.</returns>
    public static StartRequest Parse(string? text)
    {
        var value = (text ?? string.Empty).Trim();
        string? source = null;
        var sourceMatch = SourceRegex().Match(value);
        if (sourceMatch.Success)
        {
            source = sourceMatch.Groups["src"].Value.Trim().Trim('"');
            value = value.Remove(sourceMatch.Index, sourceMatch.Length).Trim();
        }

        value = PrefixRegex().Replace(value, string.Empty).Trim();
        var idMatch = IdRegex().Match(value);
        if (!idMatch.Success)
        {
            return new StartRequest(string.Empty, value, source);
        }

        return new StartRequest(idMatch.Groups["id"].Value, idMatch.Groups["rest"].Value.Trim(), source);
    }

    [GeneratedRegex(@"\(\s*source:\s*(?<src>[^)]+)\)", RegexOptions.IgnoreCase, 1000)]
    private static partial Regex SourceRegex();

    [GeneratedRegex(@"^(?:start\s+development|start)\s*", RegexOptions.IgnoreCase, 1000)]
    private static partial Regex PrefixRegex();

    [GeneratedRegex(@"^(?:PBI\s*#?\s*)?(?<id>\d{3,})\b\s*(?<rest>.*)$", RegexOptions.IgnoreCase, 1000)]
    private static partial Regex IdRegex();
}
