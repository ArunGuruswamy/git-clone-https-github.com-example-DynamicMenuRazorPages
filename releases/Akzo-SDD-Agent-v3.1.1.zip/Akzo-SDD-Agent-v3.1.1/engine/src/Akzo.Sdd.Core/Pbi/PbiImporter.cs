using System.IO.Compression;
using Akzo.Sdd.Core.Markdown;

namespace Akzo.Sdd.Core.Pbi;

/// <summary>Outcome of importing a PBI package.</summary>
/// <param name="PbiId">PBI id read from REFINED-PBI.md.</param>
/// <param name="Folder">Destination package folder.</param>
/// <param name="Copied">Files copied.</param>
/// <param name="Skipped">Files that already existed and were left unchanged.</param>
public sealed record ImportResult(string PbiId, string Folder, IReadOnlyList<string> Copied, IReadOnlyList<string> Skipped);

/// <summary>Imports a PBI package (zip, folder or loose files) into <c>docs/sdd/pbi-input/&lt;id&gt;/</c>. Never overwrites.</summary>
public static class PbiImporter
{
    /// <summary>Imports the package.</summary>
    /// <param name="source">Zip file, folder, or a REFINED-PBI.md file whose folder is the package.</param>
    /// <param name="repoRoot">Repository root.</param>
    /// <returns>The import result.</returns>
    /// <exception cref="SddException">When the source has no REFINED-PBI.md.</exception>
    public static ImportResult Import(string source, string repoRoot)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(source);
        string? tempFolder = null;
        try
        {
            var packageFolder = ResolvePackageFolder(source, out tempFolder);
            var refined = MarkdownDocument.Parse(File.ReadAllText(Path.Combine(packageFolder, SddConstants.RefinedPbiFile)));
            var (id, _) = PbiPackageReader.ParseTitle(refined.Title);
            var destination = Path.Combine(repoRoot, SddConstants.PbiInputFolder, id);
            var copied = new List<string>();
            var skipped = new List<string>();

            foreach (var file in Directory.EnumerateFiles(packageFolder, "*", SearchOption.AllDirectories))
            {
                var relative = Path.GetRelativePath(packageFolder, file);
                var target = Path.Combine(destination, relative);
                if (File.Exists(target))
                {
                    skipped.Add(relative.Replace('\\', '/'));
                    continue;
                }

                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                File.Copy(file, target);
                copied.Add(relative.Replace('\\', '/'));
            }

            return new ImportResult(id, destination, copied, skipped);
        }
        finally
        {
            if (tempFolder is not null && Directory.Exists(tempFolder))
            {
                Directory.Delete(tempFolder, recursive: true);
            }
        }
    }

    private static string ResolvePackageFolder(string source, out string? tempFolder)
    {
        tempFolder = null;
        var root = source;
        if (File.Exists(source) && source.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
        {
            tempFolder = Path.Combine(Path.GetTempPath(), "sdd-import-" + Guid.NewGuid().ToString("N"));
            ZipFile.ExtractToDirectory(source, tempFolder);
            root = tempFolder;
        }
        else if (File.Exists(source))
        {
            root = Path.GetDirectoryName(Path.GetFullPath(source))!;
        }

        if (!Directory.Exists(root))
        {
            throw new SddException(ErrorCodes.PbiNotFound, $"Source '{source}' does not exist.");
        }

        var refined = Directory.EnumerateFiles(root, SddConstants.RefinedPbiFile, SearchOption.AllDirectories)
            .OrderBy(p => p.Length)
            .FirstOrDefault();
        return refined is null
            ? throw new SddException(ErrorCodes.PbiNotFound, $"No {SddConstants.RefinedPbiFile} found in '{source}'.")
            : Path.GetDirectoryName(refined)!;
    }
}
