using System.Text.RegularExpressions;
using Akzo.Sdd.Core.Workspace;

namespace Akzo.Sdd.Core.Pbi;

/// <summary>Severity of a repository-fit finding.</summary>
public enum FitLevel
{
    /// <summary>Information for the analysis; no decision needed.</summary>
    Info = 0,

    /// <summary>The developer must decide how to scope the PBI for this repository.</summary>
    Warn,

    /// <summary>The package itself says it is not ready (Status or Readiness Blocked).</summary>
    Blocked,
}

/// <summary>One repository-fit finding.</summary>
/// <param name="Level">Severity.</param>
/// <param name="Text">Finding text.</param>
public sealed record FitFinding(FitLevel Level, string Text);

/// <summary>Checks whether a refined PBI fits the repository it is about to be implemented in:
/// readiness, title tags, out-of-scope statements, cited evidence files and UI-only acceptance criteria.</summary>
public static partial class RepositoryFit
{
    /// <summary>Suggested layer for an AC whose outcome is form / UI behaviour.</summary>
    public const string UiLayer = "UI / form";

    /// <summary>Suggested layer for an AC whose outcome is API / backend behaviour.</summary>
    public const string ApiLayer = "API / backend";

    private const int MaxListed = 6;

    private static readonly HashSet<string> SkippedFolders = new(StringComparer.OrdinalIgnoreCase)
    {
        ".git", "bin", "obj", "node_modules", "dist", ".vs", "TestResults", "packages",
    };

    /// <summary>Analyses the package against the repository.</summary>
    /// <param name="package">PBI package.</param>
    /// <param name="repoRoot">Repository root.</param>
    /// <param name="role">Repository role.</param>
    /// <returns>Findings, warnings first.</returns>
    public static IReadOnlyList<FitFinding> Analyse(PbiPackage package, string repoRoot, ProjectRole role)
    {
        ArgumentNullException.ThrowIfNull(package);
        var findings = new List<FitFinding>();
        Readiness(package, findings);
        TitleTags(package, role, findings);
        OutOfScope(package, role, findings);
        Evidence(package, repoRoot, findings);
        Layers(package, role, findings);
        return findings.OrderByDescending(f => f.Level).ToList();
    }

    /// <summary>Suggests the layer an AC belongs to from the wording of its outcome.</summary>
    /// <param name="criterion">Acceptance criterion.</param>
    /// <returns><see cref="UiLayer"/> or <see cref="ApiLayer"/>.</returns>
    public static string SuggestLayer(AcceptanceCriterion criterion)
    {
        ArgumentNullException.ThrowIfNull(criterion);
        return UiOutcomeRegex().IsMatch(criterion.Then) ? UiLayer : ApiLayer;
    }

    private static void Readiness(PbiPackage package, List<FitFinding> findings)
    {
        if (!package.IsBlocked)
        {
            return;
        }

        var blocking = package.OpenQuestions.Where(q => q.IsBlocking).Select(q => q.Id).ToList();
        findings.Add(new FitFinding(
            FitLevel.Blocked,
            $"The PBI is BLOCKED (Status: {Show(package.Status)}; Readiness: {Show(package.Readiness)})"
            + (blocking.Count > 0 ? $"; blocking question(s): {string.Join(", ", blocking)}" : string.Empty)
            + ". Implementing it now risks rework."));
    }

    private static void TitleTags(PbiPackage package, ProjectRole role, List<FitFinding> findings)
    {
        var tagged = TagRegex().Matches(package.Title)
            .Select(m => (Tag: m.Groups["tag"].Value, Role: RoleOfTag(m.Groups["tag"].Value)))
            .Where(t => t.Role != ProjectRole.Unknown)
            .ToList();
        if (tagged.Count == 0 || role == ProjectRole.Unknown)
        {
            return;
        }

        var tags = string.Join(" ", tagged.Select(t => "[" + t.Tag + "]"));
        findings.Add(tagged.Exists(t => t.Role == role)
            ? new FitFinding(FitLevel.Info, $"Title tag {tags} matches this {Name(role)} repository.")
            : new FitFinding(FitLevel.Warn, $"Title tag {tags} targets another project, but this repository is {Name(role)}."));
    }

    private static void OutOfScope(PbiPackage package, ProjectRole role, List<FitFinding> findings)
    {
        if (role == ProjectRole.Unknown)
        {
            return;
        }

        var name = Name(role);
        var word = new Regex(@"\b" + Regex.Escape(name) + @"\b", RegexOptions.IgnoreCase, TimeSpan.FromSeconds(1));
        findings.AddRange(package.OutOfScope.Replace("\r\n", "\n", StringComparison.Ordinal).Split('\n')
            .Select(l => l.Trim().TrimStart('-', '*', ' ').TrimEnd('.'))
            .Where(l => l.Length > 0 && word.IsMatch(l))
            .Select(l => new FitFinding(FitLevel.Warn, $"Out of scope mentions {name}: \"{l}\". Confirm this repository is in scope for implementation.")));
    }

    private static void Evidence(PbiPackage package, string repoRoot, List<FitFinding> findings)
    {
        if (package.CitedPaths.Count == 0)
        {
            return;
        }

        var names = RepositoryFileNames(repoRoot);
        var found = package.CitedPaths
            .Where(p => File.Exists(Path.Combine(repoRoot, p)) || names.Contains(Path.GetFileName(p)))
            .ToList();
        var missing = package.CitedPaths.Except(found, StringComparer.OrdinalIgnoreCase).ToList();
        if (found.Count == 0)
        {
            findings.Add(new FitFinding(
                FitLevel.Warn,
                $"None of the {package.CitedPaths.Count} source files cited as evidence exist in this repository (e.g. `{missing[0]}`). "
                + "The evidence describes another codebase: trace every AC in this repository before relying on 'current behaviour'."));
        }
        else if (missing.Count > 0)
        {
            findings.Add(new FitFinding(
                FitLevel.Info,
                $"{found.Count} of {package.CitedPaths.Count} cited source files exist here; not found: {List(missing)}."));
        }
        else
        {
            findings.Add(new FitFinding(FitLevel.Info, $"All {found.Count} cited source files exist in this repository."));
        }
    }

    private static void Layers(PbiPackage package, ProjectRole role, List<FitFinding> findings)
    {
        var ui = package.AcceptanceCriteria.Where(a => SuggestLayer(a) == UiLayer).Select(a => a.Id).ToList();
        var api = package.AcceptanceCriteria.Where(a => SuggestLayer(a) == ApiLayer).Select(a => a.Id).ToList();
        if (role == ProjectRole.Ui && api.Count > 0)
        {
            findings.Add(new FitFinding(FitLevel.Info, $"{api.Count} AC(s) describe API/backend outcomes ({List(api)}); the UI calls the API that implements them."));
        }
        else if (role != ProjectRole.Ui && ui.Count > 0)
        {
            findings.Add(new FitFinding(
                FitLevel.Warn,
                $"{ui.Count} of {package.AcceptanceCriteria.Count} AC(s) describe form/UI behaviour ({List(ui)}). "
                + $"In plan.md mark each 'Applies here' as Yes, Partial (the {Name(role)} part, e.g. the API or validation) or No - <owning repository>."));
        }
    }

    private static HashSet<string> RepositoryFileNames(string root)
    {
        var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (!Directory.Exists(root))
        {
            return names;
        }

        var pending = new Stack<string>();
        pending.Push(root);
        while (pending.Count > 0)
        {
            var folder = pending.Pop();
            foreach (var file in Directory.EnumerateFiles(folder))
            {
                names.Add(Path.GetFileName(file));
            }

            foreach (var child in Directory.EnumerateDirectories(folder).Where(d => !SkippedFolders.Contains(Path.GetFileName(d))))
            {
                pending.Push(child);
            }
        }

        return names;
    }

    private static ProjectRole RoleOfTag(string tag)
    {
        var upper = tag.ToUpperInvariant();
        if (upper.Contains("DAB", StringComparison.Ordinal))
        {
            return ProjectRole.Dab;
        }

        if (upper.Contains("CDMS", StringComparison.Ordinal))
        {
            return ProjectRole.Cdms;
        }

        return upper is "UI" or "ANGULAR" || upper.StartsWith("UI ", StringComparison.Ordinal) ? ProjectRole.Ui : ProjectRole.Unknown;
    }

    private static string Name(ProjectRole role) => role.ToString().ToUpperInvariant();

    private static string Show(string value) => string.IsNullOrWhiteSpace(value) ? "not stated" : value;

    private static string List(IReadOnlyList<string> items) =>
        string.Join(", ", items.Take(MaxListed)) + (items.Count > MaxListed ? $" and {items.Count - MaxListed} more" : string.Empty);

    [GeneratedRegex(@"\[(?<tag>[^\[\]]+)\]", RegexOptions.None, 1000)]
    private static partial Regex TagRegex();

    [GeneratedRegex(@"\b(offers?|offered|displayed|display|shown|shows|populated|locked|visible|hidden|enabled|disabled|greyed|read-only)\b", RegexOptions.IgnoreCase, 1000)]
    private static partial Regex UiOutcomeRegex();
}
