namespace Akzo.Sdd.Core;

/// <summary>Names, paths and thresholds shared by every SDD component.</summary>
public static class SddConstants
{
    /// <summary>Engine and template version written into every artifact.</summary>
    public const string Version = "3.1.1";

    /// <summary>Folder that holds one sub-folder per PBI package.</summary>
    public const string PbiInputFolder = "docs/sdd/pbi-input";

    /// <summary>Legacy (v2.2-v2.4) PBI Builder hand-off folder.</summary>
    public const string PbiSourcesFolder = "docs/sdd/pbi-sources";

    /// <summary>Working folder for per-PBI state and evidence.</summary>
    public const string ChangesFolder = "docs/sdd/changes";

    /// <summary>File inside <see cref="ChangesFolder"/> naming the active change folder.</summary>
    public const string ActivePointerFile = ".active";

    /// <summary>Optional per-repository settings file.</summary>
    public const string SettingsFile = ".sdd/settings.json";

    /// <summary>Primary refined PBI file.</summary>
    public const string RefinedPbiFile = "REFINED-PBI.md";

    /// <summary>Original intake file.</summary>
    public const string RequestFile = "REQUEST.md";

    /// <summary>PO/BA decision log.</summary>
    public const string DecisionLogFile = "DECISION-LOG.md";

    /// <summary>Open questions file.</summary>
    public const string OpenQuestionsFile = "OPEN-QUESTIONS.md";

    /// <summary>Evidence file.</summary>
    public const string EvidenceFile = "EVIDENCE.md";

    /// <summary>Published specification file name.</summary>
    public const string SpecFile = "spec.md";

    /// <summary>Published plan file name.</summary>
    public const string PlanFile = "plan.md";

    /// <summary>Per-PBI state file.</summary>
    public const string StateFile = "sdd-state.json";

    /// <summary>Approval record file.</summary>
    public const string ApprovalFile = "approval.json";

    /// <summary>Latest verification record file.</summary>
    public const string VerificationFile = "verification.json";

    /// <summary>Raw verification log file.</summary>
    public const string VerificationLogFile = "verification.log";

    /// <summary>Metrics report file.</summary>
    public const string MetricsFile = "metrics.md";

    /// <summary>Pull-request description file.</summary>
    public const string PrFile = "pr-description.md";

    /// <summary>Pending multiple-choice questions, rendered for chat.</summary>
    public const string QuestionsFile = "questions.md";

    /// <summary>Independent review file written by the reviewer agent.</summary>
    public const string ReviewFile = "review.md";

    /// <summary>Marker the agent must replace with repository evidence.</summary>
    public const string FillMarker = "<!-- sdd:fill";

    /// <summary>Placeholder text the agent must replace.</summary>
    public const string ToBeDetermined = "TBD";

    /// <summary>Start marker of the verbatim PBI block.</summary>
    public const string PbiSourceBegin = "<!-- sdd:pbi-source:begin";

    /// <summary>End marker of the verbatim PBI block.</summary>
    public const string PbiSourceEnd = "<!-- sdd:pbi-source:end -->";

    /// <summary>Default minimum line coverage (percent) for new or changed code.</summary>
    public const double DefaultCoverageThreshold = 90.0;

    /// <summary>Default integration branch used for diffs.</summary>
    public const string DefaultIntegrationBranch = "origin/develop";

    /// <summary>Placeholder in test commands replaced by the results directory.</summary>
    public const string ResultsPlaceholder = "{results}";

    /// <summary>Separator between URL path segments.</summary>
    public const char UrlPathSeparator = '/';

    /// <summary>Approximate characters per token used for clearly labelled estimates.</summary>
    public const int CharactersPerToken = 4;
}
