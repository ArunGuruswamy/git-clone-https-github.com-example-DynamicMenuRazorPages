namespace Akzo.Sdd.Core.Workspace;

/// <summary>Result of role detection.</summary>
/// <param name="Role">Detected role, or <see cref="ProjectRole.Unknown"/> when ambiguous or absent.</param>
/// <param name="Candidates">Roles with matching evidence.</param>
/// <param name="Evidence">Evidence lines, one per finding.</param>
public sealed record RoleDetection(ProjectRole Role, IReadOnlyList<ProjectRole> Candidates, IReadOnlyList<string> Evidence)
{
    /// <summary>True when exactly one role matched.</summary>
    public bool IsDecisive => Role != ProjectRole.Unknown;
}

/// <summary>Detects DAB / CDMS / UI from repository signatures with a bounded scan.</summary>
public static class RoleDetector
{
    private const int MaxFiles = 6000;

    private static readonly HashSet<string> SkippedFolders = new(StringComparer.OrdinalIgnoreCase)
    {
        "bin", "obj", "node_modules", ".git", ".vs", "packages", "dist", "TestResults", ".angular", "docs",
    };

    /// <summary>Scans the repository and classifies it.</summary>
    /// <param name="repoRoot">Repository root.</param>
    /// <returns>Detection result.</returns>
    public static RoleDetection Detect(string repoRoot)
    {
        var evidence = new Dictionary<ProjectRole, string>();
        foreach (var file in EnumerateFiles(repoRoot).Take(MaxFiles))
        {
            Classify(repoRoot, file, evidence);
        }

        var candidates = evidence.Keys.OrderBy(r => r).ToList();
        var role = candidates.Count == 1 ? candidates[0] : ProjectRole.Unknown;
        return new RoleDetection(role, candidates, candidates.Select(r => $"{r}: {evidence[r]}").ToList());
    }

    private static void Classify(string root, string file, Dictionary<ProjectRole, string> evidence)
    {
        var name = Path.GetFileName(file);
        var relative = Path.GetRelativePath(root, file).Replace('\\', '/');
        if (string.Equals(name, "angular.json", StringComparison.OrdinalIgnoreCase))
        {
            evidence.TryAdd(ProjectRole.Ui, relative);
        }
        else if (name.EndsWith(".graphql", StringComparison.OrdinalIgnoreCase))
        {
            evidence.TryAdd(ProjectRole.Dab, relative);
        }
        else if (name.EndsWith(".csproj", StringComparison.OrdinalIgnoreCase))
        {
            ClassifyProject(file, relative, evidence);
        }
    }

    private static void ClassifyProject(string file, string relative, Dictionary<ProjectRole, string> evidence)
    {
        var text = File.ReadAllText(file);
        if (ContainsAny(text, "StrawberryShake", "AN.ColorAppsAzure.Formula"))
        {
            evidence.TryAdd(ProjectRole.Dab, relative);
        }

        if (ContainsAny(text, "Microsoft.Xrm", "Microsoft.CrmSdk", "<TargetFramework>net48<", "<TargetFrameworkVersion>v4.8<"))
        {
            evidence.TryAdd(ProjectRole.Cdms, relative);
        }
    }

    private static bool ContainsAny(string text, params string[] values) =>
        Array.Exists(values, v => text.Contains(v, StringComparison.OrdinalIgnoreCase));

    private static IEnumerable<string> EnumerateFiles(string root)
    {
        var pending = new Queue<string>();
        pending.Enqueue(root);
        while (pending.Count > 0)
        {
            var folder = pending.Dequeue();
            foreach (var file in Directory.EnumerateFiles(folder))
            {
                yield return file;
            }

            foreach (var child in Directory.EnumerateDirectories(folder).Where(d => !SkippedFolders.Contains(Path.GetFileName(d))))
            {
                pending.Enqueue(child);
            }
        }
    }
}
