namespace Akzo.Sdd.Core.Workspace;

/// <summary>Akzo Color Apps project type.</summary>
public enum ProjectRole
{
    /// <summary>Unknown or not yet selected.</summary>
    Unknown = 0,

    /// <summary>Formula DAB/GraphQL Azure Functions (AN.ColorAppsAzure.BL).</summary>
    Dab,

    /// <summary>ColorDMS Dataverse/XRM Azure Functions.</summary>
    Cdms,

    /// <summary>AN.ColorAppsAzure.UI Angular front end.</summary>
    Ui,
}

/// <summary>Per-role defaults: skill, build and test commands.</summary>
/// <param name="Role">Role.</param>
/// <param name="Skill">Copilot skill folder to load.</param>
/// <param name="BuildCommand">Default build command.</param>
/// <param name="TestCommand">Default test command; <c>{results}</c> is replaced with the results folder.</param>
public sealed record RoleProfile(ProjectRole Role, string Skill, string BuildCommand, string TestCommand)
{
    /// <summary>Returns the default profile for a role.</summary>
    /// <param name="role">Role.</param>
    /// <returns>The profile.</returns>
    public static RoleProfile For(ProjectRole role) => role switch
    {
        ProjectRole.Ui => new RoleProfile(
            role,
            "ui-development",
            "npx ng build",
            "npx jest --ci --coverage --coverageReporters=cobertura --coverageDirectory={results}"),
        ProjectRole.Cdms => new RoleProfile(
            role,
            "cdms-development",
            "dotnet build",
            DotnetTest),
        _ => new RoleProfile(
            ProjectRole.Dab,
            "dab-development",
            "dotnet build",
            DotnetTest),
    };

    private const string DotnetTest =
        "dotnet test --no-build --logger trx --collect:\"XPlat Code Coverage\" --results-directory \"{results}\"";
}
