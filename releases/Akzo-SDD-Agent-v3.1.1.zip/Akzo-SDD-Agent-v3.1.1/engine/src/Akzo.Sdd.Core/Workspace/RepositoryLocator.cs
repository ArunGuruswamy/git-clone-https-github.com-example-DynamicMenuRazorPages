namespace Akzo.Sdd.Core.Workspace;

/// <summary>Resolves the primary Git root and the published spec root.</summary>
public static class RepositoryLocator
{
    /// <summary>Walks up from <paramref name="start"/> to the folder containing <c>.git</c>.</summary>
    /// <param name="start">Start folder (for example the solution folder under <c>src</c>).</param>
    /// <returns>The Git root, or the full start path when no <c>.git</c> exists.</returns>
    public static string FindRoot(string start)
    {
        var full = Path.GetFullPath(start);
        for (var current = new DirectoryInfo(full); current is not null; current = current.Parent)
        {
            var git = Path.Combine(current.FullName, ".git");
            if (Directory.Exists(git) || File.Exists(git))
            {
                return current.FullName;
            }
        }

        return full;
    }

    /// <summary>Returns <c>specsFolder</c> from <c>.sdd/settings.json</c> when set; otherwise
    /// <c>src/.github/specs</c> when the repository has <c>src</c>, else <c>.github/specs</c>.</summary>
    /// <param name="repoRoot">Repository root.</param>
    /// <returns>Absolute spec root.</returns>
    public static string SpecRoot(string repoRoot)
    {
        var configured = SddSettings.Load(repoRoot).SpecsFolder;
        return string.IsNullOrWhiteSpace(configured)
            ? DefaultSpecRoot(repoRoot)
            : Path.GetFullPath(Path.Combine(repoRoot, configured.Trim().TrimStart('/', '\\')));
    }

    /// <summary>Spec root used when <c>specsFolder</c> is not configured.</summary>
    /// <param name="repoRoot">Repository root.</param>
    /// <returns>Absolute spec root.</returns>
    public static string DefaultSpecRoot(string repoRoot) =>
        Directory.Exists(Path.Combine(repoRoot, "src"))
            ? Path.Combine(repoRoot, "src", ".github", "specs")
            : Path.Combine(repoRoot, ".github", "specs");

    /// <summary>Finds an existing feature folder whose spec.md declares the PBI id.</summary>
    /// <param name="specRoot">Spec root.</param>
    /// <param name="pbiId">PBI id.</param>
    /// <returns>Feature folder name, or <c>null</c>.</returns>
    public static string? FindExistingFeature(string specRoot, string pbiId)
    {
        if (!Directory.Exists(specRoot))
        {
            return null;
        }

        var marker = "PBI ID: " + pbiId;
        return Directory.EnumerateDirectories(specRoot)
            .Where(d => File.Exists(Path.Combine(d, SddConstants.SpecFile)))
            .Where(d => File.ReadLines(Path.Combine(d, SddConstants.SpecFile)).Take(20).Any(l => l.Contains(marker, StringComparison.Ordinal)))
            .Select(Path.GetFileName)
            .FirstOrDefault();
    }
}
