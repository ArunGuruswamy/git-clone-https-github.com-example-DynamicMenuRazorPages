using System.Text.Json;

namespace Akzo.Sdd.Core.Workspace;

/// <summary>Optional per-repository settings in <c>.sdd/settings.json</c>. Every value has a default.</summary>
public sealed class SddSettings
{
    /// <summary>Role to use when detection is ambiguous.</summary>
    public string? Role { get; set; }

    /// <summary>Build command override.</summary>
    public string? BuildCommand { get; set; }

    /// <summary>Test command override; <c>{results}</c> is replaced with the results folder.</summary>
    public string? TestCommand { get; set; }

    /// <summary>Minimum line coverage percent for changed code.</summary>
    public double CoverageThreshold { get; set; } = SddConstants.DefaultCoverageThreshold;

    /// <summary>Integration branch used for diffs.</summary>
    public string IntegrationBranch { get; set; } = SddConstants.DefaultIntegrationBranch;

    /// <summary>SonarQube / SonarCloud base URL (optional).</summary>
    public string? SonarUrl { get; set; }

    /// <summary>Sonar project key (optional).</summary>
    public string? SonarProjectKey { get; set; }

    /// <summary>Repository-relative folder for spec.md and plan.md (for example <c>src/.github/specs</c>).
    /// When empty, <c>src/.github/specs</c> is used if <c>src</c> exists, else <c>.github/specs</c>.</summary>
    public string? SpecsFolder { get; set; }

    /// <summary>Run the Sonar rules locally in <c>sdd verify</c> (SonarAnalyzer.CSharp injected into the .NET build).</summary>
    public bool LocalSonar { get; set; } = true;

    /// <summary>SonarAnalyzer.CSharp version used by the local Sonar gate.</summary>
    public string SonarAnalyzerVersion { get; set; } = Verification.LocalSonarAnalysis.DefaultAnalyzerVersion;

    /// <summary>Extra Sonar rule ids to enable locally (rules your SonarCloud profile adds beyond Sonar Way and the team defaults).</summary>
    public List<string> SonarExtraRules { get; set; } = [];

    /// <summary>Require a submitted server analysis for final verification.</summary>
    public bool RequireServerSonar { get; set; } = true;

    /// <summary>Pinned scanner version, installed into .sdd/tools automatically.</summary>
    public string SonarScannerVersion { get; set; } = "10.4.1";

    /// <summary>SonarCloud organization; leave empty for SonarQube Server.</summary>
    public string? SonarOrganization { get; set; }

    /// <summary>Command timeout in minutes.</summary>
    public int TimeoutMinutes { get; set; } = 30;

    /// <summary>Loads settings, returning defaults when the file is absent.</summary>
    /// <param name="repoRoot">Repository root.</param>
    /// <returns>Settings.</returns>
    public static SddSettings Load(string repoRoot)
    {
        var path = Path.Combine(repoRoot, SddConstants.SettingsFile);
        return File.Exists(path)
            ? JsonSerializer.Deserialize<SddSettings>(File.ReadAllText(path), Json.Options) ?? new SddSettings()
            : new SddSettings();
    }

    /// <summary>Saves settings.</summary>
    /// <param name="repoRoot">Repository root.</param>
    public void Save(string repoRoot)
    {
        var path = Path.Combine(repoRoot, SddConstants.SettingsFile);
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        File.WriteAllText(path, JsonSerializer.Serialize(this, Json.Options));
    }

    /// <summary>Resolves the configured role, or <see cref="ProjectRole.Unknown"/>.</summary>
    /// <returns>The role.</returns>
    public ProjectRole ConfiguredRole() =>
        Enum.TryParse<ProjectRole>(Role, ignoreCase: true, out var role) ? role : ProjectRole.Unknown;
}

/// <summary>Shared JSON options.</summary>
public static class Json
{
    /// <summary>Indented camelCase options with string enums.</summary>
    public static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        Converters = { new System.Text.Json.Serialization.JsonStringEnumConverter() },
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    };
}
