@echo off
REM Scripted install (no prompts). For the interactive wizard, double-click Setup-AkzoSddAgent.cmd.
REM Usage: Install-AkzoSddAgent.cmd AUTO|DAB|CDMS|UI "C:\path\to\repository"
if "%~2"=="" (
  echo Usage: Install-AkzoSddAgent.cmd AUTO^|DAB^|CDMS^|UI "C:\path\to\repository"
  exit /b 2
)
call "%~dp0Setup-AkzoSddAgent.cmd" /silent %1 "%~2"
exit /b %errorlevel%
