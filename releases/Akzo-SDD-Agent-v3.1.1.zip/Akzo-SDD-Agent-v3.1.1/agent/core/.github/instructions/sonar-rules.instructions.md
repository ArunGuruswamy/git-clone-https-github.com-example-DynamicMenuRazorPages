---
applyTo: "**/*.cs"
---

# Sonar rules — shared by CDMS and DAB (same SonarCloud quality profile)

If the repository already has its own `sonar-rules.instructions.md`, that file wins. Do not install this one over it.

`sdd verify` enforces these limits: its **Sonar rules (local)** gate compiles with SonarAnalyzer.CSharp and the team rules switched on, and fails on any analyzer or compiler warning in a changed file. SonarCloud reports the same issues on the PR.

## Hard limits per method / class
| Rule | Limit | Fix |
|---|---|---|
| S3776 Cognitive complexity | ≤ 15 | Extract helpers: HTTP/IO (protected virtual), exception mapping (private), business predicate (private static) |
| S1541 Cyclomatic complexity | ≤ 10 (team standard) | Same as above; guard-clause early returns |
| S1200 Class coupling | ≤ 30 types | Split by responsibility behind a facade (precedent: `MeasurementQueryService` → `CoilMeasurementQueryService`, `PhysicalModelQueryService`, `MarketColorMeasurementQueryService`) |
| S107 Parameters | ≤ 7 | Parameter object / command |
| CS1573 / CS1572 XML docs | every parameter of a documented member has a matching `<param>` | Add or rename the tag in the same change as the parameter |
| S138 Method length | keep < 60 lines | Extract |

## Always
- Unused locals, parameters and private members: remove. Use the `out _` discard (S1481, S1172, S1144).
- No magic strings or numbers. Use `Constants` / `Constants.ErrorMessages` (S1192, S109).
- No commented-out code (S125). No TODO without a work-item id (S1135).
- Make a method `static` when it does not use instance state (S2325).
- Catch broad `Exception` only with the fatal-exception filter:
  `catch (Exception ex) when (!(ex is OutOfMemoryException || ex is StackOverflowException || ex is ThreadAbortException))`
- Never swallow: log and rethrow, or map to the response with context (S2486, S2139).
- `string.IsNullOrWhiteSpace` for input checks; `StringComparison.OrdinalIgnoreCase` for searches (S1449, S4058).
- `using` for every `IDisposable` (HttpContent, HttpResponseMessage, streams).
- One static/reused `HttpClient` or `IHttpClientFactory`. Never `new HttpClient()` per call (S4462-family / reliability).
- No `.Result` / `.Wait()` on tasks (S4462). Async all the way.
- `ConfigureAwait(false)` on every `await` in **CDMS (.NET Framework 4.8)** library code. In DAB (.NET 10 isolated) follow the file's existing convention.
- XML docs on public members of new public types.
- Respect the C# language version of the project. CDMS `net48` may be C# 7.3, so no `using var`, switch expressions or records unless `LangVersion` allows them.

## Tests (MSTest + NSubstitute)
- Every test has an assertion (S2699). No `[ExpectedException]`; use `Assert.ThrowsException(Async)<T>`.
- `Assert.AreEqual(expected, actual)` order. Never `Assert.IsTrue(x == y)`.
- No `[Ignore]` without a linked reason. Never delete a failing test.
- Mock external IO through interfaces or a `protected virtual` seam overridden in a `Test<Class>` subclass. Never put test hooks in production code.

## Suppressions
No new `// NOSONAR`, `#pragma warning disable` or `[SuppressMessage]` without written reviewer agreement in the PR. Existing ones stay untouched.

## Regression guard: PR 55783
Before delivery inspect every new dependency field: is it assigned by construction and read by real behavior? An unused field such as `_versioningService` should be removed together with genuinely unused constructor plumbing after checking callers. If needed by the approved requirement, wire it into actual logic and test that behavior. Do not add `required`, change to nullable, use `null!` or suppress a diagnostic just to silence an unused/uninitialized dependency.

Use the weakest collection contract that supports the method: `IReadOnlyCollection<T>` for enumeration/Count; `IReadOnlyList<T>` when indexed access/list behavior is required. Keep generated GraphQL element interfaces unchanged. The reviewer must check this explicitly (S3242).

Ensure nullable warnings are enabled in the actual C# project before treating absence of CS8618 as evidence. The local rule configuration requests CS8618 severity but does not silently turn on nullable analysis for legacy projects. If a relevant project disables nullable checks, report the gap and resolve the appropriate project configuration in approved scope. Never claim equivalence to a differently configured server.

Historical PR comments, especially "file no longer exists", must be reconciled with current file paths, source identity and a fresh Sonar scan. Comment status alone is not proof about current code.
