---
applyTo: "**"
---
# Akzo SDD contract (v3.0)
For "Start Development …" or an active PBI (`docs/sdd/changes/.active` exists), `.github/sdd/workflow.md` is the only workflow authority. Run the `sdd` tool for start, questions, check, approve, task, verify, pr and metrics. Ask the developer only the engine's multiple-choice questions. Make no application source edits until `sdd approve` has passed. Only `sdd finish` / `sdd commit-dialog` may stage and commit after the developer explicitly selects Commit Locally in the Windows dialog. Never directly commit, push, create/merge a PR, switch branches, delete or skip tests, or add Sonar suppressions. Build, test and coverage results are valid only from `sdd verify` output.
