# Akzo SDD automated workflow v3.1.1

This file is the workflow authority. The C# engine owns deterministic gates. Copilot owns analysis, implementation and invoking the available independent reviewer. The finish action commits locally only after an explicit Windows dialog selection. Never push, create a PR or merge.

## P1 — Intake and preflight
Run `sdd start "<developer request verbatim>" --repo . --json`. Read the resulting repository fit, constitution, role skill and Sonar instructions. Reuse the existing checkout; never create a worktree unless requested. Inspect existing changes and record files unrelated to this PBI. Never include unrelated changes in an automated commit: if they remain in the final listed files, stop before delivery and explain that they require developer handling.
Run `sdd doctor`. Check that integrationBranch exists. Discover the actual solution and test commands; do not invent paths. Preserve private feed authentication. Never print tokens.

## P2 — Questions and complete analysis
Run `sdd questions`. Infer repository facts by inspection; use recommended defaults only for reversible preferences. Business decisions and approvals cannot be invented. Present unresolved required decisions using the host's supported structured question controls where available. Do not claim a popup was displayed when the host lacks that tool.
Write all spec/plan sections; run `sdd check` until PASS. The plan must include: per-AC ownership; file/class/method evidence; dependencies and existing reuse; API and data compatibility; success/error/empty/cancellation paths; AC-to-code-to-test traceability; integration/service prerequisites; security and performance impact where relevant; concrete build/test/coverage commands; rollout and rollback if applicable. Mark N/A with reasons. Every task needs a measurable outcome. Validate business meaning as well as template structure. Neither this checklist nor coverage proves 100% correctness.

## P3 — Approval
Use `sdd questions --stage approval`. Obtain the developer's explicit approval once, preferably through supported Copilot question controls. Record their actual words and identity with `sdd approve`; never manufacture a human identity or approval. This approval authorizes continuous implementation within scope. Ask again only if approved artifacts must change, required business decisions remain, or permissions are missing.

## P4 — Continuous implementation
Implement all approved tasks and tests without pausing per task. Run `sdd verify --scope targeted`. Fix failures, then record tasks with `sdd task <id> --evidence "<actual result>"`. Never disable Sonar, reduce coverage thresholds, suppress findings, change expected checksums, delete tests or invent evidence to pass.
Fix/retest at most three rounds per unchanged failure; then report the concrete blocker and completed independent work. Source changes invalidate verification and review. Save edits to disk; if Visual Studio holds proposed edits pending, the user must accept them before terminal validation can prove them. Do not pretend this host limitation is automated.

## P5 — Independent review
Run final verification: `sdd verify --scope final`. This bootstraps the pinned scanner, submits the current build and coverage, waits for its exact analysis ID, and checks its server gate. Missing service access or credentials blocks this step.
Invoke Akzo SDD Reviewer automatically only if the host exposes a supported independent-agent invocation tool. Pass PBI identity, spec/plan paths, actual diff and verification evidence. Review the exact current source. A handoff definition alone is not a callable subagent API. If automatic independent invocation is unsupported in this Visual Studio version, report NEEDS REVIEWER and request the single reviewer switch; never substitute a self-review or a forged review file.
For changes required, invoke the implementation agent where supported, fix, reverify, and request independent re-review. Maximum three review/fix rounds, then report the blocker. Do not silently waive findings.
The reviewer writes the verdict and full findings to review.md. After READY FOR PR, the reviewer runs `sdd review-seal`. The seal binds evidence; it does not prove reviewer identity or replace review.

## P6 — Automated finish and final commit popup
After review and all required gates pass, run `sdd answer Q-PR generate` and `sdd finish`. This refreshes final verification, validates the sealed review, writes PR description text for later manual use, and launches the Windows desktop commit dialog from the terminal. No further chat confirmation is necessary before showing the dialog.
The popup lists the repository, branch, all proposed files, gate summary, and editable commit message. It has Commit Locally and Cancel. Only the explicit Commit selection authorizes staging/commit. Cancel/close stages nothing. Pre-existing staged changes block delivery to preserve them. A changed source, changed file list, stale review or failed gate blocks commit. A failed Git hook leaves files staged for inspection; never reset them automatically.
The dialog is a standalone Windows WPF window, not an embedded Visual Studio control. Windows PowerShell and desktop access are required. Respect enterprise script execution policy; never bypass it. If blocked, sign/approve the script through the organization's supported process. No GUI fallback may silently commit.

## P7 — Completion
Report the actual local commit hash and message, tests and Sonar outcome, and PR-description path. PR creation, push and merge remain manual. If cancelled, report cancellation. If blocked, distinguish passed checks, failed checks and unrun checks. Never claim 100% autonomous delivery on an unsupported host or without server/Windows validation.
