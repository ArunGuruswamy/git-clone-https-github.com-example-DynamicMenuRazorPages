# Review Learnings

Rules learned from real PR review comments. The reviewer agent checks **every** rule on every review.
Add rules with `/sdd-learn-review` (paste the reviewer's comments). Keep one rule per line of behaviour. Never delete a rule; mark it `retired` with a reason.

| ID | Applies to | Rule | Example comment (source PR) | Added |
|---|---|---|---|---|
| L-001 | All | Identifiers, routes, messages and JSON keys contain no spelling mistakes | (seed) `PaintSytem` route spelling in UI | 2026-10-07 |
| L-002 | C# | No new `// NOSONAR` / pragma suppressions without written reviewer agreement | (seed) team Sonar policy | 2026-10-07 |
| L-003 | All | Do not reformat or reorder untouched code in a PBI diff | (seed) DAB merge-safety checklist | 2026-10-07 |
| L-004 | Tests | Assert exact arguments of side effects (`Received(1).X(Arg.Is<...>(...))`), not only return values | (seed) DAB testing architecture | 2026-10-07 |
| L-005 | C# | Cyclomatic complexity <= 10 per method (S1541): extract the branch logic of a new rule into its own validator/helper instead of adding `if`s to an existing handler | SonarCloud on PR 306400: `ComplaintPaintSystemValidator` 13, `CreatePaintSystemHandler` 15 | 2026-10-16 |
| L-006 | C# | A class may depend on <= 30 types (S1200): adding a service/client/DTO to a handler near the limit means moving that work into a new collaborator class | SonarCloud on PR 306400: `CreatePaintSystemHandler` 32 types | 2026-10-16 |
| L-007 | C# | Every new or changed parameter gets its `<param>` tag (CS1573) when the member has XML docs | SonarCloud on PR 306400: `CreateLinkedColorAsync(..., bool isComplaint)` | 2026-10-16 |

| L-008 | C# | Remove unused injected fields and constructor parameters after checking all call sites; if a dependency is required, initialize and actually use it. Never silence CS0169/S1144/CS8618 using nullable fields, required, null-forgiving initializers or suppressions merely to pass analysis. | User-supplied Sonar findings on PR 55783, iteration 6: ComplaintPaintSystemCollaborator._versioningService; current source not verified | 2026-10-16 |
| L-009 | C# | Use IReadOnlyCollection<T> when a parameter needs only enumeration/Count; retain IReadOnlyList<T> if actual indexed-list behavior is needed. Preserve the GraphQL element type and contract behavior. | User-supplied S3242 on PR 55783, iteration 6: ComplaintPaintSystemValidator | 2026-10-16 |
| L-010 | Evidence | A comment on a removed/moved file or older PR iteration is historical evidence. Check the latest file/commit and fresh analysis before claiming the finding remains or is resolved; do not delete a file or close a discussion merely to clear the comment. | User-supplied Azure DevOps old-iteration notices on PR 55783 | 2026-10-16 |
