# .github/sdd (Akzo SDD Agent v3.0)
- `workflow.md`: the only workflow authority (P1 to P7)
- `constitution.md`: non-negotiable rules (evidence, contract parity, Sonar, coverage gate ≥ 90 %, approval, review)
- `review-learnings.md`: rules learned from real PR comments (append after each human review)
- `templates/review.md`: reviewer output format

Per-PBI files are written by the `sdd` engine:
- `docs/sdd/pbi-input/<id>/`: PBI package (REFINED-PBI.md, REQUEST.md, DECISION-LOG.md, OPEN-QUESTIONS.md, EVIDENCE.md, attachments)
- `src/.github/specs/<Feature>/spec.md` + `plan.md`: published, checked in with the code
- `docs/sdd/changes/<id>-<Feature>/`: sdd-state.json, questions.md, approval.json, verification.json/.log, test-results/, review.md, metrics.md, pr-description.md
