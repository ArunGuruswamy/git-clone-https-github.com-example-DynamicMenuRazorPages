---
name: sonar-quality-gate
description: Sonar-clean coding and verification for CDMS and DAB C# (and UI TypeScript). Use when writing or reviewing code, fixing Sonar issues (complexity, coupling, unused code, coverage), or before commit/PR.
---

# Sonar Quality Gate

Rules: `.github/instructions/sonar-rules.instructions.md` (C#) and the TypeScript section below.
Proven patterns with code: `docs/sdd/quality-reference/` (CDMS repo). Look up the scenario in this table:

| Scenario | Reference |
|---|---|
| Complexity > limit | `SDD-BEFORE-AFTER-PATTERNS.md` Pattern 1 · `SDD-IMPLEMENTATION-CHECKLIST.md` "Extract Helper Methods" |
| HTTP/IO not testable | Pattern 7 · protected virtual seam + `Test<Class>` subclass |
| Coverage gaps | Pattern 6 · `SDD-IMPLEMENTATION-CHECKLIST.md` "Test Implementation Checklist" |
| Unused variable | Pattern 2 · `out _` |
| Broad catch | Pattern 4 · fatal-exception filter |
| String search | Pattern 8 · `OrdinalIgnoreCase` |

## Self-review before every step is declared done
1. Count decision points in each touched method. If > 10, extract before moving on.
2. Check for new magic strings, unused symbols and missing `using` blocks.
3. CDMS: `ConfigureAwait(false)` on every await.
4. DAB: no GraphQL client call in Application; no data access in Function.
5. Tests: each new branch has a test. Assert specific values, not just `IsNotNull`.

## Verify phase commands
- All roles: `sdd verify --scope targeted` at task checkpoints, `sdd verify --scope final` before PR.
- It runs the real build and tests, rejects zero-test / failed / stale-build runs, and enforces **>= 90 % line coverage on changed production files** (Sonar "Coverage on New Code").
- Commands come from the role profile or `.sdd/settings.json` (`buildCommand`, `testCommand`, `coverageThreshold`).
- Final C# verification requires a fresh submitted server scan by default: `sdd verify --scope final` installs the pinned scanner, exports current coverage and checks the submitted task's exact analysis ID. Configure HTTPS sonarUrl, sonarProjectKey, optional sonarOrganization and secure SONAR_TOKEN.
- `sdd sonar --pr <id>` is a read-only query of existing server status, not a replacement for submitting the current source. Local analyzer results are feedback; profiles, exclusions and metrics can differ from the server.
- Preserve async coverage: do not broadly exclude CompilerGeneratedAttribute, which can hide async method bodies.

## TypeScript (UI) Sonar essentials
- No `any`. Use `unknown` and narrow it. No `as unknown as` in tests (repo rule).
- Cognitive complexity ≤ 15 per function. Move logic out of templates into `computed()`.
- No unused imports or variables. No empty functions without a comment. No nested ternaries.
- Subscriptions: prefer signals, `rxMethod`, `takeUntilDestroyed`. No leaks.
- No `console.log`.
