---
name: cdms-development
description: Implement a PBI, bug or change request in CDMS (AN.ColorAppsAzure.BL.ColorDMS, .NET Framework 4.8 Azure Functions, CQRS, XRM/Dataverse). Use for CDMS imitation requests, paint systems, measurements, technical remarks, view lists, option sets, legacy-plugin rule ports, Sonar fixes and tests in the CDMS solution.
---

Workflow authority: `.github/sdd/workflow.md`. Technical patterns below require evidence in actual project files; verify SDK, framework, dispatcher, DI and dependency versions before use. These sections do not add phases or developer pauses.

# CDMS Development

Evidence-first. Same discipline as the DAB skill. CDMS-specific mechanics below.
Anything marked **(verify)** must be confirmed from the repository on first use. Record the confirmed fact in `docs/architecture/` (run `/sdd-bootstrap-architecture` if that folder is missing).

## Step 0 — Orient
1. Read `.github/sdd/constitution.md` and `.github/sdd/workflow.md`.
2. Read `docs/sdd/quality-reference/SDD-QUICK-REFERENCE-CARD.md`. Open the deeper reference files only when needed (index: `SDD-DOCUMENTATION-INDEX.md`).
3. If `docs/architecture/ARCHITECTURE-SUMMARY.md` exists, read it. If not, offer `/sdd-bootstrap-architecture` before a large PBI. For an XS/S PBI, continue and trace the flow manually.
4. Read-only: `git fetch origin`, `git status`, `git log --oneline -15 origin/develop`.

## Solution shape (verify)
| Project | Responsibility |
|---|---|
| `*.Function` | Azure Functions HTTP endpoints, auth/roles, DI composition |
| `*.Application` | Commands / queries, handlers, validators, calculators, mappers |
| `*.Data` / `XRMService/*` | XRM / Dataverse query and command services (`IOrganizationService`), split by aggregate (`.../Queries`, `.../Commands`) |
| `*.Common` | `Constants` (incl. `Constants.ErrorMessages`), `EnvConfig`, response models (`XrmServiceResponse { Ok, Id, Error, IsDuplicate }`), errors |
| `*.Tests` | MSTest + NSubstitute; folder layout mirrors production |

Dependency direction: Function → Application → Data → Common. Never upward. No `IOrganizationService` in Function or Application.

## CDMS mechanics you must respect
- **Verify the target framework in the actual project (`net48` in the reference architecture).** Check `LangVersion` before using C# 8+ syntax. Add `ConfigureAwait(false)` to every `await` in library code. Never use `.Result` / `.Wait()`.
- **CRM connection:** services obtain the org service through `TryGetService(out var service, out var error)` / `ICrmConfigurationService` (verify). A failed connection returns a failure response. It must not throw.
- **Queries:** `QueryExpression` / `FetchXml` / LINQ on early-bound entities (`cdms_*`). Filter on `statecode`/active and on deleted flags exactly as neighbouring queries do. Never invent attribute logical names. Verify each one in the early-bound entity class or the metadata.
- **Option sets / lookups:** cached via `IMemoryCacheManager`. Use nullable-safe casts. A cache miss must not throw (past bug: nullable cast on option-set lookup).
- **Entity chain traversal:** null-check every `EntityReference` hop (past bug: `GetPhysicalModelForColorAsync`).
- **Lookup by name:** return `null`, not `""`, when not found. An empty string causes a Dataverse `FaultException` (past bug: `resolveColorIdByName`).
- **External HTTP** (e.g. Color Measurement Service): a static `HttpClient` plus a `protected virtual Post…Async` seam for tests (see `SDD-BEFORE-AFTER-PATTERNS.md` Pattern 7).
- **Duplicates:** detect with `IsErrorMessage(ex.Message, "Duplicate Record Found")` → `IsDuplicate = true` plus the user-facing confirmation message from `Constants`.
- **Legacy plugin parity:** when porting a rule from an XRM plugin, cite the plugin class/step and keep its behaviour unless the PBI says otherwise (Gap if different).
- **Coupling:** a service near 30 dependencies → split behind a facade (precedent: `MeasurementQueryService` split).

## Contract parity with DAB/UI (constitution Art. 5)
The UI reaches CDMS through DAB's `RoutingMiddleware` (`FeatureFlags_Cdms`). Known forwarded paths (DAB `Constants.cs`): `imitationrequest/createimitation`, `imitationrequest/update`, `imitationrequest/delete`, `imitationrequest/Execute_Workflow_NotFeasibleImitationRequest`. Before you change a CDMS endpoint:
1. Find the UI caller (`docs/sdd/ui/UI-API-MAP.md`, installed in every repo) and its TypeScript request/response interfaces.
2. Keep the verb, route casing, query parameters, body field names (camelCase JSON) and envelope compatible.
3. If DAB also implements the same route locally, compare behaviour and record differences as a Gap.

## Areas changed recently (inventory these first when the PBI touches them)
CreateMeasurement slice (calculators per instrument, conflict/duplicate, coil deactivation) · Master Candidate IR flow (OneFD/CometFDT) · Adaptation IR for Industrial market-colour instances · ASC OTOP coarseness validation · Standard Technical Remarks (Create / ViewList / GetAll / Delete) · `Shared/ViewList` · `ColorType` derivation and calculation-method selection (CMC/TADiF/WADE).

## Implementation pattern (verify names in the repo, then copy the nearest existing slice)
1. Constants / error messages → `Common`.
2. Request/response models → `Common`/`Application` (match the existing slice).
3. Command/Query + Handler: guard clauses first, orchestration only, ≤ 10 branches. Validator invoked inside the handler or through the pipeline, as in the nearest slice.
4. Data service method on the right split service. Add an interface method and register it in DI (verify where: `Startup`/`Program`).
5. Function endpoint: route, verb and roles consistent with siblings. Thin. No business logic.
6. Tests mirror the folder. Use `Test<Service>` subclasses for HTTP seams. Use NSubstitute for `IOrganizationService` (`Retrieve`, `RetrieveMultiple`, `Create`, `Update`, `Execute`).

## Tests (minimum)
Success · validation failure · CRM connection failure (with/without error text) · XRM fault/exception · duplicate path · null/empty input · cache miss · each request type affected · each instrument type affected (measurement PBIs).

## Verify
Build and test commands come from `sdd` (role profile) or `.sdd/settings.json` (`buildCommand`, `testCommand`). Confirm them on first run: SDK-style csproj → `dotnet`; classic → `msbuild` + `vstest.console`. Then run merge safety (`git diff origin/develop --diff-filter=D --name-only`) and Sonar self-review.

## Evidence gaps → workflow question policy
Attribute or entity not found in metadata · plugin rule unclear · route also served by DAB with different behaviour · status/workflow ownership unclear · shared validator change with unclear request-type impact.

Resolve technical gaps with authorized searches first. Persist spec/plan and continue unaffected work. Ask only when an approved source leaves a required business choice unresolved; ordinary inspection needs no extra permission.
