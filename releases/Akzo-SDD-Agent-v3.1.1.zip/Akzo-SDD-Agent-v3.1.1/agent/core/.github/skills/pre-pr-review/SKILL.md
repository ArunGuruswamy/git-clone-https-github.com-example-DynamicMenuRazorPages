---
name: pre-pr-review
description: Pre-PR code review checklist for CDMS, DAB and AN.ColorAppsAzure.UI changes, built from the project standards (constitution, Sonar rules, DAB architecture docs, CDMS quality reference, UI copilot-instructions) plus learned reviewer comments. Use after development and before raising a PR, or when asked to "review my changes", "self review", "code review" or "make it reviewer-proof".
---

# Pre-PR Review (zero-comment gate)

Every rule below cites its source. When the repository's own docs are stricter, the repository wins.
Severity: **BLOCKER** (wrong behaviour, data risk, broken build or test, contract break) · **MAJOR** (standard or Sonar violation, missing test, architecture breach) · **MINOR** (convention or readability issue a reviewer would comment on) · **NIT** (cosmetic, still fixed by default).

---

## 0. Automated evidence
Follow `.github/sdd/workflow.md`. Reuse successful current-source evidence for identical commands. Run only missing/stale checks; inspect actual project frameworks, dispatcher and test libraries before applying the reference patterns below.
| Target | Commands |
|---|---|
| All | `git status --short` · `git diff <INTEGRATION_BRANCH>...HEAD --stat` · `git diff <INTEGRATION_BRANCH>...HEAD --diff-filter=D --name-only` |
| DAB | `dotnet build AN.ColorAppsAzure.BL.sln -warnaserror` (report only *new* warnings if the baseline has warnings) · `dotnet test ... --settings coverlet.runsettings --collect:"XPlat Code Coverage"` · `dotnet format AN.ColorAppsAzure.BL.sln --verify-no-changes --include <changed files>` · `git diff <INTEGRATION_BRANCH>...HEAD --stat -- "*Generated*"` |
| CDMS | `sdd verify` (commands from `.sdd/settings.json`). `dotnet format --verify-no-changes` only if the project is SDK-style. |
| UI | `npx jest <changed specs> --coverage` · `npx ng build <project>` · `npm run lint` · `npm run format:check` · `npm run lint:styles` (if SCSS changed) |

A failing command is a **BLOCKER**. Every check is reported with its evidence.

## 1. Scope & merge safety (constitution Art. 4, 6 · DAB MERGE-SAFETY-CHECKLIST)
- [ ] Every changed file is explained by a task in plan.md "Implementation tasks". Unexplained file → MAJOR.
- [ ] No deletions vs the integration branch unless planned. No functionality removed that exists in develop.
- [ ] No whole-file copy from an old branch. No reformatting or reordering of untouched code (noise diff → MINOR).
- [ ] No unintended changes to `local.settings.json`, `launchSettings.json`, `.csproj` package versions, `package.json`/`package-lock.json`, `angular.json`, pipelines, `.editorconfig`.
- [ ] Shared high-risk files touched → regression tests exist for each affected flow or request type.
- [ ] DAB: the generated `*GraphQL.Client.cs` diff matches the `.graphql` edits exactly; `schema.graphql` changed only on purpose.
- [ ] No `Program.cs` / DI registration lost; no constant renamed or removed.

## 2. Spec conformance (constitution Art. 1, 8)
- [ ] Every AC → implemented → tested (check against the plan.md traceability table). A missing AC → BLOCKER.
- [ ] No behaviour beyond the approved spec (gold plating → MAJOR).
- [ ] Every PBI-vs-Code Gap is resolved as decided in spec.md decisions and the recorded `sdd answer` choices.
- [ ] Contract parity: route, verb, JSON field names and casing, and envelope are unchanged unless planned; the UI interfaces are updated in the same PBI (constitution Art. 5).

## 3. Architecture & patterns
**DAB** (`docs/architecture/*`, `dab-formula-development.instructions.md`)
- [ ] Function → Application → Data → Common; no data access in Function; no GraphQL client in Application.
- [ ] Function is thin: `[Function]`, `[RequiresRole]`, `[OpenApiOperation]`, `req.CreateSuccessResponse(result, SuccessMessages.X)`, no generic catch.
- [ ] Handler starts with `ArgumentNullException.ThrowIfNull`; validator runs inside the handler; `AppValidationException` for validation.
- [ ] The validation style of the area is kept (throw vs collect). Not unified.
- [ ] New data services and helper interfaces are registered in `Program.cs`. Handlers and validators are not registered twice.
- [ ] No version arithmetic in the handler; status transitions only where owned; product-derivation rules not merged; Local/Global and duplicate/cross-over checks kept distinct.
- [ ] `.graphql` uses the domain prefix (`Formula_`, `Product_`, …); no invented schema fields.

**CDMS** (`cdms-development` skill, `docs/sdd/quality-reference/*`)
- [ ] XRM access only in the Data layer, via the existing `TryGetService(out _, out var error)` pattern.
- [ ] `ConfigureAwait(false)` on every await; no `.Result`/`.Wait()`; syntax fits `LangVersion`.
- [ ] `ColumnSet` lists the needed attributes, never `new ColumnSet(true)` / `AllColumns` (performance → MAJOR).
- [ ] No XRM call inside a loop when a single `RetrieveMultiple` / `In` condition works (N+1 → MAJOR).
- [ ] Null-safe option-set and cache lookups; lookup-by-name returns `null`; `EntityReference` hops null-checked.
- [ ] External HTTP through a static client plus a `protected virtual` seam; `using` on content and response.
- [ ] A ported plugin rule cites its plugin and keeps its behaviour.

**UI** (`.github/copilot-instructions.md`, `ui-sdd.instructions.md`)
- [ ] OnPush; `input()`/`output()`; `inject()`; no `standalone: true`; no `@HostBinding/@HostListener`; no `ngClass/ngStyle`.
- [ ] Signals, `computed()`, `patchState`; no `mutate`; no method calls in templates; native control flow, `@let`.
- [ ] No `any`; tests have no `as unknown as`; typed fixtures.
- [ ] Existing components and patterns reused (generic form, view-list, dialogs, snackbar); no new visual pattern; no `::ng-deep` / `!important`.
- [ ] Permissions use the enums; user text uses translation keys; no `console.log`.
- [ ] Subscriptions cleaned up (`takeUntilDestroyed` / `rxMethod` / signals).
- [ ] New spec files fall inside the `jest.config.js` `testMatch`.

## 4. Sonar (`sonar-rules.instructions.md`, `sonar-quality-gate` skill)
- [ ] Cognitive complexity ≤ 15 and cyclomatic ≤ 10 per changed method (count the branches and show the count for the largest method).
- [ ] No unused using/import, local, parameter, private member or field; `out _` for discarded outs.
- [ ] No magic strings or numbers; messages from `Constants` / `Constants.ErrorMessages` / `SuccessMessages`.
- [ ] Broad catches have the fatal-exception filter (CDMS) or are absent (DAB functions); nothing is swallowed.
- [ ] No duplicated blocks (copy-paste of > ~10 lines → extract), no identical methods.
- [ ] No commented-out code; no TODO without a work-item id; no new suppressions.
- [ ] `static` where no instance state is used; `readonly` fields where never reassigned.
- [ ] Class coupling stays under the limit for touched services.

## 5. Naming & readability (match neighbouring code)
- [ ] File, class, method and field names follow the folder's convention (`_camelCase` private fields, `Async` suffix on async methods, `I` prefix on interfaces, PascalCase constants).
- [ ] Names say intent. No abbreviations the codebase does not use. No misspellings in identifiers, routes, messages or JSON (e.g. `PaintSytem`).
- [ ] Method length reasonable; one responsibility each; early returns over nesting.
- [ ] XML docs on new public types and members (C#); short "why" comments only where the intent is not obvious.
- [ ] Usings and imports ordered as the file does; no fully qualified names where a using exists.

## 6. Tests (DAB `TESTING-ARCHITECTURE.md`, CDMS quality reference, UI Jest skill)
- [ ] MSTest + NSubstitute (C#), Jest (UI). No second mocking library.
- [ ] Test folder mirrors production; `TestParams` (DAB) instead of magic values.
- [ ] Names follow the existing pattern in the test class (e.g. `Method_Scenario_Expected`, or `should ...` in Jest).
- [ ] Arrange-Act-Assert; one behaviour per test; specific assertions (`Assert.AreEqual(expected, actual)`); no `Assert.IsTrue(x == y)`; no `[ExpectedException]`.
- [ ] Side effects verified (`Received(1)` with exact arguments, including GraphQL filter args and XRM query conditions).
- [ ] Negative paths: validation failure, service/XRM/GraphQL failure, null/empty, cache miss, every affected request type, derived-product `true/false/null`, Local/Global.
- [ ] No `Thread.Sleep`, real HTTP, real clock or shared mutable state; no `[Ignore]`, `skip` or `.only`.
- [ ] New and changed lines are covered (state the measured coverage, or "not measured").

## 7. Error handling, logging, security
- [ ] Errors map to the existing model (DAB `ExceptionHandlingMiddleware` codes; CDMS `XrmServiceResponse`; UI store error state plus the snackbar/dialog services).
- [ ] Log messages are structured, carry context and contain no PII, tokens or full payloads.
- [ ] New endpoints carry the correct role (`[RequiresRole]` / the CDMS equivalent); UI routes and actions are guarded by the permission enums.
- [ ] Inputs validated server-side, not only in the UI. No secrets or keys in code or config.

## 8. PR hygiene
- [ ] No debug code, no `console.log`, no leftover test data, no dead files.
- [ ] Formatting clean (`dotnet format`, Prettier, Stylelint); line endings as in the repo.
- [ ] `completion.md` has the commit message (`<type>(<scope>): <summary> [<PBI-ID>]`), PR title and PR description: what, why, ACs, tests, regression flows, deliberately left alone, open questions.

## 9. Learned rules
- [ ] Every rule in `.github/sdd/review-learnings.md` is checked and reported individually (rule id → pass/fail).

---

## Output: `docs/sdd/changes/<PBI>/review.md`
Use `.github/sdd/templates/review.md`. Then show a chat summary: verdict, counts per severity, top findings.
