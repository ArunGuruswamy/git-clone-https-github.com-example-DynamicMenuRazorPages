---
name: feature-inventory
description: Find and document what the application ALREADY does for a PBI across backend (CDMS or DAB) and AN.ColorAppsAzure.UI, and mark each acceptance criterion EXISTS / PARTIAL / MISSING / CONFLICT with file evidence. Use for "what is already implemented", "compare PBI with code", "existing feature", "gap analysis".
---

# Feature Inventory: compare the PBI with the application

## Step 1 — Extract search terms from the PBI
Business nouns (Imitation Request, Paint System, Formula, Measurement, Technical Remark, Primer, Derived product…), request types (New Sample, Improved Formula, Technical, Adaption/Adaptation, Industrialization, Product Modification, Master Candidate, Complaint), field names, status names, UI labels.

## Step 2 — Locate the route from the UI side first
The UI is the single consumer, so the route is the join key.
1. Search `UI_REPO/projects/**/services/*.ts` and `shared-libs/src/lib/environment/environment.service.ts` for the endpoint.
2. Use `docs/sdd/ui/UI-API-MAP.md` as the index.
3. Record the verb, route, request interface and response interface.

## Step 3 — Who serves the route today?
- DAB: find the `[Function]` with that route in `src/AN.ColorAppsAzure.Formula/AN.ColorAppsAzure.Formula.Function/**`.
- Check `RoutingMiddleware` (exclusion list + `IsValidRequestUrl`) and `FeatureFlags_Cdms`. If the route is forwarded, CDMS serves it whenever the flag is on.
- CDMS: find the Function/route in the CDMS repo (`CdmsImitationCreate = "imitationrequest/createimitation"` etc. in DAB `Constants.cs` give the CDMS paths).
- Record **both** implementations when both exist. Behaviour must match (constitution Art. 5).

## Step 4 — Trace the backend flow
Function → Command/Query → Dispatcher/Mediator → Handler → Validator → Helper/Resolver → Service → `.graphql` / XRM query → mapper → response. Use real names. Read the existing tests: they are the rule book.

## Step 5 — Trace the UI flow (when the UI is relevant)
Route (`formulas/src/app/app.routes.ts`, `dashboard/src/app/app.routes.ts`) → component (`shared-external-libs/src/lib/components/**`) → Signal Store (`**/store/*.store.ts`) → service → HTTP. Also note form controls, validators, dialogs, enums and i18n keys.

## Step 6 — AC matrix
| Status | Meaning |
|---|---|
| EXISTS | Fully implemented and tested. Reuse as is. |
| PARTIAL | Some scenarios exist. List exactly what is missing. |
| MISSING | No implementation found after searching terms, constants, `.graphql`/XRM queries and tests |
| CONFLICT | Code does something different from the PBI. Create Gap G-n. |

"MISSING" requires a list of the searches that returned nothing. Without that list, the status is "NOT VERIFIED".

## Step 7 — Blast radius
List the shared files touched and their other callers. Use DAB `MERGE-SAFETY-CHECKLIST.md` §1, the CDMS equivalents and the UI shared libs (`shared-libs`, `shared-external-libs` are consumed by several apps).

## Output
the "Existing implementation and repository evidence" table in spec.md (EXISTS / PARTIAL / MISSING / CONFLICT per AC), plus a 5-line chat summary.
