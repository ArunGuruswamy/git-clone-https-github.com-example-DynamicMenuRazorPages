---
agent: Akzo SDD Reviewer
description: "Independent pre-PR review of the active PBI; writes review.md with verdict READY FOR PR or CHANGES REQUIRED."
---
Review the active PBI (`sdd status --json`) following your agent instructions and `.github/skills/pre-pr-review/SKILL.md`. Write `review.md` and report the verdict and severity counts.
