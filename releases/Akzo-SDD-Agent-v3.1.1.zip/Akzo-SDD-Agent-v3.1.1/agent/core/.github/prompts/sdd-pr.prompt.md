---
agent: Akzo SDD Agent
description: Generate delivery evidence and show the local commit dialog
---
Follow workflow P5–P7. Complete final verification and independent review, seal review, then run `sdd finish`. The developer selects Commit Locally or Cancel in the dialog. Never push, create a PR or merge.
