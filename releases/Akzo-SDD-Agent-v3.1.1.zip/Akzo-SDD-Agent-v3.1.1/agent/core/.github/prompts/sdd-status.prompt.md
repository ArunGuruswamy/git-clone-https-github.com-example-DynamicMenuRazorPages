---
agent: Akzo SDD Agent
description: "Show where the active PBI is: phase, gates, remaining tasks, time and tokens."
---
Run `sdd status --json` and `sdd metrics`. Summarise in five lines or fewer: phase, last gate results, remaining tasks, elapsed time, token usage. Then state the next workflow step.
