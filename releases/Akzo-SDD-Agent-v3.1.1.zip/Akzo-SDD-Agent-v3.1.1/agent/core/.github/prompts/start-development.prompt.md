---
agent: Akzo SDD Agent
description: "Start Development <PBI-ID> <Feature Name> [(source: <PBI package zip or folder>)] - run sdd start, ask the multiple-choice questions, complete spec.md + plan.md, stop at the approval gate."
argument-hint: "306400 Creation of Complaint PaintSystem"
---
Start Development ${input:request:<PBI-ID> <Feature Name>}

Follow `.github/sdd/workflow.md` P1 to P4:
1. Run `sdd start "Start Development ${input:request}" --repo . --json` and report the two artifact paths.
2. Ask every pending question in one multiple-choice batch, then record the answers with `sdd answer`.
3. Fill in only the `sdd:fill` / `TBD` parts of spec.md and plan.md with repository evidence, then run `sdd check` until PASS.
4. Show the approval summary and ask `Q-APPROVE` as multiple choice. Do not edit source before `sdd approve` passes.
