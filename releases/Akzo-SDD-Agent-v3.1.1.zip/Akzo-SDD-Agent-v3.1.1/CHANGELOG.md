# v3.1.1

Adds regression protection for the four reported PR 55783 findings: explicit CS0169, CS8618 and S1144 requests alongside S3242, tests confirming these diagnostics block changed files, and implementation/reviewer guidance for dependency cleanup, collection contracts and historical PR comments. Nullable analysis must actually be enabled in the target project for CS8618 to be produced. The live business repository was not changed or reanalyzed here.

Includes the v3.1.0 Sonar orchestration, evidence freshness and Windows local commit dialog; push, PR creation and merge stay manual.
