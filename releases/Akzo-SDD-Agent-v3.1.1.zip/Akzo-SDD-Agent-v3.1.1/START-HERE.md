# Start here — v3.1.1


1. Extract the entire ZIP, including tool/ and agent/.
2. Run Setup-AkzoSddAgent.cmd, select the repository and role. It installs the packaged .NET tool and agent assets.
3. Review team-modified files reported as kept by the installer. The installer intentionally preserves them; reconcile the new workflow/constitution changes before use. Do not force-overwrite team customizations blindly.
4. In Visual Studio, enable Copilot Agent mode with terminal and edit tools, select Akzo SDD Agent, and send `Start Development <PBI-ID> <Feature>` with your PBI package source.

Requires Git for Windows, .NET SDK 8+, compatible .NET runtime, Windows PowerShell 5.1/WPF with an interactive desktop, Copilot entitlement, and your organization's permission to execute the supplied PowerShell script. Enterprise script policy is respected; sign/approve scripts using your supported process. No execution-policy bypass is included.

## One-time Sonar configuration
Set non-secret values in .sdd/settings.json. Preserve your actual build/test settings and integration branch:

```json
{
  "role": "DAB",
  "integrationBranch": "origin/develop",
  "buildCommand": "dotnet build YourSolution.sln",
  "testCommand": "dotnet test YourSolution.sln --no-build --logger trx --collect:\"XPlat Code Coverage\" --results-directory \"{results}\"",
  "coverageThreshold": 90,
  "localSonar": true,
  "requireServerSonar": true,
  "sonarUrl": "https://your-sonar-server.example/",
  "sonarProjectKey": "your-project-key",
  "sonarOrganization": null,
  "sonarScannerVersion": "10.4.1"
}
```

Set SONAR_TOKEN securely in the process environment used by the Visual Studio terminal; never save it in settings.json or source control. For SonarCloud also set sonarOrganization and the correct regional service URL. Ensure the project exists and the token can submit analysis and read its gate. Scanner branch analysis requires a server plan/edition supporting it. Private feeds and scanner/JRE/analyzer download destinations must be reachable with TLS verification intact. The scanner handles compatible JRE provisioning where supported.

The target test projects must already reference a compatible Coverlet collector; this release does not rewrite dependency declarations in business repositories. Final verification requests both Cobertura and OpenCover formats without modifying tracked runsettings. Existing custom runsettings remain in effect. A custom test runner needs explicit integration; this release's automatic server workflow is .NET-only, not Angular/TypeScript.


See README.md for the complete workflow and limits.
