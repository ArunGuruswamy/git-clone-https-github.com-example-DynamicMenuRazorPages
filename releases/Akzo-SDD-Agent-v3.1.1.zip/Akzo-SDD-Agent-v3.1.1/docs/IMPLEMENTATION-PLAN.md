# Implementation plan and acceptance evidence — v3.1.1

## Scope
Automate deterministic C# SDD verification and the final local-commit selection from Visual Studio. Preserve explicit business/scope decisions, authentic independent review and manual PR/merge. No guarantees of perfect business correctness.

## Implemented
- Scanner bootstrap pinned to 10.4.1; HTTPS host and secure SONAR_TOKEN prerequisites; begin/build/test/end orchestration; current-run OpenCover export and exact compute-task → analysis-ID → quality-gate polling.
- Corrected inherited coverage configuration to include async method bodies.
- Final server analysis required by default. Targeted local analysis retained. No forced relaxation of warnings-as-errors or ignored restore failures; local MSBuild hook requires analyzer presence/enabled state.
- Git diff/merge-base failures block rather than silently producing empty changes; branch refs checked before existing shell queries.
- Source evidence uses HEAD plus tracked/untracked content hashes. Verification is invalidated before starting; source edits during checks fail. Review text is hashed and bound to the same source. Changed evidence blocks delivery.
- Explicit Windows commit dialog: repository, branch, file list, actual gate summary, editable message, Commit Locally / Cancel. Existing index refuses automation. Structured Git arguments prevent shell interpolation; hooks remain enabled. No pushes, PR creation or merge.
- Continuous agent workflow, complete plan checklist, bounded retries, supported independent-review invocation and clear unsupported-host blockers. Upgraded installer and packaged assets.

## Required acceptance pilot outside this Linux environment
1. On Windows with supported Visual Studio/Copilot, install the packaged tool and reconcile preserved team assets. Confirm the agent is discoverable and terminal/edit tools work.
2. Configure actual solution, integration ref and test command; confirm target projects have Coverlet collector. Supply Sonar host/project/org metadata and token securely.
3. Submit a real feature analysis; confirm server new-code definition, quality profile/parameters, exclusions and branch identity match team policy. Reject stale/failed/missing scans. Confirm scanner/JRE downloads and enterprise TLS trust work.
4. Confirm independent reviewer invocation on the installed Copilot host. Where no API exists, retain one explicit reviewer switch. A future VSIX integration requires verified supported host APIs; do not promise automatic handoffs from YAML alone.
5. Run Windows dialog: edit message; cancel and close without staging; commit successfully; verify hook failure and policy failure; reject source edits during the dialog and reject pre-existing staging. Confirm the desktop window is visible when launched by the actual Copilot terminal.
6. Use Visual Studio to push/create/merge the PR manually. Confirm automation performed none of these operations.

## Future improvements requiring separately verified platform integration
- A VSIX with native tool-window presentation and supported Copilot reviewer invocation, if the installed host exposes an API.
- Hosted CI checks attached to immutable commits, authenticated reviewer identity and enterprise audit records.
- TypeScript/Angular scanner adapter, and target-specific test runner adapters.
- Machine-readable AC assertion coverage and contract tests for cross-repository APIs; neither generated traceability rows nor coverage alone prove acceptance behavior.

## Failure and recovery
Missing credentials, unsupported branch analysis, feed access or enterprise script policies are external prerequisites. Keep verification NOT EXECUTED/FAIL and resume after the prerequisite is corrected. Do not replace expected checksums, skip tests, suppress findings, auto-approve, bypass script policy, discard changes or reset the index. Git hook/commit failure can leave staged files; report that state for manual inspection.
