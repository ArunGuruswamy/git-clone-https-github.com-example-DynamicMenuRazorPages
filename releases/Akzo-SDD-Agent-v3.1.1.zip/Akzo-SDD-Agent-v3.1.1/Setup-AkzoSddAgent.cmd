@echo off
setlocal EnableExtensions
REM ==========================================================================
REM  Akzo SDD Agent v3.1 - setup wizard (double-click to run)
REM  Interactive : Setup-AkzoSddAgent.cmd
REM  Silent      : Setup-AkzoSddAgent.cmd /silent auto|dab|cdms|ui "C:\path\to\repo"
REM  Installs the sdd .NET tool for the current user and copies the Copilot
REM  agent files into the chosen repositories. Nothing is staged, committed
REM  or pushed. No administrator rights needed.
REM ==========================================================================
title Akzo SDD Agent v3.1 - Setup
set "HERE=%~dp0"
set "LOG=%TEMP%\AkzoSddAgent-setup.log"
set "OUT=%TEMP%\AkzoSddAgent-step.out"
set "SILENT="
set "ROLE="
set "REPO="
if /i "%~1"=="/silent" (
  set "SILENT=1"
  set "ROLE=%~2"
  set "REPO=%~3"
)
echo Akzo SDD Agent setup started %DATE% %TIME% > "%LOG%"

if defined SILENT goto prereq
cls
echo ==============================================================
echo    Akzo SDD Agent v3.1 - Setup wizard
echo    Spec-driven development agent for GitHub Copilot
echo ==============================================================
echo.
echo  This wizard will:
echo    1. Check the .NET SDK 8 or later and Git
echo    2. Install or update the 'sdd' tool for your Windows user
echo    3. Add the Copilot agent files to one or more repositories
echo    4. Run a health check on each repository
echo.
echo  Nothing is committed or pushed. No admin rights are needed.
echo.
pause

:prereq
echo.
echo [1/4] Checking prerequisites...
where dotnet >nul 2>&1
if errorlevel 1 goto no_dotnet
set "SDKMAJOR="
for /f "tokens=1 delims=." %%v in ('dotnet --version 2^>nul') do set "SDKMAJOR=%%v"
if not defined SDKMAJOR goto no_dotnet
if %SDKMAJOR% LSS 8 goto no_dotnet
echo       OK  .NET SDK %SDKMAJOR% found
where git >nul 2>&1
if errorlevel 1 goto no_git
echo       OK  Git found
goto tool

:no_git
echo       WARNING  Git was not found. Install Git for Windows before using the agent.
echo Git missing >> "%LOG%"

:tool
echo.
echo [2/4] Installing the sdd tool...
dotnet tool update --global Akzo.Sdd.Tool --add-source "%HERE%tool" --version 3.1.1 --ignore-failed-sources >> "%LOG%" 2>&1
if errorlevel 1 dotnet tool install --global Akzo.Sdd.Tool --add-source "%HERE%tool" --version 3.1.1 --ignore-failed-sources >> "%LOG%" 2>&1
if errorlevel 1 goto tool_failed
set "PATH=%PATH%;%USERPROFILE%\.dotnet\tools"
set "SDDV="
for /f "delims=" %%v in ('sdd version 2^>nul') do set "SDDV=%%v"
if not defined SDDV goto tool_failed
echo       OK  sdd %SDDV% installed
if not defined SILENT goto repo
if not exist "%REPO%\" goto repo_missing
goto install

:repo
echo.
echo [3/4] Choose a repository
echo    Drag the repository folder into this window, or type its path, then press Enter.
echo    Example: C:\Users\%USERNAME%\source\repos\AN.ColorAppsAzure.BL
set "REPO="
set /p "REPO=   Repository path: "
if not defined REPO goto repo
set "REPO=%REPO:"=%"
if not exist "%REPO%\" goto repo_missing

:role
echo.
echo    Which project is this repository?
echo      1. Auto-detect  (recommended)
echo      2. DAB   - AN.ColorAppsAzure.BL, Formula / GraphQL
echo      3. CDMS  - AN.ColorAppsAzure.BL.ColorDMS, Dataverse / XRM
echo      4. UI    - AN.ColorAppsAzure.UI, Angular
choice /c 1234 /n /m "   Select 1-4: "
set "SEL=%errorlevel%"
set "ROLE=auto"
if "%SEL%"=="2" set "ROLE=dab"
if "%SEL%"=="3" set "ROLE=cdms"
if "%SEL%"=="4" set "ROLE=ui"

:install
echo.
echo [4/4] Installing agent files into "%REPO%" (role: %ROLE%)...
sdd install --role %ROLE% --repo "%REPO%" --update-agents > "%OUT%" 2>&1
set "RC=%errorlevel%"
type "%OUT%"
type "%OUT%" >> "%LOG%"
if not "%RC%"=="0" goto install_failed
echo.
echo    Health check:
sdd doctor --repo "%REPO%" > "%OUT%" 2>&1
set "RC=%errorlevel%"
type "%OUT%"
type "%OUT%" >> "%LOG%"
if defined SILENT exit /b %RC%
echo.
echo    [WARN] lines are advice. Set buildCommand/testCommand in .sdd\settings.json when the defaults do not fit.
echo.
choice /c YN /n /m "   Install into another repository? [Y/N]: "
if errorlevel 2 goto done
goto repo

:repo_missing
echo    Folder not found: "%REPO%"
if defined SILENT exit /b 2
goto repo

:install_failed
echo.
echo    Installation into this repository did not complete. Details are above.
if defined SILENT exit /b %RC%
echo    If auto-detect could not decide, choose the project explicitly.
goto role

:no_dotnet
echo.
echo    The .NET SDK 8 or later is required.
echo    Install it from https://dotnet.microsoft.com/download then run this setup again.
echo .NET SDK missing or older than 8 >> "%LOG%"
if defined SILENT exit /b 2
pause
exit /b 2

:tool_failed
echo.
echo    The sdd tool could not be installed. See the log: "%LOG%"
echo    Common cause: the tool folder is missing next to this script. Extract the whole zip first.
if defined SILENT exit /b 1
pause
exit /b 1

:done
echo.
echo ==============================================================
echo    Setup complete.
echo.
echo    Next steps in Visual Studio or VS Code:
echo      1. Open the repository ROOT folder or solution.
echo      2. Open Copilot Chat in Agent mode.
echo      3. In the agent picker choose: Akzo SDD Agent
echo         and allow the terminal and file-edit tools.
echo      4. Type: Start Development ^<PBI-ID^> ^<Feature name^>
echo.
echo    Log file: "%LOG%"
echo ==============================================================
echo.
choice /c YN /n /m "   Open the team installation guide now? [Y/N]: "
if errorlevel 2 exit /b 0
start "" notepad "%HERE%TEAM-INSTALL-GUIDE.md"
exit /b 0
