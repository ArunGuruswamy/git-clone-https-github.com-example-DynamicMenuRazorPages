@echo off
REM Removes the sdd tool for the current user. Repository files (.github, docs, .sdd) are left
REM in place because they are shared with the team through Git; delete them through a normal PR if needed.
dotnet tool uninstall --global Akzo.Sdd.Tool
echo.
echo The sdd tool was removed. Repository files were not changed.
pause
