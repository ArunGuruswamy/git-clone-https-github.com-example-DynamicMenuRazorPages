# Historical samples

The 305912 and 306400 folders are inherited v3.0.x examples from the supplied archive, including mock business implementations and historical verification records. They are not fresh v3.1.1 validation. See ../docs/TEST-REPORT.md for this release's actual results.
