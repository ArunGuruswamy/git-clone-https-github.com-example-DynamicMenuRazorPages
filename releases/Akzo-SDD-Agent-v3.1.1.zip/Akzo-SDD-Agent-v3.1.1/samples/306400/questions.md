# Pending questions

Reply with the question id and option number, e.g. `Q-BIZ 1`.

**Q-REVIEW** (required) All tasks are done and targeted verification passed. Start the independent pre-PR review?
  1. Start review now (Recommended) - Hand off to Akzo SDD Reviewer; findings become fix tasks (max 3 rounds).
  2. I have more changes - Stay in implementation; ask again later.

**Q-PR** Final verification passed. Generate the SDD pull-request description?
  1. Generate PR description (Recommended) - Write pr-description.md with traceability, evidence and metrics. Nothing is committed or pushed.
  2. Later - Skip for now.

