# ComplaintPaintSystem - Specification

- PBI ID: 306400
- PBI title: [CAA] [DAB API] Creation of "Complaint" PaintSystem - (Part1)
- Feature folder: ComplaintPaintSystem
- Primary project role: Dab
- PBI input package: `docs/sdd/pbi-input/306400` (5 files)
- SDD agent: v3.0.0
- Refined PBI approval: Pending (status: Ready for PO-BA review)
- Technical feasibility review: Pending

## Refined PBI (verbatim source)

<!-- sdd:pbi-source:begin sha256=fd37107a6843e50edf28547e7ceb0d91587345aac6d0bd5d6043e68c4ccc0d5a -->
````markdown
# 306400 - [CAA] [DAB API] Creation of "Complaint" PaintSystem - (Part1)

Status: Ready for PO-BA review

## Original requirement

See `REQUEST.md`.

## Business need and actors

Users need Complaint Paint System processing for Primary and Secondary Derived Products after a valid Complaint IR.

## Current behavior and supporting evidence

**CONFIRMED:** Legacy `PaintSystemOperations` routes Complaint type 1 separately for Primary and Secondary Derived Products. Primary major version increments and alternative resets to 1; Secondary appends `C` to the alternative. Primary and Secondary paths create Color for tools 2/4. `Source/Formula/PaintSystem/PaintSystem/PaintSystemOperations.cs`.

**CONFIRMED:** Current conversion logic blocks Complaint conversion for Salcomix 1306 and a derived product under a 1306 parent. Product 752 returns false for conversion but absolute rejection was not confirmed in this path. Same source.

**INFERRED:** PBI 305183 covers substantially similar Complaint IR rules, but its decisions do not approve this separate PBI.

## Expected behavior

1. Process Complaint PS after approved IR validation and product pre-validation.
2. For Primary Derived Product, increment major version and reset alternative to 1; create Color; set conversion to all products allowed; do not associate Product.
3. For Secondary Derived Product, associate Product only when not already associated. If already associated, continue silently without a duplicate association.
4. Handle invalid version, missing Product/PS, association, and Color failures. Invalid version shows `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.` Missing Product shows `Product is missing. A Complaint Paint System cannot be created.` Missing existing PS shows `An existing Paint System is required. A Complaint Paint System cannot be created.` Failed Product association shows `Product association failed. The Complaint Paint System could not be completed.` Failed Color creation shows `Color creation failed. The Complaint Paint System could not be completed.`
5. Do not apply the product 752 rejection during Paint System Part 1 processing; it applies only while creating the IR.
6. Revalidate the Salcomix 1306 derived-product Complaint restriction during both IR creation and Paint System Part 1 processing.

## Business rules

| ID | Rule | Evidence / decision | Confidence / unresolved issue |
| --- | --- | --- | --- |
| BR-01 | Complaint type is processed separately for Primary and Secondary Derived Products. | Current source. | CONFIRMED |
| BR-02 | Primary version `{major+1}.1`; existing `1.3` becomes `2.1`. | Intake and current source. | CONFIRMED |
| BR-03 | Primary sets conversion allowed and creates Color; no Product association. | Intake; partial source support. | Feasibility review pending. |
| BR-04 | Secondary associates Product only if absent. | Intake and current source path. | Feasibility review pending. |
| BR-05 | Product 752 rejection applies only during IR creation and is out of scope for Paint System Part 1 processing. | User decision, 2026-10-07. | Approved business decision. |
| BR-06 | Salcomix 1306 derived-product Complaint restriction applies during both IR creation and Paint System Part 1 processing. IR shows `Complaint Imitation Requests are not allowed for a derived product in the Salcomix 1306 product family.` PS shows `Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.` | User decision, 2026-10-07. | Approved business decision; PS enforcement feasibility is pending. |
| BR-07 | Invalid existing PS version format blocks Complaint PS creation with the approved message. | User decision, 2026-10-07. | Approved business decision; technical validation behavior is pending review. |
| BR-08 | Missing Product blocks Complaint PS creation with the approved message. | User decision, 2026-10-07. | Approved business decision; technical validation behavior is pending review. |
| BR-09 | Missing existing PS blocks Complaint PS creation with the approved message. | User decision, 2026-10-07. | Approved business decision; technical validation behavior is pending review. |
| BR-10 | Failed Product association blocks Complaint PS completion with the approved message. | User decision, 2026-10-07. | Approved business decision; technical behavior is pending review. |
| BR-11 | Existing Product association does not create a duplicate or show a message; processing continues silently. | User decision, 2026-10-07. | Approved business decision; technical behavior is pending review. |
| BR-12 | Failed Color creation blocks Complaint PS completion with the approved message. | User decision, 2026-10-07. | Approved business decision; technical behavior is pending review. |

## Acceptance criteria

| ID | Given | When | Then |
| --- | --- | --- | --- |
| AC-01 | Primary Derived Product PS version is `1.3` | Complaint PS is created | PS version is `2.1`. |
| AC-02 | Primary Derived Product Complaint PS is created | Processing succeeds | Color is created and conversion is allowed without Product association. |
| AC-03 | Secondary Derived Product is not associated to existing PS | Complaint PS processing succeeds | Product association is created once. |
| AC-04 | Product is Salcomix 1306 derived | User creates Complaint IR | Creation is blocked with `Complaint Imitation Requests are not allowed for a derived product in the Salcomix 1306 product family.` |
| AC-05 | Product is Salcomix 1306 derived | Complaint Paint System Part 1 processing starts | Processing is blocked with `Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.` |
| AC-06 | Existing PS version format is invalid | Complaint PS processing starts | Processing is blocked with `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.` |
| AC-07 | Product is missing | Complaint PS processing starts | Processing is blocked with `Product is missing. A Complaint Paint System cannot be created.` |
| AC-08 | Required existing PS is missing | Complaint PS processing starts | Processing is blocked with `An existing Paint System is required. A Complaint Paint System cannot be created.` |
| AC-09 | Product association fails | Complaint PS processing starts | Processing is blocked with `Product association failed. The Complaint Paint System could not be completed.` |
| AC-10 | Product is already associated to the PS | Complaint PS processing starts | Processing continues without a duplicate association or message. |
| AC-11 | Color creation fails | Complaint PS processing starts | Processing is blocked with `Color creation failed. The Complaint Paint System could not be completed.` |

## Dependencies and affected business areas

Complaint IR validation, Product/parent Product, PS, Color, Formula, and Product association. DAB/CDMS source paths are unavailable.

## Open questions and blockers

See `OPEN-QUESTIONS.md`.

## PO/BA decisions

See `DECISION-LOG.md`.

## Review status

- Business approval: Pending
- Technical feasibility review: Pending
- Blocking questions: Resolved
- Readiness: Ready for PO-BA review
````
<!-- sdd:pbi-source:end -->

## Acceptance criteria

- **AC-01** - Given Primary Derived Product PS version is `1.3`; When Complaint PS is created; Then PS version is `2.1`.
- **AC-02** - Given Primary Derived Product Complaint PS is created; When Processing succeeds; Then Color is created and conversion is allowed without Product association.
- **AC-03** - Given Secondary Derived Product is not associated to existing PS; When Complaint PS processing succeeds; Then Product association is created once.
- **AC-04** - Given Product is Salcomix 1306 derived; When User creates Complaint IR; Then Creation is blocked with `Complaint Imitation Requests are not allowed for a derived product in the Salcomix 1306 product family.`
- **AC-05** - Given Product is Salcomix 1306 derived; When Complaint Paint System Part 1 processing starts; Then Processing is blocked with `Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.`
- **AC-06** - Given Existing PS version format is invalid; When Complaint PS processing starts; Then Processing is blocked with `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.`
- **AC-07** - Given Product is missing; When Complaint PS processing starts; Then Processing is blocked with `Product is missing. A Complaint Paint System cannot be created.`
- **AC-08** - Given Required existing PS is missing; When Complaint PS processing starts; Then Processing is blocked with `An existing Paint System is required. A Complaint Paint System cannot be created.`
- **AC-09** - Given Product association fails; When Complaint PS processing starts; Then Processing is blocked with `Product association failed. The Complaint Paint System could not be completed.`
- **AC-10** - Given Product is already associated to the PS; When Complaint PS processing starts; Then Processing continues without a duplicate association or message.
- **AC-11** - Given Color creation fails; When Complaint PS processing starts; Then Processing is blocked with `Color creation failed. The Complaint Paint System could not be completed.`

## PBI sources and attachments

The refined PBI is the source of truth. Other files are evidence and add no scope by themselves.

| File | Size (bytes) | SHA-256 (12) | Status |
|---|---|---|---|
| `DECISION-LOG.md` | 1986 | 98c3b481e106 | Read by sdd |
| `EVIDENCE.md` | 457 | adc8710bd68e | Read by sdd |
| `OPEN-QUESTIONS.md` | 2765 | 293cbd2c2493 | Read by sdd |
| `REFINED-PBI.md` | 7308 | 3d812be1ef03 | Read by sdd |
| `REQUEST.md` | 1882 | 57cee75bd521 | Read by sdd |

## Decisions (DECISION-LOG.md)

| ID | Decision | Status | Affected |
|---|---|---|---|
| D-01 | Treat intake PS rules as requested behavior for this separate Part 1 PBI. | Proposed | BR-01 to BR-05 |
| D-02 | Product 752 rejection applies only during IR creation and is not performed by Paint System Part 1. | Approved | BR-05 |
| D-03 | Salcomix 1306 derived-product Complaint restriction applies during both IR creation and Paint System Part 1. | Approved | BR-06; AC-04 |
| D-04 | Salcomix Paint System rejection uses `Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.` | Approved | BR-06; AC-05 |
| D-05 | Invalid version format message is `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.` | Approved | BR-07; AC-06 |
| D-06 | Missing Product message is `Product is missing. A Complaint Paint System cannot be created.` | Approved | BR-08; AC-07 |
| D-07 | Missing existing PS message is `An existing Paint System is required. A Complaint Paint System cannot be created.` | Approved | BR-09; AC-08 |
| D-08 | Failed Product association message is `Product association failed. The Complaint Paint System could not be completed.` | Approved | BR-10; AC-09 |
| D-09 | An existing Product association is left unchanged; processing continues silently without creating a duplicate association. | Approved | BR-11; AC-10 |
| D-10 | Failed Color creation message is `Color creation failed. The Complaint Paint System could not be completed.` | Approved | BR-12; AC-11 |

## Open questions

9 recorded, 0 unresolved.

- Q-01 [RESOLVED] Does product 752 rejection in this Part 1 scope apply only to Complaint processing or to every IR type? -> Resolved: applies only while creating the IR, not during Paint System Part 1.
- Q-02 [RESOLVED] Does the Salcomix 1306 derived-product Complaint restriction also apply only while creating the IR, or must Paint System Part 1 revalidate it? -> Resolved: applies at both IR creation and Paint System Part 1.
- Q-03 [RESOLVED] Must both IR creation and Paint System Part 1 show the same Salcomix rejection message, `Complaint Imitation Requests are not allowed for a derived product in the Salcomix 1306 product family.`? -> Resolved: use stage-specific IR and Paint System messages.
- Q-04 [RESOLVED] What exact message must be displayed when Complaint Paint System processing finds an invalid version format? -> Resolved: `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.`
- Q-05 [RESOLVED] What exact message must be displayed when the Product is missing during Complaint Paint System processing? -> Resolved: `Product is missing. A Complaint Paint System cannot be created.`
- Q-06 [RESOLVED] What exact message must be displayed when the required existing Paint System is missing during Complaint Paint System processing? -> Resolved: `An existing Paint System is required. A Complaint Paint System cannot be created.`
- Q-07 [RESOLVED] What exact message must be displayed when Product association fails during Complaint Paint System processing? -> Resolved: `Product association failed. The Complaint Paint System could not be completed.`
- Q-08 [RESOLVED] If the Product is already associated to the Paint System, should processing continue silently without creating a duplicate association, or show a message? -> Resolved: continue silently without a duplicate association.
- Q-09 [RESOLVED] What exact message must be displayed when Color creation fails during Complaint Paint System processing? -> Resolved: `Color creation failed. The Complaint Paint System could not be completed.`

## Business rules

| ID | Rule | Evidence | Confidence |
|---|---|---|---|
| BR-01 | Complaint type is processed separately for Primary and Secondary Derived Products. | Current source. | CONFIRMED |
| BR-02 | Primary version `{major+1}.1`; existing `1.3` becomes `2.1`. | Intake and current source. | CONFIRMED |
| BR-03 | Primary sets conversion allowed and creates Color; no Product association. | Intake; partial source support. | Feasibility review pending. |
| BR-04 | Secondary associates Product only if absent. | Intake and current source path. | Feasibility review pending. |
| BR-05 | Product 752 rejection applies only during IR creation and is out of scope for Paint System Part 1 processing. | User decision, 2026-10-07. | Approved business decision. |
| BR-06 | Salcomix 1306 derived-product Complaint restriction applies during both IR creation and Paint System Part 1 processing. IR shows `Complaint Imitation Requests are not allowed for a derived product in the Salcomix 1306 product family.` PS shows `Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.` | User decision, 2026-10-07. | Approved business decision; PS enforcement feasibility is pending. |
| BR-07 | Invalid existing PS version format blocks Complaint PS creation with the approved message. | User decision, 2026-10-07. | Approved business decision; technical validation behavior is pending review. |
| BR-08 | Missing Product blocks Complaint PS creation with the approved message. | User decision, 2026-10-07. | Approved business decision; technical validation behavior is pending review. |
| BR-09 | Missing existing PS blocks Complaint PS creation with the approved message. | User decision, 2026-10-07. | Approved business decision; technical validation behavior is pending review. |
| BR-10 | Failed Product association blocks Complaint PS completion with the approved message. | User decision, 2026-10-07. | Approved business decision; technical behavior is pending review. |
| BR-11 | Existing Product association does not create a duplicate or show a message; processing continues silently. | User decision, 2026-10-07. | Approved business decision; technical behavior is pending review. |
| BR-12 | Failed Color creation blocks Complaint PS completion with the approved message. | User decision, 2026-10-07. | Approved business decision; technical behavior is pending review. |

## Existing implementation and repository evidence

Mock-repository analysis (searched `src/**/PaintSystem*`, `GraphqlAssets/*.graphql`). Only `PaintSystemVersion.Format` exists today.

| AC | Status | Evidence (file > class > method) |
|---|---|---|
| AC-01 | PARTIAL | `PaintSystemVersion.cs > PaintSystemVersion > Format` formats only; no Complaint increment |
| AC-02 | MISSING | no Complaint Color/conversion flow |
| AC-03 | MISSING | no association flow |
| AC-04 | MISSING | no IR Salcomix check |
| AC-05 | MISSING | - |
| AC-06 | MISSING | - |
| AC-07 | MISSING | - |
| AC-08 | MISSING | - |
| AC-09 | MISSING | - |
| AC-10 | MISSING | - |
| AC-11 | MISSING | - |

## Delta requirements (ADDED / MODIFIED / REMOVED)

### ADDED
- R-1 (AC-01) The system SHALL compute the Primary Complaint PS version as `{major+1}.1` (`1.3` -> `2.1`).
- R-2 (AC-02) For a Primary Derived Product the system SHALL create Color, set conversion allowed, and SHALL NOT associate the Product.
- R-3 (AC-03, AC-10) For a Secondary Derived Product the system SHALL associate the Product once, and continue silently when already associated.
- R-4 (AC-04) Complaint IR creation SHALL be rejected for Salcomix 1306 derived products with the IR message.
- R-5 (AC-05..AC-09, AC-11) Complaint PS processing SHALL stop with the approved message for each failure.
### MODIFIED
None - no existing Complaint PS behaviour (evidence above).
### REMOVED
None - nothing removed.

## API and GraphQL contracts

No route or GraphQL change in Part 1: processing is internal to the Application layer (mock). UI change: no.

## Validation rules and messages

Approved user-visible messages (verbatim; implement as constants, assert exact text in tests):

- `Complaint Imitation Requests are not allowed for a derived product in the Salcomix 1306 product family.`
- `Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.`
- `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.`
- `Product is missing. A Complaint Paint System cannot be created.`
- `An existing Paint System is required. A Complaint Paint System cannot be created.`
- `Product association failed. The Complaint Paint System could not be completed.`
- `Color creation failed. The Complaint Paint System could not be completed.`

Failures return `ComplaintResult(Success=false, Error=<message constant>)`; messages live in `ComplaintMessages`.

## Testable scenarios

### AC-01
GIVEN Primary Derived Product PS version is `1.3`
WHEN Complaint PS is created
THEN PS version is `2.1`.

### AC-02
GIVEN Primary Derived Product Complaint PS is created
WHEN Processing succeeds
THEN Color is created and conversion is allowed without Product association.

### AC-03
GIVEN Secondary Derived Product is not associated to existing PS
WHEN Complaint PS processing succeeds
THEN Product association is created once.

### AC-04
GIVEN Product is Salcomix 1306 derived
WHEN User creates Complaint IR
THEN Creation is blocked with `Complaint Imitation Requests are not allowed for a derived product in the Salcomix 1306 product family.`

### AC-05
GIVEN Product is Salcomix 1306 derived
WHEN Complaint Paint System Part 1 processing starts
THEN Processing is blocked with `Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.`

### AC-06
GIVEN Existing PS version format is invalid
WHEN Complaint PS processing starts
THEN Processing is blocked with `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.`

### AC-07
GIVEN Product is missing
WHEN Complaint PS processing starts
THEN Processing is blocked with `Product is missing. A Complaint Paint System cannot be created.`

### AC-08
GIVEN Required existing PS is missing
WHEN Complaint PS processing starts
THEN Processing is blocked with `An existing Paint System is required. A Complaint Paint System cannot be created.`

### AC-09
GIVEN Product association fails
WHEN Complaint PS processing starts
THEN Processing is blocked with `Product association failed. The Complaint Paint System could not be completed.`

### AC-10
GIVEN Product is already associated to the PS
WHEN Complaint PS processing starts
THEN Processing continues without a duplicate association or message.

### AC-11
GIVEN Color creation fails
WHEN Complaint PS processing starts
THEN Processing is blocked with `Color creation failed. The Complaint Paint System could not be completed.`

