# Metrics - PBI 306400 ComplaintPaintSystem

| Phase | Started (UTC) | Duration | Tokens in/out (actual) | Tokens in/out (estimated) |
|---|---|---|---|---|
| Start (sdd engine) | 2026-10-15 13:00 | 0.2s | Unknown | Unknown |
| Analysis (agent) | 2026-10-15 13:00 | 1.5s | Unknown | Unknown |
| Implementation (agent) | 2026-10-15 13:01 | 13.0s | Unknown | 12,145 / 2,786 |
| Review | 2026-10-15 13:01 | 0.2s | Unknown | Unknown |
| **Total** | | **14.9s** | **Unknown** | **12,145 / 2,786** |

Deterministic generation by `sdd`: 24,034 characters of spec/plan written without the LLM (about 6,009 output tokens avoided, estimated).

Actual tokens come from the Copilot/provider usage view entered with `sdd tokens --actual`; estimated tokens are characters/4 and are never reported as actual. Unknown means not recorded.
