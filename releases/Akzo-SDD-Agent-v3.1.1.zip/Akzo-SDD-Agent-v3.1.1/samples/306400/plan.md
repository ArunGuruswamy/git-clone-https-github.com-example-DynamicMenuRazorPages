# ComplaintPaintSystem - Implementation Plan

- PBI ID: 306400
- PBI title: [CAA] [DAB API] Creation of "Complaint" PaintSystem - (Part1)
- Feature folder: ComplaintPaintSystem
- Primary project role: Dab
- PBI input package: `docs/sdd/pbi-input/306400` (5 files)
- SDD agent: v3.0.0

## Current implementation inventory

- `src/Formula.Application/PaintSystem/PaintSystemVersion.cs > PaintSystemVersion > Format` (reused).
- No Complaint processor, messages or tests exist.

## Implementation impact matrix

| Area | File or component | Change (new/modify) | AC | Risk |
|---|---|---|---|---|
| Application | `src/Formula.Application/PaintSystem/ComplaintPaintSystemProcessor.cs` | new | AC-01..AC-11 | Low - isolated new class |
| Tests | `tests/Formula.Application.Tests/ComplaintPaintSystemProcessorTests.cs` | new | AC-01..AC-11 | - |

## Traceability (AC -> code -> test)

| AC | Expected outcome | Code (file > class > method) | Test (class.method) |
|---|---|---|---|
| AC-01 | PS version is `2.1`. | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC01` |
| AC-02 | Color is created and conversion is allowed without Product association. | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC02` |
| AC-03 | Product association is created once. | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC03` |
| AC-04 | Creation is blocked with `Complaint Imitation Requests are not allowed for a derived product in the Salcomix 1306 product family.` | `ComplaintPaintSystemProcessor > ValidateComplaintIr` | `ComplaintPaintSystemProcessorTests.AC04` |
| AC-05 | Processing is blocked with `Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.` | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC05` |
| AC-06 | Processing is blocked with `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.` | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC06` |
| AC-07 | Processing is blocked with `Product is missing. A Complaint Paint System cannot be created.` | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC07` |
| AC-08 | Processing is blocked with `An existing Paint System is required. A Complaint Paint System cannot be created.` | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC08` |
| AC-09 | Processing is blocked with `Product association failed. The Complaint Paint System could not be completed.` | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC09` |
| AC-10 | Processing continues without a duplicate association or message. | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC10` |
| AC-11 | Processing is blocked with `Color creation failed. The Complaint Paint System could not be completed.` | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC11` |

## Implementation tasks

- [ ] T1 [BE] `src/Formula.Application/PaintSystem/ComplaintPaintSystemProcessor.cs` - messages, version rule, Primary/Secondary processing, IR check (AC-01..AC-11)
- [ ] T2 [T] `tests/Formula.Application.Tests/ComplaintPaintSystemProcessorTests.cs` - one test per AC, exact messages

## Test strategy and coverage gate

- Every AC has at least one automated test asserting the exact outcome or message.
- Every handler/service path: success, validation failure, dependency failure.
- Tests are written with the code (same task group), never deleted or ignored to go green.
- Coverage gate: >= 90% line coverage on new/changed code (SonarQube 'Coverage on New Code'), enforced by `sdd verify`.
- A run with zero executed tests, failed tests, compiler errors or a stale-build fallback fails verification.

## Sonar quality rules

- Cognitive complexity <= 15 (S3776), cyclomatic <= 10 per method, <= 7 parameters (S107).
- No magic strings/numbers (messages as constants), no unused code, no commented-out code, no new suppressions.
- Async all the way (no .Result/.Wait), `using` for IDisposable, fatal-exception filter on broad catches, never swallow.
- Full rules: `.github/instructions/sonar-rules.instructions.md`.

## Build and test verification

- Build: `dotnet build`
- Test: `dotnet test --no-build --logger trx --collect:"XPlat Code Coverage" --results-directory "{results}"`
- Targeted checkpoint: `sdd verify --scope targeted`; final regression: `sdd verify --scope final`.

## Dependency and contract checks

No DI or GraphQL change; the gateway interface is injected by the existing handler (Part 2).

## Risks and implementation sequence

Risk: version strings with suffixes (e.g. `1.3C`) - rejected as invalid format (AC-06). Sequence: T1 then T2, then final verify.

