using Formula.Application.PaintSystem;

namespace Formula.Application.Tests;

[TestClass]
public sealed class ComplaintPaintSystemProcessorTests
{
    private static ComplaintPaintSystemRequest Primary(string? version = "1.3") =>
        new(version, ProductExists: true, PaintSystemExists: true, DerivedProductKind.Primary, IsSalcomix1306Derived: false, AlreadyAssociated: false);

    private static ComplaintPaintSystemRequest Secondary(bool associated = false) =>
        new("1.3", ProductExists: true, PaintSystemExists: true, DerivedProductKind.Secondary, IsSalcomix1306Derived: false, associated);

    [TestMethod]
    public void AC01_PrimaryVersionIncrementsMajorAndResetsAlternative()
    {
        Assert.AreEqual("2.1", new ComplaintPaintSystemProcessor(new FakeGateway()).Process(Primary()).NewVersion);
    }

    [TestMethod]
    public void AC02_PrimaryCreatesColorAllowsConversionWithoutAssociation()
    {
        var gateway = new FakeGateway();
        var result = new ComplaintPaintSystemProcessor(gateway).Process(Primary());
        Assert.IsTrue(result.Success && result.ConversionAllowed);
        Assert.AreEqual(1, gateway.ColorCalls);
        Assert.AreEqual(0, gateway.AssociationCalls);
    }

    [TestMethod]
    public void AC03_SecondaryAssociatesOnce()
    {
        var gateway = new FakeGateway();
        var result = new ComplaintPaintSystemProcessor(gateway).Process(Secondary());
        Assert.IsTrue(result.AssociationCreated);
        Assert.AreEqual(1, gateway.AssociationCalls);
    }

    [TestMethod]
    public void AC04_IrBlockedForSalcomix1306()
    {
        Assert.AreEqual(ComplaintMessages.IrSalcomix, ComplaintPaintSystemProcessor.ValidateComplaintIr(true));
        Assert.IsNull(ComplaintPaintSystemProcessor.ValidateComplaintIr(false));
    }

    [TestMethod]
    public void AC05_PsBlockedForSalcomix1306()
    {
        var request = Primary() with { IsSalcomix1306Derived = true };
        Assert.AreEqual("Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.", new ComplaintPaintSystemProcessor(new FakeGateway()).Process(request).Error);
    }

    [TestMethod]
    public void AC06_InvalidVersionBlocked()
    {
        foreach (var version in new[] { "1.3C", "x.1", "1", null })
        {
            Assert.AreEqual(ComplaintMessages.InvalidVersion, new ComplaintPaintSystemProcessor(new FakeGateway()).Process(Primary(version)).Error);
        }
    }

    [TestMethod]
    public void AC07_MissingProductBlocked()
    {
        Assert.AreEqual(ComplaintMessages.MissingProduct, new ComplaintPaintSystemProcessor(new FakeGateway()).Process(Primary() with { ProductExists = false }).Error);
    }

    [TestMethod]
    public void AC08_MissingPaintSystemBlocked()
    {
        Assert.AreEqual(ComplaintMessages.MissingPaintSystem, new ComplaintPaintSystemProcessor(new FakeGateway()).Process(Primary() with { PaintSystemExists = false }).Error);
    }

    [TestMethod]
    public void AC09_AssociationFailureBlocked()
    {
        var result = new ComplaintPaintSystemProcessor(new FakeGateway { AssociationResult = false }).Process(Secondary());
        Assert.AreEqual(ComplaintMessages.AssociationFailed, result.Error);
    }

    [TestMethod]
    public void AC10_AlreadyAssociatedContinuesSilently()
    {
        var gateway = new FakeGateway();
        var result = new ComplaintPaintSystemProcessor(gateway).Process(Secondary(associated: true));
        Assert.IsTrue(result.Success);
        Assert.IsNull(result.Error);
        Assert.AreEqual(0, gateway.AssociationCalls);
    }

    [TestMethod]
    public void AC11_ColorFailureBlocked()
    {
        Assert.AreEqual(ComplaintMessages.ColorFailed, new ComplaintPaintSystemProcessor(new FakeGateway { ColorResult = false }).Process(Primary()).Error);
    }

    [TestMethod]
    public void NullRequestThrows()
    {
        Assert.ThrowsException<ArgumentNullException>(() => new ComplaintPaintSystemProcessor(new FakeGateway()).Process(null!));
    }

    private sealed class FakeGateway : IComplaintPaintSystemGateway
    {
        public bool ColorResult { get; init; } = true;

        public bool AssociationResult { get; init; } = true;

        public int ColorCalls { get; private set; }

        public int AssociationCalls { get; private set; }

        public bool CreateColor()
        {
            ColorCalls++;
            return ColorResult;
        }

        public bool AssociateProduct()
        {
            AssociationCalls++;
            return AssociationResult;
        }
    }
}
