using System.Globalization;

namespace Formula.Application.PaintSystem;

/// <summary>Derived product kind for Complaint processing.</summary>
public enum DerivedProductKind
{
    /// <summary>Primary derived product.</summary>
    Primary,

    /// <summary>Secondary derived product.</summary>
    Secondary,
}

/// <summary>Input for Complaint Paint System Part 1 processing (PBI 306400).</summary>
/// <param name="ExistingVersion">Existing PS version, for example 1.3.</param>
/// <param name="ProductExists">True when the Product is present.</param>
/// <param name="PaintSystemExists">True when the required existing PS is present.</param>
/// <param name="Kind">Primary or Secondary derived product.</param>
/// <param name="IsSalcomix1306Derived">True for a derived product in the Salcomix 1306 family.</param>
/// <param name="AlreadyAssociated">True when the Product is already associated to the PS.</param>
public sealed record ComplaintPaintSystemRequest(
    string? ExistingVersion,
    bool ProductExists,
    bool PaintSystemExists,
    DerivedProductKind Kind,
    bool IsSalcomix1306Derived,
    bool AlreadyAssociated);

/// <summary>Outcome of Complaint processing.</summary>
/// <param name="Success">True when processing completed.</param>
/// <param name="Error">Approved message when blocked.</param>
/// <param name="NewVersion">New PS version for a Primary derived product.</param>
/// <param name="ConversionAllowed">True when conversion to all products is allowed.</param>
/// <param name="AssociationCreated">True when a Product association was created.</param>
public sealed record ComplaintResult(bool Success, string? Error, string? NewVersion, bool ConversionAllowed, bool AssociationCreated)
{
    /// <summary>Creates a blocked result.</summary>
    public static ComplaintResult Blocked(string message) => new(false, message, null, false, false);
}

/// <summary>Data operations used by Complaint processing.</summary>
public interface IComplaintPaintSystemGateway
{
    /// <summary>Creates the Color; false when creation failed.</summary>
    bool CreateColor();

    /// <summary>Associates the Product to the PS; false when association failed.</summary>
    bool AssociateProduct();
}

/// <summary>Approved user-visible messages (DECISION-LOG D-04..D-10).</summary>
public static class ComplaintMessages
{
    /// <summary>AC-04.</summary>
    public const string IrSalcomix = "Complaint Imitation Requests are not allowed for a derived product in the Salcomix 1306 product family.";

    /// <summary>AC-05.</summary>
    public const string PsSalcomix = "Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.";

    /// <summary>AC-06.</summary>
    public const string InvalidVersion = "The existing Paint System version format is invalid. A Complaint Paint System cannot be created.";

    /// <summary>AC-07.</summary>
    public const string MissingProduct = "Product is missing. A Complaint Paint System cannot be created.";

    /// <summary>AC-08.</summary>
    public const string MissingPaintSystem = "An existing Paint System is required. A Complaint Paint System cannot be created.";

    /// <summary>AC-09.</summary>
    public const string AssociationFailed = "Product association failed. The Complaint Paint System could not be completed.";

    /// <summary>AC-11.</summary>
    public const string ColorFailed = "Color creation failed. The Complaint Paint System could not be completed.";
}

/// <summary>Complaint Paint System Part 1 processing.</summary>
public sealed class ComplaintPaintSystemProcessor
{
    private const int FirstAlternative = 1;
    private readonly IComplaintPaintSystemGateway _gateway;

    /// <summary>Creates the processor.</summary>
    public ComplaintPaintSystemProcessor(IComplaintPaintSystemGateway gateway)
    {
        _gateway = gateway;
    }

    /// <summary>AC-04: IR creation check for the Salcomix 1306 family; returns the message or null.</summary>
    public static string? ValidateComplaintIr(bool isSalcomix1306Derived) =>
        isSalcomix1306Derived ? ComplaintMessages.IrSalcomix : null;

    /// <summary>Processes a Complaint PS (AC-01..AC-03, AC-05..AC-11).</summary>
    public ComplaintResult Process(ComplaintPaintSystemRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);
        var blocked = Prevalidate(request);
        if (blocked is not null)
        {
            return ComplaintResult.Blocked(blocked);
        }

        return request.Kind == DerivedProductKind.Primary ? ProcessPrimary(request) : ProcessSecondary(request);
    }

    /// <summary>AC-01: {major+1}.1, or null when the version format is invalid.</summary>
    public static string? NextPrimaryVersion(string? existing)
    {
        var parts = (existing ?? string.Empty).Split('.');
        if (parts.Length != 2
            || !int.TryParse(parts[0], NumberStyles.None, CultureInfo.InvariantCulture, out var major)
            || !int.TryParse(parts[1], NumberStyles.None, CultureInfo.InvariantCulture, out _))
        {
            return null;
        }

        return PaintSystemVersion.Format(major + 1, FirstAlternative);
    }

    private static string? Prevalidate(ComplaintPaintSystemRequest request)
    {
        if (request.IsSalcomix1306Derived)
        {
            return ComplaintMessages.PsSalcomix;
        }

        if (!request.ProductExists)
        {
            return ComplaintMessages.MissingProduct;
        }

        return request.PaintSystemExists ? null : ComplaintMessages.MissingPaintSystem;
    }

    private ComplaintResult ProcessPrimary(ComplaintPaintSystemRequest request)
    {
        var version = NextPrimaryVersion(request.ExistingVersion);
        if (version is null)
        {
            return ComplaintResult.Blocked(ComplaintMessages.InvalidVersion);
        }

        return _gateway.CreateColor()
            ? new ComplaintResult(true, null, version, ConversionAllowed: true, AssociationCreated: false)
            : ComplaintResult.Blocked(ComplaintMessages.ColorFailed);
    }

    private ComplaintResult ProcessSecondary(ComplaintPaintSystemRequest request)
    {
        if (request.AlreadyAssociated)
        {
            return new ComplaintResult(true, null, null, false, AssociationCreated: false);
        }

        return _gateway.AssociateProduct()
            ? new ComplaintResult(true, null, null, false, AssociationCreated: true)
            : ComplaintResult.Blocked(ComplaintMessages.AssociationFailed);
    }
}
