# feat(ComplaintPaintSystem): [CAA] [DAB API] Creation of "Complaint" PaintSystem - (Part1) [AB#306400]

> **Status: READY FOR PR** - all SDD gates passed.

## 1. Why - PBI
- PBI: AB#306400 - [CAA] [DAB API] Creation of "Complaint" PaintSystem - (Part1)
- Business approval: Pending; technical review: Pending
- Role: Dab | Branch: `feature/306400-complaint-paint-system` | Mode: FAST
- Spec: `src/.github/specs/ComplaintPaintSystem/spec.md` | Plan: `src/.github/specs/ComplaintPaintSystem/plan.md`
- Approved by Arun on 2026-10-15 13:01 UTC: "Selected: Approve implementation" (hash-bound; unchanged since approval)

## 2. What - delta requirements
### ADDED
- R-1 (AC-01) The system SHALL compute the Primary Complaint PS version as `{major+1}.1` (`1.3` -> `2.1`).
- R-2 (AC-02) For a Primary Derived Product the system SHALL create Color, set conversion allowed, and SHALL NOT associate the Product.
- R-3 (AC-03, AC-10) For a Secondary Derived Product the system SHALL associate the Product once, and continue silently when already associated.
- R-4 (AC-04) Complaint IR creation SHALL be rejected for Salcomix 1306 derived products with the IR message.
- R-5 (AC-05..AC-09, AC-11) Complaint PS processing SHALL stop with the approved message for each failure.
### MODIFIED
None - no existing Complaint PS behaviour (evidence above).
### REMOVED
None - nothing removed.

## 3. Acceptance criteria traceability (AC -> code -> test)
| AC | Expected outcome | Code (file > class > method) | Test (class.method) |
|---|---|---|---|
| AC-01 | PS version is `2.1`. | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC01` |
| AC-02 | Color is created and conversion is allowed without Product association. | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC02` |
| AC-03 | Product association is created once. | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC03` |
| AC-04 | Creation is blocked with `Complaint Imitation Requests are not allowed for a derived product in the Salcomix 1306 product family.` | `ComplaintPaintSystemProcessor > ValidateComplaintIr` | `ComplaintPaintSystemProcessorTests.AC04` |
| AC-05 | Processing is blocked with `Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.` | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC05` |
| AC-06 | Processing is blocked with `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.` | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC06` |
| AC-07 | Processing is blocked with `Product is missing. A Complaint Paint System cannot be created.` | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC07` |
| AC-08 | Processing is blocked with `An existing Paint System is required. A Complaint Paint System cannot be created.` | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC08` |
| AC-09 | Processing is blocked with `Product association failed. The Complaint Paint System could not be completed.` | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC09` |
| AC-10 | Processing continues without a duplicate association or message. | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC10` |
| AC-11 | Processing is blocked with `Color creation failed. The Complaint Paint System could not be completed.` | `ComplaintPaintSystemProcessor > Process` | `ComplaintPaintSystemProcessorTests.AC11` |

## 4. Decisions applied
- D-01 (Proposed -> developer: accept): Treat intake PS rules as requested behavior for this separate Part 1 PBI.
- D-02 (Approved): Product 752 rejection applies only during IR creation and is not performed by Paint System Part 1.
- D-03 (Approved): Salcomix 1306 derived-product Complaint restriction applies during both IR creation and Paint System Part 1.
- D-04 (Approved): Salcomix Paint System rejection uses `Complaint Paint Systems are not allowed for derived products in the Salcomix 1306 product family.`
- D-05 (Approved): Invalid version format message is `The existing Paint System version format is invalid. A Complaint Paint System cannot be created.`
- D-06 (Approved): Missing Product message is `Product is missing. A Complaint Paint System cannot be created.`
- D-07 (Approved): Missing existing PS message is `An existing Paint System is required. A Complaint Paint System cannot be created.`
- D-08 (Approved): Failed Product association message is `Product association failed. The Complaint Paint System could not be completed.`
- D-09 (Approved): An existing Product association is left unchanged; processing continues silently without creating a duplicate association.
- D-10 (Approved): Failed Color creation message is `Color creation failed. The Complaint Paint System could not be completed.`
- Q-D-01: PO confirmed in refinement: intake PS rules are in scope for Part 1

## 5. Files changed
**Specification (approved) (2)**
- `src/.github/specs/ComplaintPaintSystem/plan.md`
- `src/.github/specs/ComplaintPaintSystem/spec.md`
**Production code (1)**
- `src/Formula.Application/PaintSystem/ComplaintPaintSystemProcessor.cs`
**Tests (2)**
- `tests/Formula.Application.Tests/ComplaintPaintSystemProcessorTests.cs`
- `tests/Formula.Application.Tests/LocalTestRunner.cs`

## 6. Verification evidence
Scope **final**, run 2026-10-15 13:01 UTC, 5.1s.

| Gate | Result | Evidence |
|---|---|---|
| Build | PASS | `dotnet build src/Formula.Application -c Debug --source <sandbox>/feed -nologo` exit 0 in 1.9s |
| Tests | PASS | 12 executed, 12 passed, 0 failed (source: console summary) |
| Coverage | PASS | 100% line coverage on changed production files (1); threshold 90% |

## 7. Review
- Independent review (Akzo SDD Reviewer): READY FOR PR

## 8. Delivery metrics
| Phase | Started (UTC) | Duration | Tokens in/out (actual) | Tokens in/out (estimated) |
|---|---|---|---|---|
| Start (sdd engine) | 2026-10-15 13:00 | 0.2s | Unknown | Unknown |
| Analysis (agent) | 2026-10-15 13:00 | 1.5s | Unknown | Unknown |
| Implementation (agent) | 2026-10-15 13:01 | 13.0s | Unknown | 12,145 / 2,786 |
| Review | 2026-10-15 13:01 | 0.2s | Unknown | Unknown |
| **Total** | | **14.9s** | **Unknown** | **12,145 / 2,786** |

Deterministic generation by `sdd`: 24,034 characters of spec/plan written without the LLM (about 6,009 output tokens avoided, estimated).

Actual tokens come from the Copilot/provider usage view entered with `sdd tokens --actual`; estimated tokens are characters/4 and are never reported as actual. Unknown means not recorded.

## 9. Reviewer checklist
- [ ] Every AC above has code and a passing test
- [ ] Messages match the approved text exactly (constants)
- [ ] No unplanned files, deletions, suppressions or package changes
- [ ] Contract parity (route, verb, envelope) kept for the UI
