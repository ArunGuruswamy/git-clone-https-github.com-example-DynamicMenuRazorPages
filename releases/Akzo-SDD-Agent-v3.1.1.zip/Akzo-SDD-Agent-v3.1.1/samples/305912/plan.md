# AdaptationImitationRequest - Implementation Plan

- PBI ID: 305912
- PBI title: [CAA] [DAB API] Creation of Imitation Request & Paint System - Adaptation
- Feature folder: AdaptationImitationRequest
- Primary project role: Dab
- PBI input package: `docs/sdd/pbi-input/305912` (5 files)
- SDD agent: v3.0.5

## Current implementation inventory

No Adaptation rules in this repository (searched `ImitationRequest`, `Adaptation`, `PaintSystemLevel`). Existing: `src/Formula.Application/PaintSystem/PaintSystemVersion.cs > PaintSystemVersion > Format`.

## Implementation impact matrix

| Area | File or component | Change (new/modify) | AC | Risk |
|---|---|---|---|---|
| Domain | `src/Formula.Application/ImitationRequest/AdaptationRules.cs` | new | AC-02..AC-16 | Medium (assumptions Q-01, Q-02, Q-04) |
| Tests | `tests/Formula.Application.Tests/AdaptationRulesTests.cs` | new | AC-02..AC-16 | Low |

## Traceability (AC -> code -> test)

'Applies here': Yes, Partial (say which part) or No - <owning repository>. Rows marked No need no code or test here (write N/A); they are listed in the PR.

| AC | Expected outcome | Layer (suggested) | Applies here | Code (file > class > method) | Test (class.method) |
|---|---|---|---|---|---|
| AC-01 | Color Name offers that MCI. | UI / form | No - UI repository (Color Name lookup filter on the IR form) | N/A | N/A |
| AC-02 | Color Name does not offer that MCI. | UI / form | Partial - eligibility rule exposed by the API; lookup filter is UI | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > IsEligibleIndustrialInstance` | `AdaptationRulesTests.AC02_OnlyActiveIndustrialWithoutKindOfVariationAndWithSuffixIsEligible` |
| AC-03 | Save is blocked with `Active imitation request already exists for same Market Color - "Industrial" instance and Product`. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ValidateCreate` | `AdaptationRulesTests.AC03_DuplicateActiveAdaptationIsBlockedWithExactMessage` |
| AC-04 | Save is blocked with `Only Adaption is allowed; Paint system does not exist for this Market Color Instance and Product`. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ValidateCreate` | `AdaptationRulesTests.AC04_OtherTypeOnIndustrialInstanceIsBlockedWithExactMessage` |
| AC-05 | Reference Color is populated with that Standard MCI. | UI / form | Partial - new Reference Color API (Q-03); populating the form is UI | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ResolveReferenceColor` | `AdaptationRulesTests.AC05_ReferenceColorIsTheMeasuredGlobalStandardOfTheSameMarketColor` |
| AC-06 | The warning `Standard does not have measurement, Kindly add measurement for the Standard instance` is displayed and creation cannot proceed. | UI / form | Partial - API returns the warning; showing it is UI | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ResolveReferenceColor` | `AdaptationRulesTests.AC06_MissingMeasurementReturnsExactWarning` |
| AC-07 | Both may be created subject to their own duplicate combinations. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ValidateCreate` | `AdaptationRulesTests.AC07_DifferentProductionLinesOfOneMarketColorDoNotBlockEachOther` |
| AC-08 | IR name follows the approved suffix naming convention, including `SES1A__3FICESC_` if that example is confirmed as exact. | API / backend | Yes (assumption Q-02) | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > BuildName` | `AdaptationRulesTests.AC08_NameIncludesProductionLineSuffix` |
| AC-09 | PS Level is `Adapted`. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > PaintSystemLevel` | `AdaptationRulesTests.AC09_AC10_PaintSystemLevel` |
| AC-10 | PS Level is empty and locked. | UI / form | Partial - API leaves it empty; locking the field is UI | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > PaintSystemLevel` | `AdaptationRulesTests.AC09_AC10_PaintSystemLevel` |
| AC-11 | PS, Color Imitation, and Formula are created under the applicable existing rules. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > CreatesColorImitationAndFormula` | `AdaptationRulesTests.AC11_ColorAppsAndOwnColorCreateColorImitationAndFormula` |
| AC-12 | Processing stops. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > CanProcess` | `AdaptationRulesTests.AC12_ProcessingStopsWithoutImitationRequestOrDevelopmentTool` |
| AC-13 | Version/Alternative is `1.1`. | API / backend | Yes (follow-up versions: Q-04 assumption) | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > InitialVersion` | `AdaptationRulesTests.AC13_NewPaintSystemStartsAtOnePointOne` |
| AC-14 | Prior related PS records become Historic. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ToHistoric` | `AdaptationRulesTests.AC14_NonAutomotiveMakesAllPreviousHistoric` |
| AC-15 | Only the approved matching production-line records become Historic; unmatched-line records remain unchanged. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ToHistoric` | `AdaptationRulesTests.AC15_AutomotiveOnlyMatchingProductionLineBecomesHistoric` |
| AC-16 | The existing MCI, rather than a new MCI, receives the approved Global/Industry, suffix, and promotion updates. | API / backend | Yes (D-04 accepted; Color Point D-05 rejected) | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > Promote` | `AdaptationRulesTests.AC16_ActualizationUpdatesTheSameInstance` |

## Implementation tasks

- [ ] T1 [BE] `src/Formula.Application/ImitationRequest/AdaptationRules.cs` - Adaptation eligibility, validation, reference color, naming, PS level, versioning, historic, promotion (AC-02..AC-16)
- [ ] T2 [T] `tests/Formula.Application.Tests/AdaptationRulesTests.cs` - one test per applicable AC, exact messages asserted

## Test strategy and coverage gate

- Every AC has at least one automated test asserting the exact outcome or message.
- Every handler/service path: success, validation failure, dependency failure.
- Tests are written with the code (same task group), never deleted or ignored to go green.
- Coverage gate: >= 90% line coverage on new/changed code (SonarQube 'Coverage on New Code'), enforced by `sdd verify`.
- A run with zero executed tests, failed tests, compiler errors or a stale-build fallback fails verification.

## Sonar quality rules

- Cognitive complexity <= 15 (S3776), cyclomatic <= 10 per method, <= 7 parameters (S107).
- No magic strings/numbers (messages as constants), no unused code, no commented-out code, no new suppressions.
- Async all the way (no .Result/.Wait), `using` for IDisposable, fatal-exception filter on broad catches, never swallow.
- Full rules: `.github/instructions/sonar-rules.instructions.md`.

## Build and test verification

- Build: `dotnet build src/Formula.Application -c Debug --source <sandbox>/feed -nologo`
- Test: `sh run-tests.sh {results}`
- Targeted checkpoint: `sdd verify --scope targeted`; final regression: `sdd verify --scope final`.

## Dependency and contract checks

No DI change (static rules). No StrawberryShake regeneration in this slice. UI parity: AC-01 and the form parts of AC-02/05/06/10 go to the UI repository.

## Risks and implementation sequence

Blocked PBI: Q-01/Q-02/Q-04 implemented as recorded assumptions; revisit when PO/BA answers. Sequence: rules + tests, then handlers, then UI.

