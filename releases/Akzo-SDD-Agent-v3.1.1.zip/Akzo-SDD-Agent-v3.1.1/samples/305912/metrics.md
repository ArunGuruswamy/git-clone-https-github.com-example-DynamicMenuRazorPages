# Metrics - PBI 305912 AdaptationImitationRequest

| Phase | Started (UTC) | Duration | Tokens in/out (actual) | Tokens in/out (estimated) |
|---|---|---|---|---|
| Start (sdd engine) | 2026-10-15 17:42 | 0.2s | Unknown | Unknown |
| Analysis (agent) | 2026-10-15 17:42 | 3.4s | Unknown | Unknown |
| Implementation (agent) | 2026-10-15 17:42 | 15.3s | Unknown | Unknown |
| Review | 2026-10-15 17:42 | 0.2s | Unknown | Unknown |
| **Total** | | **19.0s** | **Unknown** | **Unknown** |

Deterministic generation by `sdd`: 34,565 characters of spec/plan written without the LLM (about 8,642 output tokens avoided, estimated).

Actual tokens come from the Copilot/provider usage view entered with `sdd tokens --actual`; estimated tokens are characters/4 and are never reported as actual. Unknown means not recorded.
