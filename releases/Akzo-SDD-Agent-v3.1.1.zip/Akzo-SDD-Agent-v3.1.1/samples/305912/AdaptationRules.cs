namespace Formula.Application.ImitationRequest;

/// <summary>Imitation request types relevant to PBI 305912.</summary>
public enum ImitationRequestType
{
    /// <summary>Adaptation of an Industrial instance.</summary>
    Adaptation = 0,

    /// <summary>Industrialization.</summary>
    Industrialization,

    /// <summary>Improved Formula.</summary>
    ImprovedFormula,
}

/// <summary>Market Color Instance data used by the Adaptation rules.</summary>
/// <param name="Id">Instance id.</param>
/// <param name="MarketColorId">Market Color id.</param>
/// <param name="Name">Instance name.</param>
/// <param name="IsActive">Active state.</param>
/// <param name="Role">Role (Industrial, Global ...).</param>
/// <param name="KindOfVariation">Kind of Variation; empty for an Industrial instance.</param>
/// <param name="VariantSuffix">Variant suffix (production-line short name).</param>
/// <param name="IsActual">Actual status.</param>
/// <param name="HasMeasurement">True when a measurement exists.</param>
public sealed record MarketColorInstance(
    Guid Id,
    Guid MarketColorId,
    string Name,
    bool IsActive,
    string Role,
    string? KindOfVariation,
    string? VariantSuffix,
    bool IsActual,
    bool HasMeasurement);

/// <summary>An existing imitation request.</summary>
/// <param name="InstanceId">Market Color Instance id.</param>
/// <param name="ProductId">Product id.</param>
/// <param name="IsGlobal">Local/Global flag.</param>
/// <param name="Type">IR type.</param>
/// <param name="IsActive">Awaiting Development or In Development.</param>
public sealed record ExistingImitationRequest(Guid InstanceId, string ProductId, bool IsGlobal, ImitationRequestType Type, bool IsActive);

/// <summary>A previous paint system considered for historic handling.</summary>
/// <param name="Id">Paint system id.</param>
/// <param name="ProductionLine">Production line, or null.</param>
public sealed record PreviousPaintSystem(Guid Id, string? ProductionLine);

/// <summary>Outcome of a validation rule.</summary>
/// <param name="Success">True when allowed.</param>
/// <param name="Message">Approved message when refused.</param>
public sealed record RuleResult(bool Success, string? Message)
{
    /// <summary>Allowed.</summary>
    public static RuleResult Ok { get; } = new(true, null);

    /// <summary>Refused with an approved message.</summary>
    /// <param name="message">Message.</param>
    /// <returns>Result.</returns>
    public static RuleResult Fail(string message) => new(false, message);
}

/// <summary>Approved user-visible messages (verbatim from the refined PBI).</summary>
public static class AdaptationMessages
{
    /// <summary>AC-03.</summary>
    public const string Duplicate = "Active imitation request already exists for same Market Color - \"Industrial\" instance and Product";

    /// <summary>AC-04.</summary>
    public const string OnlyAdaptation = "Only Adaption is allowed; Paint system does not exist for this Market Color Instance and Product";

    /// <summary>AC-06.</summary>
    public const string MissingMeasurement = "Standard does not have measurement, Kindly add measurement for the Standard instance";
}

/// <summary>Business rules for Adaptation imitation requests and paint systems (PBI 305912).</summary>
public static class AdaptationRules
{
    /// <summary>Paint System Level for Adaptation.</summary>
    public const string AdaptedLevel = "Adapted";

    /// <summary>First version/alternative of a new paint system.</summary>
    public const string FirstVersion = "1.1";

    private const string IndustrialRole = "Industrial";
    private const string GlobalRole = "Global";
    private const string StandardKind = "Standard";
    private const string IndustryKind = "Industry";
    private const int ColorApps = 2;
    private const int OwnColor = 4;

    /// <summary>AC-02: an instance can be adapted only when Active, Industrial, without Kind of Variation and with a production-line suffix.</summary>
    /// <param name="instance">Instance.</param>
    /// <returns>True when eligible.</returns>
    public static bool IsEligibleIndustrialInstance(MarketColorInstance instance)
    {
        ArgumentNullException.ThrowIfNull(instance);
        return instance.IsActive
            && string.Equals(instance.Role, IndustrialRole, StringComparison.OrdinalIgnoreCase)
            && string.IsNullOrWhiteSpace(instance.KindOfVariation)
            && !string.IsNullOrWhiteSpace(instance.VariantSuffix);
    }

    /// <summary>AC-03, AC-04, AC-07: validates a new imitation request for an Industrial instance.</summary>
    /// <param name="type">Requested IR type.</param>
    /// <param name="instance">Selected instance.</param>
    /// <param name="productId">Product.</param>
    /// <param name="isGlobal">Local/Global.</param>
    /// <param name="existing">Existing imitation requests.</param>
    /// <returns>Result.</returns>
    public static RuleResult ValidateCreate(ImitationRequestType type, MarketColorInstance instance, string productId, bool isGlobal, IEnumerable<ExistingImitationRequest> existing)
    {
        ArgumentNullException.ThrowIfNull(instance);
        ArgumentNullException.ThrowIfNull(existing);
        if (!IsEligibleIndustrialInstance(instance))
        {
            return RuleResult.Ok;
        }

        if (type != ImitationRequestType.Adaptation)
        {
            return RuleResult.Fail(AdaptationMessages.OnlyAdaptation);
        }

        var duplicate = existing.Any(r => r.IsActive
            && r.Type == ImitationRequestType.Adaptation
            && r.InstanceId == instance.Id
            && r.IsGlobal == isGlobal
            && string.Equals(r.ProductId, productId, StringComparison.OrdinalIgnoreCase));
        return duplicate ? RuleResult.Fail(AdaptationMessages.Duplicate) : RuleResult.Ok;
    }

    /// <summary>AC-05, AC-06: the measured, Active/Actual, Global/Standard instance of the same Market Color.</summary>
    /// <param name="industrial">Selected Industrial instance.</param>
    /// <param name="candidates">Instances of the same Market Color.</param>
    /// <returns>The reference instance, or the approved warning.</returns>
    public static (MarketColorInstance? Reference, string? Warning) ResolveReferenceColor(MarketColorInstance industrial, IEnumerable<MarketColorInstance> candidates)
    {
        ArgumentNullException.ThrowIfNull(industrial);
        ArgumentNullException.ThrowIfNull(candidates);
        var standard = candidates.FirstOrDefault(c => c.MarketColorId == industrial.MarketColorId
            && c.IsActive
            && c.IsActual
            && c.HasMeasurement
            && string.Equals(c.Role, GlobalRole, StringComparison.OrdinalIgnoreCase)
            && string.Equals(c.KindOfVariation, StandardKind, StringComparison.OrdinalIgnoreCase));
        return standard is null ? (null, AdaptationMessages.MissingMeasurement) : (standard, null);
    }

    /// <summary>AC-08: IR name = instance name + production-line suffix + '_' (assumption Q-02).</summary>
    /// <param name="instance">Instance.</param>
    /// <returns>Name.</returns>
    public static string BuildName(MarketColorInstance instance)
    {
        ArgumentNullException.ThrowIfNull(instance);
        return instance.Name + instance.VariantSuffix + "_";
    }

    /// <summary>AC-09, AC-10: PS Level is Adapted for Adaptation and empty for other types.</summary>
    /// <param name="type">IR type.</param>
    /// <returns>Level or null.</returns>
    public static string? PaintSystemLevel(ImitationRequestType type) =>
        type == ImitationRequestType.Adaptation ? AdaptedLevel : null;

    /// <summary>AC-12: processing needs the imitation request and the development tool.</summary>
    /// <param name="imitationRequestId">cdms_imitationrequestid.</param>
    /// <param name="developmentTool">cdms_developmenttool.</param>
    /// <returns>True when processing may start.</returns>
    public static bool CanProcess(Guid? imitationRequestId, int? developmentTool) =>
        imitationRequestId.HasValue && developmentTool.HasValue;

    /// <summary>AC-11: ColorApps and OwnColor create Color Imitation and Formula (layer 1).</summary>
    /// <param name="developmentTool">Development tool option value.</param>
    /// <returns>True when Color Imitation and Formula are created.</returns>
    public static bool CreatesColorImitationAndFormula(int developmentTool) =>
        developmentTool is ColorApps or OwnColor;

    /// <summary>AC-13: a new paint system without a matching Product/Color/Geo paint system starts at 1.1.</summary>
    /// <param name="matchingPaintSystems">Number of matching paint systems.</param>
    /// <returns>The version, or null when the follow-up rule (Q-04) applies.</returns>
    public static string? InitialVersion(int matchingPaintSystems) =>
        matchingPaintSystems == 0 ? FirstVersion : null;

    /// <summary>AC-14, AC-15: previous paint systems that become Historic on actualization.</summary>
    /// <param name="isAutomotive">Owner is Automotive.</param>
    /// <param name="productionLine">Production line of the actualized paint system.</param>
    /// <param name="previous">Previous related paint systems.</param>
    /// <returns>Ids to set Historic.</returns>
    public static IReadOnlyList<Guid> ToHistoric(bool isAutomotive, string? productionLine, IEnumerable<PreviousPaintSystem> previous)
    {
        ArgumentNullException.ThrowIfNull(previous);
        return previous
            .Where(p => !isAutomotive || string.Equals(p.ProductionLine, productionLine, StringComparison.OrdinalIgnoreCase))
            .Select(p => p.Id)
            .ToList();
    }

    /// <summary>AC-16: actualization updates the selected instance itself to Global/Industry with the production-line suffix.</summary>
    /// <param name="instance">Selected Industrial instance.</param>
    /// <param name="productionLineShortName">Production-line short name.</param>
    /// <returns>The same instance, updated.</returns>
    public static MarketColorInstance Promote(MarketColorInstance instance, string productionLineShortName)
    {
        ArgumentNullException.ThrowIfNull(instance);
        return instance with { Role = GlobalRole, KindOfVariation = IndustryKind, VariantSuffix = "(" + productionLineShortName + ")" };
    }
}
