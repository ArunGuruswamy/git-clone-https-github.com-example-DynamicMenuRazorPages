using Formula.Application.ImitationRequest;

namespace Formula.Application.Tests;

[TestClass]
public sealed class AdaptationRulesTests
{
    private static readonly Guid MarketColor = Guid.NewGuid();

    private static MarketColorInstance Industrial(string suffix = "FICESC") =>
        new(Guid.NewGuid(), MarketColor, "SES1A__3", IsActive: true, "Industrial", KindOfVariation: null, suffix, IsActual: true, HasMeasurement: false);

    private static MarketColorInstance Standard(bool measured = true) =>
        new(Guid.NewGuid(), MarketColor, "SES1A", IsActive: true, "Global", "Standard", VariantSuffix: null, IsActual: true, measured);

    [TestMethod]
    public void AC02_OnlyActiveIndustrialWithoutKindOfVariationAndWithSuffixIsEligible()
    {
        var eligible = Industrial();
        Assert.IsTrue(AdaptationRules.IsEligibleIndustrialInstance(eligible));
        Assert.IsFalse(AdaptationRules.IsEligibleIndustrialInstance(eligible with { IsActive = false }));
        Assert.IsFalse(AdaptationRules.IsEligibleIndustrialInstance(eligible with { Role = "Global" }));
        Assert.IsFalse(AdaptationRules.IsEligibleIndustrialInstance(eligible with { KindOfVariation = "Industry" }));
        Assert.IsFalse(AdaptationRules.IsEligibleIndustrialInstance(eligible with { VariantSuffix = " " }));
    }

    [TestMethod]
    public void AC03_DuplicateActiveAdaptationIsBlockedWithExactMessage()
    {
        var mci = Industrial();
        var existing = new[] { new ExistingImitationRequest(mci.Id, "P1", IsGlobal: true, ImitationRequestType.Adaptation, IsActive: true) };

        var result = AdaptationRules.ValidateCreate(ImitationRequestType.Adaptation, mci, "p1", isGlobal: true, existing);

        Assert.IsFalse(result.Success);
        Assert.AreEqual("Active imitation request already exists for same Market Color - \"Industrial\" instance and Product", result.Message);
        Assert.IsTrue(AdaptationRules.ValidateCreate(ImitationRequestType.Adaptation, mci, "P1", isGlobal: false, existing).Success);
        Assert.IsTrue(AdaptationRules.ValidateCreate(ImitationRequestType.Adaptation, mci, "P1", true, [existing[0] with { IsActive = false }]).Success);
        Assert.IsTrue(AdaptationRules.ValidateCreate(ImitationRequestType.Adaptation, mci, "P1", true, [existing[0] with { Type = ImitationRequestType.Industrialization }]).Success);
    }

    [TestMethod]
    public void AC04_OtherTypeOnIndustrialInstanceIsBlockedWithExactMessage()
    {
        var result = AdaptationRules.ValidateCreate(ImitationRequestType.ImprovedFormula, Industrial(), "P1", true, []);

        Assert.IsFalse(result.Success);
        Assert.AreEqual("Only Adaption is allowed; Paint system does not exist for this Market Color Instance and Product", result.Message);
        Assert.IsTrue(AdaptationRules.ValidateCreate(ImitationRequestType.ImprovedFormula, Standard(), "P1", true, []).Success);
    }

    [TestMethod]
    public void AC05_ReferenceColorIsTheMeasuredGlobalStandardOfTheSameMarketColor()
    {
        var standard = Standard();
        var other = standard with { Id = Guid.NewGuid(), MarketColorId = Guid.NewGuid() };

        var (reference, warning) = AdaptationRules.ResolveReferenceColor(Industrial(), [other, standard]);

        Assert.AreEqual(standard, reference);
        Assert.IsNull(warning);
    }

    [TestMethod]
    public void AC06_MissingMeasurementReturnsExactWarning()
    {
        var (reference, warning) = AdaptationRules.ResolveReferenceColor(Industrial(), [Standard(measured: false)]);

        Assert.IsNull(reference);
        Assert.AreEqual("Standard does not have measurement, Kindly add measurement for the Standard instance", warning);
    }

    [TestMethod]
    public void AC07_DifferentProductionLinesOfOneMarketColorDoNotBlockEachOther()
    {
        var lineA = Industrial("FICESC");
        var lineB = Industrial("TSL");
        var existing = new[] { new ExistingImitationRequest(lineA.Id, "P1", true, ImitationRequestType.Adaptation, true) };

        Assert.IsTrue(AdaptationRules.ValidateCreate(ImitationRequestType.Adaptation, lineB, "P1", true, existing).Success);
    }

    [TestMethod]
    public void AC08_NameIncludesProductionLineSuffix()
    {
        Assert.AreEqual("SES1A__3FICESC_", AdaptationRules.BuildName(Industrial()));
    }

    [TestMethod]
    public void AC09_AC10_PaintSystemLevel()
    {
        Assert.AreEqual("Adapted", AdaptationRules.PaintSystemLevel(ImitationRequestType.Adaptation));
        Assert.IsNull(AdaptationRules.PaintSystemLevel(ImitationRequestType.Industrialization));
    }

    [TestMethod]
    public void AC11_ColorAppsAndOwnColorCreateColorImitationAndFormula()
    {
        Assert.IsTrue(AdaptationRules.CreatesColorImitationAndFormula(2));
        Assert.IsTrue(AdaptationRules.CreatesColorImitationAndFormula(4));
        Assert.IsFalse(AdaptationRules.CreatesColorImitationAndFormula(1));
    }

    [TestMethod]
    public void AC12_ProcessingStopsWithoutImitationRequestOrDevelopmentTool()
    {
        Assert.IsTrue(AdaptationRules.CanProcess(Guid.NewGuid(), 2));
        Assert.IsFalse(AdaptationRules.CanProcess(null, 2));
        Assert.IsFalse(AdaptationRules.CanProcess(Guid.NewGuid(), null));
    }

    [TestMethod]
    public void AC13_NewPaintSystemStartsAtOnePointOne()
    {
        Assert.AreEqual("1.1", AdaptationRules.InitialVersion(0));
        Assert.IsNull(AdaptationRules.InitialVersion(1));
    }

    [TestMethod]
    public void AC14_NonAutomotiveMakesAllPreviousHistoric()
    {
        var previous = new[] { new PreviousPaintSystem(Guid.NewGuid(), "A"), new PreviousPaintSystem(Guid.NewGuid(), null) };
        Assert.AreEqual(2, AdaptationRules.ToHistoric(isAutomotive: false, "A", previous).Count);
    }

    [TestMethod]
    public void AC15_AutomotiveOnlyMatchingProductionLineBecomesHistoric()
    {
        var match = new PreviousPaintSystem(Guid.NewGuid(), "FICESC");
        var other = new PreviousPaintSystem(Guid.NewGuid(), "TSL");

        var historic = AdaptationRules.ToHistoric(isAutomotive: true, "ficesc", [match, other]);

        Assert.AreEqual(1, historic.Count);
        Assert.AreEqual(match.Id, historic[0]);
    }

    [TestMethod]
    public void AC16_ActualizationUpdatesTheSameInstance()
    {
        var mci = Industrial();

        var promoted = AdaptationRules.Promote(mci, "FICESC");

        Assert.AreEqual(mci.Id, promoted.Id);
        Assert.AreEqual("Global", promoted.Role);
        Assert.AreEqual("Industry", promoted.KindOfVariation);
        Assert.AreEqual("(FICESC)", promoted.VariantSuffix);
    }
}
