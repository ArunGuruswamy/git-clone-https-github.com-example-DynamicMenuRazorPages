# AdaptationImitationRequest - Specification

- PBI ID: 305912
- PBI title: [CAA] [DAB API] Creation of Imitation Request & Paint System - Adaptation
- Feature folder: AdaptationImitationRequest
- Primary project role: Dab
- PBI input package: `docs/sdd/pbi-input/305912` (5 files)
- SDD agent: v3.0.5
- Refined PBI approval: Pending (status: Blocked)
- Technical feasibility review: Pending

## Refined PBI (verbatim source)

<!-- sdd:pbi-source:begin sha256=082e5c24f5bd29a6d46b7d222d1a6a36599c8c00fae3d0c2d2e79c9f11d937f4 -->
````markdown
# 305912 - [CAA] [DAB API] Creation of Imitation Request & Paint System - Adaptation

Status: Blocked

## Business objective and user story

Enable Formula App users to create an Adaptation Imitation Request (IR) and Paint System (PS) for an eligible active Industrial Market Color Instance (MCI), with reference color sourced from the related Standard MCI, production-line-aware naming, and the requested PS creation and history behavior.

As a Formula App user, I want to create an Adaptation IR and PS for an Industrial MCI by completing mandatory fields and applicable BU optional fields, so that I can manage an Adaptation process for the selected production line.

## Current behavior and supporting evidence

**CONFIRMED - Adaptation lookup:** For Adaptation (`800000001`), the IR form filters Color Name to Active MCIs with role Industrial (`800000005`). It does not filter Kind of Variation to empty or require a Variant Suffix/production line. `Source/WebResources/ANAAC.DDC.ColorApps.WebResources/Scripts/OnloadImitationRequest.js`, `addFilter`.

**CONFIRMED - generic duplicate rule:** Backend duplicate checking uses MCI, Product, Local/Global, and statuses Awaiting Development or In Development. The current message is generic and does not identify an Industrial instance or Adaptation. `Source/Formula/ImitationRequest/ImitationRequest/ClsPostOnSaveImitationRequest.cs`, `CheckActiveImitationRequestWithProduct`.

**CONFIRMED - no IR-type exclusivity validation:** Adaptation, Industrialization, and Digital Variant bypass `CheckImitationRequestStatus`; the reviewed backend does not enforce that an Industrial MCI can be used only for Adaptation. Same source, `CheckImitationRequestStatus`.

**CONFIRMED - existing reference-color client logic:** On a new Adaptation IR, the form searches for an Active/Actual MCI of Kind of Variation Standard (`800000009`) under the same Market Color and joins through Color to Measurement. It sets that result as Reference Color when found. The filter does not explicitly require Global role, and no specific warning is shown when no measured Standard instance is found. `Source/WebResources/ANAAC.DDC.ColorApps.WebResources/Scripts/OnSaveImitationRecord.js`, `LoadColorReferences` and `setStandardReferenceColor`.

**CONFIRMED - server accepts supplied reference color:** IR create/update uses `cdms_referencecolorid` to create/update Target Color. The reviewed server validation does not require Reference Color or validate its measurement. `Source/Formula/ImitationRequest/ImitationRequest/ClsPostOnSaveImitationRequest.cs`, `CreateUpdateImitationRequest`.

**CONFIRMED - PS level:** The existing PS UI sets PS Level to the IR option value for both Industrialization and Adaptation. It does not clear or lock the field for other types; the targeted backend branch has no PS Level assignment. `Source/WebResources/ANAAC.DDC.ColorApps.WebResources/Scripts/PaintSystemLib.js`, `GetImitationRequestDetails`; targeted `Source/Formula/PaintSystem` search.

**CONFIRMED - PS processing:** Adaptation shares the Improved Formula and Industrialization processing branch. It validates required PS references before this branch, retrieves existing PS records by product/color/Geo, and applies ColorApps/OwnColor creation behavior through the existing helper flow. `Source/Formula/PaintSystem/PaintSystem/PaintSystemOperations.cs`, `ExecutePaintSystemOperation`.

**CONFIRMED - versioning limitation:** Automotive recalculation is applied only when IR type is Improved Formula (`2`), not Adaptation. Therefore the requested version/alternative rule is not confirmed for Adaptation. Same source, `ExecutePaintSystemOperation` and `ReCalculateVersionForImproveFormula`.

**CONFIRMED - history limitation:** The Automotive production-line association handler selects only Improved Formula IRs. The shared Adaptation branch invokes Improved Formula history handling when PS becomes Actual, but Adaptation applicability and its behavior before a production-line association need feasibility review. Same source, `AssociateProductionLine` and `ChangePaintSystemStatusForImprovedFormula`.

**CONFIRMED - adaptation actualization:** For ColorApps, successful Adaptation actualization updates the selected existing MCI to Global, Industry, promoted date, and a production-line suffix. It explicitly does not replace its Color Point; the reviewed source uses `DateTime.Now`, assigns `(<short name>)`, and does not contain the supplied `Update4Adaptation` or `CreateVariantSuffix` methods. `Source/Formula/PaintSystem/PaintSystem/PaintSystemStatusChange.cs`.

## Expected behavior

1. Adaptation IR can use only an Active Industrial MCI with empty Kind of Variation and a production-line Variant Suffix.
2. A duplicate active Adaptation IR for the same Industrial MCI, Product, and Local/Global combination is blocked with the specified Industrial-instance message.
3. An Industrial MCI permits Adaptation only; another IR type is blocked with the specified message.
4. The form automatically uses the same-Market-Color Standard Global MCI as Reference Color only when it has measurement data; otherwise it shows the specified warning and prevents the requested flow from continuing.
5. Multiple Industrial MCIs for one Market Color remain separately usable for same or different production lines.
6. The IR name includes the selected Industrial MCI's production-line suffix according to an approved naming rule.
7. Adaptation PS Level is `Adapted`; other IR types have no PS Level value and it is locked.
8. PS creation preserves required-reference checks, development-tool behavior, Color Imitation/Formula creation, conversion-to-all-products handling, and product association rules.
9. New PS version/alternative behavior follows an agreed rule beginning with `1.1`.
10. On actualization, non-Automotive historic handling and Automotive production-line historic handling meet the stated outcomes.
11. Adaptation updates the existing selected MCI rather than creating a new MCI; the Color Point behavior is conditional only if explicitly approved and technically feasible.

## In scope

- Adaptation eligibility, lookup filtering, duplicate validation, IR-type restriction, Reference Color retrieval/validation, and IR naming.
- Adaptation PS Level, PS creation, version/alternative numbering, product association, and actualization history behavior.
- Adaptation update of the selected MCI and the requested conditional Color Point behavior.

## Out of scope

- Other IR types and unrelated MCI workflows, except their requested PS Level empty/locked behavior.
- Changes to DAB or CDMS repositories. They are not configured in `playbook/pbi-builder/sources.yaml`.
- Application-code changes, Azure DevOps publication, permissions changes, and technical design during PBI refinement.

## Business rules

| ID | Rule | Evidence / decision | Confidence / unresolved issue |
| --- | --- | --- | --- |
| BR-01 | Adaptation is available only for an Active Industrial MCI with empty Kind of Variation and production-line Variant Suffix. | Intake; current lookup only checks Active + Industrial role. | Requested; suffix/KoV enforcement needs feasibility review. |
| BR-02 | Multiple Industrial MCIs of one Market Color may support Adaptation, including same or different production lines. | Intake. | Requested. |
| BR-03 | Block a duplicate active Adaptation IR for the same Industrial MCI, Product, and Local/Global with the specified message. | Intake; generic duplicate check is current precedent. | Requested. |
| BR-04 | Only Adaptation is allowed for an eligible Industrial MCI; other IR types show the specified message. | Intake; no reviewed enforcement. | Requested. |
| BR-05 | Reference Color is the measured, Active/Actual, Global/Standard MCI of the same Market Color. Missing measurement shows the specified warning. | Intake; existing client selects measured Active/Actual Standard MCI without explicit Global check or warning. | Requested. |
| BR-06 | Reference Color retrieval for Adaptation uses a new API. | Intake; existing implementation is client-side FetchXML. | Needs PO/BA clarification of required observable outcome versus integration constraint. |
| BR-07 | Adaptation IR name includes the selected Industrial MCI's production-line suffix. | Intake; no confirmed source implementation. | Naming punctuation and update behavior need decision. |
| BR-08 | Adaptation sets PS Level to `Adapted`; other IR types leave it empty and locked. | Intake; UI currently assigns Adaptation/Industrialization values, backend does not enforce clearing/locking. | Change required. |
| BR-09 | Stop PS processing if `cdms_imitationrequestid` or `cdms_developmenttool` is missing. | Intake and existing PS flow. | Confirmed current behavior. |
| BR-10 | ColorApps (`2`) or OwnColor (`4`) create Color Imitation and Formula with layer `1`. | Intake; creation branch confirmed, layer detail not traced. | Partially confirmed. |
| BR-11 | Existing PS matching uses Product, Color, and Geo; conversion/product association rules apply. | Intake and shared Adaptation branch. | Partially confirmed. |
| BR-12 | New PS starts at version/alternative `1.1`; subsequent version rule needs confirmation. | Intake; existing Automotive recalculation is Improved Formula only. | Blocking technical feasibility issue. |
| BR-13 | Non-Automotive makes prior related PS Historic; Automotive uses production-line matching and leaves unmatched lines unchanged. | Intake; current production-line association is Improved Formula only. | Adaptation applicability needs feasibility review. |
| BR-14 | Successful Adaptation modifies the existing selected MCI to Global/Industry, sets promoted date, and updates suffix using approved production-line logic. | Intake; close current precedent exists. | Requested exact suffix rule needs confirmation. |
| BR-15 | Color Point replacement is conditional behind the stated compilation flag and disabled in production builds by default. | Intake; current Adaptation code does not replace it. | Needs explicit business approval and feasibility review. |

## Acceptance criteria

| ID | Given | When | Then |
| --- | --- | --- | --- |
| AC-01 | An MCI is Active, Industrial, has empty Kind of Variation, and a production-line Variant Suffix | User selects Adaptation | Color Name offers that MCI. |
| AC-02 | An MCI is inactive, not Industrial, has non-empty Kind of Variation, or has no production-line suffix | User selects Adaptation | Color Name does not offer that MCI. |
| AC-03 | An active Adaptation IR exists for the same Industrial MCI, Product, and Local/Global | User saves another Adaptation IR | Save is blocked with `Active imitation request already exists for same Market Color - "Industrial" instance and Product`. |
| AC-04 | An eligible Industrial MCI is selected | User selects any IR type other than Adaptation | Save is blocked with `Only Adaption is allowed; Paint system does not exist for this Market Color Instance and Product`. |
| AC-05 | The selected Industrial MCI's Market Color has an Active/Actual Global/Standard MCI with a measurement | User selects Adaptation and Color Name | Reference Color is populated with that Standard MCI. |
| AC-06 | The selected Industrial MCI's Market Color has no qualifying measured Standard MCI | User selects Adaptation and Color Name | The warning `Standard does not have measurement, Kindly add measurement for the Standard instance` is displayed and creation cannot proceed. |
| AC-07 | Two eligible Industrial MCIs represent different production lines for one Market Color | User creates Adaptation IRs for each | Both may be created subject to their own duplicate combinations. |
| AC-08 | Industrial MCI `SES1A__3` has production-line suffix `FICESC` | User creates an Adaptation IR | IR name follows the approved suffix naming convention, including `SES1A__3FICESC_` if that example is confirmed as exact. |
| AC-09 | An Adaptation IR creates a PS | User opens or saves the PS | PS Level is `Adapted`. |
| AC-10 | A non-Adaptation IR creates a PS | User opens or saves the PS | PS Level is empty and locked. |
| AC-11 | Required PS references are present and Development Tool is ColorApps or OwnColor | User creates a PS | PS, Color Imitation, and Formula are created under the applicable existing rules. |
| AC-12 | `cdms_imitationrequestid` or `cdms_developmenttool` is absent | PS processing starts | Processing stops. |
| AC-13 | No matching Product/Color/Geo PS exists | User creates an Adaptation PS | Version/Alternative is `1.1`. |
| AC-14 | A non-Automotive Adaptation PS becomes Actual | Prior related PS records exist | Prior related PS records become Historic. |
| AC-15 | An Automotive Adaptation PS becomes Actual and older PS records have different production lines | Actualization completes | Only the approved matching production-line records become Historic; unmatched-line records remain unchanged. |
| AC-16 | Adaptation actualization succeeds | The selected Industrial MCI is updated | The existing MCI, rather than a new MCI, receives the approved Global/Industry, suffix, and promotion updates. |

## Examples, exceptions and boundary cases

- Positive: Two eligible Industrial MCIs for Market Color `MC-1`, with different production-line suffixes, can each have one active Adaptation IR for Product `P1` and the same Local/Global value.
- Negative: An Industrial MCI without a measured qualifying Standard MCI cannot proceed and receives the specified warning.
- Boundary: A duplicate check must distinguish Industrial MCIs, so different production lines do not incorrectly block each other.
- Boundary: An existing suffix `(B)` and short name `TSL` is expected by the intake to result in `(B)TSL`; whether parentheses are always required remains unresolved.

## Permissions and business validations

- Existing role and field-level permissions were not reviewed; no permission changes are assumed.
- Existing IR mandatory fields confirmed in source: Market Color Instance, IR Type, Product, Local/Global, Urgency, and Due Date.
- BU optional fields were not supplied and remain UNKNOWN.

## Dependencies and affected business areas

- Imitation Request form/client scripts and server validation.
- Reference Color/measurement records and a requested DAB API, whose repository is not configured.
- Paint System form, operations, versioning, actualization, and production-line associations.
- Market Color Instance, Production Line, Color Imitation, Formula, and Automotive ownership data.

## Open questions and blockers

See `OPEN-QUESTIONS.md`.

## PO/BA decisions

See `DECISION-LOG.md`.

## Review status

- Business approval: Pending
- Technical feasibility review: Pending
- Blocking questions: Q-01 pending
- Readiness: Blocked
````
<!-- sdd:pbi-source:end -->

## Acceptance criteria

- **AC-01** - Given An MCI is Active, Industrial, has empty Kind of Variation, and a production-line Variant Suffix; When User selects Adaptation; Then Color Name offers that MCI.
- **AC-02** - Given An MCI is inactive, not Industrial, has non-empty Kind of Variation, or has no production-line suffix; When User selects Adaptation; Then Color Name does not offer that MCI.
- **AC-03** - Given An active Adaptation IR exists for the same Industrial MCI, Product, and Local/Global; When User saves another Adaptation IR; Then Save is blocked with `Active imitation request already exists for same Market Color - "Industrial" instance and Product`.
- **AC-04** - Given An eligible Industrial MCI is selected; When User selects any IR type other than Adaptation; Then Save is blocked with `Only Adaption is allowed; Paint system does not exist for this Market Color Instance and Product`.
- **AC-05** - Given The selected Industrial MCI's Market Color has an Active/Actual Global/Standard MCI with a measurement; When User selects Adaptation and Color Name; Then Reference Color is populated with that Standard MCI.
- **AC-06** - Given The selected Industrial MCI's Market Color has no qualifying measured Standard MCI; When User selects Adaptation and Color Name; Then The warning `Standard does not have measurement, Kindly add measurement for the Standard instance` is displayed and creation cannot proceed.
- **AC-07** - Given Two eligible Industrial MCIs represent different production lines for one Market Color; When User creates Adaptation IRs for each; Then Both may be created subject to their own duplicate combinations.
- **AC-08** - Given Industrial MCI `SES1A__3` has production-line suffix `FICESC`; When User creates an Adaptation IR; Then IR name follows the approved suffix naming convention, including `SES1A__3FICESC_` if that example is confirmed as exact.
- **AC-09** - Given An Adaptation IR creates a PS; When User opens or saves the PS; Then PS Level is `Adapted`.
- **AC-10** - Given A non-Adaptation IR creates a PS; When User opens or saves the PS; Then PS Level is empty and locked.
- **AC-11** - Given Required PS references are present and Development Tool is ColorApps or OwnColor; When User creates a PS; Then PS, Color Imitation, and Formula are created under the applicable existing rules.
- **AC-12** - Given `cdms_imitationrequestid` or `cdms_developmenttool` is absent; When PS processing starts; Then Processing stops.
- **AC-13** - Given No matching Product/Color/Geo PS exists; When User creates an Adaptation PS; Then Version/Alternative is `1.1`.
- **AC-14** - Given A non-Automotive Adaptation PS becomes Actual; When Prior related PS records exist; Then Prior related PS records become Historic.
- **AC-15** - Given An Automotive Adaptation PS becomes Actual and older PS records have different production lines; When Actualization completes; Then Only the approved matching production-line records become Historic; unmatched-line records remain unchanged.
- **AC-16** - Given Adaptation actualization succeeds; When The selected Industrial MCI is updated; Then The existing MCI, rather than a new MCI, receives the approved Global/Industry, suffix, and promotion updates.

## Repository fit

Checked by `sdd start` against this Dab repository:

- [BLOCKED] The PBI is BLOCKED (Status: Blocked; Readiness: Blocked); blocking question(s): Q-01. Implementing it now risks rework.
- [WARN] Out of scope mentions DAB: "Changes to DAB or CDMS repositories. They are not configured in `playbook/pbi-builder/sources.yaml`". Confirm this repository is in scope for implementation.
- [WARN] None of the 7 source files cited as evidence exist in this repository (e.g. `Source/WebResources/ANAAC.DDC.ColorApps.WebResources/Scripts/OnloadImitationRequest.js`). The evidence describes another codebase: trace every AC in this repository before relying on 'current behaviour'.
- [WARN] 5 of 16 AC(s) describe form/UI behaviour (AC-01, AC-02, AC-05, AC-06, AC-10). In plan.md mark each 'Applies here' as Yes, Partial (the DAB part, e.g. the API or validation) or No - <owning repository>.
- [INFO] Title tag [DAB API] matches this DAB repository.

- BLOCKED: developer chose Q-BIZ 'proceed' after PO confirmation in chat; Q-01 answered by assumption (promote to Global/Industry as current legacy code). Recorded in approval.json and the PR.
- Out of scope mentions DAB: that line describes the PBI Builder refinement scope (no DAB source configured), not delivery. Q-FIT = 'here'.
- Cited evidence is legacy CDMS/XRM (`Source/...`). Re-traced in this repository: no Adaptation rules exist; `src/Formula.Application` has no ImitationRequest folder.
- Owned by another repository: AC-01 (UI form lookup). Partial here: AC-02, AC-05, AC-06, AC-10 (API part only).

## PBI sources and attachments

The refined PBI is the source of truth. Other files are evidence and add no scope by themselves.

| File | Size (bytes) | SHA-256 (12) | Status |
|---|---|---|---|
| `DECISION-LOG.md` | 1062 | a5d900c535b8 | Read by sdd |
| `EVIDENCE.md` | 2927 | bbf8d6234088 | Read by sdd |
| `OPEN-QUESTIONS.md` | 1767 | 7ded9a66852e | Read by sdd |
| `REFINED-PBI.md` | 14923 | c3a4244720c4 | Read by sdd |
| `REQUEST.md` | 6775 | abe74f1c9eb3 | Read by sdd |

## Decisions (DECISION-LOG.md)

| ID | Decision | Status | Affected |
|---|---|---|---|
| D-01 | Adaptation is limited to active Industrial MCIs with empty Kind of Variation and a production-line suffix. | Proposed | - |
| D-02 | The Reference Color outcome requires a measured Global/Standard MCI and the specified missing-measurement warning. | Proposed | - |
| D-03 | Adaptation PS Level is `Adapted`; other types are empty and locked. | Proposed | - |
| D-04 | Adaptation promotes the selected existing Industrial MCI to Global/Industry after actualization. | Proposed | - |
| D-05 | Conditional Color Point replacement is required and disabled by default in production. | Proposed | - |

## Open questions

5 recorded, 5 unresolved.

- Q-01 [OPEN] After successful Adaptation, should the selected Industrial MCI always be promoted to Global/Industry and therefore no longer be eligible for another Adaptation, or must it remain/revert as an Industrial MCI so the same production line can be adapted again? -> Open - blocking
- Q-02 [OPEN] Is `SES1A__3FICESC_` the exact required IR-name format, including underscore placement and behavior when a suffix already has parentheses? -> Deferred until Q-01 is resolved
- Q-03 [OPEN] Does "new API" mean DAB must be the authoritative source for Reference Color, or is the business requirement satisfied by equivalent automatic population and validation? -> Deferred until Q-01 is resolved
- Q-04 [OPEN] What version/alternative result is expected after existing versions, for example `1.1`, `1.2`, and `2.1`? -> Deferred until Q-01 is resolved
- Q-05 [OPEN] Is conditional Color Point replacement a required production behavior, and who enables the stated compilation flag? -> Deferred until Q-01 is resolved

## Business rules

| ID | Rule | Evidence | Confidence |
|---|---|---|---|
| BR-01 | Adaptation is available only for an Active Industrial MCI with empty Kind of Variation and production-line Variant Suffix. | Intake; current lookup only checks Active + Industrial role. | Requested; suffix/KoV enforcement needs feasibility review. |
| BR-02 | Multiple Industrial MCIs of one Market Color may support Adaptation, including same or different production lines. | Intake. | Requested. |
| BR-03 | Block a duplicate active Adaptation IR for the same Industrial MCI, Product, and Local/Global with the specified message. | Intake; generic duplicate check is current precedent. | Requested. |
| BR-04 | Only Adaptation is allowed for an eligible Industrial MCI; other IR types show the specified message. | Intake; no reviewed enforcement. | Requested. |
| BR-05 | Reference Color is the measured, Active/Actual, Global/Standard MCI of the same Market Color. Missing measurement shows the specified warning. | Intake; existing client selects measured Active/Actual Standard MCI without explicit Global check or warning. | Requested. |
| BR-06 | Reference Color retrieval for Adaptation uses a new API. | Intake; existing implementation is client-side FetchXML. | Needs PO/BA clarification of required observable outcome versus integration constraint. |
| BR-07 | Adaptation IR name includes the selected Industrial MCI's production-line suffix. | Intake; no confirmed source implementation. | Naming punctuation and update behavior need decision. |
| BR-08 | Adaptation sets PS Level to `Adapted`; other IR types leave it empty and locked. | Intake; UI currently assigns Adaptation/Industrialization values, backend does not enforce clearing/locking. | Change required. |
| BR-09 | Stop PS processing if `cdms_imitationrequestid` or `cdms_developmenttool` is missing. | Intake and existing PS flow. | Confirmed current behavior. |
| BR-10 | ColorApps (`2`) or OwnColor (`4`) create Color Imitation and Formula with layer `1`. | Intake; creation branch confirmed, layer detail not traced. | Partially confirmed. |
| BR-11 | Existing PS matching uses Product, Color, and Geo; conversion/product association rules apply. | Intake and shared Adaptation branch. | Partially confirmed. |
| BR-12 | New PS starts at version/alternative `1.1`; subsequent version rule needs confirmation. | Intake; existing Automotive recalculation is Improved Formula only. | Blocking technical feasibility issue. |
| BR-13 | Non-Automotive makes prior related PS Historic; Automotive uses production-line matching and leaves unmatched lines unchanged. | Intake; current production-line association is Improved Formula only. | Adaptation applicability needs feasibility review. |
| BR-14 | Successful Adaptation modifies the existing selected MCI to Global/Industry, sets promoted date, and updates suffix using approved production-line logic. | Intake; close current precedent exists. | Requested exact suffix rule needs confirmation. |
| BR-15 | Color Point replacement is conditional behind the stated compilation flag and disabled in production builds by default. | Intake; current Adaptation code does not replace it. | Needs explicit business approval and feasibility review. |

## Existing implementation and repository evidence



| AC | Status | Evidence (file > class > method) |
|---|---|---|
| AC-01 | MISSING | UI repository (not this repository) |
| AC-02 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > IsEligibleIndustrialInstance` |
| AC-03 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ValidateCreate` |
| AC-04 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ValidateCreate` |
| AC-05 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ResolveReferenceColor` |
| AC-06 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ResolveReferenceColor` |
| AC-07 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ValidateCreate` |
| AC-08 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > BuildName` |
| AC-09 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > PaintSystemLevel` |
| AC-10 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > PaintSystemLevel` |
| AC-11 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > CreatesColorImitationAndFormula` |
| AC-12 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > CanProcess` |
| AC-13 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > InitialVersion` |
| AC-14 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ToHistoric` |
| AC-15 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ToHistoric` |
| AC-16 | MISSING | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > Promote` |

## Delta requirements (ADDED / MODIFIED / REMOVED)

- R-1 (AC-02) ADDED: The system SHALL implement IsEligibleIndustrialInstance for AC-02. Current behaviour: MISSING in this repository.
- R-2 (AC-03) ADDED: The system SHALL implement ValidateCreate for AC-03. Current behaviour: MISSING in this repository.
- R-3 (AC-04) ADDED: The system SHALL implement ValidateCreate for AC-04. Current behaviour: MISSING in this repository.
- R-4 (AC-05) ADDED: The system SHALL implement ResolveReferenceColor for AC-05. Current behaviour: MISSING in this repository.
- R-5 (AC-06) ADDED: The system SHALL implement ResolveReferenceColor for AC-06. Current behaviour: MISSING in this repository.
- R-6 (AC-07) ADDED: The system SHALL implement ValidateCreate for AC-07. Current behaviour: MISSING in this repository.
- R-7 (AC-08) ADDED: The system SHALL implement BuildName for AC-08. Current behaviour: MISSING in this repository.
- R-8 (AC-09) ADDED: The system SHALL implement PaintSystemLevel for AC-09. Current behaviour: MISSING in this repository.
- R-9 (AC-10) ADDED: The system SHALL implement PaintSystemLevel for AC-10. Current behaviour: MISSING in this repository.
- R-10 (AC-11) ADDED: The system SHALL implement CreatesColorImitationAndFormula for AC-11. Current behaviour: MISSING in this repository.
- R-11 (AC-12) ADDED: The system SHALL implement CanProcess for AC-12. Current behaviour: MISSING in this repository.
- R-12 (AC-13) ADDED: The system SHALL implement InitialVersion for AC-13. Current behaviour: MISSING in this repository.
- R-13 (AC-14) ADDED: The system SHALL implement ToHistoric for AC-14. Current behaviour: MISSING in this repository.
- R-14 (AC-15) ADDED: The system SHALL implement ToHistoric for AC-15. Current behaviour: MISSING in this repository.
- R-15 (AC-16) ADDED: The system SHALL implement Promote for AC-16. Current behaviour: MISSING in this repository.

## API and GraphQL contracts

Rules live in `Formula.Application/ImitationRequest/AdaptationRules.cs`, called by the IR create handler and the PS create/actualize handlers (DAB). No GraphQL schema change in this slice; the Reference Color API (Q-03) is a new query on the existing DAB endpoint. UI change: yes (AC-01, form parts of AC-02/05/06/10) in the UI repository.

## Validation rules and messages

Approved user-visible messages (verbatim; implement as constants, assert exact text in tests):

- `Active imitation request already exists for same Market Color - "Industrial" instance and Product`
- `Only Adaption is allowed; Paint system does not exist for this Market Color Instance and Product`
- `Standard does not have measurement, Kindly add measurement for the Standard instance`

`RuleResult.Fail(message)` returned to the handler, mapped to the existing 400 validation envelope; messages are constants in `AdaptationMessages`.

## Testable scenarios

### AC-01
GIVEN An MCI is Active, Industrial, has empty Kind of Variation, and a production-line Variant Suffix
WHEN User selects Adaptation
THEN Color Name offers that MCI.

### AC-02
GIVEN An MCI is inactive, not Industrial, has non-empty Kind of Variation, or has no production-line suffix
WHEN User selects Adaptation
THEN Color Name does not offer that MCI.

### AC-03
GIVEN An active Adaptation IR exists for the same Industrial MCI, Product, and Local/Global
WHEN User saves another Adaptation IR
THEN Save is blocked with `Active imitation request already exists for same Market Color - "Industrial" instance and Product`.

### AC-04
GIVEN An eligible Industrial MCI is selected
WHEN User selects any IR type other than Adaptation
THEN Save is blocked with `Only Adaption is allowed; Paint system does not exist for this Market Color Instance and Product`.

### AC-05
GIVEN The selected Industrial MCI's Market Color has an Active/Actual Global/Standard MCI with a measurement
WHEN User selects Adaptation and Color Name
THEN Reference Color is populated with that Standard MCI.

### AC-06
GIVEN The selected Industrial MCI's Market Color has no qualifying measured Standard MCI
WHEN User selects Adaptation and Color Name
THEN The warning `Standard does not have measurement, Kindly add measurement for the Standard instance` is displayed and creation cannot proceed.

### AC-07
GIVEN Two eligible Industrial MCIs represent different production lines for one Market Color
WHEN User creates Adaptation IRs for each
THEN Both may be created subject to their own duplicate combinations.

### AC-08
GIVEN Industrial MCI `SES1A__3` has production-line suffix `FICESC`
WHEN User creates an Adaptation IR
THEN IR name follows the approved suffix naming convention, including `SES1A__3FICESC_` if that example is confirmed as exact.

### AC-09
GIVEN An Adaptation IR creates a PS
WHEN User opens or saves the PS
THEN PS Level is `Adapted`.

### AC-10
GIVEN A non-Adaptation IR creates a PS
WHEN User opens or saves the PS
THEN PS Level is empty and locked.

### AC-11
GIVEN Required PS references are present and Development Tool is ColorApps or OwnColor
WHEN User creates a PS
THEN PS, Color Imitation, and Formula are created under the applicable existing rules.

### AC-12
GIVEN `cdms_imitationrequestid` or `cdms_developmenttool` is absent
WHEN PS processing starts
THEN Processing stops.

### AC-13
GIVEN No matching Product/Color/Geo PS exists
WHEN User creates an Adaptation PS
THEN Version/Alternative is `1.1`.

### AC-14
GIVEN A non-Automotive Adaptation PS becomes Actual
WHEN Prior related PS records exist
THEN Prior related PS records become Historic.

### AC-15
GIVEN An Automotive Adaptation PS becomes Actual and older PS records have different production lines
WHEN Actualization completes
THEN Only the approved matching production-line records become Historic; unmatched-line records remain unchanged.

### AC-16
GIVEN Adaptation actualization succeeds
WHEN The selected Industrial MCI is updated
THEN The existing MCI, rather than a new MCI, receives the approved Global/Industry, suffix, and promotion updates.

