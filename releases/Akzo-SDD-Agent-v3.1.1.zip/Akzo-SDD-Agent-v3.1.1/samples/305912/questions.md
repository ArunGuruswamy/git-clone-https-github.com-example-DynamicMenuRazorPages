# Pending questions

Reply with the question id and option number, e.g. `Q-BIZ 1`.

**Q-FEATURE** Feature folder for spec.md and plan.md (current: AdaptationImitationRequest)?
  1. AdaptationImitationRequest (Recommended) - Use .../specs/AdaptationImitationRequest/
  2. ImitationRequestPaintSystem - Use .../specs/ImitationRequestPaintSystem/
  3. CreationOfImitationRequestPaint - Use .../specs/CreationOfImitationRequestPaint/

**Q-BIZ** (required) The refined PBI is BLOCKED (Status: Blocked; Readiness: Blocked; blocking: Q-01) and business approval is Pending. How should I proceed?
  1. Proceed and record it - Analyse and implement; approval.json and the PR state the PBI was not business-approved and was blocked.
  2. Wait for PO/BA (Recommended) - Finish analysis only; implementation stays blocked until the PBI is approved.

**Q-FIT** (required) The PBI does not fully fit this DAB repository: Out of scope mentions DAB: "Changes to DAB or CDMS repositories. They are not configured in `playbook/pbi-builder/sources.yaml`". Confirm this repository is in scope for implementation. | None of the 7 source files cited as evidence exist in this repository (e.g. `Source/WebResources/ANAAC.DDC.ColorApps.WebResources/Scripts/OnloadImitationRequest.js`). The evidence describes another codebase: trace every AC in this repository before relying on 'current behaviour'. | 5 of 16 AC(s) describe form/UI behaviour (AC-01, AC-02, AC-05, AC-06, AC-10). In plan.md mark each 'Applies here' as Yes, Partial (the DAB part, e.g. the API or validation) or No - <owning repository>. How should I scope it?
  1. Implement what applies here (Recommended) - Mark every AC in plan.md as Yes / Partial / No - <owning repository>; only Yes and Partial are implemented and tested here; the PR lists the rest.
  2. Implement every AC here - Treat the whole PBI as this repository's scope.
  3. Wrong repository / needs PO/BA - Finish analysis only; implementation approval is blocked.

**Q-D-01** (required) Decision D-01 is 'Proposed': "Adaptation is limited to active Industrial MCIs with empty Kind of Variation and a production-line suffix." (affects not stated). Confirm?
  1. Accept for this PBI (Recommended) - Treat it as approved scope; recorded in approval.json.
  2. Reject - Exclude the affected behaviour; plan marks it out of scope.
  3. Needs PO/BA - Keep it open; implementation approval is blocked.

**Q-D-02** (required) Decision D-02 is 'Proposed': "The Reference Color outcome requires a measured Global/Standard MCI and the specified missing-measurement warning." (affects not stated). Confirm?
  1. Accept for this PBI (Recommended) - Treat it as approved scope; recorded in approval.json.
  2. Reject - Exclude the affected behaviour; plan marks it out of scope.
  3. Needs PO/BA - Keep it open; implementation approval is blocked.

**Q-D-03** (required) Decision D-03 is 'Proposed': "Adaptation PS Level is `Adapted`; other types are empty and locked." (affects not stated). Confirm?
  1. Accept for this PBI (Recommended) - Treat it as approved scope; recorded in approval.json.
  2. Reject - Exclude the affected behaviour; plan marks it out of scope.
  3. Needs PO/BA - Keep it open; implementation approval is blocked.

**Q-D-04** (required) Decision D-04 is 'Proposed': "Adaptation promotes the selected existing Industrial MCI to Global/Industry after actualization." (affects not stated). Confirm?
  1. Accept for this PBI (Recommended) - Treat it as approved scope; recorded in approval.json.
  2. Reject - Exclude the affected behaviour; plan marks it out of scope.
  3. Needs PO/BA - Keep it open; implementation approval is blocked.

**Q-D-05** (required) Decision D-05 is 'Proposed': "Conditional Color Point replacement is required and disabled by default in production." (affects not stated). Confirm?
  1. Accept for this PBI (Recommended) - Treat it as approved scope; recorded in approval.json.
  2. Reject - Exclude the affected behaviour; plan marks it out of scope.
  3. Needs PO/BA - Keep it open; implementation approval is blocked.

**Q-01** (required) [BLOCKING] Open question Q-01 (Open - blocking): After successful Adaptation, should the selected Industrial MCI always be promoted to Global/Industry and therefore no longer be eligible for another Adaptation, or must it remain/revert as an Industrial MCI so the same production line can be adapted again? (impact: This determines the lifecycle rule, repeat-Adaptation behavior, lookup eligibility, and the meaning of multiple requests per production line. Current code promotes the existing MCI to Global/Industry.)
  1. I will answer now - Type the answer; it is recorded as a confirmed decision.
  2. Proceed with an assumption - Record an ASSUMPTION in spec.md; not used as a requirement.
  3. Needs PO/BA (Recommended) - Implementation approval is blocked until answered.

**Q-02** (required) Open question Q-02 (Deferred until Q-01 is resolved): Is `SES1A__3FICESC_` the exact required IR-name format, including underscore placement and behavior when a suffix already has parentheses? (impact: Controls observable naming and prevents inconsistent IR names.)
  1. I will answer now - Type the answer; it is recorded as a confirmed decision.
  2. Proceed with an assumption - Record an ASSUMPTION in spec.md; not used as a requirement.
  3. Needs PO/BA - Implementation approval is blocked until answered.

**Q-03** (required) Open question Q-03 (Deferred until Q-01 is resolved): Does "new API" mean DAB must be the authoritative source for Reference Color, or is the business requirement satisfied by equivalent automatic population and validation? (impact: DAB source is unconfigured; determines dependency and delivery scope.)
  1. I will answer now - Type the answer; it is recorded as a confirmed decision.
  2. Proceed with an assumption - Record an ASSUMPTION in spec.md; not used as a requirement.
  3. Needs PO/BA - Implementation approval is blocked until answered.

**Q-04** (required) Open question Q-04 (Deferred until Q-01 is resolved): What version/alternative result is expected after existing versions, for example `1.1`, `1.2`, and `2.1`? (impact: Intake specifies only the initial `1.1`; the legacy Adaptation path does not apply Improved Formula recalculation.)
  1. I will answer now - Type the answer; it is recorded as a confirmed decision.
  2. Proceed with an assumption - Record an ASSUMPTION in spec.md; not used as a requirement.
  3. Needs PO/BA - Implementation approval is blocked until answered.

**Q-05** (required) Open question Q-05 (Deferred until Q-01 is resolved): Is conditional Color Point replacement a required production behavior, and who enables the stated compilation flag? (impact: Existing Adaptation behavior leaves Color Point unchanged; this affects actualization outcomes.)
  1. I will answer now - Type the answer; it is recorded as a confirmed decision.
  2. Proceed with an assumption - Record an ASSUMPTION in spec.md; not used as a requirement.
  3. Needs PO/BA - Implementation approval is blocked until answered.

**Q-MODE** Execution mode after approval?
  1. FAST (Recommended) - Implement all tasks continuously; verify at checkpoints; no per-file pauses.
  2. STEP - One task per message; wait for my build result before the next.

