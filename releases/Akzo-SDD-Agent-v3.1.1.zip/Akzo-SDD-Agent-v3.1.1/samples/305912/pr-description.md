# feat: Creation of Imitation Request & Paint System - Adaptation [SDD]

> **Status: READY FOR PR** - all SDD gates passed.

## 1. Why - PBI
- PBI: #305912 - [CAA] [DAB API] Creation of Imitation Request & Paint System - Adaptation (AB#305912)
- Business approval: Pending; technical review: Pending
- **PBI readiness: BLOCKED** in the package (Readiness: Blocked); developer chose 'proceed'. Assumptions are listed in section 4.
- Role: Dab | Branch: `feature/305912-adaptation` | Mode: FAST
- Spec: `src/.github/specs/AdaptationImitationRequest/spec.md` | Plan: `src/.github/specs/AdaptationImitationRequest/plan.md`
- Approved by Arun on 2026-10-15 17:42 UTC: "Selected: Approve implementation" (hash-bound; unchanged since approval)

## 2. What - delta requirements
- R-1 (AC-02) ADDED: The system SHALL implement IsEligibleIndustrialInstance for AC-02. Current behaviour: MISSING in this repository.
- R-2 (AC-03) ADDED: The system SHALL implement ValidateCreate for AC-03. Current behaviour: MISSING in this repository.
- R-3 (AC-04) ADDED: The system SHALL implement ValidateCreate for AC-04. Current behaviour: MISSING in this repository.
- R-4 (AC-05) ADDED: The system SHALL implement ResolveReferenceColor for AC-05. Current behaviour: MISSING in this repository.
- R-5 (AC-06) ADDED: The system SHALL implement ResolveReferenceColor for AC-06. Current behaviour: MISSING in this repository.
- R-6 (AC-07) ADDED: The system SHALL implement ValidateCreate for AC-07. Current behaviour: MISSING in this repository.
- R-7 (AC-08) ADDED: The system SHALL implement BuildName for AC-08. Current behaviour: MISSING in this repository.
- R-8 (AC-09) ADDED: The system SHALL implement PaintSystemLevel for AC-09. Current behaviour: MISSING in this repository.
- R-9 (AC-10) ADDED: The system SHALL implement PaintSystemLevel for AC-10. Current behaviour: MISSING in this repository.
- R-10 (AC-11) ADDED: The system SHALL implement CreatesColorImitationAndFormula for AC-11. Current behaviour: MISSING in this repository.
- R-11 (AC-12) ADDED: The system SHALL implement CanProcess for AC-12. Current behaviour: MISSING in this repository.
- R-12 (AC-13) ADDED: The system SHALL implement InitialVersion for AC-13. Current behaviour: MISSING in this repository.
- R-13 (AC-14) ADDED: The system SHALL implement ToHistoric for AC-14. Current behaviour: MISSING in this repository.
- R-14 (AC-15) ADDED: The system SHALL implement ToHistoric for AC-15. Current behaviour: MISSING in this repository.
- R-15 (AC-16) ADDED: The system SHALL implement Promote for AC-16. Current behaviour: MISSING in this repository.

## 3. Acceptance criteria traceability (AC -> code -> test)
'Applies here': Yes, Partial (say which part) or No - <owning repository>. Rows marked No need no code or test here (write N/A); they are listed in the PR.

| AC | Expected outcome | Layer (suggested) | Applies here | Code (file > class > method) | Test (class.method) |
|---|---|---|---|---|---|
| AC-01 | Color Name offers that MCI. | UI / form | No - UI repository (Color Name lookup filter on the IR form) | N/A | N/A |
| AC-02 | Color Name does not offer that MCI. | UI / form | Partial - eligibility rule exposed by the API; lookup filter is UI | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > IsEligibleIndustrialInstance` | `AdaptationRulesTests.AC02_OnlyActiveIndustrialWithoutKindOfVariationAndWithSuffixIsEligible` |
| AC-03 | Save is blocked with `Active imitation request already exists for same Market Color - "Industrial" instance and Product`. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ValidateCreate` | `AdaptationRulesTests.AC03_DuplicateActiveAdaptationIsBlockedWithExactMessage` |
| AC-04 | Save is blocked with `Only Adaption is allowed; Paint system does not exist for this Market Color Instance and Product`. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ValidateCreate` | `AdaptationRulesTests.AC04_OtherTypeOnIndustrialInstanceIsBlockedWithExactMessage` |
| AC-05 | Reference Color is populated with that Standard MCI. | UI / form | Partial - new Reference Color API (Q-03); populating the form is UI | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ResolveReferenceColor` | `AdaptationRulesTests.AC05_ReferenceColorIsTheMeasuredGlobalStandardOfTheSameMarketColor` |
| AC-06 | The warning `Standard does not have measurement, Kindly add measurement for the Standard instance` is displayed and creation cannot proceed. | UI / form | Partial - API returns the warning; showing it is UI | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ResolveReferenceColor` | `AdaptationRulesTests.AC06_MissingMeasurementReturnsExactWarning` |
| AC-07 | Both may be created subject to their own duplicate combinations. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ValidateCreate` | `AdaptationRulesTests.AC07_DifferentProductionLinesOfOneMarketColorDoNotBlockEachOther` |
| AC-08 | IR name follows the approved suffix naming convention, including `SES1A__3FICESC_` if that example is confirmed as exact. | API / backend | Yes (assumption Q-02) | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > BuildName` | `AdaptationRulesTests.AC08_NameIncludesProductionLineSuffix` |
| AC-09 | PS Level is `Adapted`. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > PaintSystemLevel` | `AdaptationRulesTests.AC09_AC10_PaintSystemLevel` |
| AC-10 | PS Level is empty and locked. | UI / form | Partial - API leaves it empty; locking the field is UI | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > PaintSystemLevel` | `AdaptationRulesTests.AC09_AC10_PaintSystemLevel` |
| AC-11 | PS, Color Imitation, and Formula are created under the applicable existing rules. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > CreatesColorImitationAndFormula` | `AdaptationRulesTests.AC11_ColorAppsAndOwnColorCreateColorImitationAndFormula` |
| AC-12 | Processing stops. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > CanProcess` | `AdaptationRulesTests.AC12_ProcessingStopsWithoutImitationRequestOrDevelopmentTool` |
| AC-13 | Version/Alternative is `1.1`. | API / backend | Yes (follow-up versions: Q-04 assumption) | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > InitialVersion` | `AdaptationRulesTests.AC13_NewPaintSystemStartsAtOnePointOne` |
| AC-14 | Prior related PS records become Historic. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ToHistoric` | `AdaptationRulesTests.AC14_NonAutomotiveMakesAllPreviousHistoric` |
| AC-15 | Only the approved matching production-line records become Historic; unmatched-line records remain unchanged. | API / backend | Yes | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > ToHistoric` | `AdaptationRulesTests.AC15_AutomotiveOnlyMatchingProductionLineBecomesHistoric` |
| AC-16 | The existing MCI, rather than a new MCI, receives the approved Global/Industry, suffix, and promotion updates. | API / backend | Yes (D-04 accepted; Color Point D-05 rejected) | `src/Formula.Application/ImitationRequest/AdaptationRules.cs > AdaptationRules > Promote` | `AdaptationRulesTests.AC16_ActualizationUpdatesTheSameInstance` |

**Not implemented in this repository (owned elsewhere):**
- AC-01: No - UI repository (Color Name lookup filter on the IR form)

## 4. Decisions applied
- D-01 (Proposed -> developer: accept): Adaptation is limited to active Industrial MCIs with empty Kind of Variation and a production-line suffix.
- D-02 (Proposed -> developer: accept): The Reference Color outcome requires a measured Global/Standard MCI and the specified missing-measurement warning.
- D-03 (Proposed -> developer: accept): Adaptation PS Level is `Adapted`; other types are empty and locked.
- D-04 (Proposed -> developer: accept): Adaptation promotes the selected existing Industrial MCI to Global/Industry after actualization.
- D-05 (Proposed -> developer: reject): Conditional Color Point replacement is required and disabled by default in production.
- Q-D-05: Color Point replacement out of scope for this slice
- Q-01: Promote the selected Industrial MCI to Global/Industry (current legacy behaviour, D-04)
- Q-02: Name = <instance name><suffix>_ as in the example SES1A__3FICESC_
- Q-03: New DAB query returns the Reference Color; form populates it
- Q-04: Only the initial 1.1 is implemented; follow-up versions wait for PO/BA
- Q-05: Not implemented (D-05 rejected)
- Q-BIZ: PO (chat 2026-10-15): proceed with recorded assumptions for Q-01..Q-05

## 5. Files changed
**Specification (approved) (2)**
- `src/.github/specs/AdaptationImitationRequest/plan.md`
- `src/.github/specs/AdaptationImitationRequest/spec.md`
**Production code (1)**
- `src/Formula.Application/ImitationRequest/AdaptationRules.cs`
**Tests (1)**
- `tests/Formula.Application.Tests/AdaptationRulesTests.cs`

## 6. Verification evidence
Scope **final**, run 2026-10-15 17:42 UTC, 4.4s.

| Gate | Result | Evidence |
|---|---|---|
| Build | PASS | `dotnet build src/Formula.Application -c Debug --source <sandbox>/feed -nologo` exit 0 in 1.7s |
| Tests | PASS | 14 executed, 14 passed, 0 failed (source: console summary) |
| Coverage | PASS | 100% line coverage on changed production files (1); threshold 90% |

## 7. Review
- Independent review (Akzo SDD Reviewer): READY FOR PR

## 8. Delivery metrics
| Phase | Started (UTC) | Duration | Tokens in/out (actual) | Tokens in/out (estimated) |
|---|---|---|---|---|
| Start (sdd engine) | 2026-10-15 17:42 | 0.2s | Unknown | Unknown |
| Analysis (agent) | 2026-10-15 17:42 | 3.4s | Unknown | Unknown |
| Implementation (agent) | 2026-10-15 17:42 | 15.3s | Unknown | Unknown |
| Review | 2026-10-15 17:42 | 0.2s | Unknown | Unknown |
| **Total** | | **19.0s** | **Unknown** | **Unknown** |

Deterministic generation by `sdd`: 34,565 characters of spec/plan written without the LLM (about 8,642 output tokens avoided, estimated).

Actual tokens come from the Copilot/provider usage view entered with `sdd tokens --actual`; estimated tokens are characters/4 and are never reported as actual. Unknown means not recorded.

## 9. Reviewer checklist
- [ ] Every AC marked Yes / Partial above has code and a passing test
- [ ] Messages match the approved text exactly (constants)
- [ ] No unplanned files, deletions, suppressions or package changes
- [ ] Contract parity (route, verb, envelope) kept for the UI
