# Akzo SDD Agent v3.1.1 — automated verification and local commit dialog

For C# development with Visual Studio / GitHub Copilot on Windows. PR creation, push and merge remain manual. The original v3.0.8 upload is unchanged.

## Install / upgrade
1. Extract the entire ZIP, including tool/ and agent/.
2. Run Setup-AkzoSddAgent.cmd, select the repository and role. It installs the packaged .NET tool and agent assets.
3. Review team-modified files reported as kept by the installer. The installer intentionally preserves them; reconcile the new workflow/constitution changes before use. Do not force-overwrite team customizations blindly.
4. In Visual Studio, enable Copilot Agent mode with terminal and edit tools, select Akzo SDD Agent, and send `Start Development <PBI-ID> <Feature>` with your PBI package source.

Requires Git for Windows, .NET SDK 8+, compatible .NET runtime, Windows PowerShell 5.1/WPF with an interactive desktop, Copilot entitlement, and your organization's permission to execute the supplied PowerShell script. Enterprise script policy is respected; sign/approve scripts using your supported process. No execution-policy bypass is included.

## One-time Sonar configuration
Set non-secret values in .sdd/settings.json. Preserve your actual build/test settings and integration branch:

```json
{
  "role": "DAB",
  "integrationBranch": "origin/develop",
  "buildCommand": "dotnet build YourSolution.sln",
  "testCommand": "dotnet test YourSolution.sln --no-build --logger trx --collect:\"XPlat Code Coverage\" --results-directory \"{results}\"",
  "coverageThreshold": 90,
  "localSonar": true,
  "requireServerSonar": true,
  "sonarUrl": "https://your-sonar-server.example/",
  "sonarProjectKey": "your-project-key",
  "sonarOrganization": null,
  "sonarScannerVersion": "10.4.1"
}
```

Set SONAR_TOKEN securely in the process environment used by the Visual Studio terminal; never save it in settings.json or source control. For SonarCloud also set sonarOrganization and the correct regional service URL. Ensure the project exists and the token can submit analysis and read its gate. Scanner branch analysis requires a server plan/edition supporting it. Private feeds and scanner/JRE/analyzer download destinations must be reachable with TLS verification intact. The scanner handles compatible JRE provisioning where supported.

The target test projects must already reference a compatible Coverlet collector; this release does not rewrite dependency declarations in business repositories. Final verification requests both Cobertura and OpenCover formats without modifying tracked runsettings. Existing custom runsettings remain in effect. A custom test runner needs explicit integration; this release's automatic server workflow is .NET-only, not Angular/TypeScript.

## Automatic sequence
After explicit scope approval, Copilot follows the complete plan, implements and tests, fixes within three rounds, and requests independent review through a supported host invocation tool. Final verification automatically installs the pinned SonarScanner in .sdd/tools/, submits the current build and coverage, waits for the exact task's analysis ID, and requires its quality gate to pass. Local analyzer feedback remains available on targeted runs.

The reviewer validates requirements and records `sdd review-seal` only after a genuine READY FOR PR review of final verified source. The seal protects evidence freshness; it is not an authenticated reviewer identity or a substitute for platform review policy.

The agent then runs `sdd finish`: final verification → sealed-review freshness → PR description text → Windows commit dialog. The dialog shows repository, branch, all proposed changed files, check summary and editable commit message. Select Commit Locally or Cancel. Closing/cancelling stages nothing. Commit is never auto-confirmed. No push, PR creation or merge is performed. A later commit needs fresh verification/review because HEAD changed.

Commands:
- `sdd verify --scope targeted`: fast build/test/coverage/local Sonar feedback.
- `sdd verify --scope final`: fresh server scan and gate by default.
- `sdd review-seal`: reviewer records current source/review hashes after final verification.
- `sdd finish`: final verification and delivery dialog.
- `sdd commit-dialog`: reopen the dialog while evidence is current; avoids another scan.

The dialog commits all listed changed files. It does not let you silently exclude dependencies. Handle unrelated changes and pre-existing staging in Visual Studio before delivery. Git hooks remain enabled; a hook failure leaves staged files intact for your inspection. Do not modify files/index concurrently during commit. After a successful local commit use Visual Studio to push, create a PR and merge manually.

## Practical automation boundary
The desktop dialog is a standalone WPF window launched by a terminal command, not a VSIX or an embedded Copilot popup. Copilot must accept/save proposed edits to disk before validation can see them. Visual Studio versions without an independent-agent invocation API still require a reviewer switch; the agent must report that host limitation rather than self-approve. Business ambiguity, initial approval, missing access and enterprise script restrictions cannot be solved by silently inventing answers.

This release implements deterministic automation and stronger agent instructions. It is not a guarantee of 100% correct requirements or unattended IDE delivery. See docs/IMPLEMENTATION-PLAN.md and docs/TEST-REPORT.md for completed work and the remaining Windows/server pilot.

## Build and test
From engine/:
```
dotnet build Akzo.Sdd.sln -c Release
dotnet test Akzo.Sdd.sln -c Release --settings coverlet.runsettings --collect:"XPlat Code Coverage" --logger trx
dotnet pack src/Akzo.Sdd.Cli -c Release -o ../tool
```
Use the existing isolated checkout; no additional Git worktree is required. SDK/tool/dependency download and private feed access must be available. Never disable package signatures, TLS or analyzer checks to unblock setup.

## v3.1.1 review regressions
The four reported PR 55783 findings are explicitly requested by the local gate and covered by real-build regression evidence: CS0169, CS8618, S1144 and S3242. Implementation/review instructions now cover unused dependency cleanup, true constructor initialization, weakest sufficient collection contracts and latest-iteration evidence. CS8618 still requires nullable analysis to be enabled by the actual target project. See the HTML guide and docs/TEST-REPORT.md. No live PR business-source changes are included.
